/*! \file geometry.hpp
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 * 
 *  \class object3D
 *  Used for storing several different geometrical shapes only for basic test purposes.
 *  Currently, spherical, cubic and toroidal objects can be created.
 */

#ifndef GEOMETRY_HPP_
#define GEOMETRY_HPP_

class object3D {
public:
	object3D(int);
	~object3D();
	bool *** grid;

	int sphere(int, int);
	int double_sphere(int, int);
	int cube(int, int);
	int torus(int, int);

	void print_slice(int);
	void write_uhbd_file_ascii(int, int, int);
	void write_uhbd_file_binary(int, int, int);
	void write_dt_file_binary(int, float ***, int, int, int);

	int dimension;

protected:
	int radius; //! number of grid points that define the radius of a sphere
	int separation_distance; //! distance between two separate spherical objects in one grid.
	int side; //! number of grid points for each side of a cube
	int rTorus; //! torus thickness
	int rShape; //! maximum length of a torus (in grid points)

	bool *** Allocate();
	void Deallocate(bool ***);
};

#endif /* GEOMETRY_HPP_ */
