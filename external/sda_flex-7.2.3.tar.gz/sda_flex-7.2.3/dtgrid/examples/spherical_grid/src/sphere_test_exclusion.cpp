/*! \file sphere_test_exclusion.cpp
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 * 
 * Description : This test program creates sphere objects of various different
 *               sizes, compress them into a DT-Grid structure and compares
 *               the execution times of a simple operation on these DT-Grids.
 *               
 *               Similar to sphere_test, sphere_test_exclusion evaluates the performance
 *               of DT-Grid for excluded volume type grids.
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <cstdlib>
#include <ctime>
#include <vector>
#include "../../../datastructures/DTGrid3Dex.hpp"
#include "./geometry.hpp"
#include <limits>

typedef std::numeric_limits< long double > ldbl;

// to store the grid information and execution statistics for each grid size tested
struct stats{
    int dimension; // grid dimension (cubic) in number of grid points
    long file_size; // size of the UHBD/DT-Grid files required to store the grids in disk
    float exec_time1; // execution time using direct random access operations
    float exec_time2; // execution time using random cell access operations
};

// Here we test only size of binary files!
// ASCII format files are typically much larger
long size_file(char * file_n){
    std::ifstream is (file_n, std::ifstream::binary);
    long length;

    if (is) {
        // get file length
        is.seekg (0, is.end);
        length = is.tellg();
        is.seekg (0, is.beg);
        is.close();
    }
    return length;
}


int main(int argc, char* argv[]) {
    //
    // check the number of arguments provided by the user
    if (argc < 4) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << " Number_of_access_operations Seed_number grid_edge_length" << std::endl;
        std::cerr << "Note:  " << "If the input for the seed number is 0 or smaller, then the clock time will be used!" << std::endl;
        return 1;
    } 

    unsigned int num_acc_op;
    int seed, dim;

    istringstream ss(argv[1]);
    if (!(ss >> num_acc_op))
        std::cerr << "Invalid integer value for: number of access operations to be performed" << argv[1] << std::endl;

    istringstream ss2(argv[2]);
    if (!(ss2 >> seed))
        std::cerr << "Invalid integer value for: a seed for random number generator" << argv[2] << std::endl;
    
    // The dimension provided by the user!
    istringstream ss3(argv[3]);
    if (!(ss3 >> dim))
        std::cerr << "Invalid integer value for: number of grid points that makes a grid edge" << argv[3] << std::endl;
    
    // provide the seed the random number generator
    if (seed > 0)
        srand ( seed );
    else 
        srand ( static_cast <unsigned> (time(NULL)) );
    
    int rn1, rn2, rn3;
    const float  PI_F=3.14159265358979f;
    float co, var;
    long double sum1=0.0, sum2=0.0, sum3=0.0;
    double time_val1, time_val2;
    
    //usefull when multiple grid size tests performed at once.
    stats stats_local;
    std::vector<stats> stats_regular;
    std::vector<stats> stats_dt;

    // check the time and store in order to obtain the execution time.
    clock_t init, final;

    // grid files will be created and deleted automatically during the program run. 
    // therefore, please do not delete these files during program execution
    char DTFILE [] = "object.dtgrd";
    char uhbdFILE [] = "object.grd";
    char out_file_n [] = "time_excl.txt";

    FILE* output_file;
    output_file = fopen(out_file_n,"a");

    //create a sphere object. can be change to a torus or a cube from the object3D class.
    object3D *sphere;
    bool * flist;
    float *** rand_mt = 0;

    // initialize the unit cell that will store the fetched grid cells
    flist = new bool [8];
    for (int i= 0; i<8; i++)
    	flist[i] = false;

    std::cout << "Dimension: " << dim << std::endl;

    //Allocate memory for the matrix and create the shape
    sphere = new object3D(dim);
    sphere->sphere(dim, 0);
    sphere->write_dt_file_binary(0, rand_mt, dim, dim, dim);
    delete sphere;

    //create a dt-grid object
    //Initialize the dtgrid object
    DTGrid3Dex * dtGrid;
    dtGrid = new DTGrid3Dex (DTFILE);

    //accessxyz function test
    // zero the sums at the begining
    sum1 = 0.0;
    sum2 = 0.0;

    //start the clock for random access to grid points using DT-Grid
    init=clock();
    //start the random access operations
    for (unsigned int i = 0;i<num_acc_op;i++){
    	rn1 = rand() % (dim-1); 
    	rn2 = rand() % (dim-1); 
    	rn3 = rand() % (dim-1); 
    	sum1 += static_cast <long double> (dtGrid->accessxyz(rn3,rn2,rn1));
    }
    //stop the clock
    final=clock()-init;
    time_val1 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

    //start the clock for random access to grid cells using DT-Grid
	init=clock();
	//perform the random cell access operations
	for (unsigned int i = 0;i<num_acc_op;i++){
		rn1 = rand() % (dim-2); 
		rn2 = rand() % (dim-2); 
		rn3 = rand() % (dim-2); 

		for (int ifl= 0; ifl<8; ifl++)
			flist[ifl] = false;

		dtGrid->getCell2(flist,rn3,rn2,rn1);
		sum2 += static_cast <long double> (flist[0]);
		sum2 += static_cast <long double> (flist[1]);
		sum2 += static_cast <long double> (flist[2]);
		sum2 += static_cast <long double> (flist[3]);
		sum2 += static_cast <long double> (flist[4]);
		sum2 += static_cast <long double> (flist[5]);
		sum2 += static_cast <long double> (flist[6]);
		sum2 += static_cast <long double> (flist[7]);
	}

	//stop the clock
	final=clock()-init;
	time_val2 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

	// You don't need this value.
	printf("Sum of the values: %15Lf %15Lf\n", sum1, sum2);

	//store the stats for DT-Grid
	stats_local.dimension = dim;
	stats_local.file_size = size_file(DTFILE);
	stats_local.exec_time1 = time_val1;
	stats_local.exec_time2 = time_val2;
	stats_dt.push_back(stats_local);

	//delete the object and remove the grid file from storage
	delete dtGrid;
	remove( DTFILE );

	sphere = new object3D(dim);
	sphere->sphere(dim, 0);

	// zero the sums again
	sum1 = 0.0;
	sum2 = 0.0;

	//start the clock for random access to grid points using a regular Cartesian grid
	init=clock();
	//perform the random access operations
	for (unsigned int i = 0;i<num_acc_op;i++){
		rn1 = rand() % (dim-1); 
		rn2 = rand() % (dim-1); 
		rn3 = rand() % (dim-1); 
		sum1 += static_cast <long double> (sphere->grid[rn3][rn2][rn1]);
	}
	// stop the clock
	final=clock()-init;
	time_val1 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

	//start the clock for random access to grid 8 points that define a cell using regular Cartesian grid
	init=clock();
	//perform the random cell access operations
	for (unsigned int i = 0;i<num_acc_op;i++){
		rn3 = rand() % (dim-2); 
		rn2 = rand() % (dim-2); 
		rn1 = rand() % (dim-2); 
		sum2 += static_cast <long double> (sphere->grid[rn1][rn2][rn3]);
		sum2 += static_cast <long double> (sphere->grid[rn1][rn2][rn3+1]);
		sum2 += static_cast <long double> (sphere->grid[rn1][rn2+1][rn3]);
		sum2 += static_cast <long double> (sphere->grid[rn1+1][rn2][rn3]);
		sum2 += static_cast <long double> (sphere->grid[rn1][rn2+1][rn3+1]);
		sum2 += static_cast <long double> (sphere->grid[rn1+1][rn2+1][rn3]);
		sum2 += static_cast <long double> (sphere->grid[rn1+1][rn2][rn3+1]);
		sum2 += static_cast <long double> (sphere->grid[rn1+1][rn2+1][rn3+1]);
	}
	//stop the clock
	final=clock()-init;
	time_val2 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

	sphere->write_uhbd_file_binary(dim, dim, dim);
	printf("Sum of the values: %15Lf %15Lf\n", sum1, sum2);

	//store the statistics for the regular grid
	stats_local.dimension = dim;
	stats_local.file_size = size_file(uhbdFILE);
	stats_local.exec_time1 = time_val1;
	stats_local.exec_time2 = time_val2;
	stats_regular.push_back(stats_local);

	//delete the sphere object and remove the UHBD file
	delete sphere;
	remove( uhbdFILE );

	//Write the statistics to the output file
    //fprintf(output_file, "# Dime Size_dt Size_reg Rand_acc_dt Rand_acc_reg Rand_vox_dt Rand_vox_reg\n");
    for (int i = 0;i<stats_regular.size();i++){
        fprintf(output_file, "%4d %12ld %12ld %12f %12f %12f %12f\n",stats_regular[i].dimension, \
        stats_dt[i].file_size, stats_regular[i].file_size, stats_dt[i].exec_time1, \
        stats_regular[i].exec_time1, stats_dt[i].exec_time2, stats_regular[i].exec_time2);
        //stats_regular[i].dimension;
    }

    fclose(output_file);
    return 0;
}
