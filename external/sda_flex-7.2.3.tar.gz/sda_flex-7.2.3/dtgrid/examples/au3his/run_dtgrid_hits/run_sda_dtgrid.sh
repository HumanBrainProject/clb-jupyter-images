
BIN=../../../bin
AUXI=../../../auxi
GNUPLOT_EXE=gnuplot

#==============================================
export BIN
export AUXI
export UHBD2DTGRID_EXE
export GNUPLOT_EXE
#==============================================

#### convert the LJ files from regular grid format to dt-grid
#### and store them in *.dtgrd files
#### Note that the regular grids are saved using UHBD format!
$BIN/UHBD2dtgrid -g ../data_grid/p2lj1.grd -p ../data_grid/p2.pqr -f binary -o ../data_grid/p2lj1.dtgrd -s 10.0 -pr 0.0
$BIN/UHBD2dtgrid -g ../data_grid/p2lj2.grd -p ../data_grid/p2.pqr -f binary -o ../data_grid/p2lj2.dtgrd -s 10.0 -pr 0.0

#### run the pmf simulation
$BIN/sda_flex sda_prometcs.in > sda.out
$GNUPLOT_EXE make_plot.gp
