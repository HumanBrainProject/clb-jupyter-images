set -x
SDA_DIR=../../../
BIN=${SDA_DIR}/bin
AUXI=${SDA_DIR}/auxi
AUXILJ=${SDA_DIR}/auxi/LJ-GRID-preparation
#UHBD_EXE=uhbd
APBS_EXE=apbs

#==============================================
export BIN
export AUXI
export APBS_EXE
export UHBD_EXE
export AUXILJ
#==============================================

#==============================================
# remove hydrgoens in the structure. used for ed and ecm calc.
${AUXILJ}/no_H.py p2.pqr p2_noh.pdb
#==============================================

#==============================================
## Electrostatic potential calculation
# Use p2.pqr and qtable as input when using UHBD:
##
# $UHBD_EXE < uhbd.in > uhbd.ou
##
#### APBS calculation, use p2.pqr as input:
$APBS_EXE apbs.in > apbs2.ou; cat io.mc >> apbs2.ou;
if [ -f tmp-PE0.grd ]
then
    mv tmp-PE0.grd ep2.apbs.grd
else
    if [ -f tmp.grd ]
    then
        mv tmp.grd ep2.apbs.grd
    else
        echo "Electrostatic grid was not generated - check APBS output !"
    fi
fi
# Convert the grid
${BIN}/convert_grid ep2.apbs.grd -scale 0.6 -convert > convert_grid.ou
mv ep2.apbs.bin.grd  ep2.grd
#==============================================

#==============================================
## Make ECM for protein 2, version in one run, no need of ecm.in
##
${BIN}/ecm_all -fp p2_noh.pdb -fg ep2.grd -is 10. -rc 1.0 -fe p2.echa > ecm2.ou
#==============================================

#==============================================
## Make Lennard-Jones grid for protein 2
##
cp p2.pqr p2.pdb
#why do we change atom types?
${AUXILJ}/change_atomNames.sh
mv p2-new.pdb p2.pdb
# you have to remove this file if exists
rm  -f ProbeFile.txt
ulimit -s unlimited 
python ${AUXILJ}/prepLJgrids.py prepLJgrids_input > prepLJgrids.ou
#==============================================

#==============================================
## Make electrostatic desolvation (ed) and Lennard-Jones (lj) grids for protein 2
##
${BIN}/make_edhdlj_grid -ed ed2.in


#### Make electrostatic desolvation (ed), nonpolar (hd) and Lennard-Jones (lj) grids for protein 1

# Solutes never go below the surface, shifting the grid allows to save space
${BIN}/make_edhdlj_grid -ed ed1.in -shift_center 0. 0. 21. > edhdlj1.ou
${BIN}/make_edhdlj_grid -hd hd1.in -shift_center 0. 0. 14. >> edhdlj1.ou
#==============================================

#==============================================
# clean tmp files
#
rm -f p2.access
rm -f gold3layersflex.access
rm -f fort.44
rm -f ProbeFile.txt
#rm -f logout

## move grids and ecm in data_grid
mv ed?.grd ../data_grid
mv ep2.grd ../data_grid
mv hd1.grd ../data_grid
mv p*.echa ../data_grid
mv apLJp2-001.grd ../data_grid/p2lj1.grd
mv apLJp2-002.grd ../data_grid/p2lj2.grd

# copy the original files into data_grid
cp p2.pqr ../data_grid/p2.pqr
cp gold3layersflex.pdb ../data_grid
#==============================================
