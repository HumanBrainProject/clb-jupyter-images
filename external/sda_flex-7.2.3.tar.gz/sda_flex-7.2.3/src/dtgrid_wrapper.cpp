/*! \file dtgrid_wrapper.cpp
 * \brief Wrapper for linking C++ and Fortran functions
 *
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 *
 *  C++ wrapper for DT-GRID functions to call from SDA code
 *
 */

#include <stdlib.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <typeinfo>
#include "./tools/DT-Grid/datastructures/DTGrid3D.hpp"
#include "./tools/DT-Grid/datastructures/DTGrid3Dex.hpp"

enum grid_type_enum {
	double_type = 1,
	logical_type = 2 }; // Any other types ???

extern "C" {
   int associate_grid_(intptr_t **grdptr, char * file_name, double * scfct_f, int *grid_type );
   int deallocate_grid_(intptr_t * grdptr, int *grid_type );
   int access_(intptr_t * grdptr,int *i, int *j, int *k, double *value);
   int access_voxel_(intptr_t * grdptr,int *i, int *j, int *k, double *voxel);
   int access_exclusion_(intptr_t * grdptr,int *i, int *j, int *k, bool *b_value);
   int access_voxel_exclusion_(intptr_t * grdptr,int *i, int *j, int *k, bool *b_voxel);
}

//! Associate the pointer received from SDA code to a DT-Grid pointer
/*!
 * This function is called from mod_grid.f90 and associates a DT-Grid object (created and allocated inside) 
 * with the pointer address provided by the fortran module.
 * 
 * \param grdptr the address that stores the pointer of a DT-Grid object and will be known by the fortran modules
 * \param file_name the name of the UHBD file input to SDA.
 * \param scfct_f the scaling factor from the SDA code.
 * \param grid_type type of grid: excluded-volume or data. 1 for data, 2 for excluded-volume (or other logical type) grids
 */
int associate_grid_( intptr_t ** grdptr, char * file_name, double * scfct_f, int *grid_type){
	file_name[127] = '\0';
	
    char filename2[128];
    int j=0;
    for (int i = 0; i<128; i++){
        if (file_name[i] != ' ')
            filename2[j++] = file_name[i];
    }
	ifstream input (filename2);
	
    //std::cout << "!!!" << file_name << "!!!" << std::endl;
    
	if (!input.is_open()){
	    std::cout << "ERROR: Unable to open the grid file!" << std::endl;
	    exit(0);
	}
	
	grid_type_enum grid_type_name;

	grid_type_name = (grid_type_enum) (*grid_type);
    double scfct_c = *scfct_f;
	
	if (grid_type_name == double_type){
		DTGrid3D <double, int> * dt_Grid;
		dt_Grid = new DTGrid3D <double, int> (filename2, scfct_c, 0.0);
		*grdptr = reinterpret_cast<intptr_t *> (dt_Grid);		
	} 
	else if (grid_type_name == logical_type){
		DTGrid3Dex * dt_Grid;
		dt_Grid = new DTGrid3Dex (filename2);
		*grdptr = reinterpret_cast<intptr_t *> (dt_Grid);
	}
	else{
		std::cout << "ERROR!!! UNDEFINED DATA TYPE!!!" << std::endl;
	}

	return 0;
}

//! Deallocator for the DT-Grid object
/*!
 * This function is called from mod_grid.f90 and will deallocate the associated DT-Grid object accessible with the pointer given.
 * \param grdptr the address that stores the pointer of a DT-Grid object
 * \param grid_type type of grid: excluded-volume or data
 */
int deallocate_grid_(intptr_t * grdptr, int *grid_type){

	grid_type_enum grid_type_name;
	grid_type_name = (grid_type_enum)(*grid_type);

	if (grid_type_name == double_type){
		DTGrid3D <double,int> * temp = reinterpret_cast<DTGrid3D <double,int> *> (*grdptr);
		delete temp;
	}
	else if (grid_type_name == logical_type){
		DTGrid3Dex * temp = reinterpret_cast<DTGrid3Dex *> (*grdptr);
		delete temp;
	}
	else{
		std::cout << "WARNING: NO GRID TO BE DELETED!" << std::endl;
	}

	return 0;
}

//! Random access to grid points stored in a data grid
/*!
 * 
 * \param grdptr the address that stores the pointer of a DT-Grid object
 * \param i grid point coordinate 'i'
 * \param j grid point coordinate 'j'
 * \param k grid point coordinate 'k'
 * \param value pointer to copy the grid point value into
 * 
 * \warning In fortran, array indexing starts from 1, in C/C++ from 0!
 */
int access_(intptr_t * grdptr,int *i, int *j, int *k, double *value){
	DTGrid3D <double,int> * temp = reinterpret_cast<DTGrid3D <double,int> *> (*grdptr);
	*value = temp->accessxyz((*i)-1,(*j)-1,(*k)-1);
	return 0;
}

//! Random access to grid points stored in an excluded-volume grid
/*!
 * 
 * \param grdptr the address that stores the pointer of a DT-Grid object
 * \param i grid point coordinate 'i'
 * \param j grid point coordinate 'j'
 * \param k grid point coordinate 'k'
 * \param value pointer to copy the grid point value into
 * 
 * \warning In fortran, array indexing starts from 1, in C/C++ from 0!
 */
int access_voxel_(intptr_t * grdptr,int *i, int *j, int *k, double *voxel){
	DTGrid3D <double,int> * temp = reinterpret_cast<DTGrid3D <double,int> *> (*grdptr);
	voxel = temp->getCell2(voxel, (*i)-1,(*j)-1,(*k)-1);
	return 0;
}

//! Random access to grid cells stored in a data grid
/*!
 * 
 * \param grdptr the address that stores the pointer of a DT-Grid object
 * \param i grid cell origin coordinate 'i'
 * \param j grid cell origin coordinate 'j'
 * \param k grid cell origin coordinate 'k'
 * \param b_voxel pointer to a unit cell to copy the grid cell values into
 * 
 * \warning In fortran, array indexing starts from 1, in C/C++ from 0!
 */
int access_exclusion_(intptr_t * grdptr,int *i, int *j, int *k, bool *b_value){
	DTGrid3Dex * temp = reinterpret_cast<DTGrid3Dex *> (*grdptr);
	*b_value = temp->accessxyz((*i)-1,(*j)-1,(*k)-1);
	return 0;
}

//! Random access to grid cells stored in an excluded-volume grid
/*!
 * 
 * \param grdptr the address that stores the pointer of a DT-Grid object
 * \param i grid cell origin coordinate 'i'
 * \param j grid cell origin coordinate 'j'
 * \param k grid cell origin coordinate 'k'
 * \param b_voxel pointer to a unit cell to copy the grid cell values into
 * 
 * \warning In fortran, array indexing starts from 1, in C/C++ from 0!
 */
int access_voxel_exclusion_(intptr_t * grdptr,int *i, int *j, int *k, bool *b_voxel){
	DTGrid3Dex * temp = reinterpret_cast<DTGrid3Dex *> (*grdptr);
	b_voxel = temp->getCell2(b_voxel, (*i)-1,(*j)-1,(*k)-1);
	return 0;
}
