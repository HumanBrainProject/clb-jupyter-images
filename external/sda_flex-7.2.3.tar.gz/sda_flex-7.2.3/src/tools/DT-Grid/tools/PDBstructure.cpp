/*! \file PDBstructure.cpp
 *  \brief Group functions to read-write PDB files and describe the molecular structures inside
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 */

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#include <vector>

#include "PDBstructure.hpp"
//using namespace std;

//! Atom destructor
Atom::~Atom() {;};

//! Residue destructor
Residue::~Residue()
{
	delete[] Atoms;
}

//! PDB constructor
PDB::PDB()
{
	pqr = false;
}

//! PDB constructor (overload for pqr)
PDB::PDB(bool pqr_value)
{
	pqr = pqr_value;
}

//! PDB destructor.
PDB::~PDB()
{
	delete[] Residues;
}

//! Read the pdb file and extract the information.
/*!
 * \param pdbfile file name
 */
void PDB::Read_PDB_File(std::ifstream &pdbfile){

	// initialize the temporary integers to zero.
	int total_atom_counter = 0; 
	int residue_atom_counter = 0 ;
	int residue_counter = 0 ;
	int numAtoms = 0;
	int numDummyAtoms = 0;

	int residue_number, residue_number_prev;

	std::string line, ATOM_string, DUMMY_string;
	std::string coordinateX, coordinateY, coordinateZ;
	std::string atom_radii, residueN, residueT;
	std::string ATOMname = "ATOM";

	// Following is a new definition for the dummy atoms of distinct properties.
	std::string DUMMYname = "DUMMY";

	std::vector<std::string> List_Atom_Type;
	std::vector<std::string> List_Residue_Type;
	std::vector<int> List_Atom_Numbers;
	std::vector<float> List_X_Coords, dummy_List_X_Coords;
	std::vector<float> List_Y_Coords, dummy_List_Y_Coords;
	std::vector<float> List_Z_Coords, dummy_List_Z_Coords;
	std::vector<float> List_VdW_Radii, dummy_List_VdW_Radii;

	// read the pdb file
	if (pdbfile){
		while (getline(pdbfile, line)){
			//++numLines;
			ATOM_string = line.substr(0, 4);
			DUMMY_string = line.substr(0, 5);

			if (ATOM_string.compare(ATOMname) == 0){

				residueN    = line.substr(22,4);
				coordinateX = line.substr(30,8);
				coordinateY = line.substr(38,8);
				coordinateZ = line.substr(46,8);

				residue_number = atoi(residueN.c_str());
				List_X_Coords.push_back(atof(coordinateX.c_str()));
				List_Y_Coords.push_back(atof(coordinateY.c_str()));
				List_Z_Coords.push_back(atof(coordinateZ.c_str()));

				/* 
				 * if a pqr file is given, than extract the vdw information from the file
				 * instead of assigning one from the default Atom::VdW_Radius function.
				 */ 
				if (pqr == true){
					atom_radii  = line.substr(62,8);
					List_VdW_Radii.push_back(atof(atom_radii.c_str()));
				}

				if (numAtoms == 0){
					//++residue_counter;
					residue_number_prev = residue_number;
				}

				if (residue_number != residue_number_prev){
					List_Atom_Numbers.push_back(residue_atom_counter);
					List_Residue_Type.push_back(residueT);
					total_atom_counter += residue_atom_counter ;
					residue_atom_counter = 0 ;
					++residue_counter;
					residue_number_prev = residue_number;
				}

				residueT = line.substr(17, 3);
				List_Atom_Type.push_back(line.substr(13, 1));
				++residue_atom_counter;
				++numAtoms;
			}
			else if (DUMMY_string.compare(DUMMYname) == 0){

				coordinateX = line.substr(30,8);
				coordinateY = line.substr(38,8);
				coordinateZ = line.substr(46,8);
				atom_radii  = line.substr(62,8);

				// Maximum dummy radius allowed currently is 1000 nm
				if ((atof(atom_radii.c_str()) > 0.0) and (atof(atom_radii.c_str()) < 1000.0)){

					std::cout << "WARNING: Found the following DUMMY atom in the input file!" << std::endl;
					std::cout << line << std::endl << std::endl;

					dummy_List_X_Coords.push_back(atof(coordinateX.c_str()));
					dummy_List_Y_Coords.push_back(atof(coordinateY.c_str()));
					dummy_List_Z_Coords.push_back(atof(coordinateZ.c_str()));
					dummy_List_VdW_Radii.push_back(atof(atom_radii.c_str()));

					numDummyAtoms += 1;
				}
			}
		}
		//The last residue
		List_Atom_Numbers.push_back(residue_atom_counter);
		List_Residue_Type.push_back(residueT);
		total_atom_counter += residue_atom_counter ;
		++residue_counter;

		if (numAtoms != total_atom_counter) {
			std::cout << " ERROR: The number of atoms in the pdb file does not match: ";
			std::cout << numAtoms << " " << total_atom_counter << std::endl;
			exit(0);
		}
		else {
			std::cout << "Total number of atoms in the PDB file: " << total_atom_counter << std::endl;
			std::cout << "Total number of residues in the PDB file: " << residue_counter << std::endl;
		}

		Number_of_Atoms = total_atom_counter;
		Number_of_Residues = residue_counter;

		// create a Residue instance for each residue in the structure.
		Residues = new Residue [residue_counter];

		int atom_c = 0;
		for (int i = 0; i < residue_counter; i++){
			Residues[i].Number_of_Atoms = List_Atom_Numbers.at(i);
			Residues[i].Residue_Type = List_Residue_Type.at(i);
			// create a new atom object for each unique atom in the residue
			Residues[i].Atoms = new Atom [Residues[i].Number_of_Atoms];
			//std::cout << List_Residue_Type.at(i) << " " << List_Atom_Numbers.at(i) << std::endl;
			for (int j = 0; j < Residues[i].Number_of_Atoms; j++){
				Residues[i].Atoms[j].Atom_Number = atom_c + 1;
				Residues[i].Atoms[j].Atom_Type = List_Atom_Type.at(atom_c);
				Residues[i].Atoms[j].Coord.X = List_X_Coords.at(atom_c);
				Residues[i].Atoms[j].Coord.Y = List_Y_Coords.at(atom_c);
				Residues[i].Atoms[j].Coord.Z = List_Z_Coords.at(atom_c);
				if (pqr == true){
					Residues[i].Atoms[j].radii = List_VdW_Radii.at(atom_c);
				}
				else{
					Residues[i].Atoms[j].radii = Residues[i].Atoms[j].VdW_Radius();
				}
				++atom_c;
			}
		}
		Center_of_Geometry(); // measure the center of geometry of the structure

		// Dummy atoms
		atom_c = 0;
		Dummy.Number_of_Atoms = numDummyAtoms;
		Dummy.Atoms = new Atom [Dummy.Number_of_Atoms];
		for (int j = 0; j < Dummy.Number_of_Atoms; j++){
			Dummy.Atoms[j].Atom_Number = atom_c + 1;
			Dummy.Atoms[j].Coord.X = dummy_List_X_Coords.at(atom_c);
			Dummy.Atoms[j].Coord.Y = dummy_List_Y_Coords.at(atom_c);
			Dummy.Atoms[j].Coord.Z = dummy_List_Z_Coords.at(atom_c);
			Dummy.Atoms[j].radii   = dummy_List_VdW_Radii.at(atom_c);
			++atom_c;
		}
	}
}

//! Measure center of geometry of the structure
/*! 
 * Find the center of geometry and store it in CoG .
 * 
 */
int PDB::Center_of_Geometry(){
	//Atom::Coordinates temp;
	float vdw_atom;
	vdw_atom = 0.0;
	max_vdw = 0.0;
	//max_dummy_rad = 0.0;
	
	CoG.X = 0.0;
	CoG.Y = 0.0;
	CoG.Z = 0.0;
	
	//int total_number_of_atoms = 0;
	// iterate over the residues and their atoms.
	for (int i = 0; i < Number_of_Residues; i++){
		//total_number_of_atoms += Residues[i].Number_of_Atoms;
		for (int j = 0; j < Residues[i].Number_of_Atoms; j++){
			CoG.X += Residues[i].Atoms[j].Coord.X;
			CoG.Y += Residues[i].Atoms[j].Coord.Y;
			CoG.Z += Residues[i].Atoms[j].Coord.Z;

			// find the maximum vdW radius in the structre.
			vdw_atom = Residues[i].Atoms[j].radii;
			if ( vdw_atom > max_vdw )
				max_vdw = vdw_atom;
		}
	}
	CoG.X /= (float) Number_of_Atoms;
	CoG.Y /= (float) Number_of_Atoms;
	CoG.Z /= (float) Number_of_Atoms;

	/*
	// for dummy atoms
	if (Dummy.Number_of_Atoms > 0){
		for (int j = 0; j < Dummy.Number_of_Atoms; j++){
			vdw_atom = Dummy.Atoms[j].radii;
			if ( vdw_atom > max_dummy_rad )
				max_dummy_rad = vdw_atom;
		}
	}
	*/
	return 0;
}

//! Measure residue center of geometry
/*! 
 * Find the center of geometry of a residue return it.
 * 
 */
Atom::Coordinates Residue::Center_of_Geometry(){
	Atom::Coordinates temp;
	temp.X = 0.0;
	temp.Y = 0.0;
	temp.Z = 0.0;
	for (int j = 0; j < Number_of_Atoms; j++)
	{
		temp.X += Atoms[j].Coord.X;
		temp.Y += Atoms[j].Coord.Y;
		temp.Z += Atoms[j].Coord.Z;
	}
	temp.X /= Number_of_Atoms;
	temp.Y /= Number_of_Atoms;
	temp.Z /= Number_of_Atoms;
	return temp;
}

//! Assign the vdW radius for a given atom
/*! 
 * \warning atom types and radii given below should be kept consistent with the rest of the SDA code!
 * 
 */
float Atom::VdW_Radius()
{
	float radius;
	if (Atom_Type.compare("H") == 0){
		radius = 1.20;
	}
	else if (Atom_Type.compare("C") == 0){
		radius = 1.90;
	}
	else if (Atom_Type.compare("N") == 0){
		radius = 1.625;
	}
	else if (Atom_Type.compare("O") == 0){
		radius = 1.48;
	}
	else if (Atom_Type.compare("P") == 0){
		radius = 1.90;
	}
	else if (Atom_Type.compare("S") == 0){
		radius = 1.85;
	}
	else if (Atom_Type.compare("F") == 0){
		radius = 0.64;
	}
	else if (Atom_Type.compare("Z") == 0){
		radius = 1.38;
	}
	else if (Atom_Type.compare("B") == 0){
		radius = 1.95;
	}
	else if (Atom_Type.compare("I") == 0){
		radius = 2.15;
	}
	else if (Atom_Type.compare("A") == 0){
		radius = 1.60; // for gold
	}
	else{
		radius = 1.90;
	}
	return radius;
}

// iterate over the members. not used.
/*Atom iterate::begin()
{
	iter = start;
}

iterate::iterate(PDB * THIS)
{
	iter = THIS->Residues[0].Atoms;//->Residues[0].Atoms[0];
	start = (Atom*) iter;
}

Atom iterate::operator++()
{
	((PDB*) iter)->Residues[0].Atoms;
	this->iter++;
}*/
