/*! \file PDBstructure.hpp
 *  \brief Group functions to read-write PDB files and describe the molecular structures inside (Header)
 * 
 * This file contains classes to store the necessary information for a given molecular structure (in pdb or pqr structure file formats)
 * Residues: id, type, etc..
 * Atoms: id, type, vdw radius, mass, etc.
 * Structure: center of geometry, number of residues and atoms, etc..
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 */

#ifndef PROTEINDATABANKSTRUCTURE_HPP_
#define PROTEINDATABANKSTRUCTURE_HPP_

#include <stdlib.h>
#include <sstream>
#include <string>

// it has to be mentioned before Atom class, since that calls PDB
class PDB; 

/*! \class Atom
 * 
 * This class store the parameters for each atom instance in a Residue 
 */
class Atom
{
	Atom() {;};
	~Atom();
	friend class PDB;
	friend class Residue;
	//friend class iterate;
	std::string Atom_Type; //! Atom_type: H, C, O, etc. 
	int Atom_Number; //! atom id number
public:
	//std::string Atom_Type;
	struct Coordinates
	{
		float X; //! x coordinate of the atom
		float Y; //! y coordinate of the atom
		float Z; //! z coordinate of the atom
	} Coord; // Store the (x,y,z) coordinates of the atoms

	// If given in pqr file, charge and radii will be assigned!
	float charge; //! atomic charge
	float radii; //! atomic radii
	//If not pqr, use the default parameters for vdW radii
    float VdW_Radius ();
	int Read_PDB_File();
};

/*! \class Atom
 * 
 * This class store the parameters for each residue instance in a PDB
 */
class Residue
{
	Residue() {;};
	~Residue();
	friend class PDB;
	//friend class iterate;
	
	std::string Residue_Type; //! type of residue: ala, ser, tyr, etc..
	
public:
    int Number_of_Atoms; //! total number of items of the residue
    Atom * Atoms; //! a pointer for a list of Atom instances
	int Read_PDB_File();
	Atom::Coordinates Center_of_Geometry();
};

/*! \class PDB
 * 
 * This class store the parameters for an input pdb file
 */
class PDB
{
private:
	bool pqr; //! flag for pdb or pqr file. 
	//friend class iterate;
public:
	//PDB() {;};
	PDB();
	PDB(bool);
	~PDB();

	int Number_of_Residues; //!the total number of residues in the structure
	int Number_of_Atoms; //! the toral number of atoms in the structure
	float max_vdw; //! the maximum van der Waals value of any atom in the input pdb file.
	Residue * Residues; 
	Residue Dummy;
	
public:
	void Read_PDB_File(std::ifstream&);
	int Center_of_Geometry();
	Atom::Coordinates CoG; //! store the coordinates of Center of Geometry.
	int Get_Coordinates();	
};

/*class iterate
{
private:
    Atom * start;
	Atom * finish;
	void * iter;
	Atom begin();
	Atom end();
	iterate (PDB * THIS);
	Atom operator++ ();
};*/

#endif /* PROTEINDATABANKSTRUCTURE_HPP_ */
