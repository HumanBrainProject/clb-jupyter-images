/*! \file dtgrid2UHBD.cpp
 *  \brief Main program to convert a DT-Grid file into a UHBD format file.
 * 
 * This program converts a DT-Grid file into a UHBD grid file.
 * It inputs and outputs both ascii and binary types.
 * Running the program with "-h" option in command line returns the options available for the user.
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 */

// Load the libraries
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#include <iomanip>
#include "../datastructures/DTGrid3Dex.hpp"
#include "../datastructures/DTGrid3D.hpp"

//! //WRITE THE UHBD FILE HEADER in ascii format
void write_uhbd_ascii_header(FILE * output_file, char * Title, float scale, float spacing, int one, int grdflag, \
		int dimi, int dimj, int dimk, float o_x, float o_y, float o_z, float dummy1, \
		float dummy2, float dummy3, float dummy4,float dummy5, float dummy6, float dummy7, \
		int idummy1, int idummy2, int idummy3, int idummy4, int idummy5){

	std::cout << "Writing the UHBD (ascii) to the output file ..." << std::endl;
	fprintf(output_file, "%72s\n", Title);
	fprintf(output_file, "%12.5E%12.5E%7d%7d%7d%7d%7d\n", scale, dummy1, 3, idummy1, idummy2, one, idummy3);
	fprintf(output_file, "%7d%7d%7d%12.5E%12.5E%12.5E%12.5E\n", dimi, dimj, dimk, spacing, o_x, o_y, o_z);
	fprintf(output_file, "%12.5E%12.5E%12.5E%12.5E\n", dummy2, dummy3, dummy4, dummy5);
	fprintf(output_file, "%12.5E%12.5E%7d%7d\n", dummy6, dummy7, idummy4, idummy5);
}

//! //WRITE THE UHBD FILE HEADER in binary format
void write_uhbd_binary_header(FILE * output_file, char * Title, float scale, float spacing, int one, int grdflag, \
		int dimi, int dimj, int dimk, float o_x, float o_y, float o_z, float dummy1, \
		float dummy2, float dummy3, float dummy4,float dummy5, float dummy6, float dummy7, \
		int idummy1, int idummy2, int idummy3, int idummy4, int idummy5){

	int binary_uhbd_type = 4;
	int binary_file_vmd_flag = 160;
	std::cout << "Writing the UHBD (binary) to the output file ..." << std::endl;
	fwrite(&binary_file_vmd_flag, sizeof(int),1,output_file);
	fwrite(Title, sizeof(char), 72, output_file);
	fwrite(&scale, sizeof(float),1,output_file);
	fwrite(&dummy1, sizeof(float),1,output_file);
	fwrite(&binary_uhbd_type, sizeof(int),1,output_file);
	fwrite(&idummy1, sizeof(int),1,output_file);
	fwrite(&idummy2, sizeof(int),1,output_file);
	fwrite(&one, sizeof(int),1,output_file);
	fwrite(&idummy3, sizeof(int),1,output_file);
	fwrite(&dimi, sizeof(int),1,output_file);
	fwrite(&dimj, sizeof(int),1,output_file);
	fwrite(&dimk, sizeof(int),1,output_file);
	fwrite(&spacing, sizeof(float),1,output_file);
	fwrite(&o_x, sizeof(float),1,output_file);
	fwrite(&o_y, sizeof(float),1,output_file);
	fwrite(&o_z, sizeof(float),1,output_file);
	fwrite(&dummy2, sizeof(float),1,output_file);
	fwrite(&dummy3, sizeof(float),1,output_file);
	fwrite(&dummy4, sizeof(float),1,output_file);
	fwrite(&dummy5, sizeof(float),1,output_file);
	fwrite(&dummy6, sizeof(float),1,output_file);
	fwrite(&dummy7, sizeof(float),1,output_file);
	fwrite(&idummy4, sizeof(int),1,output_file);
	fwrite(&idummy5, sizeof(int),1,output_file);
}

/*void print_slice_grid(DTGrid3D <float,int> * dtGrid, int k){
	std::string slice_n, out_name;
	slice_n = static_cast<std::ostringstream*>( &(std::ostringstream() << k) )->str();
	out_name = "exclusion" + slice_n + "slice_dt.txt";

	std::ofstream excl_slice;
	excl_slice.open (out_name.c_str(), std::ios::out);

	for (int k=0; k < dtGrid->uhbd.dim.k ; k++){
		std::cout << "------------    " << k << std::endl;
		for (int i=0; i< dtGrid->uhbd.dim.i; i++){
			for (int j=0; j< dtGrid->uhbd.dim.j; j++){
				if (((bool)dtGrid->accessxyz(i,j,k)) == true )
					excl_slice << "*";
				else
					excl_slice << " ";
			}
			excl_slice << "\n";
		}
	}
	excl_slice.close();
}*/

//! help menu function
void help_menu(void)
{
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "                     DT-GRID TO UHBD FILE CONVERTOR                        " << std::endl;
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "Usage:" << std::endl;
	std::cout << "./dtgrid2UHBD -g 'dtgrid_file' -f 'File_type'" << std::endl;
	std::cout << std::endl;
	std::cout << "Option\t Opt?\t Description" << std::endl;
	std::cout << "-------  ------  ------------------------------------------------------------------------" << std::endl;
	std::cout << "-g\t No\t The DT-Grid file name to be converted into UHBD" << std::endl;
	std::cout << "-f\t No\t The output file type" << std::endl;
	std::cout << "  \t \t There are two options: Binary and ASCII" << std::endl;
	std::cout << "  \t \t You can save your DT-Grid using the format you want" << std::endl;
	std::cout << "-o\t Yes\t The name of the outputting *.grd file name" << std::endl;
	std::cout << "  \t \t The grid file will be named as 'dtgrid2.uhbd' unless this option is used" << std::endl;
	std::cout << "-v\t Yes\t The number used for omitted values during the conversion from UHBD to DT-Grid" << std::endl;
	std::cout << "  \t \t A default value of 0.0 will be used unless this option is used" << std::endl;
	std::cout << "-excl\t Yes\t Input DT-Grid is of type exclusion" << std::endl;
	std::cout << "  \t \t Grid is assumed to be a data grid, if this option is not used!" << std::endl;
	std::cout << "-h\t \t Displays the usage information and terminates the execution!" << std::endl;
	std::cout << std::endl;
}

//! main program call
int main(int argc, char *argv[])
{
	bool exclusion = false; // parameter for grid type. excluded or data?
	char *DTFILE = NULL; // file name input
	char *FILETYPE = NULL; // file type: binary or ascii

	char output_file_name [] = "dtgrid2.uhbd"; //Default output name
	char *  OUTPUT ;
	OUTPUT = output_file_name;

	float omitted_value = 0.0; //Default value for the omitted grid points

	// Interate over the command line arguments
	for (int c = 1; c < argc; c++) 
	{
		if (strcmp(argv[c], "-h") == 0)
		{
			help_menu();
			return 0;
		}
		if (strcmp(argv[c], "--help") == 0)
		{
			help_menu();
			return 0;
		}
		if (strcmp(argv[c], "-g") == 0)
		{
			DTFILE = argv[c+1];
		}
		if (strcmp(argv[c], "-excl") == 0)
		{
			exclusion = true;
		}
		if (strcmp(argv[c], "-f") == 0)
		{
			FILETYPE = argv[c+1];
			if (strcmp(FILETYPE, "ascii") == 0 or strcmp(FILETYPE, "ASCII") == 0 or \
					strcmp(FILETYPE, "Ascii") == 0 or strcmp(FILETYPE, "binary") == 0 or \
					strcmp(FILETYPE, "BINARY") == 0 or strcmp(FILETYPE, "Binary") == 0)
			{
				continue;
			}
			else
			{
				std::cout << "The file type '" << FILETYPE << "' is not supported!" << std::endl;
				std::cout << "Please check your input parameters" << std::endl;
				std::cout << "Try -h option to get the usage information" << std::endl;
				std::cout << "Exiting..." << std::endl;
				return 0;
			}
		}
		//Optional parameters
		if (strcmp(argv[c], "-o") == 0)
		{
			OUTPUT = argv[c+1];
		}
		if (strcmp(argv[c], "-v") == 0)
		{
			omitted_value = atof(argv[c+1]);
		}
	}

	if (DTFILE == NULL){
		std::cout << "Please input DT-Grid file name!" << std::endl;
		std::cout << "Try -h option to get the usage information" << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
	if (FILETYPE == NULL){
		std::cout << "Please input UHBD file type!" << std::endl;
		std::cout << "Try -h option to get the usage information" << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
	//Check if the output file already exists?
	std::ifstream infile(OUTPUT);
	if (infile){
		std::cout << "The output file already exists! Please change the file name and try again." << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
	infile.close();

	// Print the program information and parameters in terminal for the user.
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "                     DTGRID TO UHBD FILE CONVERTOR                        " << std::endl;
	std::cout << std::endl;
	std::cout << "               Heidelberg Institute for Theoretical Studies               " << std::endl;
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "Program call: ";
	for (int c = 0; c < argc; c++)
		std::cout << argv[c] << " ";
	std:: cout << std::endl << std::endl;
	std::cout << "For further information about the program options" << std::endl;
	std::cout << "please check out the help menu!!!" << std::endl << std::endl;
	std::cout << "Option\t Value" << std::endl;
	std::cout << "-------  -----------------------------------------------------------------" << std::endl;
	std::cout << "-g\t " << DTFILE << std::endl;
	std::cout << "-f\t " << FILETYPE << std::endl;
	std::cout << "-o\t " << OUTPUT << std::endl;
	std::cout << "-v\t " << omitted_value << std::endl;
	std::cout << "-excl\t " << exclusion << std::endl;
	std::cout << std::endl;

	//Initialize the dtGrid object to read the dtgrid file
	if (exclusion){
		DTGrid3Dex * dtGrid;
		dtGrid = new DTGrid3Dex (DTFILE);

		// Initialize the output *uhbd file and fill in the file
		FILE* output_file;
		
		//if (strcmp(FILETYPE,"ascii") == 0 or strcmp(FILETYPE,"Ascii") == 0 or strcmp(FILETYPE,"ASCII") == 0){
		if (strcasecmp(FILETYPE,"ascii") == 0){
			output_file = fopen(OUTPUT,"w");
			//Write the header of the UHBD file
			write_uhbd_ascii_header(output_file, dtGrid->uhbd.Title, dtGrid->uhbd.scale, dtGrid->uhbd.spacing, dtGrid->uhbd.one, 0, \
					dtGrid->uhbd.dim.i, dtGrid->uhbd.dim.j, dtGrid->uhbd.dim.k, dtGrid->uhbd.o.x, dtGrid->uhbd.o.y, dtGrid->uhbd.o.z,\
					dtGrid->uhbd.dummy1, dtGrid->uhbd.dummy2, dtGrid->uhbd.dummy3, dtGrid->uhbd.dummy4, dtGrid->uhbd.dummy5, \
					dtGrid->uhbd.dummy6, dtGrid->uhbd.dummy7, dtGrid->uhbd.idummy1, dtGrid->uhbd.idummy2, dtGrid->uhbd.idummy3,\
					dtGrid->uhbd.idummy4, dtGrid->uhbd.idummy5);
			//Write the body of the UHBD file
			int counter;
			for (int k=0; k < dtGrid->uhbd.dim.k ; k++){
				counter = 0;
				fprintf(output_file, "%7d%7d%7d\n", k+1, dtGrid->uhbd.dim.i, dtGrid->uhbd.dim.j);
				for (int j=0; j < dtGrid->uhbd.dim.j ; j++){
					for (int i=0; i < dtGrid->uhbd.dim.i ; i++){
						fprintf(output_file, " %12.5E", (float) dtGrid->accessxyz(i,j,k));
						counter++;
						if (counter == 6){
							fprintf(output_file, "\n");
							counter = 0;
						}
					}
				}
				if (counter != 0)
					fprintf(output_file, "\n");
			}
			fclose(output_file);
		}

		if (strcasecmp(FILETYPE,"binary") == 0){
			output_file = fopen(OUTPUT,"wb");
			//Write the header of the UHBD file
			write_uhbd_binary_header(output_file, dtGrid->uhbd.Title, dtGrid->uhbd.scale, dtGrid->uhbd.spacing, dtGrid->uhbd.one, 0, \
					dtGrid->uhbd.dim.i, dtGrid->uhbd.dim.j, dtGrid->uhbd.dim.k, dtGrid->uhbd.o.x, dtGrid->uhbd.o.y, dtGrid->uhbd.o.z,\
					dtGrid->uhbd.dummy1, dtGrid->uhbd.dummy2, dtGrid->uhbd.dummy3, dtGrid->uhbd.dummy4, dtGrid->uhbd.dummy5, \
					dtGrid->uhbd.dummy6, dtGrid->uhbd.dummy7, dtGrid->uhbd.idummy1, dtGrid->uhbd.idummy2, dtGrid->uhbd.idummy3,\
					dtGrid->uhbd.idummy4, dtGrid->uhbd.idummy5);
			//Write the body of the UHBD file
			float f_value;
			int i_value;

			/* 
			 * Note that when written to a binary file. Fortran format is used!
			 * That is everytime before writing a chunk of data, its size is written first!
			 */
			i_value = sizeof(char) * 72 + sizeof(int) * 11 + sizeof(float) * 11;
			fwrite(&i_value, sizeof(int),1,output_file);

			for (int k=0; k < dtGrid->uhbd.dim.k ; k++){
				i_value = sizeof(int) * 3;
				fwrite(&i_value, sizeof(int),1,output_file);
				i_value = k+1;
				fwrite(&i_value, sizeof(int),1,output_file);
				fwrite(&(dtGrid->uhbd.dim.i), sizeof(int),1,output_file);
				fwrite(&(dtGrid->uhbd.dim.j), sizeof(int),1,output_file);
				i_value = sizeof(int) * 3;
				fwrite(&i_value, sizeof(int),1,output_file);
				i_value = sizeof(float) * dtGrid->uhbd.dim.i * dtGrid->uhbd.dim.j;
				fwrite(&i_value, sizeof(int),1,output_file);
				for (int j=0; j < dtGrid->uhbd.dim.j ; j++){
					for (int i=0; i < dtGrid->uhbd.dim.i ; i++){
						f_value = (float) dtGrid->accessxyz(i,j,k);
						fwrite(&f_value, sizeof(float),1,output_file);
					}
				}
				i_value = sizeof(float) * dtGrid->uhbd.dim.i * dtGrid->uhbd.dim.j;
				fwrite(&i_value, sizeof(int),1,output_file);
			}
			fclose(output_file);
		}

		delete dtGrid;
	}
	else{
		DTGrid3D <float,int> * dtGrid;
		dtGrid = new DTGrid3D <float,int>(DTFILE, 1.0, omitted_value);

		// Initialize the output *uhbd file and write
		FILE* output_file;
		// write the header of the file
		if (strcasecmp(FILETYPE,"ascii") == 0){
			output_file = fopen(OUTPUT,"w");
			write_uhbd_ascii_header(output_file, dtGrid->uhbd.Title, dtGrid->uhbd.scale, dtGrid->uhbd.spacing, dtGrid->uhbd.one, 0, \
					dtGrid->uhbd.dim.i, dtGrid->uhbd.dim.j, dtGrid->uhbd.dim.k, dtGrid->uhbd.o.x, dtGrid->uhbd.o.y, dtGrid->uhbd.o.z,\
					dtGrid->uhbd.dummy1, dtGrid->uhbd.dummy2, dtGrid->uhbd.dummy3, dtGrid->uhbd.dummy4, dtGrid->uhbd.dummy5, \
					dtGrid->uhbd.dummy6, dtGrid->uhbd.dummy7, dtGrid->uhbd.idummy1, dtGrid->uhbd.idummy2, dtGrid->uhbd.idummy3,\
					dtGrid->uhbd.idummy4, dtGrid->uhbd.idummy5);
			//Write the body of the UHBD file
			int counter;
			for (int k=0; k < dtGrid->uhbd.dim.k ; k++){
				counter = 0;
				fprintf(output_file, "%7d%7d%7d\n", k+1, dtGrid->uhbd.dim.i, dtGrid->uhbd.dim.j);
				for (int j=0; j < dtGrid->uhbd.dim.j ; j++){
					for (int i=0; i < dtGrid->uhbd.dim.i ; i++){
						fprintf(output_file, " %12.5E", dtGrid->accessxyz(i,j,k));
						counter++;
						if (counter == 6){
							fprintf(output_file, "\n");
							counter = 0;
						}
					}
				}
				if (counter != 0)
					fprintf(output_file, "\n");
			}
			fclose(output_file);
		}

		if (strcasecmp(FILETYPE,"binary") == 0){
			output_file = fopen(OUTPUT,"wb");
			//write the file header
			write_uhbd_binary_header(output_file, dtGrid->uhbd.Title, dtGrid->uhbd.scale, dtGrid->uhbd.spacing, dtGrid->uhbd.one, 0, \
					dtGrid->uhbd.dim.i, dtGrid->uhbd.dim.j, dtGrid->uhbd.dim.k, dtGrid->uhbd.o.x, dtGrid->uhbd.o.y, dtGrid->uhbd.o.z,\
					dtGrid->uhbd.dummy1, dtGrid->uhbd.dummy2, dtGrid->uhbd.dummy3, dtGrid->uhbd.dummy4, dtGrid->uhbd.dummy5, \
					dtGrid->uhbd.dummy6, dtGrid->uhbd.dummy7, dtGrid->uhbd.idummy1, dtGrid->uhbd.idummy2, dtGrid->uhbd.idummy3,\
					dtGrid->uhbd.idummy4, dtGrid->uhbd.idummy5);
			//Write the body of the UHBD file
			float f_value;
			int i_value;

			/* 
			 * Note that when written to a binary file. Fortran format is used!
			 * That is everytime before writing a chunk of data, its size is written first!
			 */
			i_value = sizeof(char) * 72 + sizeof(int) * 11 + sizeof(float) * 11;
			fwrite(&i_value, sizeof(int),1,output_file);

			for (int k=0; k < dtGrid->uhbd.dim.k ; k++){
				i_value = sizeof(int) * 3;
				fwrite(&i_value, sizeof(int),1,output_file);
				i_value = k+1;
				fwrite(&i_value, sizeof(int),1,output_file);
				fwrite(&(dtGrid->uhbd.dim.i), sizeof(int),1,output_file);
				fwrite(&(dtGrid->uhbd.dim.j), sizeof(int),1,output_file);
				i_value = sizeof(int) * 3;
				fwrite(&i_value, sizeof(int),1,output_file);
				i_value = sizeof(float) * dtGrid->uhbd.dim.i * dtGrid->uhbd.dim.j;
				fwrite(&i_value, sizeof(int),1,output_file);
				for (int j=0; j < dtGrid->uhbd.dim.j ; j++){
					for (int i=0; i < dtGrid->uhbd.dim.i ; i++){
						f_value = dtGrid->accessxyz(i,j,k);
						fwrite(&f_value, sizeof(float),1,output_file);
					}
				}
				i_value = sizeof(float) * dtGrid->uhbd.dim.i * dtGrid->uhbd.dim.j;
				fwrite(&i_value, sizeof(int),1,output_file);
			}
			fclose(output_file);
		}

		delete dtGrid;
	}

	return 0;
}
