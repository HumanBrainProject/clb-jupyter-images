/*! \file DTGrid1D.hpp
 *  \brief Define the 1D DT-Grid class and group its functions
 *  
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 */
 

#ifndef DTGRID1D_HPP_
#define DTGRID1D_HPP_

template<typename T, typename K>
class DTGrid1D {

	~DTGrid1D();

protected:
    ArrayPrs <K> *Value_List_1D;
    ArrayPrs <K> *Xcoord_List;
    ArrayPtr <T, K> *Ptr_List_1D;

    int Length_of_Value_List_1D;
    int Length_of_Xcoord_List;
    int Length_of_Ptr_List_1D;

    /* 
     * WARNING!!! definining the variables below in here instead of in functions is not parallel-safe!
	 * Private members for use inside accessx! Do not use outside this function!
     */
    
	/*ArrayMix <typename ArrayPrs <K>::PairArray,K> *Rarray;
	typename ArrayPrs <K>::PairArray ** ptt1;
	typename ArrayPrs <K>::PairArray * coo1;

	T ** ptt3;
	typename ArrayPrs <K>::PairArray * coo3;

	bool key1;
	short skey1;
	int countdown_1;

	K checkpoint_11;
	K checkpoint_12;
	*/
    
    int set_countdown_1;

    template <class M, class H>
    friend class DTGrid2D;
    template <class M, class H>
    friend class DTGrid3D;
    friend class DTGrid3Dex;

    void set_value_list_1D(K*,int);
    void set_xcoord_list(K*,int);
    void set_ptr_list_1D(K*,int);

	//ArrayMix <typename ArrayPrs <K>::PairArray,K> * accessx(int);
    typename ArrayPrs <K>::PairArray * accessx(int);
    typename ArrayPrs <K>::PairArray * accessx2(int);
    T * getVoxelxyz(T*, int, int, int);

    void Reset_pointers_1D(void);
};

//! DTGrid3D destructor
template <typename T, typename K>
DTGrid1D<T,K>::~DTGrid1D(){
	delete Value_List_1D;
	delete Xcoord_List;
	delete Ptr_List_1D;
}

//! DTGrid1D 'value' array setup
/*!
 *
 * Read the 1D 'value' array and store.
 * \param values pointer to the array that stores the 'value' array of DTGrid1D.
 * \param length length of the 'value' array.
 */
template <typename T, typename K>
void DTGrid1D<T,K>::set_value_list_1D(K* values, int length){
	Value_List_1D = new (std::nothrow) ArrayPrs <K>;
	Value_List_1D->Set_Pair_Array_Values(values,length);
	Length_of_Value_List_1D = length;
}

//! xCoord array setup
/*!
 * Read and store the xCoord array that stores in minimum and maximum coordinates of the connected components in x direction.
 * \param values the pointer that addresses to the values of xCoord array.
 * \param length the length of the xCoord array.
 */
template <typename T, typename K>
void DTGrid1D<T,K>::set_xcoord_list(K* values, int length){
	Xcoord_List = new (std::nothrow) ArrayPrs <K>;
	Xcoord_List->Set_Pair_Array_Values(values,length);
	Length_of_Xcoord_List = length;
	set_countdown_1 = length -1;
}

//! acc (1D) array setup
/*!
 * Read and store the list of pointers to the first member of each of the connected components in a 1D DT-Grid.
 * \param values pointer to the array that stores the acc array indices.
 * \param length length of the acc array.
 */
template <typename T, typename K>
void DTGrid1D<T,K>::set_ptr_list_1D(K* values, int length){
	Ptr_List_1D = new (std::nothrow) ArrayPtr <T,K>;
	Ptr_List_1D->Set_Pointer_Array_Values(Value_List_1D->PArray,values,Length_of_Value_List_1D,length);
	Length_of_Ptr_List_1D = length;
}

//! Reset pointers for random access. Similar to that for DT-Grid2D.
/*!
 * The function is not required when the pointers are not used as global variables.
 */
/*template <typename T, typename K>
void DTGrid1D<T,K>::Reset_pointers_1D(void){
	Value_List_1D->Reset_Set_Pair_Array_Values();
	Xcoord_List->Reset_Set_Pair_Array_Values();
	Ptr_List_1D->Reset_Set_Pointer_Array_Values();
}*/

//! Random access function of DTGrid1D class.
/*!
 *
 * \param a index x of the data value to be returned
 */
template <typename T, typename K>
typename ArrayPrs <K>::PairArray * DTGrid1D<T,K>::accessx(int a){

    bool key1 = false; // a local logical operation variable.
    int countdown_1 = set_countdown_1; // Use the predetermined number of connected components in the 1D tubular grid.

    typename ArrayPrs <K>::PairArray ** ptt1 = Ptr_List_1D->PtrArray; // a temporary pointer to store an acc array member.
    typename ArrayPrs <K>::PairArray * coo1 = Xcoord_List->PArray; // a temporary pointer to store an xCoord array pair.

    // iterate over the connected components in DTGrid1D
    for (;countdown_1>0;countdown_1--){
    	// check whether index a is inside one of the connected components using the xCoord index array.
        key1 = a>=coo1->v1 ? (a<=coo1->v2 ? true : false) : false;
        if (key1 == true){
            return *(ptt1) + a - coo1->v1;
        }
        else {
        	// increment the pointer for the next connected component.
            ++ptt1;
            ++coo1;
            continue;
        }
    }
    return NULL;
}

//! A more compact version of the random access function of DTGrid1D class.
/*!
 *
 * \param a index x of the data value to be returned.
 */
template <typename T, typename K>
typename ArrayPrs <K>::PairArray * DTGrid1D<T,K>::accessx2(int a){

	// Same as that of accessx
    bool key1 = false;
    typename ArrayPrs <K>::PairArray ** ptt1 = Ptr_List_1D->PtrArray;
    typename ArrayPrs <K>::PairArray * coo1 = Xcoord_List->PArray;

    //! 1D DT-Grid is assumed to consist only of one connected component.
    /*!
     * Therefore no iteration required.
     * Computational gain is not significant.
     */
    key1 = a>=coo1->v1 ? (a<=coo1->v2 ? true : false) : false;
    if (key1 == true){
    	return *(ptt1) + a - coo1->v1;
    }
    else
    	return NULL;
}

/*template <typename T, typename K>
T * DTGrid1D<T,K>::getVoxelxyz(T * Voxel, int a, int b, int c){

	int ainc = a+1;
	short skey1 = 0;
	int countdown_1 = Length_of_Xcoord_List-1;

	typename ArrayPrs <K>::PairArray ** ptt1 = Ptr_List_1D->PtrArray;
	typename ArrayPrs <K>::PairArray * coo1 = Xcoord_List->PArray;

	for (;countdown_1>0;countdown_1--){
		skey1 = a>=coo1->v1 ? (ainc<=coo1->v2 ? 1 : 2 ) : (ainc>=coo1->v1 ? 3 : 0);
		//key1 = a>=coo1->v1 ? (a<=coo1->v2 ? true : false) : false;
		switch (skey1)
		{
		case 0:
			++ptt1;
			++coo1;
			break;
		case 1:
			getVoxelyz(Voxel, 0,b,c, *(ptt1) + a - coo1->v1);
			getVoxelyz(Voxel, 1,b,c, *(ptt1) + ainc - coo1->v1);
			return Voxel;
		case 2:
			getVoxelyz(Voxel, 0,b,c, *(ptt1) + a - coo1->v1);
			return Voxel;
		case 3:
			getVoxelyz(Voxel, 1,b,c, *(ptt1) + ainc - coo1->v1);
			return Voxel;
		}
	}
	return Voxel;
}*/

#endif /* DTGRID1D_HPP_ */
