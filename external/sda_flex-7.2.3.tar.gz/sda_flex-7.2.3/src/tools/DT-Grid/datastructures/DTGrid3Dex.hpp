/*!  \file DTGrid3Dex.hpp
  *  \brief Main DT-Grid class to create a boolean-type 3D grid structure.
  * 
  *  \author Musa Ozboyaci
  *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
  *  
  *  DTGrid3Dex class is a modified version of the class DTGrid3D. 
  *  It is modified for excluded volume type of grids and does not use template structure of C++.
  *  It seems that this version is slightly faster than that uses the templates.
  *  
  *  \warning If DT-Grid file IO operations are separated from both DTGrid3D and DTGrid3Dex, 
  *  the code would be neater and more easy to maintain.
  *  
  *  \warning If you find a bug in this code, please do check DTGrid3D.hpp file for a similar one.
  *  
  *  
  * DTGRID ORIGINAL PAPER:
  *  M. B. Nielsen and K. Museth. Dynamic Tubular Grid: An efficient data structure and algorithms
  *  for high resolution level sets. Accepted for publication in Journal of Scientific Computing,
  *  January 26, 2005.
  *
  * 
  * \par DTGRID data structure is created based on three layers: 
  * DTGrid3D, DTGrid2D and DTGrid1D.
  * 
  * \par 
  * DTGrid1D stores the structure for mapping onto DTGrid2D.
  * \par 
  * DTGrid2D stores the structure for mapping onto DTGrid3D.
  * \par 
  * DTGrid3D stores the required structure to the numerical values
  * 
  * 
  * To be able to make it more structured and more readable the code is divided into separate
  * files inside separate folders, eventhough many of them keep very simple structures (classes).
  * Files that start with "Array" keep header files for basic array types
  * DTGrid1D, DTGrid2D and DTGrid3D / DTGrid3Dex classes keep the three layered dtgrid structure
  * 
  * 
  * Note that this dtgrid implementation is aimed to use as a replacement of UHBD type grids
  * UHBD parameters (dimensions, origin, etc.) can be associated to objects
  * 
  * \warning Check if all UHBD parameters are included!
  * 
  * 
  * The current format of the dtgrid cannot be used effectively for "skins"
  * this is because of the vagueness of that the insideconstant (gamma_i) and outsideconstant (gamma_o)
  * variables are returned depending on the sign of the values nearby! This idea could be used for lennard-jones
  * grids since the skin on the surface will most definitely have large positive values due to strong repulsion.
  * However not suitable for electrostatic grid! This has to be considered!!!
  * Another idea to solve the problem would be to define "shaped skin" rather than using the row one!
  * The shape could be an ellipsoid or a sphere. But then the grid cannot be used for exclusion grid!
  * 
  * Iterators and the neighbourfind methods have yet to be implemented in the present version!
  */

#ifndef DTGRID3DEX_HPP_
#define DTGRID3DEX_HPP_
//
#include <stdlib.h>
#include <string.h>
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>
#include <typeinfo>
//
#include "ArrayReg.hpp"
#include "ArrayPtr.hpp"
#include "ArrayPrs.hpp"
#include "DTGrid2D.hpp"

class DTGrid3Dex {
public:
	DTGrid3Dex(char *);
	~DTGrid3Dex();
	
private:

    ArrayReg <bool> * Value_List_3D;
    ArrayPrs <int> * Zcoord_List;
    ArrayPtr <bool,int> * Ptr_List_3D;

    DTGrid2D <bool,int> * proj2D;

    int Length_of_Value_List_3D;
    int Length_of_Zcoord_List;
    int Length_of_Ptr_List_3D;

    //! grid file format: binary = 0; ascii = 1
    int iform;

    //! grid type: exclusion grid = 0; normal grid = 1
    int grid_type;
	
	float scale; //! not used for data scaling
	float spacing; //! grid resolution

	//! grid dimensions in x, y and z directions given by i, j and k, respectively
	struct {
		int i;
		int j;
		int k;
	}dimensions;
	
	//! hold the coordinates (in x, y and z) of the grid origin.
	struct {
		float x;
		float y;
		float z;
	}origin;
	
	//
    void set_zcoord_list(int*,int);
    void set_projection2D(int*, int*, int*, int*, int*, int*, int, int, int, int, int, int);
	void set_uhbd_parameters(float, float, float, float, float, int, int, int);
	void Reset_pointers_3D(void);

	//
	void test_format_dtgrid(char *);
	void size_ds(unsigned int);
	void format_ascii(char *);
	void format_binary(char *);

public:
	//! UHBD header information
	struct {
		char * Title;
		int grdflag;
		int one;
		int idummy1;
		int idummy2;
		int idummy3;
		int idummy4;
		int idummy5;
		float scale;
		float spacing;
		float dummy1;
		float dummy2;
		float dummy3;
		float dummy4;
		float dummy5;
		float dummy6;
		float dummy7;
		struct dimensions
		{
			int i;
			int j;
			int k;
		}dim;
		struct origin
		{
			float x;
			float y;
			float z;
		}o;
	}uhbd;

	bool accessxyz(int, int, int);
	bool * getCell(bool *, int, int, int);
	bool * getCell2(bool *, int, int, int);

protected:
    void getCellz(bool *, int, int, int, typename ArrayPrs <int>::PairArray *);
    void getCellyz(bool *, int, int, int, typename ArrayPrs <int>::PairArray *);

};

//! DTGrid3Dex destructor
DTGrid3Dex::~DTGrid3Dex(){
	delete proj2D;
	delete Zcoord_List;
}

//! DTGrid3Dex constructor
/*! 
 * \param file_name input dt-grid file.
 */
DTGrid3Dex::DTGrid3Dex(char * file_name){

	Length_of_Ptr_List_3D = 0;
	Length_of_Value_List_3D = 0;

	test_format_dtgrid(file_name);
	if (iform == 0)
		format_binary(file_name);
	else if (iform == 1)
		format_ascii(file_name);
	else{
		std::cout << "Error: Unknown file format" << std::endl;
		exit(0);
	}
}

//! zCoord array setup
/*! 
 * Read and store the zCoord array that stores in minimum and maximum coordinates of the connected components in z direction.
 * \param values a pointer that holds the zCoord array.
 * \param length the length of the zCoord array.
 */
void DTGrid3Dex::set_zcoord_list(int* values, int length){
	Zcoord_List = new (std::nothrow) ArrayPrs <int>;
	Zcoord_List->Set_Pair_Array_Values(values,length);
	Length_of_Zcoord_List = length;
}

//! proj2D setup
/*! 
 * Create an instance of a DTGrid2D class and set up this proj2D object that contain yCoord, acc (2D) and the 'value' (2D) arrays.
 * \param values1 pointer to the 'value' array of the DTGrid2D.
 * \param values2 pointer to the yCoord array of the DTGrid2D.
 * \param values3 pointer to the acc array of the DTGrid2D.
 * \param values4 pointer (to be passed to DTGrid1D) to the 'value' array of the DTGrid1D.
 * \param values5 pointer (to be passed to DTGrid1D) to the xCoord array of the DTGrid1D.
 * \param values6 pointer (to be passed to DTGrid1D) to the acc array of the DTGrid1D.
 * \param length1 the length of the 'value' (2D) array.
 * \param length2 the length of the yCoord array.
 * \param length3 the length of the acc (2D) array.
 * \param length4 the length of the 'value' (1D) array.
 * \param length5 the length of the xcoord array.
 * \param length6 the length of the acc (1D) array.
 */
void DTGrid3Dex::set_projection2D(int* values1, int* values2, int* values3, \
		int* values4, int* values5, int* values6, int length1, int length2, \
		int length3, int length4, int length5, int length6){

	proj2D = new (std::nothrow) DTGrid2D <bool,int>;
	proj2D->set_value_list_2D(values1,length1);
	proj2D->set_ycoord_list(values2,length2);
	proj2D->set_ptr_list_2D(values3,length3);
	proj2D->set_projection1D(values4, values5, values6, length4, length5, length6);
}

//! Read and set the grid parameters.
/*! 
 *  These parameters are inherited from the UHBD file format and kept in DTGrid files.
 * \param sc the scaling factor.
 * \param sp the uniform spacing value of the grid.
 * \param ox coordinate x of the origin.
 * \param oy coordinate y of the origin.
 * \param oz coordinate z of the origin.
 * \param dimi dimension of the grid in x direction.
 * \param dimj dimension of the grid in y direction.
 * \param dimk dimension of the grid in z direction.
 */
void DTGrid3Dex::set_uhbd_parameters(float sc, float sp, float ox, float oy, float oz, int dimi, int dimj, int dimk){
	scale = sc;
	spacing = sp;
	
	origin.x = ox;
	origin.y = oy;
	origin.z = oz;
	
	dimensions.i = dimi;
	dimensions.j = dimk;
	dimensions.k = dimk;
}

//! Random access function.
/*! 
 *  A different implementation of random data access function \sa access_fast
 *  In SDA random cell access function is used. 
 *  This function returns the data for a single grid point.
 *  
 * \param a index x of the data value to be returned
 * \param b index y of the data value to be returned
 * \param c index z of the data value to be returned
 * 
 * \attention
 * Check for parallel safety! 
 * The function is not used in current SDA implementation, though.
 */
bool DTGrid3Dex::accessxyz(int a, int b, int c){

	// Call the random access function in the DTGrid2D.
	typename ArrayPrs <int>::PairArray * coord3 = proj2D->accessxy(a,b);

	// Return the default value if recursive function call returns NULL.
	if (coord3 == NULL) return false;

	bool key3 = false; // a local logical operation variable.

	int checkpoint_31 = coord3->v2; // the index of the first connected component in a tubular grid in the zCoord array.
	int checkpoint_32 = (coord3+1)->v2; // the index of the last connected component in a tubular grid in the zCoord array.
	int countdown_3 = checkpoint_32 - checkpoint_31; // Determine how many connected components are there in the corresponding tubular grid (3D).

	// Return when no connected component found
	if (countdown_3 == 0) return false;

	typename ArrayPrs <int>::PairArray * coo3 = Zcoord_List->PArray+checkpoint_31; // a temporary pointer to store an zCoord array pair.

	// iterate over the connected components in DTGrid3Dex
	for (; countdown_3 >= 1; countdown_3--){

		// check whether index c is inside one of the connected components using the zCoord index array.
		key3 = c>=coo3->v1 ? (c<=coo3->v2 ? true : false) : false;
		if (key3 == true){
			return true;
		}
		else {
			++coo3;
			continue;
		}
	}
	return false;
}

//! Random access to grid cells in z direction.
/*! 
 *  Call to this function fills the corresponding points in the cubic cell input by looking up the values from the actual grid.
 * \param Cell array to copy the values stored inside the grid cell that accessed randomly.
 * \param x index of the grid cell point in x direction (0 or 1 for a 3dimensional cubic cell)
 * \param y index of the grid cell point in y direction (0 or 1 for a 3dimensional cubic cell)
 * \param c index z of the origin of the data cell inside the complete grid to be returned
 * \param coord3 pointer to the index pair stored in zCoord array that list the indices to the first connected component in the 3D tubular grid.
 */
void DTGrid3Dex::getCellz(bool * Cell, int x, int y, int c, typename ArrayPrs <int>::PairArray * coord3){

	short skey3;
	int cinc = c+1;

	int checkpoint_31 = coord3->v2;
	int checkpoint_32 = (coord3+1)->v2;
	int countdown_3 = checkpoint_32 - checkpoint_31;

	typename ArrayPrs <int>::PairArray * coo3 = Zcoord_List->PArray+checkpoint_31;

	for (; countdown_3 >= 1; countdown_3--){
		skey3 = c>=coo3->v1 ? (cinc<=coo3->v2 ? 1 : (c<=coo3->v2 ? 2 : 0) ) : (cinc>=coo3->v1 ? (cinc<=coo3->v2 ? 3 : 0) : 0);
		//key3 = c>=coo3->v1 ? (c<=coo3->v2 ? true : false) : false;
		switch (skey3)
		{
		case 0:
			++coo3;
			break;
		case 1:
			Cell[4*x+2*y] = true;
			Cell[4*x+2*y+1] = true;
			return;
		case 2:
			Cell[4*x+2*y] = true;
			return;
		case 3:
			Cell[4*x+2*y+1] = true;
			return;
		}
	}
	return;
}

//! Random access function for grid cells (y direction, DTGrid2D).
/*! 
 * Call to this function returns the last function call (\sa getCellz) in order to fill the corresponding points in the cubic cell input.
 * \param Cell array to copy the values stored inside the grid cell that accessed randomly.
 * \param x index of the grid cell point in x direction (0 or 1 for a 3dimensional cubic cell)
 * \param b index y of the origin of the data cell inside the complete grid to be returned.
 * \param c index z of the origin of the data cell inside the complete grid to be returned
 * \param coord2 pointer to the index pair stored in yCoord array that list the indices to the first connected component in the 2D tubular grid.
 */
void DTGrid3Dex::getCellyz(bool * Cell, int x, int b, int c, typename ArrayPrs <int>::PairArray * coord2){

	short skey2;
	int binc = b+1;

	int checkpoint_21 = coord2->v2;
	int checkpoint_22 = (coord2+1)->v2;
	int countdown_2 = checkpoint_22 - checkpoint_21;

	if (countdown_2 == 0){ return;}

	typename ArrayPrs <int>::PairArray ** ptt2 = proj2D->Ptr_List_2D->PtrArray+checkpoint_21;
	typename ArrayPrs <int>::PairArray * coo2 = proj2D->Ycoord_List->PArray+checkpoint_21;

	for (; countdown_2 >= 1; countdown_2--){
		skey2 = b>=coo2->v1 ? (binc<=coo2->v2 ? 1 : (b<=coo2->v2 ? 2 : 0) ) : (binc>=coo2->v1 ? (binc<=coo2->v2 ? 3 : 0) : 0);

		switch (skey2)
		{
		case 0:
			++ptt2;
			++coo2;
			break;
		case 1:
			getCellz(Cell, x,0,c, *(ptt2)+b-coo2->v1);
			//++b;
			getCellz(Cell, x,1,c, *(ptt2)+binc-coo2->v1);
			return;
		case 2:
			//printf("%d %d %d %d\n",b,b+1,coo2->v1,coo2->v2);
			getCellz(Cell, x,0,c, *(ptt2)+b-coo2->v1);
			return;
		case 3:
			getCellz(Cell, x,1,c, *(ptt2)+binc-coo2->v1);
			return;
		}
	}
	return;
}

//! Random access to grid cells.
/*! 
 * This function returns a cubic grid cell that contains the data stored in the grid point whose indices are input by the user,
 * as well as the other 7 neighbor points that make up the 8 point grid cell.
 * The given set of index: x, y and z defines the origin of the grid cell that is to be accessed.
 * The other grid points are: {(x,y,z),(x,y,z+1),(x,y+1,z),(x,y+1,z+1),(x+1,y,z),(x+1,y+1,z),(x+1,y,z+1),(x+1,y+1,z+1)}
 * 
 * \param Cell array to copy the values stored inside the grid cell that accessed randomly.
 * \param a index x of the origin of the data cell inside the complete grid to be returned.
 * \param b index y of the origin of the data cell inside the complete grid to be returned.
 * \param c index z of the origin of the data cell inside the complete grid to be returned.
 */
bool * DTGrid3Dex::getCell(bool * Cell, int a, int b, int c){

	short skey1;
	int ainc = a+1;
	int countdown_1 = proj2D->proj1D->set_countdown_1;

	typename ArrayPrs <int>::PairArray ** ptt1 = proj2D->proj1D->Ptr_List_1D->PtrArray;
	typename ArrayPrs <int>::PairArray * coo1 = proj2D->proj1D->Xcoord_List->PArray;

	for (;countdown_1>0;countdown_1--){
		skey1 = a>=coo1->v1 ? (ainc<=coo1->v2 ? 1 : (a<=coo1->v2 ? 2 : 0) ) : (ainc>=coo1->v1 ? (ainc<=coo1->v2 ? 3 : 0) : 0);
		switch (skey1)
		{
		case 0:
			++ptt1;
			++coo1;
			break;
		case 1:
			getCellyz(Cell, 0,b,c, *(ptt1) + a - coo1->v1);
			getCellyz(Cell, 1,b,c, *(ptt1) + ainc - coo1->v1);
			return Cell;
		case 2:
			getCellyz(Cell, 0,b,c, *(ptt1) + a - coo1->v1);
			return Cell;
		case 3:
			getCellyz(Cell, 1,b,c, *(ptt1) + ainc - coo1->v1);
			return Cell;
		}
	}
	return Cell;
}

//!  Random access to grid cells. (2nd version)
/*! 
 * This function assumes that there is only one connected component in DTGrid1D level.
 *  Structures, potential fields are usually one connected piece in 3D. So care should be taken when this function is used
 *
 * \param Cell array to copy the values stored inside the grid cell that accessed randomly.
 * \param a index x of the origin of the data cell inside the complete grid to be returned.
 * \param b index y of the origin of the data cell inside the complete grid to be returned.
 * \param c index z of the origin of the data cell inside the complete grid to be returned.
 */
bool * DTGrid3Dex::getCell2(bool * Cell, int a, int b, int c){

	short skey1;
	int ainc = a+1;

	typename ArrayPrs <int>::PairArray ** ptt1 = proj2D->proj1D->Ptr_List_1D->PtrArray;
	typename ArrayPrs <int>::PairArray * coo1 = proj2D->proj1D->Xcoord_List->PArray;

	skey1 = a>=coo1->v1 ? (ainc<=coo1->v2 ? 1 : (a<=coo1->v2 ? 2 : 0) ) : (ainc>=coo1->v1 ? (ainc<=coo1->v2 ? 3 : 0) : 0);
	switch (skey1)
	{
	case 1:
		getCellyz(Cell, 0,b,c, *(ptt1) + a - coo1->v1);
		getCellyz(Cell, 1,b,c, *(ptt1) + ainc - coo1->v1);
		return Cell;
	case 2:
		getCellyz(Cell, 0,b,c, *(ptt1) + a - coo1->v1);
		return Cell;
	case 3:
		getCellyz(Cell, 1,b,c, *(ptt1) + ainc - coo1->v1);
		return Cell;
	default:
		return Cell;
	}
}

//! Determine the DT-Grid file format
/*! 
 * This function opens and reads the dt-grid file in order to determine whether it is binary or ASCII.
 * \param Input name of input dt-grid file.
 */
void DTGrid3Dex::test_format_dtgrid(char * Input)
{
	std::ifstream file_bt;
	file_bt.open(Input, std::ifstream::in | std::ifstream::binary);

	int flag;
	file_bt.read((char *) &flag, sizeof(int));

	//Read the first 120 characters
	char * buffer = new char [120];
	file_bt.read(buffer, 120);

	char * binary_test;
	binary_test = (char*) memchr (buffer, '\n', 120);

	if (flag == 160){
		//Binary file
		std::cout << "Test format dtgrid: No return statement, binary zeros found" << std::endl;
		std::cout << "The file was detected to be of type binary" << std::endl;
		iform = 0;
	}
	else{
		if (binary_test == NULL) { // NO return statement
			binary_test = (char*) memchr (buffer, '\0', 120);
			if (binary_test == NULL) {
				//ASCII file
				std::cout << "Test format dtgrid: No return statement, no binary zeros" << std::endl;
				std::cout << "The file was detected to be of type ASCII" << std::endl;
				iform = 1;
			}
			else{
				//Binary file
				std::cout << "Test format dtgrid: No return statement, binary zeros found" << std::endl;
				std::cout << "The file was detected to be of type binary" << std::endl;
				iform = 0;
			}
		}
		else{
			//ASCII file
			std::cout << "Test format dtgrid: Return statement found" << std::endl;
			std::cout << "The file was detected to be of type ASCII" << std::endl;
			iform = 1;
		}
	}
	file_bt.close();
	delete[] buffer;
}

//! Open and Read the binary grid file
/*! 
 * The header of a DT-Grid file is same as that of a UHBD file. Therefore the parameter definitions are identical.
 *
 * \note This function and the rest of the file related functions, as well as parameters can be put together in a class.
 * \sa format_ascii and \sa size_ds
 *
 * \param file_binary name of the grid file.
 */
void DTGrid3Dex::format_binary(char * file_binary)
{
	std::ifstream dtgrid_file;
	dtgrid_file.open(file_binary, std::ifstream::in | std::ifstream::binary);

	float sc, sp, ox, oy, oz, fval;
	int dimi, dimj, dimk, ival, flag_binary, flag_grid_type;

	//uhbd header parameters
	dtgrid_file.read((char *) &flag_binary, sizeof(int));
	uhbd.Title = new char [72];
	dtgrid_file.read(uhbd.Title, 72);
	dtgrid_file.read((char *) &uhbd.scale, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy1, sizeof(float));
	dtgrid_file.read((char *) &uhbd.grdflag, sizeof(int));
	dtgrid_file.read((char *) &uhbd.idummy1, sizeof(int));
	dtgrid_file.read((char *) &uhbd.idummy2, sizeof(int));
	dtgrid_file.read((char *) &uhbd.one, sizeof(int));
	dtgrid_file.read((char *) &uhbd.idummy3, sizeof(int));
	dtgrid_file.read((char *) &uhbd.dim.i, sizeof(int));
	dtgrid_file.read((char *) &uhbd.dim.j, sizeof(int));
	dtgrid_file.read((char *) &uhbd.dim.k, sizeof(int));
	dtgrid_file.read((char *) &uhbd.spacing, sizeof(float));
	dtgrid_file.read((char *) &uhbd.o.x, sizeof(float));
	dtgrid_file.read((char *) &uhbd.o.y, sizeof(float));
	dtgrid_file.read((char *) &uhbd.o.z, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy2, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy3, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy4, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy5, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy6, sizeof(float));
	dtgrid_file.read((char *) &uhbd.dummy7, sizeof(float));
	dtgrid_file.read((char *) &uhbd.idummy4, sizeof(int));
	dtgrid_file.read((char *) &uhbd.idummy5, sizeof(int));

	//DT-Grid header parameters
	int len_Value, len_xcoord, len_ycoord, len_zcoord;
	int len_acc, len_acc2, len_acc3, len_projection, len_projection2;

	dtgrid_file.read((char *) &flag_grid_type, sizeof(int));
	dtgrid_file.read((char *) &len_Value, sizeof(int));
	dtgrid_file.read((char *) &len_xcoord, sizeof(int));
	dtgrid_file.read((char *) &len_ycoord, sizeof(int));
	dtgrid_file.read((char *) &len_zcoord, sizeof(int));
	dtgrid_file.read((char *) &len_acc, sizeof(int));
	dtgrid_file.read((char *) &len_acc2, sizeof(int));
	dtgrid_file.read((char *) &len_acc3, sizeof(int));
	dtgrid_file.read((char *) &len_projection, sizeof(int));
	dtgrid_file.read((char *) &len_projection2, sizeof(int));

	grid_type = flag_grid_type;
	if (grid_type == 0)
		std::cout << "Type of grid: Excluded volume" << std::endl;
	else if (grid_type == 1)
		std::cout << "Type of grid: Potential/Energy" << std::endl;
	else
		std::cout << "Type of grid: Unknown/Not-Set" << std::endl;

	std::cout << "DT-Grid Header information: " << std::endl;
	std::cout << "Length of Value array:\t" << len_Value << std::endl;
	std::cout << "Length of xCoord array:\t" << len_xcoord<< std::endl;
	std::cout << "Length of yCoord array:\t" << len_ycoord << std::endl;
	std::cout << "Length of zCoord array:\t" << len_zcoord << std::endl;
	std::cout << "Length of acc1D array:\t" << len_acc << std::endl;
	std::cout << "Length of acc2D array:\t" << len_acc2 << std::endl;
	std::cout << "Length of acc3D array:\t" << len_acc3 << std::endl;
	std::cout << "Length of proj1D array:\t" << len_projection << std::endl;
	std::cout << "Length of proj2D array:\t" << len_projection2 << std::endl << std::endl;

	int dtgrid_size;
	dtgrid_size = sizeof(int) * (len_xcoord + len_ycoord + len_zcoord + \
			len_acc + len_acc2 + len_acc3) + sizeof(int *) * (len_projection + len_projection2);
	size_ds(dtgrid_size);

	//dtgrid main body
	int * zcoord;
	zcoord = new int [len_zcoord];
	for (int i=0;i<len_zcoord;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		zcoord[i] = (int) ival;
	}

	int * acc;
	acc = new int [len_acc];
	for (int i=0;i<len_acc;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		acc[i] = (int) ival;
	}

	int * projection;
	projection = new int [len_projection];
	for (int i=0;i<len_projection;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		projection[i] = (int) ival;
	}

	int * ycoord;
	ycoord = new int [len_ycoord];
	for (int i=0;i<len_ycoord;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		ycoord[i] = (int) ival;
	}

	int * acc2;
	acc2 = new int [len_acc2];
	for (int i=0;i<len_acc2;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		acc2[i] = (int) ival;
	}

	int * projection2;
	projection2 = new int [len_projection2];
	for (int i=0;i<len_projection2;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		projection2[i] = (int) ival;
	}

	int * xcoord;
	xcoord = new int [len_xcoord];
	for (int i=0;i<len_xcoord;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		xcoord[i] = (int) ival;
	}

	int * acc3;
	acc3 = new int [len_acc3];
	for (int i=0;i<len_acc3;i++){
		dtgrid_file.read((char *) &ival, sizeof(int));
		acc3[i] = (int) ival;
	}

	// Initialization of the grid object
	set_uhbd_parameters(uhbd.scale, uhbd.spacing, uhbd.o.x, uhbd.o.y, \
			uhbd.o.z, uhbd.dim.i, uhbd.dim.j, uhbd.dim.k);
	set_zcoord_list(zcoord,len_zcoord);
	set_projection2D(projection,ycoord,acc2,projection2,xcoord,acc3,len_projection, \
			len_ycoord,len_acc2,len_projection2,len_xcoord,len_acc3);

	delete[] zcoord;
	delete[] acc;
	delete[] projection;
	delete[] ycoord;
	delete[] acc2;
	delete[] projection2;
	delete[] xcoord;
	delete[] acc3;

	dtgrid_file.close();
}

//! Open and Read the ascii grid file
/*! 
 * \note very similar to \sa format_binary function. Can these two functions be merged?
 * Detailed description of the variables used in this function is available in the \sa format_binary function
 *
 * \param file_ascii name of the grid file.
 */
void DTGrid3Dex::format_ascii(char * file_ascii)
{
	std::ifstream dtgrid_file;
	dtgrid_file.open(file_ascii, std::ifstream::in);

	std::string title_str, line;
	std::string scale_str, dum1_str, grdflag_str, idum1_str, idum2_str, one_str, idum3_str;
	std::string i_str, j_str, k_str;
	std::string spacing_str, ox_str, oy_str, oz_str;
	std::string dum2_str, dum3_str, dum4_str, dum5_str;
	std::string dum6_str, dum7_str, idum4_str, idum5_str;

    bool fval;
	int ival;
	int flag_grid_type;
	int len_Value, len_xcoord, len_ycoord, len_zcoord;
	int len_acc, len_acc2, len_acc3, len_projection, len_projection2;

	//DTGrid (UHBD) Title
	getline(dtgrid_file,line);
	title_str = line.substr(0,72);

	//uhbd header parameters
	getline(dtgrid_file,line);
	scale_str = line.substr(0,12);
	dum1_str = line.substr(12,12);
	grdflag_str = line.substr(24,7);
	idum1_str = line.substr(31,7);
	idum2_str = line.substr(38,7);
	one_str = line.substr(45,7);
	idum3_str = line.substr(52,7);
	getline(dtgrid_file,line);
	i_str = line.substr(0,7);
	j_str = line.substr(7,7);
	k_str = line.substr(14,7);
	spacing_str = line.substr(21,12);
	ox_str = line.substr(33,12);
	oy_str = line.substr(45,12);
	oz_str = line.substr(57,12);
	getline(dtgrid_file,line);
	dum2_str = line.substr(0,12);
	dum3_str = line.substr(12,12);
	dum4_str = line.substr(24,12);
	dum5_str = line.substr(36,12);
	getline(dtgrid_file,line);
	dum6_str = line.substr(0,12);
	dum7_str = line.substr(12,12);
	idum4_str = line.substr(24,7);
	idum5_str = line.substr(31,7);

	//
	uhbd.Title = new char [72];
	std::strncpy (uhbd.Title, title_str.c_str(), 72);

	std::stringstream (scale_str) >> uhbd.scale;
	std::stringstream (dum1_str) >> uhbd.dummy1;
	std::stringstream (grdflag_str) >> uhbd.grdflag;
	std::stringstream (idum1_str) >> uhbd.idummy1;
	std::stringstream (idum2_str) >> uhbd.idummy2;
	std::stringstream (one_str) >> uhbd.one;
	std::stringstream (idum3_str) >> uhbd.idummy3;
	std::stringstream (i_str) >> uhbd.dim.i;
	std::stringstream (j_str) >> uhbd.dim.j;
	std::stringstream (k_str) >> uhbd.dim.k;
	std::stringstream (spacing_str) >> uhbd.spacing;
	std::stringstream (ox_str) >> uhbd.o.x;
	std::stringstream (oy_str) >> uhbd.o.y;
	std::stringstream (oz_str) >> uhbd.o.z;
	std::stringstream (dum2_str) >> uhbd.dummy2;
	std::stringstream (dum3_str) >> uhbd.dummy3;
	std::stringstream (dum4_str) >> uhbd.dummy4;
	std::stringstream (dum5_str) >> uhbd.dummy5;
	std::stringstream (dum6_str) >> uhbd.dummy6;
	std::stringstream (dum7_str) >> uhbd.dummy7;
	std::stringstream (idum4_str) >> uhbd.idummy4;
	std::stringstream (idum5_str) >> uhbd.idummy5;


	//dtgrid header parameters
	dtgrid_file >> flag_grid_type;
	dtgrid_file >> len_Value;
	dtgrid_file >> len_xcoord;
	dtgrid_file >> len_ycoord;
	dtgrid_file >> len_zcoord;
	dtgrid_file >> len_acc;
	dtgrid_file >> len_acc2;
	dtgrid_file >> len_acc3;
	dtgrid_file >> len_projection;
	dtgrid_file >> len_projection2;

	grid_type = flag_grid_type;
	if (grid_type == 0)
		std::cout << "Type of grid: Excluded volume" << std::endl;
	else if (grid_type == 1)
		std::cout << "Type of grid: Potential/Energy" << std::endl;
	else
		std::cout << "Type of grid: Unknown/Not-Set" << std::endl;

	std::cout << "DT-Grid Header information: " << std::endl;
	std::cout << "Length of Value array:\t" << len_Value << std::endl;
	std::cout << "Length of xCoord array:\t" << len_xcoord<< std::endl;
	std::cout << "Length of yCoord array:\t" << len_ycoord << std::endl;
	std::cout << "Length of zCoord array:\t" << len_zcoord << std::endl;
	std::cout << "Length of acc1D array:\t" << len_acc << std::endl;
	std::cout << "Length of acc2D array:\t" << len_acc2 << std::endl;
	std::cout << "Length of acc3D array:\t" << len_acc3 << std::endl;
	std::cout << "Length of proj1D array:\t" << len_projection << std::endl;
	std::cout << "Length of proj2D array:\t" << len_projection2 << std::endl << std::endl;

	unsigned int dtgrid_size;
	dtgrid_size = sizeof(int) * (len_xcoord + len_ycoord + len_zcoord + \
			len_acc + len_acc2 + len_acc3) + sizeof(int *) * (len_projection + len_projection2);
	size_ds(dtgrid_size);

	//dtgrid main body
   	int * zcoord;
	zcoord = new int [len_zcoord];
   	for (int i=0;i<len_zcoord;i++){
   		dtgrid_file >> ival;
   		zcoord[i] = ival;
   	}

   	int * acc;
	acc = new int [len_acc];
   	for (int i=0;i<len_acc;i++){
   		dtgrid_file >> ival;
   		acc[i] = ival;
   	}

   	int * projection;
	projection = new int [len_projection];
   	for (int i=0;i<len_projection;i++){
		dtgrid_file >> ival;
   		projection[i] = ival;
   	}

   	int * ycoord;
	ycoord = new int [len_ycoord];
   	for (int i=0;i<len_ycoord;i++){
   		dtgrid_file >> ival;
   		ycoord[i] = ival;
   	}

   	int * acc2;
	acc2 = new int [len_acc2];
   	for (int i=0;i<len_acc2;i++){
   		dtgrid_file >> ival;
   		acc2[i] = ival;
   	}

   	int * projection2;
	projection2 = new int [len_projection2];
   	for (int i=0;i<len_projection2;i++){
   		dtgrid_file >> ival;
   		projection2[i] = ival;
   	}

   	int * xcoord;
	xcoord = new int [len_xcoord];
   	for (int i=0;i<len_xcoord;i++){
   		dtgrid_file >> ival;
   		xcoord[i] = ival;
   	}

   	int * acc3;
	acc3 = new int [len_acc3];
   	for (int i=0;i<len_acc3;i++){
   		dtgrid_file >> ival;
   		acc3[i] = ival;
   	}

	// Initialization of the grid object
   	set_uhbd_parameters(uhbd.scale, uhbd.spacing, uhbd.o.x, uhbd.o.y, \
   					uhbd.o.z, uhbd.dim.i, uhbd.dim.j, uhbd.dim.k);
	set_zcoord_list(zcoord,len_zcoord);
	set_projection2D(projection,ycoord,acc2,projection2,xcoord,acc3,len_projection, \
			len_ycoord,len_acc2,len_projection2,len_xcoord,len_acc3);
	delete[] zcoord;
	delete[] acc;
	delete[] projection;
	delete[] ycoord;
	delete[] acc2;
	delete[] projection2;
	delete[] xcoord;
	delete[] acc3;

	dtgrid_file.close();
}

//! Estimate the grid file size
/*! 
 * \param val size of file in bytes
 */
void DTGrid3Dex::size_ds(unsigned int val)
{
	float dtgrid_size;
	int kb, mb, gb;

	kb = 1024;
	mb = 1024 * 1024;
	gb = 1024 * 1024 * 1024;

	if ((val / gb) > 1) {
		dtgrid_size = (float) val / (float) gb;
		std::cout << "Size of DT-Grid data structure is " << dtgrid_size << " GB" << std::endl;
	}
	else {
		if ((val / mb) > 1) {
			dtgrid_size = (float) val / (float) mb;
			std::cout << "Size of DT-Grid data structure is " << dtgrid_size << " MB" << std::endl;
		}
		else {
			dtgrid_size = (float) val / (float) kb;
			std::cout << "Size of DT-Grid data structure is " << dtgrid_size << " KB" << std::endl;
		}
	}
}

#endif /* DTGRID3DEX_HPP_ */
