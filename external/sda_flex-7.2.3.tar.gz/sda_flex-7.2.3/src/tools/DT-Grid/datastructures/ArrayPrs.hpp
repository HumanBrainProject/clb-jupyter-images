/*! \file ArrayPrs.hpp
 *  \brief Define the array for storing pairs of indices
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 *  ArrayPrs class is used for storing pairs of indices
 *  This data class at present is used for iCoord arrays and projnD (proj1D,proj2D)arrays
 *  nCoord arrays keep indices for each connected component in nth dimension
 *  The class includes a sub-class "PairArray" for the start and end indices in each connected component in dtgrid
 *  Note that indices are kept in list of structures and NOT in structures of list, which might introduce more efficiency,
 *  However it has not been tested yet!
 */
 
#ifndef ARRAYPRS_HPP_
#define ARRAYPRS_HPP_

template<typename K>
class ArrayPrs {
	
	~ArrayPrs();

public:

	void Set_Pair_Array_Values(K*,int);
	void Reset_Set_Pair_Array_Values(void);

	template <class M, class H>
	friend class DTGrid2D;
	template <class M, class H>
	friend class DTGrid3D;
	friend class DTGrid3Dex;
	template <class M, class H>
	friend class DTGrid1D;
	template <class M, class H>
	friend class ArrayPtr;
	template <class M, class H>
	friend class ArrayMix;

protected:

	class PairArray {
	public:
		K v1; //! index into the icoord array (min connected component)
		K v2; //! index into the icoord array (max connected component)

	public:
		void Set_Pair_Array_Elements(K,K);
	};

	PairArray *PArray;
	PairArray *PArray_Copy; //! copy of the original pointer address.

};

//! ArrayPrs destructor
/*!
 * input void
 */
template<typename K>
ArrayPrs<K>::~ArrayPrs()
{
	delete[] PArray;
	//delete[] PArray_Copy;
}

//! Setup the array that stores the complete icoord values
/*!
 * This function initializes the PArray to store the PairArray structures
 * \param array pointer to the array that stores the min and max indices of the connected components.
 * \param I length of this array.
 */
template<typename K>
void ArrayPrs<K>::Set_Pair_Array_Values(K* array,int I){
	int count = 0;
	PArray = new (std::nothrow) PairArray [I/2];
	for (int i =0;i<I;i+=2)  {
		PArray[count].Set_Pair_Array_Elements(array[i],array[i+1]);
		++count;
	}
	PArray_Copy = PArray;
}

//! Set each of the PairArray structure elements.
/*!
 * Store a single pair of values.
 * \param a index into the icoord array.
 * \param b index into the icoord array.
 */
template<typename K>
void ArrayPrs<K>::PairArray::Set_Pair_Array_Elements(K a,K b){
	v1 = a;
	v2 = b;
}

//! Reset pointer to the array
/*!
 *
 * This function is used to reset the pointer back to its original value!
 * It does not reset the values that the pointer originally points to!
 */
template<typename K>
void ArrayPrs<K>::Reset_Set_Pair_Array_Values(void){
	PArray_Copy = PArray;
}

#endif /* ARRAYPRS_HPP_ */
