/*! \file DTGrid2D.hpp
 *  \brief Define 2D DT-Grid class and group its functions
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 */

#ifndef DTGRID2D_HPP_
#define DTGRID2D_HPP_
#include "./ArrayReg.hpp"
#include "./ArrayPrs.hpp"
#include "./ArrayPtr.hpp"
#include "DTGrid1D.hpp"
//template<typename T, typename K>
//class DTGrid1D;
template<typename T,typename K>
class DTGrid2D {
	
	~DTGrid2D();
	
private:

    ArrayPrs <K> * Value_List_2D;
    ArrayPrs <K> * Ycoord_List;
    ArrayPtr <T,K> * Ptr_List_2D;

    DTGrid1D <T,K> * proj1D;

    int Length_of_Value_List_2D;
    int Length_of_Ycoord_List;
    int Length_of_Ptr_List_2D;
	
	// WARNING!!! definining the variables below in here instead of in functions is not parallel-safe! 
    /*
	//Private members for use inside accessxy! Do not use outside this function!
	typename ArrayPrs <K>::PairArray * coord2;
	typename ArrayPrs <K>::PairArray ** ptt2;
	typename ArrayPrs <K>::PairArray * coo2;
	K checkpoint_21;
	K checkpoint_22;
	K countdown_2;
	bool key2;
	short skey2;
	*/

protected:
    template <class M, class H>
    friend class DTGrid3D;
    friend class DTGrid3Dex;
    template <class M, class H>
    friend class DTGrid1D;

    void set_value_list_2D(K*,int);
    void set_ycoord_list(K*,int);
    void set_ptr_list_2D(K*,int);

    void set_projection1D(K*, K*, K*, int, int, int);
    //typedef ArrayPrs <K>* newtype;

    typename ArrayPrs <K>::PairArray * accessxy(int, int);
    void getVoxelyz(T*, int, int, int, typename ArrayPrs <K>::PairArray *);

    void Reset_pointers_2D(void);
};

//! DTGrid3D destructor
template <typename T, typename K>
DTGrid2D<T,K>::~DTGrid2D(){
	delete proj1D;
	delete Value_List_2D;
	delete Ycoord_List;
	delete Ptr_List_2D;
}

//! DTGrid2D 'value' array setup
/*!
 *
 * Read the 2D 'value' array and store.
 * \param values pointer to the array that stores the 'value' array of DTGrid2D.
 * \param length length of the 'value' array.
 */
template <typename T, typename K>
void DTGrid2D<T,K>::set_value_list_2D(K* values, int length){
	Value_List_2D = new (std::nothrow) ArrayPrs <K>;
	Value_List_2D->Set_Pair_Array_Values(values,length);
	Length_of_Value_List_2D = length;
}

//! yCoord array setup
/*!
 * Read and store the yCoord array that stores in minimum and maximum coordinates of the connected components in y direction.
 * \param values the pointer that addresses to the values of yCoord array.
 * \param length the length of the yCoord array.
 */
template <typename T, typename K>
void DTGrid2D<T,K>::set_ycoord_list(K* values, int length){
	Ycoord_List = new (std::nothrow) ArrayPrs <K>;
	Ycoord_List->Set_Pair_Array_Values(values,length);
	Length_of_Ycoord_List = length;
}

//! acc (2D) array setup
/*!
 * Read and store the list of pointers to the first member of each of the connected components in a 2-dimensional DT-Grid.
 * \param values pointer to the array that stores the acc array indices.
 * \param length length of the acc array.
 */
template <typename T, typename K>
void DTGrid2D<T,K>::set_ptr_list_2D(K* values, int length){
	Ptr_List_2D = new (std::nothrow) ArrayPtr <T,K>;
	Ptr_List_2D->Set_Pointer_Array_Values(Value_List_2D->PArray,values,Length_of_Value_List_2D,length);
	Length_of_Ptr_List_2D = length;
}

//! proj2D setup
/*!
 * Create an instance of a DTGrid1D class and set up the proj1D object that contain xCoord, acc and the 'value' arrays of DTGrid1D.
 * \param values1 pointer to the 'value' array of the DTGrid1D.
 * \param values2 pointer to the xCoord array of the DTGrid1D.
 * \param values3 pointer to the acc array of the DTGrid1D.
 * \param length1 length of the 'value' array.
 * \param length2 length of the xCoord array.
 * \param length3 length of the acc array.
 */
template <typename T, typename K>
void DTGrid2D<T,K>::set_projection1D(K* values1, K* values2, K* values3, int length1, int length2, int length3){
	proj1D = new (std::nothrow) DTGrid1D <T,K>;
	proj1D->set_value_list_1D(values1,length1);
	proj1D->set_xcoord_list(values2,length2);
	proj1D->set_ptr_list_1D(values3,length3);
}

//! Reset pointers that temporarily store addresses for random access. Similar to that for DT-Grid3D.
/*!
 * The function is not required when the pointers are not used as global variables.
 */
/*template <typename T, typename K>
void DTGrid2D<T,K>::Reset_pointers_2D(void){
	Value_List_2D->Reset_Set_Pair_Array_Values();
	Ycoord_List->Reset_Set_Pair_Array_Values();
	Ptr_List_2D->Reset_Set_Pointer_Array_Values();
	proj1D->Reset_pointers_1D();
}*/

//! Random access function of DTGrid2D class.
/*!
 *
 * \param a index x of the data value to be returned
 * \param b index y of the data value to be returned
 *
 */
template <typename T, typename K>
typename ArrayPrs <K>::PairArray * DTGrid2D<T,K>::accessxy(int a, int b){
	
	// Call the DTGrid1D random access function.
	typename ArrayPrs <K>::PairArray * coord2 = proj1D->accessx(a);

	// Return NULL if recursive function call returns NULL.
	if (coord2 == NULL) return NULL;

	bool key2 = false; // a local logical operation variable.

	K checkpoint_21 = coord2->v2; // the index of the first connected component in a tubular grid in the yCoord array.
	K checkpoint_22 = (coord2+1)->v2; // the index of the last connected component in a tubular grid in the yCoord array.
	K countdown_2 = checkpoint_22 - checkpoint_21; // Determine the number of connected components in the corresponding 2D tubular grid.
	
	// Return NULL when no connected component found
	if (countdown_2 == 0){ return NULL;}

	typename ArrayPrs <K>::PairArray ** ptt2 = Ptr_List_2D->PtrArray+checkpoint_21; // a temporary pointer to store an acc array member.
	typename ArrayPrs <K>::PairArray * coo2 = Ycoord_List->PArray+checkpoint_21; // a temporary pointer to store an yCoord array pair.
	
	// iterate over the connected components in DTGrid2D
	for (; countdown_2 >= 1; countdown_2--){
		// check whether index b is inside one of the connected components using the yCoord index array.
		key2 = b>=coo2->v1 ? (b<=coo2->v2 ? true : false) : false;
		if (key2 == true){
			return *(ptt2)+b-coo2->v1;
		}
		else {
			// increment the pointers to the next connected component
			++ptt2;
			++coo2;
			continue;
		}
	}
	return NULL;
}

/*template <typename T, typename K>
void DTGrid2D<T,K>::getVoxelyz(T * Voxel, int x, int b, int c, typename ArrayPrs <K>::PairArray * coord2){

	short skey2 = 0;
	int binc = b+1;

	K checkpoint_21 = coord2->v2;
	K checkpoint_22 = (coord2+1)->v2;
	K countdown_2 = checkpoint_22 - checkpoint_21;

	if (countdown_2 == 0){ return 0;}

	typename ArrayPrs <K>::PairArray ** ptt2 = Ptr_List_2D->PtrArray+checkpoint_21;
	typename ArrayPrs <K>::PairArray * coo2 = Ycoord_List->PArray+checkpoint_21;

	for (; countdown_2 >= 1; countdown_2--){
		skey2 = b>=coo2->v1 ? (binc<=coo2->v2 ? 1 : 2 ) : (binc>=coo2->v1 ? 3 : 0);
		switch (skey2)
		{
		case 0:
			++ptt2;
			++coo2;
			break;
		case 1:
			getVoxelz(Voxel, x,0,c, *(ptt2)+b-coo2->v1);
			//++b;
			getVoxelz(Voxel, x,1,c, *(ptt2)+binc-coo2->v1);
			return;
		case 2:
			getVoxelz(Voxel, x,0,c, *(ptt2)+b-coo2->v1);
			return;
		case 3:
			getVoxelz(Voxel, x,1,c, *(ptt2)+binc-coo2->v1);
			return;
		}
	}
	return;
}*/

#endif /* DTGRID2D_HPP_ */
