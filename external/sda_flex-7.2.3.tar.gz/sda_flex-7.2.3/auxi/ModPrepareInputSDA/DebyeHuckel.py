#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>

#import logging
import math
#import pylab

# on cluster, certainly not available...need a test ??
# not available at home
#import matplotlib.pyplot as plt

"""
    Debye-Huckel approximation of a charged solute
     
    
"""

epssol = 78.5  # Solvent relative permittivity epssol = 78.5
epsi_o = 8.854187817e-12  # Vacuum permittivity [A^2 s^4 Kg^-1 m^-3]
rcnst = 1.987e-3  # Gas constant here expressed in kcal/(mol.K)
rcnstj = 8.314472  # Gas constant [joule mol^-1 K^-1]
kcnst = 1.3806503e-23  # Boltzmann constant [kg m^2 s^-2 K^-1]
e_q = 1.602176487e-19  # Elementary charge [A s]
temper = 300  # Temperature [K]
navo = 6.0221415e+23         # Avogadro number [mol^-1]


class DebyeHuckel:

    def __init__(self, charge, radius_sphere, ionic_strength, bin_width, distance_max):

        self.charge = charge
        self.radius_sphere = radius_sphere*1e-10  # in meter
        self.ionic_strength = ionic_strength*1000  # given in mol/l converted mol/m3
        self.distance_max = distance_max
        self.bin_width = bin_width
        self.potential = None
        # bjerrum length ( in meter ??)
        self.bjerrum = None
        # inverse of dh length ( in meter^-1 )
        self.ki = None
        # debye-huckecl length ( in angstrom ) == 1 / ki
        self.dl = None
        # counter used only when checking size_cutoff, not need to be "self"
        #self.counter        = 0
        self.potential_list = []
        self.distance_list = []

        # compute ki and bjerrum only once
        self.setup_parameters()

    def setup_parameters(self):
        """ precompute the ki, invers debye length"""
        '''ki = inverse of Debye-Hueckel length [1/m]'''

        self.bjerrum = float(
            e_q * e_q / (4*math.pi * epsi_o * epssol * kcnst * temper))  # in meter
        bjerrum_angstrom = self.bjerrum * 10**10
        print("bjerrum ", self.bjerrum)
        print('bj angs', bjerrum_angstrom)

        self.ki = math.sqrt(8*(math.pi) * self.bjerrum *
                            navo * self.ionic_strength)  # in meter^-1
        print('ki', self.ki)

        self.dl = ((1/self.ki)*10**10)  # in angstrom
        print("dl", self.dl)

    def compute_debye(self):
        """ Fill potential array """

        #print "Entry compute debye"
        nb_bin = self.distance_max / self.bin_width

        for bin in range(1, nb_bin+1):

            distance = bin * self.bin_width * 1e-10  # in meter
            self.distance_list.append(distance)

            #self.potential= float (self.charge*self.charge*self.bjerrum*(math.e)**(-self.ki*(distance-self.radius_sphere)) / (distance*(1+self.ki*self.radius_sphere)))
            self.potential = float(self.charge * self.bjerrum*(math.e)**(-self.ki*(
                distance-self.radius_sphere)) / (distance*(1+self.ki*self.radius_sphere)))

            self.potential_list.append(self.potential)

        # too much requirement
        # self.plot()

    def give_cutoffs(self, b_throw_error=False):
        """
            For different cutoffs in energy, return the minimum size needed.

            return a dictionary with order / size(in A), order could be a parameter of the function.

            If b_throw_error is True, thrown an exception if we cannot determine the size at 10^-2 kT
        """

        #print "Entry give_cutoffs "

        # dictionary order (2,3..4) / size
        dict_cutoffs = {}
        # useful ?? will use for the order
        counter = 0

        for j in range(len(self.potential_list)):

            if abs(float(self.potential_list[j])) < 1e-2 and counter == 0:
                print("Energy is smaller than 1e-2 kT: %e when the distance is bigger than %d Angstrom" % (
                    self.potential_list[j],  self.distance_list[j]*1e+10))
                counter = counter + 1
                dict_cutoffs[counter+1] = self.distance_list[j]*1e+10

            if abs(float(self.potential_list[j])) < 1e-3 and counter == 1:
                print("Energy is smaller than 1e-3 kT: %e when the distance is bigger than %d Angstrom" % (
                    self.potential_list[j], self.distance_list[j]*1e+10))
                counter = counter + 1
                dict_cutoffs[counter+1] = self.distance_list[j]*1e+10

            if abs(float(self.potential_list[j])) < 1e-4 and counter == 2:
                print("Energy is smaller than 1e-4 kT: %e when the distance is bigger than %d Angstrom" % (
                    self.potential_list[j], self.distance_list[j]*1e+10))
                counter = counter + 1
                dict_cutoffs[counter+1] = self.distance_list[j]*1e+10

        # need to test if not achieved full convergence
        if counter != 3:
            print("Cannot achieve convergence for order %d and higher " % (
                counter + 2))

        ##
        if counter == 0:
            raise Exception(
                "Debye-Huckel, cannot determine the box size for the threshold of 10E-2 kT")

        #print "dict_cutoffs ", dict_cutoffs
        return dict_cutoffs

    # Should always be optional, on the cluster library certainly not installed, for sure not working
    def plot(self):

        plt.plot(self.potential_list, self.distance_list, linewidth=5)
        pylab.xlabel('Solute radius (A)')
        pylab.ylabel('Potential of mean force (kT)')
        pylab.title('Debye-Huckel graph')
        pylab.show()


if __name__ == "__main__":
    """
        Example to run the module Debye-Huckel
    """

    print("execute main debyeHuckel")
    # def __init__(self, charge, radius_sphere, ionic_strength, bin_width, distance_max):
    debye = DebyeHuckel(1, 2, 0.001, 1, 400)
    potential = debye.compute_debye()

    dict_cutoffs = debye.give_cutoffs()
    print("dictionary cutoffs")
    print(dict_cutoffs)
