#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>


import os
import sys
import numpy

from Bio.PDB.Polypeptide import Polypeptide, _PPBuilder
# many small function in Polpypetide
from Bio.PDB.Polypeptide import *

"""
Polypeptide DNA is an extension of the group polypeptide.
Try to read DNA/RNA, to read the chain (for MW), and detect if DNA or RNA
"""

import warnings

#from Bio.Alphabet import generic_protein
from Bio.Seq import Seq
# Editted by Xiaofeng, this to_one_letter_code can not be imported because Bio.SCOP.Raf does not have this method
# Need a replacement but not sure what this method does
#from Bio.SCOP.Raf import to_one_letter_code
#from Bio.PDB.PDBExceptions import PDBException
#from Bio.PDB.Residue import Residue, DisorderedResidue
#from Bio.PDB.Vector import calc_dihedral, calc_angle

standart_dna_name = ["A", "T", "G", "C", "U", "DA", "DT", "DG", "DT", "DU",
                     "RA", "RC", "RT", "RG", "RU"]

# extend is_aa function


def is_dna(residue):
    """Added to original file"""

    #print "is_dna residue ", residue, residue.get_resname()
    short_name = residue.get_resname().replace(' ', '')
    if short_name in standart_dna_name:
        # if residue.get_resname() in standart_dna_name:
        #print 'return True'
        return True
    else:
        return False

# main class to extend
# class Polypeptide_DNA( Polypeptide (list) ):


class Polypeptide_DNA (Polypeptide):

    def __init__(self):
        Polypeptide.__init__(self)

    def get_sequence(self):
        """Return the DNA sequence as a Seq object.
        @return: polypeptide sequence 
        @rtype: L{Seq}
        """
        #print " entry get sequence dna "

        s = ""
        for res in self:
            #print "res name ", res.get_resname()
            resn = res.get_resname()
            #print "resn2 ", resn[:2]
            #s += to_one_letter_code.get(res.get_resname(), 'X')

            if (resn[0] == "A") | (resn[:2] == "DA"):
                s += "A"
            if (resn[0] == "T") | (resn[:2] == "DT"):
                s += "T"
            if (resn[0] == "C") | (resn[:2] == "DC"):
                s += "C"
            if (resn[0] == "G") | (resn[:2] == "DG"):
                s += "G"
            if (resn[0] == "U") | (resn[:2] == "DU"):
                s += "U"
            if (resn[:2] == "RA"):
                s += "A"
            if (resn[:2] == "RT"):
                s += "T"
            if (resn[:2] == "RG"):
                s += "G"
            if (resn[:2] == "RC"):
                s += "C"
            if (resn[:2] == "RU"):
                s += "U"

        #print "s ", s
        seq = Seq(s, generic_protein)
        return seq


# Parser done apart, as often in Biopython
class DNABuilder(_PPBuilder):
    """Extension of the _PPBuilder
    """

    def __init__(self, radius=7.5):
        """ used to see if residues are connected, need to adapt in case of DNA/RNA 
            Can Fox1- model DNA, 6.49
        """
        _PPBuilder.__init__(self, radius)
        #print "initialize DNABuilder "

    def _accept(self, residue, standard_aa_only):
        """Check if the residue is a base-pair (PRIVATE)."""

        # if is_aa(residue, standard=standard_aa_only):
        #    return True
        # elif not standard_aa_only and "CA" in residue.child_dict:
        # It has an alpha carbon...
        # We probably need to update the hard coded list of
        # non-standard residues, see function is_aa for details.
        #    warnings.warn("Assuming residue %s is an unknown modified "
        #                  "amino acid" % residue.get_resname())
        #    return True

        if is_dna(residue):
            #print "residue %s force True dna ", residue
            return True

        else:
            # not a standard dna name so skip
            return False

    def _is_connected(self, prev_res, next_res):

        #print "is connected prev_res, next_res ", prev_res, next_res
        for r in [prev_res, next_res]:
            if not r.has_id("P"):
                return False

        n = next_res["P"]  # original CA
        p = prev_res["P"]

        # Unpack disordered
        # if n.is_disordered():
        #    nlist=n.disordered_get_list()
        # else:
        #    nlist=[n]
        # if p.is_disordered():
        #    plist=p.disordered_get_list()
        # else:
        #    plist=[p]

        # disorderd
        nlist = [n]
        plist = [p]
        for nn in nlist:
            for pp in plist:
                if (nn-pp) < self.radius:
                    #print "_is_connected_dna return true ", nn-pp
                    return True

        print("_is_connected_dna return False, check your structure ")
        return False

    def build_peptides(self, entity, aa_only=1):
        """Build and return a list of Polypeptide objects.

        @param entity: polypeptides are searched for in this object
        @type entity: L{Structure}, L{Model} or L{Chain}

        @param aa_only: if 1, the residue needs to be a standard AA
        @type aa_only: int
        """
        is_connected = self._is_connected
        accept = self._accept
        level = entity.get_level()
        # Decide wich entity we are dealing with
        if level == "S":
            model = entity[0]
            chain_list = model.get_list()
        elif level == "M":
            chain_list = entity.get_list()
        elif level == "C":
            chain_list = [entity]
        else:
            print("Error Entity should be Structure, Model or Chain.")
            raise PDBException("Entity should be Structure, Model or Chain.")

        pp_list = []
        for chain in chain_list:
            chain_it = iter(chain)
            try:
                prev_res = chain_it.next()
                while not accept(prev_res, aa_only):
                    prev_res = chain_it.next()
            except StopIteration:
                # No interesting residues at all in this chain
                print("Not interesting base for dna prev_res ", prev_res)
                continue
            pp = None
            for next_res in chain_it:
                if accept(prev_res, aa_only) \
                        and accept(next_res, aa_only) \
                        and is_connected(prev_res, next_res):
                    if pp is None:
                        pp = Polypeptide_DNA()
                        pp.append(prev_res)
                        pp_list.append(pp)
                    pp.append(next_res)
                else:
                    # Either too far apart, or one of the residues is unwanted.
                    # End the current peptide
                    pp = None
                prev_res = next_res

        #print "build peptide, dna ", pp_list
        return pp_list
