#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>

import sys
import os
import imp
import logging

import pybel
import openbabel
from openbabel import OBMol, OBMolAtomIter, OBResidueIter

## import pdb2pqr
# pdb2pqrClasses = ExtProgPath().PDB2PQRCLASSES

# need to setup path in PYTHONPATH or add absolute path as second argument
#  print "sys.path ", sys.path

# here sure to load propka pdb, if pdb2pqr load
fp, pathname, description = imp.find_module('propka')
logging.info("tuple %s %s %s", fp, pathname, description)
propka_mod = imp.load_module('propka', fp, pathname, description)

# works as well, but will load some pdb2pqr file ??
#pdb2pqr_mod = imp.load_module ( 'pdb2pqr', fp, pathname, description )
#print "propka_mod ", propka_mod

#from pdb2pqr import *
# modules exisiting only in propka
from Source.ligand import *
# if pdb2pqr is loaded first
#from propka30.Source.ligand import *

# imported with ligand
#import Source.protonate
#import Source.bonds

# module exists in both, which one is loaded ! seems propka
#import pdb
from pdb import *
# import propka30/propka.py as propka

from Transformers import *

logging.info("ModAddH before loading Interface PDB2PQR")
# safer to not load all function (avoid similar name)
import InterfacePDB2PQR
# from Inter

""" 
    Module for dealing with ligands.
    - adding hydrogens with OpenBabel and/or PDB2PQR
    
    biopython used as general tool for dealing  with the structure
    
    Mol2 files seem necessary for PDB2PQR/PROPKA_30 to deal with ligands
    Format of Mol2 are slightly different with Fconv and obabel  
"""

# First use test, needed for ligand is to use residue
# ObResidue does not implement AddHydrogen, ObMol can deal with many residues


class LigandObabel(OBMol):
    """
        Class which is specialized for ligands, usually one single residue.
        ObResidue implements already many function, but not AddHydrogens,

        ObMol more functions available.
        For the moment, with split_ligand, each ligand is a different OBMol
    """

    # can add other arguments
    def __init__(self):
        """ Constructor"""

        #print "Constructor LigandObabel"
        # no argument in default constructor
        OBMol.__init__(self)

        self.formal_charge = 0.  # None
        self.partial_charge = 0.  # None

        # may set HETATM by default for ligand

    def getResnum(self):
        """ Used ? """
        #print "Entry getResNum() "
        #print "obabel mol ", self

        # only one resiude until now
        for res in OBResidueIter(self):
            #    print "residue ", res
            #    print "res.GetNum() ", res.GetNum()
            #    print "res.GetName() ", res.GetName()
            return res.GetNum()

    def print_info_ligand(self, b_all_atoms=False):
        """ Print info about the obabel ligand.

            Function name identical for obabel/propka

            All print taken from C++ API
        """

        print("\n Entry print info ligand openbabel, assume only one residue ")

        print("\n==obmol info==")
        print("num obmol residues ", self.NumResidues())
        print("num obmol atoms ", self.NumAtoms())
        print("num obmol bonds ", self.NumBonds())

        print("\n==Residue info==")
        print("residue 0", self.GetResidue(0))
        print("resname ", self.GetResidue(0).GetName())
        print("residue nb atoms ", self.GetResidue(0).GetNumAtoms())
        print("residue number ", self.GetResidue(0).GetNum())

        print("residue char ",  self.GetResidue(0).GetChain())
        print("residue int ",  self.GetResidue(0).GetChainNum())
        print("residue Idx ", self.GetResidue(0).GetIdx())
        print("residue ResKey", self.GetResidue(0).GetResKey())

        print("\nFormal charges %f " % (self.formal_charge))
        print("Partial charges %f " % (self.formal_charge))

        # if b_all_toms print infos about all atoms
        if b_all_atoms:
            print("==atoms info ==")
            # for atom in self.
            for obatom in OBMolAtomIter(self):
                #print "obatom ", obatom
                print("AtomicNum %d " % obatom.GetAtomicNum())
                # type is setup automatically with SetAtomicNum
                print("Type %s " % obatom.GetType())
                print("Id %d " % obatom.GetId())
                # not assigned yet
                print("ImplicitValence %d " % obatom.GetImplicitValence())
                print("Mass %f " % obatom.GetExactMass())
                print("Formal charge %f " % obatom.GetFormalCharge())
                print("Partial charge %f " % obatom.GetPartialCharge())

        print("==End info ligand==")

    # move to specialized class, obabel for splitted ligand, each one is an OBMol
    def print_infos_splited_ligands(self):
        """ print info ligand obabel """

        print("\n Print Iinfos splitted ligands \n")

        #print "ob type %s ", self.GetType()
        #print "ob Id ", self.GetId()

        print("\n Info ligand Obabel \n")
        for model in self.pdb.get_list():
            for chain in model.get_list():
                print("chain: ", chain)

                for ligand in chain.list_pdbligand:

                    if inspect.isclass(type(LigandObabel())):
                        print("ligand derive from LigandObabel an OBMol")
                        #print "ob coord %f", obatom.GetVector()

                        print("NumAtoms ", ligand.NumAtoms())
                        print("NumResidues ", ligand.NumResidues())

                        # first try from C++ iter is different from python
                        #first_res = ligand.BeginResidues()
                        #print "first_res ", first_res

                        # second try
                        res_iter = OBResidueIter(ligand)
                        print("res_iter ", res_iter)
                        for res in res_iter:
                            print("res ", res)
                            print("res.GetChain() ", res.GetChain())
                            print("res.GetChainNum() ", res.GetChainNum())
                            print("res.GetIdx() ", res.GetIdx())
                            print("res.GetNum() ", res.GetNum())

                        # iterator over residues
                        # for residue in ligand.G
                        #print "GetIdx (internal) %d ", ligand.GetIdx()
                        #print "GetNum() ", ligand.GetNum()
                        #print "GetName() ", ligand.GetName()

    def addH(self, pH, chargemodel):
        """ Add Hydrogens to ligands, name is confusing
            Use one of the charge model provided by openbabel

            May test for proteins later
        """

        print("Entry LigandOBabel.addH pH ", pH)

        ff = openbabel.OBChargeModel.FindType(chargemodel)
        #print  "ff selected ", ff

        # All methods not available by all versions
        if ff == None:
            print(("Charge model  %s is not available in this version " %
                   chargemodel))
            # continue
            return Exception("Charge model  %s is not available in this version " % chargemodel)

        # Very Important to correct for pH, now almost all methods give -4
        self.AddHydrogens(False, True, pH)
        #self.mol.OBMol.AddHydrogens( False )
        print("after AddHydrogens AtomNums ", self.NumAtoms())
        print("after AddHydrogens BondNums ", self.NumBonds())

        # mmffCharges->ComputeCharges(inputMolecule))
        ff.ComputeCharges(self)

        sum_charge = 0.
        for charge in ff.GetPartialCharges():
            #print "partial charges ", charge
            sum_charge += charge

        self.partial_charge = sum_charge
        print("Total partial charge ", sum_charge)
        print("#############")

        sum_charge = 0.
        for charge in ff.GetFormalCharges():
            #print "formal charges ", charge
            sum_charge += charge

        self.formal_charge = sum_charge
        print("Total formal charge ", sum_charge)
        print("#############")


# used only for test by /Test)AddHydrogens,
# main code use LigandObabel(ObMol)
class MolObabel:

    """ 
        Class which uses OpenBabel to protonate a ligand (/protein)
        Different charges models can be used.
    """

    # eem , qeq, qtpie not in all versions of obabel
    LIST_CHARGEMODEL_BABEL = ["gasteiger", "mmff94", "qeq", "qtpie", "eem"]

    def __init__(self, pdb_filename, ph=7.4):

        #print "Constructor MolObabel ", pdb_filename
        self.pdb_filename = pdb_filename

        # load the first mol from a pdb file, return a new ObMol
        self.mol = pybel.readfile("pdb", pdb_filename).next()
        # load all molecules, (in case of NMR?)
        #mols = list(readfile("pdb", pdb_filename))
        self.ph = ph

    def write(self, chargemodel):
        """ Not sure if partial or formal charges are printed
            To check, seems partial
        """

        logging.info(
            "write protonated strcture with obabel in pqr and mol2 format ")

        outfilename = chargemodel + '_' + self.pdb_filename
        out_pqr_filename = outfilename.replace(".pdb", ".pqr")
        self.mol.write("pqr", out_pqr_filename, overwrite=True)

        out_mol2_filename = outfilename.replace(".pdb", ".mol2")

        #outfilename = chargemodel + '_' + self.pdb_filename
        self.mol.write("mol2", out_mol2_filename, overwrite=True)

        # mol2 need to be corrected before.
        # let like this for the moment and test the correction
        # to be done in an other function
        self.checkMol2(out_mol2_filename)

    def checkMol2(self, fileMol2):
        """ Copy from Stefan, SUBSTRCUTRE is said missing by PDB2PQR
            check mol2 file for BOND and SUBSTRUCTURE
            this is needed because fconv -w miss this
            Obabel miss as well

            For obabel, SUBSTRUCTURE is missing. To check what it means ?
            Atom name are identical, so creates duplicate.

            In case of simple insertion in the final protein strcture, not really
            needed of Mol2 intermediate
        """

        logging.info(
            "checkMol2 add SUBSTRCTURE and rename H for pdb2pqr, file version ")

        # U ligdig tool
        #content = U.readfile(fileMol2)
        with file(fileMol2) as f1:
            content = f1.read()
        f1.close()

        molecule = False
        atom = False
        bond = False
        substructure = False

        # need to rename the Hydrogens name as well
        # start at one and update
        h_number = 1

        # should go back at the origin of the file to rewrite
        f = open(fileMol2, "wb")
        for line in content.split('\n'):
            if line.startswith("@<TRIPOS>MOLECULE"):
                molecule = True
            if line.startswith("@<TRIPOS>ATOM"):
                atom = True
            if line.startswith("@<TRIPOS>BOND"):
                bond = True
                atom = False
            if line.startswith("@<TRIPOS>SUBSTRUCTURE"):
                substructure = True

            if len(line) > 0:

                # only if fconv
                if atom:
                    line = line.replace('_', ' ')

                    # need to replace H name for pdb2pqr

                f.writelines(line + "\n")
                if molecule:
                    f.writelines(fileMol2 + "\n")
                    molecule = False

        if not bond:
            f.writelines("@<TRIPOS>BOND\n")
        if not substructure:
            f.writelines("@<TRIPOS>SUBSTRUCTURE\n")
        f.close()

    # should add an option in final module
    def test_all_models(self):
        """ Only for test, test all charges models """

        logging.info("test_all_models with pybel/obabel: %s",
                     MolObabel.LIST_CHARGEMODEL_BABEL)

        for chargemodel in MolObabel.LIST_CHARGEMODEL_BABEL:

            logging.info("charge mod. %s", chargemodel)

            ff = openbabel.OBChargeModel.FindType(chargemodel)
            #print  "ff selected ", ff

            # All methods not available by all versions
            if ff == None:
                logging.info(
                    "Charge model  %s is not available in this version of openbabel", chargemodel)
                continue

            # Very important to correct for pH, now almost all methods give -4
            # bool polaronly=false, bool correctForPH=false, double pH=7.4
            self.mol.OBMol.AddHydrogens(False, True, self.ph)
            # self.mol.OBMol.AddHydrogens( False
            logging.info("after AddHydrogens AtomNums %s",
                         self.mol.OBMol.NumAtoms())
            logging.info("after AddHydrogens BondNums %s",
                         self.mol.OBMol.NumBonds())

            # mmffCharges->ComputeCharges(inputMolecule))
            ff.ComputeCharges(self.mol.OBMol)

            sum_charge = 0.
            for charge in ff.GetPartialCharges():
                #print "partial charges ", charge
                sum_charge += charge

            logging.info("Total partial charge %s", sum_charge)
            # print "#############"

            sum_charge = 0.
            for charge in ff.GetFormalCharges():
                #print "formal charges ", charge
                sum_charge += charge

            #print "Total formal charge ", sum_charge
            # print "#############"

            # only for tests
            #self.print_info( True )

            # write output in chargemodel_name.pqr
            self.write(chargemodel)

    # copy from LigandObabel code
    def print_info(self, b_all_atoms=False):
        """ Print info about the molecule

            Function name identical for obabel/propka

            All print taken from C++ API
        """

        print("\n Entry print info MolObabel, assume only one residue ")

        print("\n==obmol info==")
        print("num obmol residues ", self.mol.OBMol.NumResidues())
        print("num obmol atoms ", self.mol.OBMol.NumAtoms())
        print("num obmol bonds ", self.mol.OBMol.NumBonds())

        print("\n==Residue info==")
        print("residue 0", self.mol.OBMol.GetResidue(0))
        print("resname ", self.mol.OBMol.GetResidue(0).GetName())
        print("residue nb atoms ", self.mol.OBMol.GetResidue(0).GetNumAtoms())
        print("residue number ", self.mol.OBMol.GetResidue(0).GetNum())

        print("residue char ",  self.mol.OBMol.GetResidue(0).GetChain())
        print("residue int ",  self.mol.OBMol.GetResidue(0).GetChainNum())
        print("residue Idx ", self.mol.OBMol.GetResidue(0).GetIdx())
        print("residue ResKey", self.mol.OBMol.GetResidue(0).GetResKey())

        #print "\nFormal charges %f " % ( self.mol.OBMol.formal_charge )
        #print "Partial charges %f " % ( self.mol.OBMol.formal_charge )

        # if b_all_toms print infos about all atoms
        if b_all_atoms:
            print("\n==atoms info ==\n")
            # for atom in self.
            for obatom in OBMolAtomIter(self.mol.OBMol):
                #print "obatom ", obatom
                print("AtomicNum %d " % obatom.GetAtomicNum())
                # type is setup automatically with SetAtomicNum
                print("Type %s " % obatom.GetType())
                print("Id %d " % obatom.GetId())
                # not assigned yet
                print("ImplicitValence %d " % obatom.GetImplicitValence())
                print("Mass %f " % obatom.GetExactMass())
                print("Formal charge %f " % obatom.GetFormalCharge())
                print("Partial charge %f " % obatom.GetPartialCharge())

        print("==End info ligand==")


# no need an object, only an intermediate to generate propka type of ligand
# only static methods : convenient, but limited if many conversion

# moved Transformers into independent file, to delete
# class Transformers:
#
#     @staticmethod
#     def Mol2ToPDB ( filename, output_prog ): #, input_prog
#
#         print "Entry Transformers : Mol2ToPDB "
#         #print "prog_input ", input_prog
#         print "prog output ", output_prog
#
#         if "mol2" in filename:
#
#             print "mol2 file"
#
#             if output_prog == "propka":
#                 Transformers.getAtomsMol2( filename )
#
#
#
#     @staticmethod
#     def getAtomsMol2( filename ):
#         """
#             Read mol2 file generated by fconv originally
#             Use openBabel, pybel to transform to PDB and use again readPDB ( seems only call version readPDB of propka )
#             finally set self.atoms of propka.ligand
#         """
#
#         #ligandPybel = None
#         #if os.path.dirname(self.mol2[0]) == "":  ## path to mol2 file
#         #    self.mol2File = self.dirIn + self.mol2[0]
#         #else:
#         #    self.mol2File = self.mol2[0]
#         print "self.mol2file ", filename
#
#         ### need dictionary like ligdig if read fconv
#         #self.chain = (self.mol2[1])[-1]  ## chain name got from file name
#         #self.residue = self.mol2[1]  ## residue name/number got from file name ##"UDP 900 A"
#         #self.ligandTemp = self.dirIn + "ligTemp_" + str(self.ligandNumber) + ".pdb"
#         #print "ligTemp:",self.ligandTemp
#         ligandTemp = "new_pdb_afterpybabel.pdb"
#
#         ligandPybel = pybel.readfile("mol2", filename ).next()
#
#         # set correct chain
#         #for atom in ob.OBMolAtomIter(self.ligandPybel.OBMol):  ## set chain name
#         #    atom.GetResidue().SetChain(self.chain)
#         ligandPybel.write( "pdb", ligandTemp, overwrite=True )
#
#
#         ### here should be in normal Ligand
#         ## now reuse pdb.readPDB to load a pdb, code from Propka
#         #ligandAtoms = pdb.readPDB(self.ligandTemp, tags=["ATOM", "HETATM"])
#         #print pdb
#         #print pdb.readPDB
#         # print info
#         #print "chain", self.chain, "residue", self.residue
#         #print self.ligandAtoms
#         #return self.ligandAtoms[self.chain][self.residue]
#
#         #print "ligandatoms ", ligandAtoms
#         #return ligandAtoms

"""
    Derived class from ligand (propka), add functionalities.
    
    Default, read only PDB and extract "atoms".
    mol2 files, only read by pdb2pqr pdb.py
"""


class LigandPDB2PQR(ligand):

    # ligandPDB2PQR is a ligand self.atoms valid
    def __init__(self, atoms=None, propka=False, pH=7.):
        """
           add atoms, it is in the base class of ligands.
           file = "mol2" / "pdb"
        """
        # clean initialisation of base class
        ligand.__init__(self, atoms)

        self.propka = propka
        self.pH = pH
        print("Init LigandPDB2PQR")
        print("propka ", self.propka)
        print("pH ", self.pH)

        print("list atoms ")
        # self.__str__() # not working ??
        res = '----Ligand----\n'
        for atom in self.atoms:
            res += '%s\n' % atom
        res += '--------------'
        print(res)

        # set up the ligand object, it is a ligand
        # self.ligand = MyLigand(mol2=ligandMol2, dirIn=inputFileDir))
        self.atomNumber = 0  # sum of all ligand atoms

    def assignAtomNames(self):
        '''protonate ligand mol2 file for using in pdb2pqr'''

        # if propka:
        #    self.propka = True

        # for ligand in self.listLigands:

        protonator = protonate.Protonate()
        # removing hydrogen atoms makes it much faster
        # but adding hydrogens cause problems in matching to input mol2 files
        protonator.remove_all_hydrogen_atoms_from_ligand(ligand)

        # run propka for ligand. This takes long time!
        if self.propka:  # and ligand.propka != True:
            ligand.runPropka()
            ligand.propka = True

        # assign sybyl names, before or after propka ??
        ligand.assign_atom_names()  # assign atom types using propka/ligand.py

        # adding protons
        # protonator.protonate_ligand(ligand)

        #ligand.firstAtomNumber = ligand.atomNumber + 1
        #ligand.atomNumber += ligand.atomNumber

        write("fill dict for SYBYL atom types, used by ??? ")
        for atom in ligand.atoms:  # fill dict for SYBYL atom types
            ligand.atomTypeMapping[atom.numb] = atom.name
            print(atom.numb, atom.name)

        print("end assign atom names")
        return

    # working in library ?? can generate hydrogens ??
    def runPropka(self):
        # run propka for ligand. This takes long time!
        protonator = protonate.Protonate()
        protonator.remove_all_hydrogen_atoms_from_ligand(self)
        ## print type(self.atoms),len(self.atoms),self.atoms
        protonator.protonate_ligand(self)
        #self.propka = True

    # function used by Stefan to convert mol2 generated by fconv to a mol2 read by PDB2PQR.
    # assign_atoms_names(self)
    def assign_sybyl_names(self):
        """
        From Stefan code.
        Assigns sybyl names to ligand atoms based on elements and coordinates 
        copied from propka/ligand.py 
        modified: 
        P -> P3
        O.co2+ - > O.co2
        """

        print("LigandPDB2PQR:assign_sybyl_names ")

        # find bonding atoms
        self.my_bond_maker = bonds.bondmaker()
        self.my_bond_maker.find_bonds_for_atoms(self.atoms)
        # self.my_bond_maker.find_bonds_for_ligand(self.atoms)

        for atom in self.atoms:
            #print atom.__dict__
            print(atom.numb, atom.name, atom.get_element())

            # check if we already have assigned a name to this atom
            if hasattr(atom, 'sybyl_assigned'):
                print((atom.resName, atom.numb, atom.name, 'already assigned'))
                continue

            # find some properties of the atom
            ring_atoms = self.is_ring_member(atom)
            aList = []
            for a in ring_atoms:
                aList.append(a.numb)
            #print "ring_atoms",len(ring_atoms),aList

            # here, the planarity of the ring atoms are checked
            aromatic = self.is_aromatic_ring(ring_atoms)
            planar = self.is_planar(atom)
            #print "aromatic",aromatic, "planar",planar

            bonded_elements = {}
            for i in range(len(atom.bonded_atoms)):
                bonded_elements[i] = atom.bonded_atoms[i].get_element()

            # Aromatic carbon/nitrogen
            if aromatic:
                #print "--- if aromatic",atom.resName, atom.numb, atom.name, atom.get_element()
                # for ra in ring_atoms:
                #    if ra.get_element() in ['C', 'N']:
                #        self.set_type(ra, ra.get_element() + '.ar')
                # continue
                '''SH: In the original version, if a ring is planar (eg., 4FXF_D_FBP_606)
                but contains other atoms than C or N the loop breaks without assigning these atoms
                '''
                if atom.get_element() in ['C', 'N']:
                    self.set_type(atom, atom.get_element() + '.ar')
                    continue

            # check for amide
            if atom.get_element() in ['O', 'N']:
                #print "--- if O/N",atom.resName, atom.numb, atom.name, atom.get_element()
                amide = 0
                for b in atom.bonded_atoms:
                    if b.element == 'C':
                        for bb in b.bonded_atoms:
                            if (bb.get_element() == 'N' and atom.get_element() == 'O'):
                                self.set_type(bb, 'N.am')
                                self.set_type(b, 'C.2')
                                self.set_type(atom, 'O.2')
                                amide = 1
                            if (bb.get_element() == 'O' and atom.get_element() == 'N'):
                                self.set_type(atom, 'N.am')
                                self.set_type(b, 'C.2')
                                self.set_type(bb, 'O.2')
                                amide = 1
                if amide == 1:
                    continue

            if atom.get_element() == 'C':
                #print "--- if C",atom.resName, atom.numb, atom.name, atom.get_element()
                # check for amide
                if 'O' in list(bonded_elements.values()) and 'N' in list(bonded_elements.values()):
                    self.set_type(atom, 'C.2')
                    for b in atom.bonded_atoms:
                        if b.get_element() == 'N':
                            self.set_type(b, 'N.am')
                        if b.get_element() == 'O':
                            self.set_type(b, 'O.2')
                    continue

                # check for carboxyl
                if len(atom.bonded_atoms) == 3 and list(bonded_elements.values()).count('O') == 2:
                    i1 = list(bonded_elements.values()).index('O')
                    i2 = list(bonded_elements.values()).index('O', i1 + 1)
                    if len(atom.bonded_atoms[i1].bonded_atoms) == 1 and len(atom.bonded_atoms[i2].bonded_atoms) == 1:
                        #self.set_type(atom.bonded_atoms[i1], 'O.co2+')
                        # SH: problems in 1a3w
                        self.set_type(atom.bonded_atoms[i1], 'O.co2')
                        self.set_type(atom.bonded_atoms[i2], 'O.co2')
                        self.set_type(atom, 'C.2')
                        continue

                # sp carbon
                if len(atom.bonded_atoms) <= 2:
                    for b in atom.bonded_atoms:
                        if self.my_bond_maker.squared_distance(atom, b) < max_C_triple_bond_squared:
                            self.set_type(atom, 'C.1')
                            self.set_type(b, b.get_element() + '.1')
                    if hasattr(atom, 'sybyl_assigned'):
                        continue

                # sp2 carbon
                if planar:
                    self.set_type(atom, 'C.2')
                    # check for N.pl3
                    for b in atom.bonded_atoms:
                        if b.get_element() == 'N':
                            if len(b.bonded_atoms) < 3 or self.is_planar(b):
                                self.set_type(b, 'N.pl3')
                    continue

                # sp3 carbon
                self.set_type(atom, 'C.3')
                continue

            # Nitrogen
            if atom.get_element() == 'N':
                #print "--- if N",atom.resName, atom.numb, atom.name, atom.get_element()
                # check for planar N
                if len(atom.bonded_atoms) == 1:
                    if self.is_planar(atom.bonded_atoms[0]):
                        self.set_type(atom, 'N.pl3')
                        continue

                if planar:
                    self.set_type(atom, 'N.pl3')
                    continue

                self.set_type(atom, 'N.3')
                continue

            # Oxygen
            if atom.get_element() == 'O':
                #print "--- if O",atom.resName, atom.numb, atom.name, atom.get_element()
                self.set_type(atom, 'O.3')
                # check for X=O
                if len(atom.bonded_atoms) == 1:
                    if self.my_bond_maker.squared_distance(atom, atom.bonded_atoms[0]) < max_C_double_bond_squared:
                        self.set_type(atom, 'O.2')
                        if atom.bonded_atoms[0].get_element() == 'C':
                            self.set_type(atom.bonded_atoms[0], 'C.2')
                continue

            # Sulphur
            if atom.get_element() == 'S':
                # check for SO2
                if list(bonded_elements.values()).count('O') == 2:
                    i1 = list(bonded_elements.values()).index('O')
                    i2 = list(bonded_elements.values()).index('O', i1 + 1)
                    self.set_type(atom.bonded_atoms[i1], 'O.2')
                    self.set_type(atom.bonded_atoms[i2], 'O.2')
                    self.set_type(atom, 'S.o2')
                    continue

                # check for SO4
                if list(bonded_elements.values()).count('O') == 4:
                    no_O2 = 0
                    for i in range(len(atom.bonded_atoms)):
                        if len(atom.bonded_atoms[i].bonded_atoms) == 1 and no_O2 < 2:
                            self.set_type(atom.bonded_atoms[i], 'O.2')
                            no_O2 += 1
                        else:
                            self.set_type(atom.bonded_atoms[i], 'O.3')

                self.set_type(atom, 'S.3')
                continue

            # Phosphorous (phosphorous sp3)
            #@attention: This was added and may not consider all types of phosphorous
            if atom.get_element() == 'P':
                self.set_type(atom, 'P.3')
                continue

            element = atom.get_element().capitalize()
            self.set_type(atom, element)
            #print('Using element as type for %s'%atom.get_element())
            #print atom.numb, atom.name
        return


"""
    Encapsulate the use of PDB2PQR for protein, a priori does not derive for any class and use InterfacePDB2PQR
    Maybe later derive from Protein class
    
    Only propka30 cannot deal with protein-ligand interaction, 31 could in principle
    
    todo : make more use of this class to store data, a bit mixed up now
"""


class ProteinPDB2PQR:

    def __init__(self, pH):

        logging.debug("print Init ProteinPDB2PQR")
        # add pH or any other general data
        self.pH = pH
        logging.debug("pH %f" % pH)

        # easy, later to derive directly from PDB2PQR:structure:Protein
        self.protein_pqr = None

    def addH(self, bioatoms):
        """
            A priori need a list of pdb2pqr:src:ATOM for running runPDB2PQR ( pdbfile input )
        """

        print("\n== Entry ProteinPDB2PQR:AddH ==\n")
        #print "bioatoms ", bioatoms
        logging.debug("ProteinPDB2PQR:AddH")
        #logging.debug("%s" % bioatoms)

        # create outout
        pdbqr_atoms = list()

        # transform to PDB2PQR atoms type
        Transformers.AtomsBioToPDBQR(bioatoms, pdbqr_atoms)

        # return : header, hitlist, missedligandresidues
        #header,list_pdbqr_atoms, missedligandresidues = InterfacePDB2PQR.runPDB2PQR( pdbqr_atoms, "amber", "out.pqr")
        # try to get the protein object
        self.protein_pqr, list_pdbqr_atoms, missedligandresidues = InterfacePDB2PQR.runPDB2PQR(
            pdbqr_atoms, "amber", "out.pqr", verbose="True")
        # runPDB2PQR("toto","amber","out.pqr")
        #print "header ", header
        #print "list:pdbqr_atoms:", list_pdbqr_atoms
        #print "missedligand:", missedligandresidues
        #print "self.protein_pqr ", self.protein_pqr

        # here transform back to biopython ??
        # not need of retrun if object is saved ! just store in self, or better derive from protein

        # certainly could be stored in self
        # list not used, better to set self.protein for retriving chain/residue
        return list_pdbqr_atoms, missedligandresidues

    def find_residue_PDBQR(self, chain_id, res_id):
        """
            Return the atom of a particular resiue
            Atoms are members of src.structures.Atom, notes from code 'The Atom class inherits off the ATOM object in pdb.py'

            Much easier if all data stored in PDB2PQR Protein  
        """

        #print "\n== Entry find_residue_PDBQR ==\n"
        #print "list_pdbqr_atoms", list_pdbqr_atoms
        #print "self, ProteinPQR ", self
        #print "chain_id:!!"+ chain_id +"!!!"
        #print "res_id:!!"+str(res_id)+"!!!"

        #logging.debug("\n== Entry find_residue_PDBQR ==\n")
        #logging.debug("self, ProteinPQR %s" % self )
        #logging.debug("chain_id:!!%s!!!" % (chain_id) )
        #logging.debug("res_id:!!%s!!" % str(res_id) )
        #print "number of chains ", len( self.protein_pqr.chains )

        list_pqr_atoms = list()

        # residue know about the chain, no need this loop
        # for chain in self.protein_pqr.chains:
        #    print "chain ", chain

        for residue in self.protein_pqr.getResidues():

            #print "pqr_atom ", pqr_atom
            #print "residue ", residue
            #print "type residue ", type ( residue )
            #print "residue get name ", residue.get("name")
            #print "residue get chain ", residue.get("chainID")
            #print "residue get resSeq ", residue.get("resSeq")

            if ((residue.get("chainID") == chain_id) & (residue.get("resSeq") == res_id)):

                #print "found correct chain and resSeq"
                for atom in residue.get("atoms"):
                    #    print "atom ", atom
                    list_pqr_atoms.append(atom)

        #print "\n== End find_residue_PDBQR ==\n"
        return list_pqr_atoms


if __name__ == "__main__":

    filename = sys.argv[1]
    option = sys.argv[2]

    print("pdb_filename ", filename)

    # testing, use directly propka with ligand to protonate it
    if ".pdb" in filename:

        print(' pdbfile ', filename)

        # example Propka, read atoms first and assign the ligands
        # readPDB is called by pdb2pqr which call propka readPDB !
        atoms = pdb.readPDB(sys.argv[1], tags=["ATOM", "HETATM"])

        # return dictionary, function GetAtoms from PROPKA not working anymore
        # added chain information in dictionary, need to extract the atoms
        for (key, value) in list(atoms.items()):
            print("key, value ", key, value)

            # contains one ligand, certainly many ligands by chains
            dict_ligand = value
            name_ligands = dict_ligand["keys"]
            print("name ligand ", name_ligands)

            for name in name_ligands:
                list_atoms = dict_ligand[name]
                print("list_atoms ", list_atoms)

                #my_ligand = ligand(atoms)
                #print "atoms : ", atoms.__repr__()
                my_ligand = LigandPDB2PQR(list_atoms)

                # equivalent to function runPROPKA
                protonator = protonate.Protonate()
                # assign sybyl names
                protonator.remove_all_hydrogen_atoms_from_ligand(my_ligand)
                my_ligand.assign_atom_names()

                my_ligand.writePDB('before_ligand_protonation.pdb')

                # protonate
                protonator.protonate_ligand(my_ligand)
                my_ligand.writePDB('after_ligand_protonation.pdb')

    # try to reproduce Stefan code with an already protonated ligand in mol2 format
    # first transform to pdb with pybel, then read with propka
    elif ".mol2" in filename:

        print("mol2 file")

        #my_ligand = LigandPDB2PQR( Transformers.Mol2ToPDB( filename ) )
        Transformers.Mol2ToPDB(filename, "propka")
        print("after transform Mol2 fconv to PDB")

        atoms = pdb.readPDB("new_pdb_afterpybabel", tags=["ATOM", "HETATM"])

        # return dictionary
        for (key, value) in list(atoms.items()):
            print("key, value ", key, value)

            # contains one ligand, certainly many ligands by chains
            dict_ligand = value
            name_ligands = dict_ligand["keys"]
            print("name ligand ", name_ligands)

            for name in name_ligands:

                list_atoms = dict_ligand[name]
                print("list_atoms ", list_atoms)

                #my_ligand = ligand(atoms)
                #print "atoms : ", atoms.__repr__()
                my_ligand = LigandPDB2PQR(list_atoms)
                my_ligand.assignAtomNames()

    else:
        print("cannot determine type of the file")
    # example protonate
    # protonator.protonate_ligand(my_ligand)
    # my_ligand.writePDB('after_ligand_protonation.pdb')

    #ligand = LigandPDB2PQR(filename, propka = False )
    #ligand.assignAtomNames() #
