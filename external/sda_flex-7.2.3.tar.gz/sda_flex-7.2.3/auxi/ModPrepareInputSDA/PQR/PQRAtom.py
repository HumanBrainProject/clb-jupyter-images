#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>

""" PQRParser, derive from PDBParser """
import os
import sys
import numpy
# need ?
from Bio.PDB.Atom import Atom


class PQRAtom(Atom):

    #print "load PDBParser()"
    #parser = PDBParser()

    # unique identifier
    #id_global = 0

    def __init__(self, name, coord, bfactor, occupancy, altloc, fullname, serial_number,
                 charge, radius, element=None):

        Atom.__init__(self, name, coord, bfactor, occupancy, altloc, fullname, serial_number,
                      element)
        # element=None)

        #print "init PQRatom "
        self.charge = charge
        self.radius = radius

        #print "set atom "
        #print "name ", self.name
        #print "element ", self.element
        #print "self.charge ",self.charge
        #print "self.radius ",self.radius
        self.occupancy = 0.
        self.bfactor = 0.
        #print "self.occupancy ",self.occupancy
        #print "repr ", self.__repr__

        # declare marker for Test charges on terminus, used for SDA and ecm tools
        self.term_tc = None
        #self.Cterm = False

    def set_charge(self, charge):
        """set the charge """
        self.charge = charge

    def get_charge(self):
        """Return occupancy."""
        return self.charge

    def set_radius(self, radius):
        """set radius"""
        self.radius = radius

    def get_radius(self):
        "Return VdW radius."
        return self.radius

    def set_resname(self, res):

        self.resname = res

    def set_term(self, str):
        """set the terminal, one of the string NTR, NTN, CTR, CTN """

        #print "set_term() "
        self.term_tc = str
        #print "set %s to %s" % ( self.__repr__(), str )

    def get_term(self):
        """Return terminal marker, None by default """

        return self.term_tc
