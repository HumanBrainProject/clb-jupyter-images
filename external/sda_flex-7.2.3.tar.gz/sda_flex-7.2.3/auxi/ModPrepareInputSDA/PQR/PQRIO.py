#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>

import logging
from Bio.PDB.PDBIO import *

#from PDBIO import *

# strange cannot load this ? copy from PDBIO header
#_ATOM_FORMAT_STRING_PQR="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%s%6.2f      %4s%2s%2s\n"
#_ATOM_FORMAT_STRING_PQR="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%s%6.2f      %4s%2s%2s\n"

# probelm with pdb2pqr Hydrogen e.g.HG11                                                                  charge,vdw      element (not need for apbs anyway)
#_ATOM_FORMAT_STRING_TEST="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%8.4f%7.4f       %2s\n"  #%5i %-4s%\n"

#_ATOM_FORMAT_STRING_TEST="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%8.4f%7.4f       %2s\n"
#_ATOM_FORMAT_PQR_STRING="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%8.4f%7.4f       %2s\n"

# format depends if hydrogen and 4 letters or else, check correct PDB, correct pdb2pqr


# with original format, manage to get output ! to keep
# last version seems to work, can reproduce pdb2pqr format
_ATOM_FORMAT_PQR_STRING = "%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%8.4f%7.4f       %2s\n"

# tests
#_ATOM_FORMAT_PQR_STRING="%s%5i %4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%8.4f%7.4f       %2s\n"


class PQRIO(PDBIO):

    def __init__(self, use_model_flag=0):
        """
        @param use_model_flag: if 1, force use of the MODEL record in output.
        @type use_model_flag: int
        """
        PDBIO.__init__(self, use_model_flag)

    # format for SDA output, need marker if termini are charged
    def _get_atom_line(self, atom, hetfield, segid, atom_number, resname,
                       resseq, icode, chain_id, charge="  "):
        """Returns an ATOM PDB string (PRIVATE)."""

        #print "_get_atom_line()"
        #logging.debug("Entry PQRIO::_get_atom_line()")

        if hetfield != " ":
            record_type = "HETATM"
        else:
            record_type = "ATOM  "

        if atom.element:
            #logging.debug("atom.elemnt %s" % atom.element)
            element = atom.element.strip().upper()

            if element.capitalize() not in atom_weights:
                raise ValueError("Unrecognised element %r" % atom.element)
            element = element.rjust(2)
        else:
            element = "  "
        name = atom.get_name()

        # fullname biopython start with a space
        fullname = atom.get_fullname()
        #fullname = "%-4s" % atom.get_fullname().strip()

        altloc = atom.get_altloc()
        x, y, z = atom.get_coord()
        bfactor = atom.get_bfactor()
        occupancy = atom.get_occupancy()
        charge = atom.get_charge()
        radius = atom.get_radius()

        #print "name ", name
        #print "resname ", resname
        #print "get_term ", atom.get_term()

        # not used for producing PQR
        str_term = atom.get_term()
        if str_term:
            logging.debug(
                "modification for charged terminal of res %s to %s" % (resname, str_term))
            #print "modif terminal for charged terminl of residue ", resname, " to ", str_term
            resname = str_term

#         print "before args "
#         print "record_type ", record_type
#         print "name:!!"+name+"!!"
#         print "fullname:!!"+fullname+"!!"
#         print "atom_number ", atom_number
#         print "chain_id ", chain_id
#         print "resseq ", resseq
#         print "icode ", icode
#         print "segid ", segid
#         print "element", element
#         print "charge", atom.get_charge()
#         print "vdw radius ", atom.get_radius()
#         print "element:!!"+atom.element+"!!"
#        logging.debug( "record_type %s!!"+record_type+"!!!" )
#        logging.debug( "name:!!"+name+"!!" )
#        logging.debug( "fullname:!!"+fullname+"!!" )

        # added because cannot reproduce correct formatting
        # i ok seems to work like this, PQRIO can format
        if len(fullname.strip()) == 4:
            #fullname = " %-4s" % fullname
            fullname = "%-4s" % fullname.strip()
            #logging.debug("H atom ")
        # else:
        #    fullname = " %4s" % fullname
        #logging.debug( "fullname2:!!"+fullname+"!!" )
        #logging.debug( "atom_number %d", atom_number )
        #logging.debug( "chain_id %d" % chain_id )
        #logging.debug( "resseq %d" % resseq )
        #logging.debug( "icode %s" % icode )
        #logging.debug( "segid %s" % segid)
        #logging.debug( "element:!!"+element+"!!" )
        #logging.debug( "altloc:!!"+altloc+"!!")
        #logging.debug( "charge %d" % atom.get_charge() )
        #logging.debug( "vdw radius %f" % (atom.get_radius()) )
        #logging.debug( "element:!!%2s!!", atom.element )

        # args=(record_type, atom_number, name, altloc, resname, chain_id,
        #    resseq, icode, x, y, z, occupancy, bfactor, segid,
        #    element, str(charge))
#_ATOM_FORMAT_PQR_STRING="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%8.4f%7.4f       %2s\n"
        args = (record_type, atom_number, fullname, altloc, resname, chain_id,
                #       icode
                resseq, " ",
                #        VdW, charge
                x, y, z, charge, radius, atom.element)  # icode) #, atom_number,name)

        #print "args ", args
        return _ATOM_FORMAT_PQR_STRING % args
