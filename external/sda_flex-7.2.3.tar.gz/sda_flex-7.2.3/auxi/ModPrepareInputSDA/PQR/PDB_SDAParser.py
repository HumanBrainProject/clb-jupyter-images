#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
""" PQRParser, derive from PDBParser """
import os
import sys
import numpy
import logging
from Bio.PDB import PDBParser
from Bio.PDB.PDBExceptions import \
    PDBConstructionException, PDBConstructionWarning


class PDB_SDAParser(PDBParser):

    def __init__(self, PERMISSIVE=True, get_header=False,
                 structure_builder=None, QUIET=False):

        # not sure if necessary
        PDBParser.__init__(self, PERMISSIVE, get_header,
                           structure_builder, QUIET)

        #print "PDB_SDAParser init"
        #print "access parent self.header ", self.header
        #print "access parent ", self.structure_builder
        #print "Quiet ", self.QUIET

    def _parse_coordinates(self, coords_trailer):
        """Parse the atomic data in the PDB file format of SDA: pqrnoh file
           No occupancy, No bfactor, no charge, no radius are recorded, must accept NTR/NTN as first residue
        """

        #print "_parse coordinates PDB_SDA "
        local_line_counter = 0
        structure_builder = self.structure_builder
        current_model_id = 0
        # Flag we have an open model
        model_open = 0
        current_chain_id = None
        current_segid = None
        current_residue_id = None
        current_resname = None

        logging.info("Entry PDB_SDAParse:PDB_SDAParser:parse_coordinates ")
        #print "structure_builder ", structure_builder

        # Case of reading NTR (first atom or CTR, normally not last)
        # First by default make a new residue
        postpone_res = False

        #print "coords_trialer ", len(coords_trailer)
        for i in range(0, len(coords_trailer)):
            line = coords_trailer[i]
            #print "line ", line

            record_type = line[0:6]

            global_line_counter = self.line_counter+local_line_counter+1
            structure_builder.set_line_counter(global_line_counter)

            if(record_type == 'ATOM  ' or record_type == 'HETATM'):
                # Initialize the Model - there was no explicit MODEL record
                if not model_open:
                    #print "init model"
                    structure_builder.init_model(current_model_id)
                    current_model_id += 1
                    model_open = 1

                fullname = line[12:16]

                # get rid of whitespace in atom names
                split_list = fullname.split()
                if len(split_list) != 1:
                    # atom name has internal spaces, e.g. " N B ", so
                    # we do not strip spaces
                    name = fullname
                else:
                    # atom name is like " CA ", so we can strip spaces
                    name = split_list[0]

                #print "name ", name
                #print "fullname ", fullname
                altloc = line[16:17]
                #print "altloc ", altloc
                resname = line[17:20]
                #print "resname ", resname
                chainid = line[21:22]

                if postpone_res:
                    #print "new resname ", resname, chainid
                    #structure_builder.rename_first_residue(current_chain_id, resname)
                    # assign the new name
                    structure_builder.residue.resname = resname
                    postpone_res = False

                # else:
                #    print "postpone is False"

                # what is serial number
                try:
                    serial_number = int(line[6:11])
                except:
                    serial_number = 0

                resseq = int(line[22:26].split()[0])   # sequence identifier
                #print "resseq ", resseq
                icode = line[26:27]           # insertion code

                if record_type == 'HETATM':       # hetero atom flag
                    if resname == "HOH" or resname == "WAT":
                        hetero_flag = "W"
                    else:
                        hetero_flag = "H"

                else:
                    hetero_flag = " "
                residue_id = (hetero_flag, resseq, icode)
                #print "residue_id ", residue_id
                # atomic coordinates
                try:
                    x = float(line[30:38])
                    y = float(line[38:46])
                    z = float(line[46:54])
                except:
                    # Should we allow parsing to continue in permissive mode?
                    # If so what coordindates should we default to?  Easier to abort!
                    raise PDBConstructionException(
                        "Invalid or missing coordinate(s) at line %i."
                        % global_line_counter)

                #print "coordinates ", x, y, z
                coord = numpy.array((x, y, z), 'f')
                # occupancy & B factor not used here
                occupancy = 0.0  # Is one or zero a good default ?
                bfactor = 0.0  # The PDB use a default of zero if the data is missing

                # all has been extracted

                # What do they try to read ??
                segid = line[72:76]
                element = line[76:78].strip()
                #print "segid /current segid ",segid, current_segid

                if current_segid != segid:
                    #print "different segid current new segid ", current_segid, segid
                    current_segid = segid
                    structure_builder.init_seg(current_segid)

                # if current_chain_id!=chainid:
                if (current_chain_id != chainid):  # | (postpone_res == True):

                    #print "different chainid ", current_chain_id, chainid
                    #print "or postpone is True ", postpone_res
                    current_chain_id = chainid
                    structure_builder.init_chain(current_chain_id)

                    current_residue_id = residue_id
                    current_resname = resname
                    #print "set current_resname to ", current_resname
                    #print "current_resname ", current_resname[:2]

                    # only the case of N terminal and first atom in the chain
                    # or (current_resname[:2] == "CT"):
                    if (current_resname[:2] == "NT"):
                        logging.info(
                            "found a first terminal (%s) at begin of a chain", current_resname)
                        logging.info("postpone init set to True")
                        postpone_res = True

                    try:
                        structure_builder.init_residue(
                            resname, hetero_flag, resseq, icode)  # postres
                    except PDBConstructionException, message:
                        self._handle_PDB_exception(
                            message, global_line_counter)

                # original code
                # elif current_residue_id!=residue_id or current_resname!=resname:
                # not the good place to test about N-terminal
                elif current_residue_id != residue_id:
                    #print "different residue id ", current_residue_id, residue_id

                    current_residue_id = residue_id

                    try:
                        # here call add residue with Postpone == False by default
                        structure_builder.init_residue(
                            resname, hetero_flag, resseq, icode)
                    except PDBConstructionException, message:
                        self._handle_PDB_exception(
                            message, global_line_counter)

                try:
                    #print "first init_atom"
                    structure_builder.init_atom(name, coord, bfactor, occupancy, altloc,
                                                # add to PQRAtom      charge,vdw not present here
                                                fullname, serial_number, 0., 0.,  element)
                except PDBConstructionException, message:
                    self._handle_PDB_exception(message, global_line_counter)

            elif(record_type == 'ANISOU'):
                anisou = map(
                    float, (line[28:35], line[35:42], line[43:49], line[49:56], line[56:63], line[63:70]))
                # U's are scaled by 10^4
                anisou_array = (numpy.array(anisou, 'f')/10000.0).astype('f')
                structure_builder.set_anisou(anisou_array)
            elif(record_type == 'MODEL '):
                try:
                    serial_num = int(line[10:14])
                except:
                    self._handle_PDB_exception("Invalid or missing model serial number",
                                               global_line_counter)
                    serial_num = 0
                structure_builder.init_model(current_model_id, serial_num)
                current_model_id += 1
                model_open = 1
                current_chain_id = None
                current_residue_id = None
            elif(record_type == 'END   ' or record_type == 'CONECT'):
                # End of atomic data, return the trailer
                self.line_counter = self.line_counter+local_line_counter
                return coords_trailer[local_line_counter:]
            elif(record_type == 'ENDMDL'):
                model_open = 0
                current_chain_id = None
                current_residue_id = None
            elif(record_type == 'SIGUIJ'):
                # standard deviation of anisotropic B factor
                siguij = map(
                    float, (line[28:35], line[35:42], line[42:49], line[49:56], line[56:63], line[63:70]))
                # U sigma's are scaled by 10^4
                siguij_array = (numpy.array(siguij, 'f')/10000.0).astype('f')
                structure_builder.set_siguij(siguij_array)
            elif(record_type == 'SIGATM'):
                # standard deviation of atomic positions
                sigatm = map(
                    float, (line[30:38], line[38:45], line[46:54], line[54:60], line[60:66]))
                sigatm_array = numpy.array(sigatm, 'f')
                structure_builder.set_sigatm(sigatm_array)
            local_line_counter = local_line_counter+1

        # EOF (does not end in END or CONECT)
        self.line_counter = self.line_counter+local_line_counter
        return []
