#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>

"""Derived StructureBuilder, can be used by PQRParser """

import os
import sys
import warnings

from Bio.PDB.StructureBuilder import StructureBuilder
from PQRResidue import PQRResidue
from PQRAtom import PQRAtom

from Bio.PDB.PDBExceptions import \
    PDBConstructionException, PDBConstructionWarning

import logging
# not working
# logging.captureWarnings(True)


class PQRStructureBuilder(StructureBuilder):

    def __init__(self):
        StructureBuilder.__init__(self)

    def init_residue(self, resname, field, resseq, icode):
        """
        Initiate a new PQRResidue object.

        Arguments:
        o resname - string, e.g. "ASN"
        o field - hetero flag, "W" for waters, "H" for 
            hetero residues, otherwise blank.
        o resseq - int, sequence identifier
        o icode - string, insertion code
        """

        #print "PQRstructureBuilder.init_residue name, resseq ", resname, resseq

        if field != " ":
            if field == "H":
                # The hetero field consists of H_ + the residue name (e.g. H_FUC)
                field = "H_"+resname
        res_id = (field, resseq, icode)

        if field == " ":
            if self.chain.has_id(res_id):

                # There already is a residue with the id (field, resseq, icode).
                # This only makes sense in the case of a point mutation.

                # It can contain different orientation, is diosrdered ??
                # do not make sense with PQR ! only for PDB
                #print "duplicate res_id, field:",field,"!!!!"
                warnings.warn("WARNING: Residue ('%s', %i, '%s') "
                              "redefined at line %i."
                              % (field, resseq, icode, self.line_counter),
                              PDBConstructionWarning)
                # add to the warning
                logging.warn("Residue ('%s', %i, '%s') "
                             "redefined at line %i. If chains id are missing, try PrepareInput -rename_chains"
                             % (field, resseq, icode, self.line_counter))
                raise Exception("Residue ('%s', %i, '%s') redefined at line %i. If chain ids are missing, try PrepareInput -rename_chains"
                                % (field, resseq, icode, self.line_counter))

                duplicate_residue = self.chain[res_id]
                if duplicate_residue.is_disordered() == 2:

                    # The residue in the chain is a DisorderedResidue object.
                    # So just add the last Residue object.
                    if duplicate_residue.disordered_has_id(resname):
                        # The residue was already made
                        self.residue = duplicate_residue
                        duplicate_residue.disordered_select(resname)

                    else:
                        # Make a new residue and add it to the already
                        # present DisorderedResidue
                        #new_residue=Residue(res_id, resname, self.segid)
                        new_residue = PQRResidue(res_id, resname, self.segid)
                        duplicate_residue.disordered_add(new_residue)
                        self.residue = duplicate_residue
                        return
                else:
                    # Make a new DisorderedResidue object and put all
                    # the Residue objects with the id (field, resseq, icode) in it.
                    # These residues each should have non-blank altlocs for all their atoms.
                    # If not, the PDB file probably contains an error.
                    if not self._is_completely_disordered(duplicate_residue):
                        # if this exception is ignored, a residue will be missing
                        self.residue = None
                        raise PDBConstructionException(
                            "Blank altlocs in duplicate residue %s ('%s', %i, '%s')"
                            % (resname, field, resseq, icode))

                    self.chain.detach_child(res_id)
                    #print "new residue"
                    new_residue = PQRResidue(res_id, resname, self.segid)
                    disordered_residue = DisorderedResidue(res_id)
                    self.chain.add(disordered_residue)
                    disordered_residue.disordered_add(duplicate_residue)
                    disordered_residue.disordered_add(new_residue)
                    self.residue = disordered_residue
                    return

        # create a PQR residue
        residue = PQRResidue(res_id, resname, self.segid)
        self.chain.add(residue)
        self.residue = residue

    def init_atom(self, name, coord, b_factor, occupancy, altloc, fullname,
                  serial_number, charge, vdw_radius, element=None):
        """
        Initiate a new PQRAtom object.

        Arguments:
        o name - string, atom name, e.g. CA, spaces should be stripped
        o coord - Numeric array (Float0, size 3), atomic coordinates
        o b_factor - float, B factor
        o occupancy - float
        o altloc - string, alternative location specifier
        o fullname - string, atom name including spaces, e.g. " CA "
        o element - string, upper case, e.g. "HG" for mercury

        added 
        o charge
        o radius
        """

        residue = self.residue

        #print "PQRStructureBuilder::init_atom name / fullname:!!"+name+"!!!"+fullname+"!!!"
        #print "Element:!!"+element+"!!!"
        #print "charge ", charge
        #print "vdw_radius ", vdw_radius

        # if residue is None, an exception was generated during
        # the construction of the residue
        # michael: not really, but problem for sure !
        if residue is None:
            print("ERROR: residue is None in PQRStructurebuilder.init_atom")
            raise Exception(
                "ERROR: residue is None in PQRStrcturebuilder.init_atom")
            return
        # First check if this atom is already present in the residue.
        # If it is, it might be due to the fact that the two atoms have atom
        # names that differ only in spaces (e.g. "CA.." and ".CA.",
        # where the dots are spaces). If that is so, use all spaces
        # in the atom name of the current atom.
        if residue.has_id(name):
            duplicate_atom = residue[name]
            # atom name with spaces of duplicate atom
            duplicate_fullname = duplicate_atom.get_fullname()
            if duplicate_fullname != fullname:
                    # name of current atom now includes spaces
                name = fullname
                print("warning")
                warnings.warn("Atom names %r and %r differ "
                              "only in spaces at line %i."
                              % (duplicate_fullname, fullname,
                                 self.line_counter),
                              PDBConstructionWarning)
        # atom=self.atom=Atom(name, coord, b_factor, occupancy, altloc,
        #                    fullname, serial_number, element)
        # add specific entries for charge and radius
        atom = self.atom = PQRAtom(name, coord, b_factor, occupancy, altloc,
                                   fullname, serial_number, charge, vdw_radius, element)

        if altloc != " ":
            print("\n altloc != ' ', intended ? \n")
            # The atom is disordered
            if residue.has_id(name):
                # Residue already contains this atom
                duplicate_atom = residue[name]
                if duplicate_atom.is_disordered() == 2:
                    duplicate_atom.disordered_add(atom)
                else:
                    # This is an error in the PDB file:
                    # a disordered atom is found with a blank altloc
                    # Detach the duplicate atom, and put it in a
                    # DisorderedAtom object together with the current
                    # atom.
                    residue.detach_child(name)
                    disordered_atom = DisorderedAtom(name)
                    residue.add(disordered_atom)
                    disordered_atom.disordered_add(atom)
                    disordered_atom.disordered_add(duplicate_atom)
                    residue.flag_disordered()
                    warnings.warn("WARNING: disordered atom found "
                                  "with blank altloc before line %i.\n"
                                  % self.line_counter,
                                  PDBConstructionWarning)
            else:
                # The residue does not contain this disordered atom
                # so we create a new one.
                disordered_atom = DisorderedAtom(name)
                residue.add(disordered_atom)
                # Add the real atom to the disordered atom, and the
                # disordered atom to the residue
                disordered_atom.disordered_add(atom)
                residue.flag_disordered()
        else:
            # The atom is not disordered
            # print "not disorder call residue.add(atom)"
            residue.add(atom)
