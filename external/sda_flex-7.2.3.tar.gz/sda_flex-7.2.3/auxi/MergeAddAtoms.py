#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

import sys
import os
import logging
import warnings

# optparse depreceated
#from optparse import OptionParser
import argparse

from ModPrepareInputSDA.VdWTC_SDA import *

"""
   Merge the different add_atoms files generated for different structure by PrepareInputSDA 
"""

logging.basicConfig(filename='MergeAddAtoms.log', level=logging.DEBUG)
# working here
# logging.captureWarnings(True)

parser = argparse.ArgumentParser(
    description="Merge all input into one 'add_atoms' file before running SDA")

parser.add_argument("-list_input", dest="list_input", required=True,
                    nargs='+', help="The list of add_atoms files to merge")
parser.add_argument("-out_dir", dest="out_dir", required=False, default='.',
                    help="The directory where to write the final add_atoms file")

try:
    options = parser.parse_args()
# parse_arg will return an exit
except SystemExit:
    logging.error("ERROR in reading arguments")
    sys.exit(1)

# name solute can be used to create an unique directory,
# with all conformations, can be done before as well
#logging.info("name_solutes %s" % options.name_solutes)
logging.info("input %s " % options.list_input)
logging.info("output  %s " % options.out_dir)
print("input %s " % options.list_input)
print("output  %s " % options.out_dir)


# create output directory, maybe check if existing
main_vdw = VdWTC_SDA(options.out_dir)

# loop over the input
for file in options.list_input:

    print("file ", file)
    # check it exists
    if not os.path.exists(file):
        print("file does not exist")
        continue

    # check not empty
    if (os.stat(file).st_size == 0):
        print("file empty")
        continue

    # ok
    # else:
    print("create tmp_vdw")
    (head, tail) = os.path.split(file)
    print("head", head)
    print("tail", tail)
    tmp_vdw = VdWTC_SDA(head)

    # copy the content of tmp into main
    main_vdw.MergeWith(tmp_vdw)

# write final file
main_vdw.write_file()
