#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
__author__ = 'Gaurav'

import math
import sys


# This function prints information about the script

def printUsage():
    print("""
        
        NAME
        ECM_Ligand.py
        
        DESCRIPTION
        
        Python script to generate .tcha file with ecm sites that are used for calculation of Effective Charges for Macromolecules (ECM) for small molecules(Ligand)in SDA.
        It takes PQR file of small molecule (ligand) as input
        
        
        USAGE
        
        ECM_ligand.py    ligand_pqr    
        
        ligand_pqr  -          Name of PQR file for the ligand with .pqr extension
        
        PQR file for ligand can be generated using AMBER as follows:
        
        ambpdb -p ligand.prmtop -pqr < ligand.inpcrd > ligand.pqr
        
        
        EXAMPLE
        
        1. Python ECM_ligand.py ligand.pqr
        
        
        OUTPUT
        
        Test Charge File is generated in the same directory where the ligand_pqr file is located with name: ligand_pqr.tcha
        
        """)


if (len(sys.argv) < 2):
    printUsage()
    sys.exit(1)

""" A class to deal with x,y and z coordinates of Different atoms
    Calculates distance between any two atoms """


class point:
    x = 99999.0
    y = 99999.0
    z = 99999.0

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def print_coors(self):
        print((str(self.x) + "\t" + str(self.y) + "\t" + str(self.z)))

    def dist_to(self, apoint):
        return math.sqrt(
            math.pow(self.x - apoint.x, 2) + math.pow(self.y - apoint.y, 2) + math.pow(self.z - apoint.z, 2))

    def average_with(self, other_point):
        return point((self.x + other_point.x) / 2.0, (self.y + other_point.y) / 2.0, (self.z + other_point.z) / 2.0)

    def length(self):
        return self.dist_to(point(0.0, 0.0, 0.0))

    def minus(self, other_point):
        return point(self.x - other_point.x, self.y - other_point.y, self.z - other_point.z)

    def plus(self, other_point):
        return point(self.x + other_point.x, self.y + other_point.y, self.z + other_point.z)


# an atom object
class atom:
    def __init__(self):
        self.atomname = ""
        self.resid = 0
        self.chain = ""
        self.resname = ""
        self.coordinates = point(99999, 99999, 99999)
        self.undo_coordinates = point(99999, 99999, 99999)
        self.element = ""
        self.PDBIndex = ""
        self.line = ""
        self.IndicesOfAtomsConnecting = []
        self.charge = 0.00
        self.radius = 0.00

    # Reads text (PQR format) into an atom object
    # Requires: A string containing the PQR line

    def ReadPQRLine(self, Line):
        self.line = Line
        self.atomname = Line[11:16].strip()
        self.chain = Line[21:22]
        self.resid = int(Line[22:26])

        self.coordinates = point(float(Line[30:38]), float(
            Line[38:46]), float(Line[46:54]))
        self.element = Line[76:79].strip().upper()
        self.PDBIndex = Line[6:12].strip()
        self.resname = Line[16:20]
        if self.resname.strip() == "":
            self.resname = " MOL"
        self.charge = Line[55:62]
        self.charge = float(self.charge)
        self.radius = Line[62:70]
        if self.element == "":
            # elif self.element == "": # try to guess at element from name

            two_letters = self.atomname.strip().upper()[0:2]

            # Any number needs to be removed from the element name
            two_letters = two_letters.replace('0', '')
            two_letters = two_letters.replace('1', '')
            two_letters = two_letters.replace('2', '')
            two_letters = two_letters.replace('3', '')
            two_letters = two_letters.replace('4', '')
            two_letters = two_letters.replace('5', '')
            two_letters = two_letters.replace('6', '')
            two_letters = two_letters.replace('7', '')
            two_letters = two_letters.replace('8', '')
            two_letters = two_letters.replace('9', '')

            if two_letters == 'BR':
                self.element = 'BR'
            elif two_letters == 'CL':
                self.element = 'CL'
            elif two_letters == 'BI':
                self.element = 'BI'
            elif two_letters == 'AS':
                self.element = 'AS'
            elif two_letters == 'AG':
                self.element = 'AG'
            elif two_letters == 'LI':
                self.element = 'LI'
            elif two_letters == 'MG':
                self.element = 'MG'
            elif two_letters == 'RH':
                self.element = 'RH'
            elif two_letters == 'ZN':
                self.element = 'ZN'
            else:  # So, just assume it's the first letter.
                self.element = self.atomname.strip().upper()

                # Any number needs to be removed from the element name
                self.element = self.element.replace('0', '')
                self.element = self.element.replace('1', '')
                self.element = self.element.replace('2', '')
                self.element = self.element.replace('3', '')
                self.element = self.element.replace('4', '')
                self.element = self.element.replace('5', '')
                self.element = self.element.replace('6', '')
                self.element = self.element.replace('7', '')
                self.element = self.element.replace('8', '')
                self.element = self.element.replace('9', '')

                self.element = self.element[0:1]

# Creates a Test_Charge line from the atom object
# Returns: String
    def Create_Test_Charge_Line(self, test_charge):

        output = "ATOM "
        output = output + \
            self.PDBIndex.rjust(6) + self.atomname.rjust(5) + \
            self.resname.rjust(4)
        output = output + self.chain.rjust(2)
        output = output + str(self.resid).rjust(4)
        output = output + ("%.3f" % self.coordinates.x).rjust(12)
        output = output + ("%.3f" % self.coordinates.y).rjust(8)
        output = output + ("%.3f" % self.coordinates.z).rjust(8)
        output = output + ("%.3f" % test_charge).rjust(13)

        return output

    # Add indexes of neighbor atoms to a list: will be used later to determine atoms with only 1 neighbors
    def AddNeighborAtomIndex(self, index):
        if not (index in self.IndicesOfAtomsConnecting):
            self.IndicesOfAtomsConnecting.append(index)

# Returns the number of neighbors of any atom
    def NumberOfNeighbors(self):
        return len(self.IndicesOfAtomsConnecting)


""" PQR class
    Load the PQR from a file """


class PQR:
    def __init__(self):

        self.AllAtoms = {}
        self.resids = []
        self.polar = None

    # Loads a PQR from a file
    # Requires: trajectory_filename, a string containing the trajectory_filename
    def LoadPQR_FromFile(self, trajectory_filename):
        # Now load the file into a list
        file = open(trajectory_filename, "r")
        lines = file.readlines()
        file.close()
        self.LoadPQR_FromArray(lines)

    def LoadPQR_FromArray(self, lines):

        autoindex = 1

        self.__init__()

        for t in range(0, len(lines)):
            line = lines[t]
            if len(line) >= 7:
                # Load atom data (coordinates, etc.)
                if line[0:4] == "ATOM" or line[0:6] == "HETATM":
                    TempAtom = atom()
                    TempAtom.ReadPQRLine(line)

                    if not TempAtom.resid in self.resids:
                        self.resids.append(TempAtom.resid)

                    # because points files have no indices
                    self.AllAtoms[autoindex] = TempAtom
                    autoindex = autoindex + 1

    # Function to select test charge sites (donor-acceptors, halogens, metal atoms in cofactors etc.)
    def polar_atoms(self, arguments):
        polar = []
        if self.polar is None:
            for index in self.AllAtoms:
                atom = self.AllAtoms[index]
                if atom.element == "O" or atom.element == "N" or atom.element == "F" or atom.element == "S" or atom.element == "P" or atom.element == "FE" or atom.element == "CL" or atom.element == "BR" or atom.element == "I":
                    polar.append(index)
                self.polar = polar
        else:
            polar = self.polar


# Main function which assigns effective charge sites and create a test charge file

def calculate_test_charges(ligand_filename):
    lig = PQR()  # Assign a PQR class object
    # function call to load PQR from file
    lig.LoadPQR_FromFile(ligand_filename)
    lig.polar_atoms(ligand_filename)
    total_charge = 0.0
    polar_sites_charge = 0.0
    # A list to store indices of polar atoms (test charge sites)
    polar_sites = []
    keys = list(lig.AllAtoms.keys())

    # Caculation of total charge of the ligand

    for index1 in range(0, len(keys)):
        key1 = keys[index1]
        atom = lig.AllAtoms[key1]
        total_charge = total_charge + atom.charge

    print(("The total charge on the molecule is %f \n") % (total_charge))

    # Calculate neighbors of each atom

    for index1 in range(0, len(keys) - 1):
        key1 = keys[index1]
        atom1 = lig.AllAtoms[key1]

        for index2 in range(0, len(keys)):

            key2 = keys[index2]
            atom2 = lig.AllAtoms[key2]
            dist = atom1.coordinates.dist_to(atom2.coordinates)
            if dist > 0.4 and dist < 1.3:  # Distance of heavy atom-hydrogen bond is between 0.4 and 1.2 Angstrom

                if atom1.element != "H" and atom2.element == "H":
                    temp = atom1.charge + atom2.charge
   # Replace the charge of heavy atom with the new cumulative charge
                    atom1.charge = temp

            elif dist > 0.4 and dist <= 1.9:  # Distance of C-C, C-O, C-N,C=C bond is between 0.4 and 1.9 Angstrom
                if atom1.element != "H" and atom2.element != "H":
                    atom1.AddNeighborAtomIndex(index2)

    # Calculate total charge on polar sites
    for index1 in range(0, len(keys)):
        key1 = keys[index1]
        atom = lig.AllAtoms[key1]
        if key1 in lig.polar:
            polar_sites.append(key1)
            polar_sites_charge = polar_sites_charge + atom.charge

    print(("The total charge on the polar sites of the molecule is %f \n") % (
        polar_sites_charge))

    # Calculate the total charge that need to be redistributed over polar sites (test charge sites)
    residual_charge = total_charge - polar_sites_charge
    print(("The charge that will be resdistributed over all the polar sites is %f \n") % (
        residual_charge))

    # Calculate charge redistrubuted to each polar site
    residual_charge_atom = residual_charge/len(polar_sites)

    # open the test charge file
    file = open(ligand_filename.split('.')[0] + ".tcha", 'w')

    # Write the test charge file
    for index2 in range(0, len(keys)):
        key2 = keys[index2]
        atom2 = lig.AllAtoms[key2]
        if key2 in lig.polar:

            file.write(atom2.Create_Test_Charge_Line(
                atom2.charge + residual_charge_atom) + "\n")

    file.close()



# Generate test charge file by calling the main function
calculate_test_charges(sys.argv[1])
print("\nThe name of output file is: " + \
    sys.argv[1].split('.')[0].split('/')[-1] + \
    ".tcha  (can be found in the same directory)")
