#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
import os
import sys
import time
import math
#import pymol

# Displays information about the Script


def printUsage():

    print("""
    NAME   
         ReactionCriteria.py

    DESCRIPTION

         Python script to generate Reaction criteria file for association rate calculations in SDA for diffusional association of Protein and small molecules.
         It defines Reaction Criteria on the basis of 

		1) H-bonding contacts (donor-acceptor pairs) between protein and small molecule (ligand)
	        2) Chlorine-pi interactions
                3) pi-pi interactions between protein and small molecule (ligand).

    ARGUMENTS

        It takes total 3 parameters as input and MOL2 file of ligand as 4th optional parameter (if pi-pi interactions to be considered. Script need Mol2 file to extract information on aromatic atoms of ligand)

        1.) Name of PDB file of protein
        2.) Name of PDB file of small molecule (ligand)
        3.) Distance to define Reaction Criteria in output file (integer number)
        4.) MOL2 file of ligand (OPTIONAL ARGUMENT)


    USAGE

         ReactionCriteria.py    protein_pdb    ligand_pdb    distance   ligand_mol2
         

         protein_pdb  -      Name of PDB file for the protein with .pdb extension
         ligand_pdb   -      Name of the PDB file for the small molecule (ligand) with .pdb extension
                             (Both Protein PDB and Ligand PDB should be from the crystal Structure)

         distance     -      Distance to include in Reaction Criteria file (integer number)
	 ligand_mol2  -      MOL2 file of the small molecule (ligand) in Tripos or SYBYL format with .mol2 extension

         
    EXAMPLE
    
	python   ReactionCriteria.py   Xa.pdb   RIV.pdb   6   RIV.mol2

    
    OUTPUT
        
	Reaction Criteria File is generated in the same directory with name: ligand_pdb.rxna

     """)


if(len(sys.argv) <= 3):
    printUsage()
    sys.exit(1)


# Point class for coordinates: to calculate distance between any two atoms

class point:
    x = 99999.0
    y = 99999.0
    z = 99999.0

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def print_coors(self):
        print((str(self.x)+"\t"+str(self.y)+"\t"+str(self.z)))

    def dist_to(self, apoint):
        return math.sqrt(math.pow(self.x - apoint.x, 2) + math.pow(self.y - apoint.y, 2) + math.pow(self.z - apoint.z, 2))


# an atom object
class atom:

    def __init__(self):
        self.atomname = ""
        self.resid = 0
        self.chain = ""
        self.resname = ""
        self.coordinates = point(99999, 99999, 99999)
        self.undo_coordinates = point(99999, 99999, 99999)
        self.element = ""
        self.PDBIndex = ""
        self.line = ""
        self.IndicesOfAtomsConnecting = []
        self.beta = 0.00
        self.occupancy = 0.00

    # Reads text (PDB format) into an atom object
    # Requires: A string containing the PDB line
    def ReadPDBLine(self, Line):
        self.line = Line
        self.atomname = Line[11:16].strip()
        self.chain = Line[21:22]
        self.resid = int(Line[22:26])

        self.coordinates = point(float(Line[30:38]), float(
            Line[38:46]), float(Line[46:54]))
        self.element = Line[76:78].strip().upper()
        self.PDBIndex = Line[6:12].strip()
        self.resname = Line[16:20].strip().upper()
        if self.resname.strip() == "":
            self.resname = " MOL"

        if self.element == "":
            # elif self.element == "": # try to guess at element from name

            two_letters = self.atomname.strip().upper()[0:2]

            # Any number needs to be removed from the element name
            two_letters = two_letters.replace('0', '')
            two_letters = two_letters.replace('1', '')
            two_letters = two_letters.replace('2', '')
            two_letters = two_letters.replace('3', '')
            two_letters = two_letters.replace('4', '')
            two_letters = two_letters.replace('5', '')
            two_letters = two_letters.replace('6', '')
            two_letters = two_letters.replace('7', '')
            two_letters = two_letters.replace('8', '')
            two_letters = two_letters.replace('9', '')

            if two_letters == 'BR':
                self.element = 'BR'
            elif two_letters == 'CL':
                self.element = 'CL'
            elif two_letters == 'BI':
                self.element = 'BI'
            elif two_letters == 'AS':
                self.element = 'AS'
            elif two_letters == 'AG':
                self.element = 'AG'
            elif two_letters == 'LI':
                self.element = 'LI'
            elif two_letters == 'MG':
                self.element = 'MG'
            elif two_letters == 'RH':
                self.element = 'RH'
            elif two_letters == 'ZN':
                self.element = 'ZN'
            else:  # So, just assume it's the first letter.
                self.element = self.atomname.strip().upper()

                # Any number needs to be removed from the element name
                self.element = self.element.replace('0', '')
                self.element = self.element.replace('1', '')
                self.element = self.element.replace('2', '')
                self.element = self.element.replace('3', '')
                self.element = self.element.replace('4', '')
                self.element = self.element.replace('5', '')
                self.element = self.element.replace('6', '')
                self.element = self.element.replace('7', '')
                self.element = self.element.replace('8', '')
                self.element = self.element.replace('9', '')

                self.element = self.element[0:1]

    # Creates a PDB line from the atom object (does not include B factor and occupancy)
    # Returns: String according to format of Reaction Criteria File
    def CreatePDBLine(self):

        output = "ATOM "

        output = output + \
            self.PDBIndex.rjust(6) + self.atomname.rjust(5) + \
            self.resname.rjust(4)
        output = output + self.chain.rjust(2)
        output = output + str(self.resid).rjust(4)
        output = output + ("%.3f" % self.coordinates.x).rjust(12)
        output = output + ("%.3f" % self.coordinates.y).rjust(8)
        output = output + ("%.3f" % self.coordinates.z).rjust(8)

        return output


# PDB class
class PDB:

    def __init__(self):

        self.AllAtoms = {}
        self.resids = []
        self.N_O_F_S = None
        self.hydrogen_indicies = None

    # Loads a PDB from a file
    # Requires: trajectory_filename, a string containing the trajectory_filename
    def LoadPDB_FromFile(self, trajectory_filename):
        # Now load the file into a list
        file = open(trajectory_filename, "r")
        lines = file.readlines()
        file.close()
        self.LoadPDB_FromArray(lines)

    def LoadPDB_FromArray(self, lines):

        autoindex = 1

        self.__init__()

        for t in range(0, len(lines)):
            line = lines[t]
            if len(line) >= 7:
                # Load atom data (coordinates, etc.)
                if line[0:4] == "ATOM" or line[0:6] == "HETATM":
                    TempAtom = atom()
                    TempAtom.ReadPDBLine(line)

                    if not TempAtom.resid in self.resids:
                        self.resids.append(TempAtom.resid)

                    # because points files have no indices
                    self.AllAtoms[autoindex] = TempAtom
                    autoindex = autoindex + 1

    # Saves the PDB object to a PDB file
    # Requires: trajectory_filename to be saved
    def SavePDB(self, trajectory_filename):

        if len(self.AllAtoms) > 0:  # so the pdb is not empty (if it is empty, don't save)

            file = open(trajectory_filename, "w")

            # write coordinates
            for atomindex in self.AllAtoms:
                file.write(self.AllAtoms[atomindex].CreatePDBLine() + "\n")

            file.close()

    def id_hydrogen_bonds(self, arguments):

        # get possible donors/acceptors.
        N_O_F_S = []
        if self.N_O_F_S is None:  # so not predefined
            for index in self.AllAtoms:
                atom = self.AllAtoms[index]
                if atom.element == "O" or atom.element == "N" or atom.element == "F" or atom.element == "S":
                    N_O_F_S.append(index)
            self.N_O_F_S = N_O_F_S
        else:  # so it is predefined
            N_O_F_S = self.N_O_F_S

        hydrogen_indicies = []
        if self.hydrogen_indicies is None:  # so not predefined
            for index in self.AllAtoms:
                atom = self.AllAtoms[index]
                if atom.element == "H":
                    hydrogen_indicies.append(index)
            self.hydrogen_indicies = hydrogen_indicies
        else:  # so is predefined
            hydrogen_indicies = self.hydrogen_indicies


def ReadMol2File(Mol2_filename):
    file = open(Mol2_filename, "r")
    lines = file.readlines()
    file.close()
    aromatic = []
    for i in range(0, len(lines)):
        line = lines[i]
        if len(line) > 70:
            atom_type = line[46:53].strip()
            if atom_type in ("ca", "na", "C.ar", "N.ar"):
                atom_name = line[7:13].strip()
                aromatic.append(atom_name)

    return aromatic


# Main function to create Reaction Criteria File

def generate_Reaction_Criteria_File(protein_filename, ligand_filename, distance):

    protein = PDB()  # Makes pdb object
    lig = PDB()
    lig.LoadPDB_FromFile(ligand_filename)  # Loads PDB file for ligand
    protein.LoadPDB_FromFile(protein_filename)  # Loads PDB file for protein
    # Calculates donor/acceptor atoms and indices of hydrogen atoms
    lig.id_hydrogen_bonds(ligand_filename)
    protein.id_hydrogen_bonds(protein_filename)
    # Open a new file to write Reaction Criteria
    file = open(ligand_filename.split('.')[0] + ".rxna", 'w')
    keys_p = list(protein.AllAtoms.keys())
    keys_l = list(lig.AllAtoms.keys())

    residue_covered = []
    atom_covered = []
    halpi_atom1 = []
    halpi_atom2 = []
    flag = False
    if (len(sys.argv) == 5):
        aromatic = ReadMol2File(sys.argv[4])
        flag = True

    for key_index1 in range(0, len(keys_p)-1):  # Iteration over all protein atoms
        key1 = keys_p[key_index1]
        atom1 = protein.AllAtoms[key1]

        # Iteration over all ligand atoms
        for key_index2 in range(0, len(keys_l)-1):

            key2 = keys_l[key_index2]
            atom2 = lig.AllAtoms[key2]
            dist = atom1.coordinates.dist_to(atom2.coordinates)

            # The following code Check whether ligand and protein atom form a Hydrogen bond

            if dist < 4.5:

                if key1 in protein.N_O_F_S and key2 in lig.N_O_F_S and dist < 3.5:
                    min_distp = 9999.0
                    min_distl = 9999.0
                    for index2 in protein.hydrogen_indicies:
                        hydrogen_p = protein.AllAtoms[index2]
                        distp = atom1.coordinates.dist_to(
                            hydrogen_p.coordinates)
                        if distp < min_distp:
                            min_distp = distp     # Calculates distance of nearest Hydrogen from protein atom

                    for index3 in lig.hydrogen_indicies:
                        hydrogen = lig.AllAtoms[index3]
                        distl = atom2.coordinates.dist_to(hydrogen.coordinates)
                        if distl < min_distl:
                            min_distl = distl     # Calculates distance of nearest Hydrogen from ligand atom

                    # Check if only 1 of them is bonded to hydrogen
                    if (min_distl < 1.3 or min_distp < 1.3):

                        # Writes Reaction criteria to file according to Reaction Criteria File format
                        file.write("CNONS " + atom1.CreatePDBLine() + " |     " +
                                   str(distance) + "0| " + atom2.CreatePDBLine()+"\n")

            # The following code Check for Halogen-pi interactions

                elif atom1.resname in ("TYR", "TRP", "PHE", "HIS")and atom1.atomname in ("CG", "CD1", "CD2", "CE1", "CE2", "CZ", "NE1", "CE3", "CZ2", "CZ3", "CH2", "ND1", "NE2"):
                    if atom2.element in ("CL", "BR", "I", "F"):
                        if atom2.atomname not in halpi_atom2 and atom1.atomname not in halpi_atom1:

                         # Writes Reaction criteria to file according to Reaction Criteria File format
                            file.write("CNONS " + atom1.CreatePDBLine() + " |     " +
                                       str(distance) + "0| " + atom2.CreatePDBLine()+"\n")
                            halpi_atom1.append(atom1.atomname)
                            halpi_atom2.append(atom2.atomname)

            # The following code checks for pi-pi interactions between ligand and protein atom

                    elif (flag == True) and atom2.atomname in aromatic:

                        if atom2.atomname not in atom_covered and atom1.resid not in residue_covered:

                            # Writes Reaction criteria to file according to Reaction Criteria File format
                            file.write("CNONS " + atom1.CreatePDBLine() + " |     " +
                                       str(distance) + "0| " + atom2.CreatePDBLine()+"\n")
                            residue_covered.append(atom1.resid)
                            atom_covered.append(atom2.atomname)

    file.close()


###### This section of the code check for Hydrogens in the pdb files######
###### If there are no H in pdb, It will add Hydrogens using pymol function#######

protein = PDB()  # Makes pdb object
lig = PDB()
lig.LoadPDB_FromFile(sys.argv[2])  # Loads PDB file for ligand
protein.LoadPDB_FromFile(sys.argv[1])  # Loads PDB file for protein
# Calculates donor/acceptor atoms and indices of hydrogen atoms
lig.id_hydrogen_bonds(sys.argv[2])
protein.id_hydrogen_bonds(sys.argv[1])

if (len(protein.hydrogen_indicies) > 2 and len(lig.hydrogen_indicies) > 2):

    generate_Reaction_Criteria_File(
        sys.argv[1], sys.argv[2], float(sys.argv[3]))
    print(" The name of the output reaction criteria file is:" + \
        sys.argv[2].split('/')[-1].split('.')[0] + \
        ".rxna  (can be found in the same directory)")


elif (len(protein.hydrogen_indicies) < 2 and len(lig.hydrogen_indicies) < 2):
    pymol.finish_launching()

    StructurePath = os.path.abspath(sys.argv[1])
    StructureName = StructurePath.split('/')[-1].split('.')[0]

    pymol.cmd.load(StructurePath, StructureName)
    pymol.cmd.do("h_add")
    time.sleep(1)
    pymol.cmd.save(StructurePath.split('.')[0] + "_temp.pdb", 'all', 0, 'pdb')

    pymol.cmd.quit()
    pymol.finish_launching()

    StructurePath2 = os.path.abspath(sys.argv[2])
    StructureName2 = StructurePath2.split('/')[-1].split('.')[0]

    pymol.cmd.load(StructurePath2, StructureName2)
    pymol.cmd.do("h_add")
    time.sleep(1)
    pymol.cmd.save(StructurePath2.split('.')[0] + "_temp.pdb", 'all', 0, 'pdb')

    pymol.cmd.quit()
    generate_Reaction_Criteria_File(StructurePath.split('.')[
                                    0] + "_temp.pdb", StructurePath2.split('.')[0] + "_temp.pdb", float(sys.argv[3]))
    print(" The name of the output reaction criteria file is:" + \
        sys.argv[2].split('.')[0].split('\/')[-1] + \
        ".rxna  (can be found in the same directory)")
    print("\n Since H atoms are missing from Protein and ligand pdb files, temporary pdb files have been generated in the same directory with added H atoms using PyMOL functionality")
    print("\n Please delete the temporary files: " + sys.argv[1].split('.')[0].split(
        '/')[-1]+"_temp.pdb and " + sys.argv[2].split('.')[0].split('/')[-1]+"_temp.pdb")


elif (len(protein.hydrogen_indicies) < 2 and len(lig.hydrogen_indicies) > 2):

    pymol.finish_launching()

    StructurePath = os.path.abspath(sys.argv[1])
    StructureName = StructurePath.split('/')[-1].split('.')[0]

    pymol.cmd.load(StructurePath, StructureName)
    pymol.cmd.do("h_add")
    time.sleep(1)
    pymol.cmd.save(StructurePath.split('.')[0] + "_temp.pdb", 'all', 0, 'pdb')

    pymol.cmd.quit()
    generate_Reaction_Criteria_File(StructurePath.split(
        '.')[0] + "_temp.pdb", sys.argv[2], float(sys.argv[3]))
    print(" The name of the output reaction criteria file is:" + \
        sys.argv[2].split('.')[0].split('/')[-1] + \
        ".rxna  (can be found in the same directory)")
    print("\n Since H atoms are missing from Protein file, temporary pdb file for protein has been generated in the same directory with added H atoms using PyMOL functionality")
    print("\n Please delete the temporary file: " + \
        sys.argv[1].split('.')[0].split('/')[-1]+"_temp.pdb")


elif (len(protein.hydrogen_indicies) > 2 and len(lig.hydrogen_indicies) < 2):

    pymol.finish_launching()
    StructurePath2 = os.path.abspath(sys.argv[2])
    StructureName2 = StructurePath2.split('/')[-1].split('.')[0]

    pymol.cmd.load(StructurePath2, StructureName2)
    pymol.cmd.do("h_add")
    time.sleep(1)
    pymol.cmd.save(StructurePath2.split('.')[0] + "_temp.pdb", 'all', 0, 'pdb')

    pymol.cmd.quit()

    generate_Reaction_Criteria_File(sys.argv[1], StructurePath2.split('.')[
                                    0] + "_temp.pdb", float(sys.argv[3]))
    print(" The name of the output reaction criteria file is:" + \
        sys.argv[2].split('.')[0].split('/')[-1] + \
        ".rxna  (can be found in the same directory)")
    print("\n Since H atoms are missing from the ligand pdb file, temporary pdb file has been generated in the same directory with added H atoms using PyMOL functionality")
    print("\n Please delete the temporary file: " + \
        sys.argv[2].split('.')[0].split('/')[-1]+"_temp.pdb")
