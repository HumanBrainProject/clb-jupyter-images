#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

#   program sda
#  \version{version 6.00 (2010)}
#
#  Copyright (c) 2009, 2010
#  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#        formerly EML Research gGmbH (EML-R www.eml-research.de)
#  Schloss-Wolfsbrunnenweg 35
#  69118 Heidelberg, Germany
#
#  Please send your contact address to get information on updates and
#  new features to "mcmsoft@h-its.org". Questions will be
#  answered as soon as possible.
#  authors{D.Kokh}


import sys
import re
import os
import string
import math

polar_residues = (["ARG", "ASN", "ASP", "CYS", "GLN", "GLU",
                   "HIE", "HID", "HIS", "LYS", "SER", "THR", "TRP", "TYR", "NTR"])
H_number = ([9,      4,    0,    1,    4,    0,    1,
             1,    2,     3,    1,    1,     1,   1,    1])
H_name = (["HE", "HH11", "HH12", "HH22", "HH21", "1HH1", "2HH1", "2HH2", "1HH2"],  # ARG
          ["HD21", "HD22", "1HD2", "2HD2"],  # ASN
          [""],  # ASP
          ["HG"],  # CYS
          ["HE21", "HE22", "1HE2", "2HE2"],  # GLN
          [""],  # GLU
          ["HE2"],  # HIE
          ["HD1"],  # HID
          ["HE2", "HD1"],  # HIS
          ["HZ1", "HZ2", "HZ3"],  # LYS
          ["HG"],  # SER
          ["HG1"],  # THR
          ["HE1"],  # TRP
          ["HH"],  # TYR
          ["HN1"])  # NTRM

#################


def printUsage():
    print("""
    usage:
    ~/thisFile.py p2_with_all_H.pdb p2_with_polar_H.pdb
    """)


if len(sys.argv) < 2:
    printUsage()
    sys.exit(1)

if os.path.exists(sys.argv[1]):
    #print "OK pdb",sys.argv[2]
    pdbfile = sys.argv[1]

else:
    printUsage()
    print("pdb does not exist")
    sys.exit(1)
Number2print = 10

try:
    pdb_out_file = sys.argv[2]
except IndexError:
    print("please give the name of the output file")
    printUsage()
    sys.exit(1)


fw = open(sys.argv[2], "w")
fi = open(pdbfile, "r")

lines = fi.readlines()
for i in range(0, len(lines)):
    line = string.strip(lines[i])
    s = re.split("\s+", line)
    if(s[0] == "ATOM"):
        if(s[2].find("H") == -1):
            fw.write(lines[i])


fi.close()
fw.close()
