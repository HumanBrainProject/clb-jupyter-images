#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

#   program sda
#  \version{version 6.00 (2010)}
#
#  Copyright (c) 2009, 2010
#  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#        formerly EML Research gGmbH (EML-R www.eml-research.de)
#  Schloss-Wolfsbrunnenweg 35
#  69118 Heidelberg, Germany
#
#  Copyright (c) 2000, 2003
#  European Molecular Biology Laboratory
#  Meyerhofstr. 1, Postfach 10.2209
#  D-69012, Heidelberg, Germany
#
#  Please send your contact address to get information on updates and
#  new features to "mcmsoft@h-its.org". Questions will be
#  answered as soon as possible.
#
#  References:
#     R.R. Gabdoulline, R.C. Wade.
#  Brownian dynamics simulation of protein-protein diffusional encounter.
#  (1998) Methods, 14, 329-341.
#  for additional references see http://mcm.h-its.org/mcmsoft/sda/6.00/#ref
#
#  \authors{Authors: R.R.Gabdoulline, R.C.Wade}

import sys
import string
import time
import subprocess
import os
import shutil


def GetData(filename):
    Filename = filename
    FilePointer = open(Filename, 'r')
    DataLines = FilePointer.readlines()
    FilePointer.close()
    return(DataLines)


def make_LJ_input(InputFile):

    FilePointer = open(InputFile, 'w')

    FilePointer.write(
        "#------------------------------ h,ndimx,ndimy,ndimz"+"\n")
    FilePointer.write(str(parameters["h"])+', '+str(parameters["ndimx"])+','+str(
        parameters["ndimy"])+','+str(parameters["ndimz"])+"\n")
    FilePointer.write("#------------------------------ pfile"+"\n")
    FilePointer.write(str(parameters["pfile"])+"\n")
    FilePointer.write("#------------------------------ efile, iform"+"\n")
    FilePointer.write(str(parameters["efile"])+"\n")
    FilePointer.write(str(parameters["iform"])+"\n")
    FilePointer.write("#------------------------------ Probefile"+"\n")
    FilePointer.write(str(parameters["probef"])+"\n")
    FilePointer.write(str(parameters["ioset"])+"\n")
    FilePointer.write("#------------------------------ cutoff:"+"\n")
    FilePointer.write(str(parameters["cutoff"])+"\n")

    FilePointer.close()


def insert_INTERACTIONS():
    InputFile = parameters["probef"]
    DataLines = GetData(InputFile)
    OutputFile = open(parameters["probef"]+".tmp", 'w')
    for line in DataLines:
        if line[0:5] == "PROBE":
            parts = line.split()
            recentPROBE = parts[1]

        if line[0:8] == "ENDPROBE":
            if (recentPROBE in PROBE) == True:
                for keyword, value in list(PROBE[recentPROBE].items()):
                    if value != "-":
                        stri = "INTERACT "+keyword+" "+value+" # name sigma epsilon"
                        print(("\t** PARAMETER ADDED ", stri,
                               " to PROBE ", recentPROBE, "**"))
                        print(
                            "\t*(please check - this parameter is absent either in qtable or in pdb file)")
                        OutputFile.write(stri+"\n")
            OutputFile.write("OVERLAPENERGY "+parameters["OVERLAPENERGY"]+"\n")

        if line[0:8] == "INTERACT":
            parts = line.split()
            if (recentPROBE in PROBE) == True and (parts[1] in PROBE[recentPROBE]) == True:
                stri = parts[0]+" "+parts[1]+" " + \
                    PROBE[recentPROBE][parts[1]]+" "+"# name sigma epsilon\n"
                OutputFile.write(stri)
                PROBE[recentPROBE][parts[1]] = "-"
                continue
        OutputFile.write(line)

    OutputFile.close()
    shutil.copy(parameters["probef"]+".tmp", parameters["probef"])
    os.remove(parameters["probef"]+".tmp")
    return()


def check_essential_parameters():
    ok = True
    for keyword, value in list(parameters.items()):
        if value == "-1":
            print(("\t%s not defined. Check your inputfile" % (keyword)))
            ok = False
    if ok == False:
        sys.exit(1)
    return()


def check_files_available():
    ok = True
#	if os.path.exists(str(parameters["probef"])) == False:
#		ok = False
#		print "file ",parameters["probef"], " doesn't exist"

    if os.path.exists(str(parameters["ParameterFile"])) == False:
        ok = False
        print(("file ", parameters["ParameterFile"], " doesn't exist"))

    if os.path.exists(str(parameters["PrepareProbeFile_executable"])) == False:
        ok = False
        print((
            "file ", parameters["PrepareProbeFile_executable"], " doesn't exist"))

    if os.path.exists(str(parameters["mk_LJ_grd_executable"])) == False:
        ok = False
        print(("file ", parameters["mk_LJ_grd_executable"], " doesn't exist"))

    if ok == False:
        sys.exit(1)
    return()


#--------------------------------------
# get script source directory
path_w = sys.argv[0]
path_w = path_w[0:path_w.rfind("/")]

# define parameters
parameters = {}
PROBE = {}
parameters["h"] = 0.2
parameters["ndimx"] = 300
parameters["ndimy"] = 300
parameters["ndimz"] = 300
parameters["pfile"] = "-1"
parameters["efile"] = "ASCII"
parameters["iform"] = 1
parameters["probef"] = "ProbeFile.txt"
parameters["ioset"] = 0
parameters["cutoff"] = 10
parameters["SurfaceFile"] = "-1"
parameters["ParameterFile"] = "-1"
parameters["LJinput"] = "ds3.in"
parameters["mk_LJ_grd_executable"] = path_w + "/../../bin/mk_LJ_grd"
parameters["change_atomNames_executable"] = path_w + "/change_atomNames.sh"
parameters["PrepareProbeFile_executable"] = path_w + "/PrepareProbeFile.py"
parameters["OVERLAPENERGY"] = "1.e1"
silent = False
if len(sys.argv) < 2:
    print("please give name of the inputfile as a parameter!")
    print((sys.argv[0], " --help gives you more information"))
    sys.exit(1)
if sys.argv[1] == "--help":
    print("possible parameter keywords:\n")
    for keyword, value in list(parameters.items()):
        print(("\t%s " % (keyword)))
    sys.exit(1)

if (len(sys.argv) < 3):
    print("use --silent as the second parameter to skip the user interaction - all existing files will be overwritten")

if (len(sys.argv) > 2):
    if (sys.argv[2] == "--silent"):
        print("running in silent mode. All existing files will be overwritten ...\n")
        silent = True
    if (sys.argv[2] != "--silent"):
        print("use --silent as the second parameter to skip the user interaction - all existing files will be overwritten")

# read parameters from inputfile

InputFile = sys.argv[1]
DataLines = GetData(InputFile)

for line in DataLines:
    if line[0] == '#':
        continue
    if len(line) == 1:
        continue
    if line[0:5] == "PROBE":
        parts = line.split()
        recentPROBE = parts[1]
        PROBE[recentPROBE] = {}

    if line[0:8] == "INTERACT":
        parts = line.split()
        PROBE[recentPROBE][parts[1]] = str(parts[2]+" "+parts[3])
        continue
    parts = line.split()
    parameters[parts[0]] = parts[1]

#print "Paramter values:"
#print "-----------------"
# for keyword, value in parameters.items():
#    print "%s\t%s" % (keyword, value)
#print "INTERACTION LIST:"
#print "-----------------"
# for keyword, value in PROBE.items():
#	print "%s:" % (keyword)
#	for key, val in value.items():
#		print "%s\t%s" % (key, val)

# parameter reading finished -------------------------------

# check if all essential parameters are set....
check_essential_parameters()
# check if all given files available ...
check_files_available()


# try:
#	print("Press <ENTER> to create a ProbeFile.txt (<STRG>+C to abort)")
#	input=sys.stdin.readline()
# except KeyboardInterrupt:
#	print("Aborted...")
#	sys.exit(1)
# make ProbeFile.txt
print("---------------------------------------------------------------------")
print("       step 1:  Probe File will be prepared using qtable and probe sites")
print("---------------------------------------------------------------------")
overwrite = True
if os.path.exists(str(parameters["probef"])) == True & (silent == False):
    while input != "y\n" and input != "n\n":
        print(("File exists!! Overwrite ", str(
            parameters["probef"]), "  [y/n] ?"))
        input = sys.stdin.readline()
    if input == "n\n":
        print(("\n"+"Old ProbeFile will be used"+"\n"))
        overwrite = False

args = "python " + parameters["PrepareProbeFile_executable"] + " "+str(parameters["SurfaceFile"])+" "+str(
    parameters["pfile"])+" "+str(parameters["ParameterFile"])+" "+str(parameters["probef"]+"> logout")
if overwrite == True:
    # first run change_atomNames.sh to change atoms names in the PDB file if necessary
    x = subprocess.call(
        [parameters["change_atomNames_executable"]+" " + parameters["pfile"]], shell=True)
    x = subprocess.call([parameters["change_atomNames_executable"] +
                         " " + parameters["SurfaceFile"]], shell=True)
    if x != 0:
        print(("***** the script ", parameters["change_atomNames_executable"],
               " is not available, check parameter change_atomNames_executable in the inputfile *****\n proceeding..."))

    x = subprocess.call([args], shell=True)
    if x != 0:
        try:
            print(("***** there was an error, check whether the ",
                   parameters["ParameterFile"], " contains all probes *****\n the next step might not work"))
            input = sys.stdin.readline()
        except KeyboardInterrupt:
            print("Aborted...")
            sys.exit(1)
print("---------------------------------------------------------------------")
print("            step 2: Setting user defined interactions...")
print("---------------------------------------------------------------------")
insert_INTERACTIONS()

overwrite = True
args = "ap"+parameters["efile"]+"-001.grd"
if (os.path.exists(args) == True) & (silent == False):
    print(("\n", "     !!! LJ grid already exists:", args))
    try:
        print("Press <ENTER> to create a new LJ grid (old wiil be deleted) (<STRG>+C to skip LJ grid calculations)")
        input = sys.stdin.readline()
    except KeyboardInterrupt:
        print("Aborted...")
        sys.exit(1)

if overwrite == True & (os.path.exists(args) == True):
    os.remove("ap"+parameters["efile"]+"-001.grd")
    os.remove("ap"+parameters["efile"]+"-002.grd")

# create inputfile for mk_LJ_grd...
print("----------------------------------------------------------------------")
print("        step 3: Input file for LJ grid calculations will be prepared")
print("----------------------------------------------------------------------")
make_LJ_input(parameters["LJinput"])
args = parameters["mk_LJ_grd_executable"]+" < "+str(parameters["LJinput"])

print("------------------------------------------------------------------------")
print("        step 4: LJ grid will be computed (stdout: logout)")
print("        (process may take several hours, please check layer.doin)")
print("-----------------------------------------------------------------------")
x = subprocess.call([args], shell=True)
if x == 2:
    try:
        print("***** there was an error, please check whether the *.grd files already exists and delete/rename them if so *****")
        input = sys.stdin.readline()
    except KeyboardInterrupt:
        print("Aborted...")
        sys.exit(1)

# remove temporary files
# os.remove(parameters["LJinput"])
# os.remove(ProbeFile)
