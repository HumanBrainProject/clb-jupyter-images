#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python
#
#   program sda
#  \version{version 6.00 (2010)}
#
#  Copyright (c) 2009, 2010
#  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#        formerly EML Research gGmbH (EML-R www.eml-research.de)
#  Schloss-Wolfsbrunnenweg 35
#  69118 Heidelberg, Germany
#
#  Copyright (c) 2000, 2003
#  European Molecular Biology Laboratory
#  Meyerhofstr. 1, Postfach 10.2209
#  D-69012, Heidelberg, Germany
#
#  Please send your contact address to get information on updates and
#  new features to "mcmsoft@h-its.org". Questions will be
#  answered as soon as possible.
#
#  References:
#     R.R. Gabdoulline, R.C. Wade.
#  Brownian dynamics simulation of protein-protein diffusional encounter.
#  (1998) Methods, 14, 329-341.
#  for additional references see http://mcm.h-its.org/mcmsoft/sda/6.00/#ref
#
#  \authors{Authors: R.R.Gabdoulline, R.C.Wade}


# 14 Feb  2008
# Bingding Huang
# usage:
# ./PrepareProbeFile.py SurfaceFile.pdb ProteinFile.pdb ParameterFile  OutputName.txt
# modify from Peter's file
# Treat surface atoms as the probe atoms, since there should be fewer atom
# types than in gold.
#

import sys
import string
import time
from math import sqrt


def PrintUsage():
    print("""
    usage:
    ./PrepareProbeFile.py SurfaceFile.pdb ProteinFile.pdb ParameterFile  OutputName.txt
    """)


class AtomType:
    def name(self, name):
        self.name = name

    def epsilon(self, epsilon):
        self.epsilon = epsilon

    def sigma(self, sigma):
        self.sigma = sigma

    def number(self, number):
        self.number = number


class TypeData:

    def __init__(self):
        self.TypeList = []

    def AddType(self):  # Adds another atom instance to the collection
        self.TypeList.append(AtomType())

    def IsInList(self, query):
        value = 0
        for Probe in self.TypeList:
            if query == Probe.name:
                value = 1
                break
        return(value)


def GetData(filename):
    Filename = filename
    FilePointer = open(Filename, 'r')
    DataLines = FilePointer.readlines()
    FilePointer.close()
    return(DataLines)


def AssignSigmaEpsilon(Types, equivalences, AtomParameters):
    Assigned = 0
    for Type in Types.TypeList:
        Type.sigma = -1.0
        Type.epsilon = 0.0
    for AtomParameter in AtomParameters.TypeList:
        for Type in Types.TypeList:
            if AtomParameter.name == Type.name:
                #print "Matched probe parameters: ", Type.name, AtomParameter.sigma, AtomParameter.epsilon
                Type.sigma = AtomParameter.sigma
                Type.epsilon = AtomParameter.epsilon
                # AtomParameters.TypeList[-1].epsilon(Epsilon)
                Assigned = Assigned+1
            if Assigned == len(Types.TypeList):
                break
        if Assigned == len(Types.TypeList):
            break
    if Assigned != len(Types.TypeList):
        print(" Assigned ", Assigned, "type list len ", len(Types.TypeList))
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("ERROR - some atom names were not found in the parameter file")
        for Type in Types.TypeList:
            if(Type.sigma >= 0):
                print(Type.name, Type.sigma, Type.epsilon)
            else:
                Type.sigma = 0.0
                print(Type.name, Type.sigma, Type.epsilon,
                      "  PARAMETER WAS NOT FOUND in the PARAMETER file !!!!!!!!!!!!!!!!!")
        print("ERROR - CHECK if the ATOM NAMES in your PDB file exist in PARAMERER FILE ! (for example, qtable_Parameters_30_10_09.dat) ")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("                           ")
 #       sys.exit()

# def AssignSigmaEpsilon(ProbeName, InteractionName, equivalences, AtomParameters):
    # ProbeFound=0
    # InteractFound=0
    # for AtomParameter in AtomParameters.TypeList:
        # try:
        ##print "AtomParameter loop name N equivalence", equivalences[AtomParameter.name], AtomParameter.name
        ##print "AtomParameter loop name ", AtomParameter.name
        ##print "ProbeName, Interaction: " + ProbeName, InteractionName
        ##print "sigman, epsilon", AtomParameter.sigma, AtomParameter.epsilon
        # synonym=equivalences(AtomParameter.name)
        #print "Probe: ", ProbeName
        #print "AtomParameterCheck: ", AtomParameter.name
        # if AtomParameter.name == ProbeName  or equivalences[AtomParameter.name] == ProbeName:
        #print "Probe parameter Found:", AtomParameter.name, AtomParameter.sigma ,AtomParameter.epsilon
        #ProbeSigma = AtomParameter.sigma
        #ProbeEpsilon = AtomParameter.epsilon
        # ProbeFound=1
        # if AtomParameter.name == InteractionName or  equivalences[AtomParameter.name] == InteractionName:
        #print "Interact parameter Found:", AtomParameter.name, AtomParameter.sigma ,AtomParameter.epsilon
        #InteractionSigma = AtomParameter.sigma
        #InteractionEpsilon = AtomParameter.epsilon
        # InteractFound=1
        # if ProbeFound == 1 and InteractFound == 1:
        # break
        # except:
        ##print "AtomParameter loop name ", AtomParameter.name
        ##print "ProbeName, Interaction: " + ProbeName, InteractionName
        ##print "sigman, epsilon", AtomParameter.sigma, AtomParameter.epsilon
        # if AtomParameter.name == ProbeName  :
        #print "No equivalences"
        #print "Probe parameter Found:", AtomParameter.name, AtomParameter.sigma ,AtomParameter.epsilon
        #ProbeSigma = AtomParameter.sigma
        #ProbeEpsilon = AtomParameter.epsilon
        # ProbeFound=1
        # if AtomParameter.name == InteractionName :
        #print "No equivalences"
        #print "Interact parameter Found:", AtomParameter.name, AtomParameter.sigma ,AtomParameter.epsilon
        #InteractionSigma = AtomParameter.sigma
        #InteractionEpsilon = AtomParameter.epsilon
        # InteractFound=1
        # if ProbeFound == 1 and InteractFound == 1:
        # break
#
    # if ProbeFound == 1 and InteractFound == 1:
        # sigma=0.5*(ProbeSigma+InteractionSigma)
        # espilon=sqrt(ProbeEpsilon*InteractionEpsilon)
    # else:
        #sigma="Type Not Found"
        #epsilon="Type Not Found"
    # return(sigma,epsilon)

#___________________________________End of Classes and Functions_________________________________________
#


def ReadParameterFile(ParameterFile):
    # 3. Read parameters and return equivalence and Atom parameters
    DataLines = GetData(ParameterFile)
    counter = -1
    # for line in DataLines[counter:]:
    equivalences = {}
    while counter < len(DataLines):
        counter = counter + 1
        line = DataLines[counter]
        # Check for an EQUIVALENCE statment.
        #print line

        try:
            entry = line.split()[0]
        except:
            # blank line
            entry = " "

        # if string.split(line)[0] == "EQUIVALENCE":
        if entry == "EQUIVALENCE":
            counter = counter + 1
            # read equivalence data
            # for line in DataLines[counter:]:
            while counter < len(DataLines):
                line = DataLines[counter]
                entry = line.split()
                if len(entry) == 0:
                    print("finished equivalences")
                    #counter = counter + 1
                    break
                else:
                    equivalences[entry[1]+"_"+entry[0]] = entry[3]+"_"+entry[2]
                    equivalences[entry[3]+"_"+entry[2]] = entry[1]+"_"+entry[0]
                    #print entry
                    counter = counter + 1

        #line = DataLines[counter]
        # try:
        #    entry=string.split(line)[0]
        # except:
        #    # blank line
    #	entry=" "

        #print entry
        if entry == "OPLS":
            print("Reading OPLS data")
            counter = counter + 1
            # Read key words
            keywords = DataLines[counter].split()
            # Assess order of keywords
            # for keyword in keywords
            # store index of keywords
            # Initially just assign indices as in the current file,
            # later should have small subroutine to calculate them
            ResIndex = 0
            AtomIndex = 1
            ChrgIndex = 2
            EpsiIndex = 3
            SigIndex = 4
            RadiiIndex = 5
            counter = counter + 1
            # for line in DataLines[counter:]:
            AtomParameters = TypeData()
            while counter < len(DataLines):
                line = DataLines[counter]
                entry = line.split()
                ResidueName = entry[ResIndex]
                AtomName = entry[AtomIndex]
                Epsilon = float(entry[EpsiIndex])
                Sigma = float(entry[SigIndex])
                #print AtomName
                #print "Adding new atom interaction type"
                InteractionName = AtomName+"_"+ResidueName
                AtomParameters.AddType()
                AtomParameters.TypeList[-1].name(InteractionName)
                AtomParameters.TypeList[-1].epsilon(Epsilon)
                AtomParameters.TypeList[-1].sigma(Sigma)
                counter = counter + 1

    #print equivalences
    print("lenght of atom parameters from qtable: ", len(
        AtomParameters.TypeList))
    return equivalences, AtomParameters


if len(sys.argv) < 5:
    PrintUsage()
    sys.exit(1)

SurfaceFile = sys.argv[1]
ProteinFile = sys.argv[2]
ParameterFile = sys.argv[3]
OutputName = sys.argv[4]
InitialProbeIndex = 1
ProbeIndex = InitialProbeIndex
ScalingFactor = "1"

# 1. Determine probes
# 1a. Write PDB file with probe numbers in
# 2. Determine interactions with probes
# 3. Read parameters
# 4. Assign Parameters to probes and Interaction atoms
# 5. Write probe file

# 1. Determine Probes
#Filename = SurfaceFile
# FilePointer=open(Filename,'r')
# DataLines=FilePointer.readlines()
# FilePointer.close()
DataLines = GetData(SurfaceFile)


# Read PDB header.
Header = ''
counter = 0
for line in DataLines:
    if line[0:4] != "ATOM" and line[0:6] != "HETATM":
        Header = Header + line
        counter = counter + 1
    else:
        break

# Read atom data
# Instantiate a probe collection object
Probes = TypeData()
for line in DataLines[counter:]:
    if line[0:4] == "ATOM" or line[0:6] == "HETATM":
        AtomName = line[11:17].split()[0]
        ResidueName = line[17:21].split()[0]
        ProbeName = AtomName+"_"+ResidueName
        if not Probes.IsInList(ProbeName):
            print("Adding new probe")
            Probes.AddType()
            Probes.TypeList[-1].name(ProbeName)
            if ProbeIndex < 10:
                ProbeNumber = "00"+str(ProbeIndex)
            elif ProbeIndex < 100:
                ProbeNumber = "0"+str(ProbeIndex)
            elif ProbeIndex < 1000:
                ProbeNumber = str(ProbeIndex)
            Probes.TypeList[-1].number(ProbeNumber)
            ProbeIndex = ProbeIndex+1
            print(Probes.TypeList[-1].name)
            # for Probe in Probes.TypeList:
            #print "@@@"
            #print Probe
            #print Probe.name
    else:
        break
print(" End Of Reading Probes")

print(len(Probes.TypeList))

for Probe in Probes.TypeList:
    #print "@@@"
    #print Probe
    print(Probe.name)


ProbeDataPDB = SurfaceFile[:-4]+"_ProbeSites.pdb"
FilePointer = open(ProbeDataPDB, 'w')
FilePointer.write(Header)
for line in DataLines[counter:]:
    if line[0:4] == "ATOM" or line[0:6] == "HETATM":
        AtomName = line[11:17].split()[0]
        ResidueName = line[17:21].split()[0]
        ProbeName = AtomName+"_"+ResidueName
        for Probe in Probes.TypeList:
            if Probe.name == ProbeName:
                FilePointer.write(line[0:54]+"   " +
                                  ScalingFactor+" "+Probe.number+"\n")
                break
    else:
        FilePointer.write(line)
FilePointer.close()


# 2. Determine interactions with probes
DataLines = GetData(ProteinFile)

# Read PDB header.
Header = ''
counter = 0
for line in DataLines:
    if line[0:4] != "ATOM" and line[0:6] != "HETATM":
        Header = Header + line
        counter = counter + 1
    else:
        break

# Read atom data
# Instantiate a probe collection object
# Interactions are still atoms
Interactions = TypeData()
for line in DataLines[counter:]:
    if line[0:4] == "ATOM" or line[0:6] == "HETATM":
        AtomName = line[11:17].split()[0]
        ResidueName = line[17:21].split()[0]
        InteractionName = AtomName+"_"+ResidueName
        if not Interactions.IsInList(InteractionName):
            #print "Adding new Interaction"
            Interactions.AddType()
            Interactions.TypeList[-1].name(InteractionName)
            #print Interactions.TypeList[-1].name
            # for Interaction in Interactions.TypeList:
            #   print "@@@"
            #   print Interaction
            #   print Interaction.name
    else:
        break
print(" End Of Reading Interactions")
print(len(Interactions.TypeList))

# for Interaction in Interactions.TypeList:
#   print Interaction.name

###
# 3. Read parameters

equivalences, AtomParameters = ReadParameterFile(ParameterFile)

# for AtomParameter in AtomParameters.TypeList:
#print "@@@"
#print AtomParameter
#print AtomParameter.name, AtomParameter.sigma, AtomParameter.epsilon


# 4. Assign Parameters to probes and Interaction atoms
AssignSigmaEpsilon(Probes, equivalences, AtomParameters)

for probe in Probes.TypeList:
    print("probe data: ", probe.name, probe.sigma, probe.epsilon)

AssignSigmaEpsilon(Interactions, equivalences, AtomParameters)
# for Interaction in Interactions.TypeList:
#    print "Interaction data: ", Interaction.name, Interaction.sigma, Interaction.epsilon

# 5. Write probe file
FilePointer = open(OutputName, 'w')
FilePointer.write("#Probe file generated from: \n")
FilePointer.write("#SurfaceFile " + SurfaceFile + "\n")
FilePointer.write("#ProteinFile " + ProteinFile + "\n")
FilePointer.write("#\n")
FilePointer.write("#Probes are taken from surface file\n")
FilePointer.write("#\n")
FilePointer.write("#Probe File generated: " +
                  time.strftime("%H:%M %A %d %B %Y", time.localtime())+"\n")
FilePointer.write("#\n")
print(time.strftime("%x %H:%M %A %B %d %Y", time.localtime()))
for probe in Probes.TypeList:
    FilePointer.write("PROBE "+probe.name+" "+probe.number+"\n")
    for Interaction in Interactions.TypeList:
        print("Interaction type: ", Interaction.name)
        print("sigma for probe, interaction site:",
              probe.sigma, Interaction.sigma)
        sigma = sqrt(probe.sigma*Interaction.sigma)
        epsilon = sqrt(probe.epsilon*Interaction.epsilon)
        FilePointer.write("INTERACT " + Interaction.name + " " +
                          str(sigma) + " " + str(epsilon) + "  # name sigma epsilon\n")
    FilePointer.write("ENDPROBE\n")
FilePointer.write("ENDFILE\n")
