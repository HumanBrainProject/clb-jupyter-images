#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

"""
    This script clusters the orientations from the SDA7 output.
    A PDB and complexes files should be input for the clustering.
    For information on other options the program should be run with -h option
    for usage and help informations.
"""

from __future__ import division
from copy import deepcopy
import math
import random
import sys
import os
try:
    import numpy as NP
    from numpy import linalg
except:
    print("Intall Numpy package!!! Exiting...")
    exit()
#import time

##########################################################
# sda class stores the information from a given SDA7 complexes file.


class sda:

    orientation_n = 0
    RMSD_MAT = ([])

    p1_com = ([0.0, 0.0, 0.0])
    p2_com = ([0.0, 0.0, 0.0])

    nrcmx = ([])  # No of the trajectory
    nscmx = ([])  # No of the step in this trajectory
    cmx_1 = ([])  # Coordinates of solute 2 center: x
    cmx_2 = ([])  # Coordinates of solute 2 center: y
    cmx_3 = ([])  # Coordinates of solute 2 center: z
    cmx_4 = ([])  # Orientation of the solute 2: x vector coordinates along x
    cmx_5 = ([])  # Orientation of the solute 2: y vector coordinates along x
    cmx_6 = ([])  # Orientation of the solute 2: z vector coordinates along x
    cmx_7 = ([])  # Orientation of the solute 2: x vector coordinates along y
    cmx_8 = ([])  # Orientation of the solute 2: y vector coordinates along y
    cmx_9 = ([])  # Orientation of the solute 2: z vector coordinates along y
    cmx_10 = ([])  # Total interaction energy of the complex (in kT)
    cmx_11 = ([])  # Electrostatic interaction energy (kT) of the complex
    cmx_12 = ([])  # Electrostatic desolvation energy (kT) of the complex
    cmx_13 = ([])  # Nonpolar desolvation energy (kT)
    cmx_14 = ([])  # LJ energy of the complex (kT)
    cmx_15 = ([])  # Occupancy
    cmx_16 = ([])  # Average energy
    cmx_17 = ([])  # Standard deviation of the average energy

    def __init__(self, complexes_file_name, atom_set):

        try:
            complexes = open(complexes_file_name, 'r')
        except:
            print("The '%s' file does not exist! Exiting..." %
                  complexes_file_name)
            exit()
        sda.atom_set = atom_set
        # Read the file!!
        complexes_r = complexes.readlines()
        complexes.close()
        if len(complexes_r) < 5:
            print("The '%s' file is empty! Exiting..." % complexes_file_name)

        for item in complexes_r:
            if item[0:2] == '##':
                continue
            else:
                if item[0:1] == '#':
                    sda.p1_com[0] = float(item[1:9])
                    sda.p1_com[1] = float(item[9:17])
                    sda.p1_com[2] = float(item[17:25])
                    sda.p2_com[0] = float(item[1:9])
                    sda.p2_com[1] = float(item[9:17])
                    sda.p2_com[2] = float(item[17:25])
                elif item[0:1] == '@':
                    continue
                elif item[0:1] == '!':
                    continue
                else:
                    sda.orientation_n += 1

                    sda.nrcmx.append(int(item[0:8]))
                    sda.nscmx.append(int(item[8:16]))
                    sda.cmx_1.append(float(item[16:25]))
                    sda.cmx_2.append(float(item[25:34]))
                    sda.cmx_3.append(float(item[34:43]))
                    sda.cmx_4.append(float(item[43:52]))
                    sda.cmx_5.append(float(item[52:61]))
                    sda.cmx_6.append(float(item[61:70]))
                    sda.cmx_7.append(float(item[70:79]))
                    sda.cmx_8.append(float(item[79:88]))
                    sda.cmx_9.append(float(item[88:97]))
                    sda.cmx_10.append(float(item[97:109]))
                    sda.cmx_11.append(float(item[109:121]))
                    sda.cmx_12.append(float(item[121:133]))
                    sda.cmx_13.append(float(item[133:145]))
                    sda.cmx_14.append(float(item[145:157]))
                    sda.cmx_15.append(float(item[157:169]))
                    sda.cmx_16.append(float(item[169:181]))
                    sda.cmx_17.append(float(item[181:193]))

        print("Number of orientations in the cluster file: ", sda.orientation_n)

    def __assoc_pdb__(self, pdb_file_name):
        sda.protein = pdb(pdb_file_name, sda.atom_set)
        sda.__build_structures__(self)
        if sda.orientation_n != sda.protein.set_n:
            print("sda.orientation_n =! sda.protein.set_n", "Exiting...")
            exit()

        # sda.protein.__trans_to_origin__()

    def structure_build(self, i, coordinates, atom_set_n):
        # BINGDING's CODE!!!
        r = [sda.cmx_1[i], sda.cmx_2[i], sda.cmx_3[i]]

        xp = [sda.cmx_4[i], sda.cmx_5[i], sda.cmx_6[i]]
        yp = [sda.cmx_7[i], sda.cmx_8[i], sda.cmx_9[i]]
        zp = cross(xp, yp)
        zp = norm(zp)

        rotX1 = [xp[0], yp[0], zp[0]]  # transpose matrix
        rotY1 = [xp[1], yp[1], zp[1]]
        rotZ1 = [xp[2], yp[2], zp[2]]

        xt2a = []
        for j in range(atom_set_n):
            #print j, sda.protein.atom_n
            vorig = NP.array(coordinates[0][j])[0]
            vnew = tr(vorig, rotX1, rotY1, rotZ1)  # matrix rotation
            cc = [0.0, 0.0, 0.0]
            for k in range(3):
                # translation (+r +xc1)   cc: new coordinate after transformation
                cc[k] = vnew[k]+r[k]+sda.p2_com[k]
            xt2a.append(cc)
        return NP.matrix(xt2a)

    def __build_structures__(self):
        print("Building the structures using pdb file")
        for i in xrange(0, sda.orientation_n):
            xt2a = sda.structure_build(
                self, i, sda.protein.coordinates, sda.protein.atom_n)
            sda.protein.trajectory.append(xt2a)
            sda.protein.incr()

# for objects to store structure and coordinate information that comes from PDB files


class pdb:
    coordinates = ([])
    trajectory = ([])
    set_n = 0
    residue_n = 0
    atom_n = 0

    def __init__(self, pdb_file_name, atom_set=3):
        pdb.file_name = pdb_file_name
        atom_n, coord = pdb.extract_coordinates(self, atom_set)
        pdb.atom_n = atom_n
        pdb.coordinates.append(coord)

    def extract_coordinates(self, set_atom):
        coord = ([])
        atom_n = 0
        try:
            pdb_f = open(pdb.file_name, 'r')
        except:
            print("The '%s' file does not exist! Exiting..." % pdb.file_name)
            exit()

        # Read the file!!
        pdb_r = pdb_f.readlines()
        pdb_f.close()
        if len(pdb_r) < 2:
            print("The '%s' file is empty! Exiting..." % pdb.pdb_file_name)
            exit()

        for item in pdb_r:
            if item[0:4] == 'ATOM':
                if item[21:22] == 'A'or item[21:22] == 'X' or item[21:22] == ' ':
                    if item[13:15] == 'CA':

                        x = float(item[30:38])
                        y = float(item[38:46])
                        z = float(item[46:54])
                        coord.append([x, y, z])
                        atom_n += 1
                        pdb.residue_n += 1
                    else:
                        if set_atom == 1:
                            x = float(item[30:38])
                            y = float(item[38:46])
                            z = float(item[46:54])
                            coord.append([x, y, z])
                            atom_n += 1
                        elif set_atom == 2:
                            if item[13:15] == 'C ' or item[13:15] == 'O ' or item[13:15] == 'N ':
                                x = float(item[30:38])
                                y = float(item[38:46])
                                z = float(item[46:54])
                                coord.append([x, y, z])
                                atom_n += 1
                        else:
                            continue
        return atom_n, NP.matrix(coord)

    def __trans_to_origin__(self):
        print("Translating the structures to the origin")

        for i in xrange(0, pdb.set_n):

            mean_x = 0.0
            mean_y = 0.0
            mean_z = 0.0

            for j in xrange(0, pdb.atom_n):
                mean_x += pdb.trajectory[i][j, 0]
                mean_y += pdb.trajectory[i][j, 1]
                mean_z += pdb.trajectory[i][j, 2]
            mean_x /= pdb.atom_n
            mean_y /= pdb.atom_n
            mean_z /= pdb.atom_n

            for j in xrange(0, pdb.atom_n):
                pdb.trajectory[i][j, 0] -= mean_x
                pdb.trajectory[i][j, 1] -= mean_y
                pdb.trajectory[i][j, 2] -= mean_z

    def incr(self):
        pdb.set_n += 1

    def center_of_geometry(self):
        mean_x = 0.0
        mean_y = 0.0
        mean_z = 0.0
        for j in xrange(0, pdb.atom_n):
            mean_x += pdb.coordinates[0][j, 0]
            mean_y += pdb.coordinates[0][j, 1]
            mean_z += pdb.coordinates[0][j, 2]
        mean_x /= pdb.atom_n
        mean_y /= pdb.atom_n
        mean_z /= pdb.atom_n
        return [mean_x, mean_y, mean_z]

    def write_pdb(self, coordinates, i=0, set_atom=3, rot_matrix=NP.eye(3, 3)):
        pdb_file_name = 'complex%d.pdb' % (i+1)
        pdb_w = open(pdb_file_name, 'w')

        pdb_f = open(pdb.file_name, 'r')
        pdb_r = pdb_f.readlines()
        pdb_f.close()

        #coordinates = pdb.trajectory[i] * rot_matrix
        coordinates = coordinates * rot_matrix
        atom_n = 0

        for item in pdb_r:
            if item[0:4] == 'ATOM':
                if item[21:22] == 'A'or item[21:22] == 'X' or item[21:22] == ' ':
                    if item[13:15] == 'CA':
                        print("%s%8.3f%8.3f%8.3f%s" % (item[0:30], coordinates[atom_n, 0],
                                                       coordinates[atom_n, 1],
                                                       coordinates[atom_n, 2], item[54:69]), file=pdb_w)
                        atom_n += 1
                    else:
                        if set_atom == 1:
                            print("%s%8.3f%8.3f%8.3f%s" % (item[0:30], coordinates[atom_n, 0],
                                                           coordinates[atom_n, 1],
                                                           coordinates[atom_n, 2], item[54:69]), file=pdb_w)
                            atom_n += 1
                        elif set_atom == 2:
                            if item[13:15] == 'C ' or item[13:15] == 'O ' or item[13:15] == 'N ':
                                print("%s%8.3f%8.3f%8.3f%s" % (item[0:30], coordinates[atom_n, 0],
                                                               coordinates[atom_n, 1],
                                                               coordinates[atom_n, 2], item[54:69]), file=pdb_w)
                                atom_n += 1
                        else:
                            continue

        pdb_w.close()


##########################################################

# CHECK!!! : BINGDING's FUNCTIONS
# scaler product
def dot(a, b):

    c = a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    return c

# vector product


def cross(a, b):
    """
    cross product of two vectors
    """

    ti = [0, 0, 0]

    ti[0] = a[1]*b[2]-a[2]*b[1]
    ti[1] = a[2]*b[0]-a[0]*b[2]
    ti[2] = a[0]*b[1]-a[1]*b[0]

    return ti


def norm(wa):
    """
    normalized the vector
    """
    s = wa[0]**2
    s += wa[1]**2
    s += wa[2]**2
    s = math.sqrt(s)
    if s == 0:
        print(wa)

    wa[0] = wa[0]/s
    wa[1] = wa[1]/s
    wa[2] = wa[2]/s
    return wa


def tr(vorig, x, y, z):
    """
    Transforms a vector from one coordinate system to another.        
    vorig = vector in original coordinate system            
    vnew  = resultant vector in new coordinate system            
    x,y,z = axis vectors of new coordinate system in terms of orig coord
    syst.
    """

    # first make sure x,y,z are normalized:
    vnew = [0, 0, 0]

    sumx = 0.0
    sumy = 0.0
    sumz = 0.0
    for i in range(3):  # sum
        sumx += x[i]**2
        sumy += y[i]**2
        sumz += z[i]**2
    sumx = math.sqrt(sumx)
    sumy = math.sqrt(sumy)
    sumz = math.sqrt(sumz)

    for i in range(3):  # normalized
        x[i] = x[i]/sumx
        y[i] = y[i]/sumy
        z[i] = z[i]/sumz

    # now perform transformation
    vnew[0] = dot(vorig, x)
    vnew[1] = dot(vorig, y)
    vnew[2] = dot(vorig, z)

    return vnew
# END : BINGDING's FUNCTIONS

# calculate RMSD between two structures.


def rmsd(A, B, R=NP.eye(3, 3)):

    A = NP.transpose(A)
    B = NP.transpose(B)

    N = (NP.shape(A))[1]

    C = R * A
    KLM = C - B

    smm = NP.sum(NP.square(KLM))
    rms = math.sqrt((smm)/N)
    return rms


def rotation(A, B):
    C = (NP.transpose(A))*B
    # matrix A is transposed. the normal shape of coordinate matrix is N (rows) X 3 (columns)
    # after the transposition the shape of the coordinate matrix becomes 3 (rows) X N (columns)
    # the product of the multiplication is a matrix of shape 3 X 3
    v, x, w = linalg.svd(C)
    #isnt_reflection = (linalg.det(v)*linalg.det(w)) > 0.0
    is_reflection = linalg.det(C) > 0.0
    d = len(x)
    if is_reflection:
        s = NP.eye(d, d)
    else:
        s = NP.matrix([[1, 0, 0], [0, 1, 0], [0, 0, -1]])

    dott = NP.mat(v)*NP.mat(s)*NP.mat(w)
    #dotp = NP.mat(dott)
    theta = -1 * math.asin(dott[2, 0])
    psi = math.acos(dott[0, 0]/math.cos(theta))
    dotp = [[math.cos(psi), -math.sin(psi), 0],
            [math.sin(psi), math.cos(psi), 0], [0, 0, 1]]
    dotp = NP.mat(dotp)
    return dotp

# function to compute weighted standard deviation


def weighted_avg_and_std(values, weights):

    average = NP.average(values, weights=weights)
    variance = NP.average((values-average)**2, weights=weights)

    return math.sqrt(variance)

##########################################################

# main function that builds RMSD matrix that stores RMSD values between each orientation/conformation


def build_rmsd_matrix(object_sda, rmsd_mat):
    object_sda.RMSD_MAT.append(
        NP.zeros([object_sda.orientation_n, object_sda.orientation_n]))

    try:
        # try if RMSD matrix file is available
        rmsd_read = open(rmsd_mat, 'r')
        print("Reading from the rmsd file...")
        rmsd_read_r = rmsd_read.readlines()
        rmsd_read.close()
        for i in xrange(0, object_sda.orientation_n):
            # if ((i+1) % 10) == 0:
            #    print i+1
            # else:
            #    print i+1,
            for j in xrange(0, object_sda.orientation_n):
                object_sda.RMSD_MAT[0][i, j] = float(rmsd_read_r[i].split()[j])
    except:
        print("Couldn't read from the rmsd file!\nThe rmsd matrix is being build...")

        for i in xrange(0, object_sda.orientation_n):

            if i == int(object_sda.orientation_n * 0.2):
                print("                 20% completed")
            elif i == int(object_sda.orientation_n * 0.4):
                print("                 40% completed")
            elif i == int(object_sda.orientation_n * 0.6):
                print("                 60% completed")
            elif i == int(object_sda.orientation_n * 0.8):
                print("                 80% completed")
            else:
                pass

            for j in xrange(i+1, object_sda.orientation_n):
                #R = rotation(object_sda.protein.trajectory[i], object_sda.protein.trajectory[j])
                #rmsd_value = rmsd(object_sda.protein.trajectory[i], object_sda.protein.trajectory[j], R)
                rmsd_value = rmsd(
                    object_sda.protein.trajectory[i], object_sda.protein.trajectory[j])
                object_sda.RMSD_MAT[0][i, j] = rmsd_value

        print("                100% completed")
        print()

        for i in xrange(0, object_sda.orientation_n):
            for j in xrange(0, i):
                object_sda.RMSD_MAT[0][i, j] = object_sda.RMSD_MAT[0][j, i]

# write RMSD matrix to file


def write_rmsd_matrix(object_sda):
    matrix_file = open('RMSD_matrix.dat', 'w')
    for i in xrange(0, object_sda.orientation_n):
        for j in xrange(0, object_sda.orientation_n):
            print("%.2f" % object_sda.RMSD_MAT[0][i, j], "\t", end=' ', file=matrix_file)
        print(file=matrix_file)
    print(file=matrix_file)
    matrix_file.close()

# Method for initial cluster seed selection.
# The structures with the largest rmsd values are chosen
# Other cluster seeds are chosen from those that have largest RMSD values from the initial two
# Currently not used.


def Seeds(object_sda, seed_n):
    Seed_List = []
    Seed_List_t = NP.unravel_index(
        object_sda.RMSD_MAT[0].argmax(), object_sda.RMSD_MAT[0].shape)
    Seed_List.append(Seed_List_t[0])
    Seed_List.append(Seed_List_t[1])

    for it in range(seed_n-2):
        max_val_n = 0.0
        for i in range(0, object_sda.orientation_n):
            if Seed_List.count(i) == 0:
                temp_val = 0
                for item in Seed_List:
                    # to find the orientations that have large rmsd values for every seed in the list
                    temp_val += object_sda.RMSD_MAT[0][i, item]
                if temp_val > max_val_n:
                    max_val_n = temp_val
                    maxN = i

        Seed_List.append(maxN)

    print("Seed List:\t", Seed_List)
    return Seed_List

# Forgy method (Default)
# Select the cluster seeds randomly


def Seeds_random(object_sda, seed_n, r_seed):
    #Seed_List = [random.randrange(object_sda.orientation_n) for i in xrange (seed_n)]
    random.seed(r_seed)
    Seed_List = []
    while len(Seed_List) != seed_n:
        rand_n = random.randrange(object_sda.orientation_n)
        if Seed_List.count(rand_n) == 0:
            Seed_List.append(rand_n)

    print("Seed List:\t", Seed_List)
    return Seed_List

# Find the structures that are geometrically closest to the updated cluster seeds
# Update the list of cluster members for each seed.


def cluster_first_step(object_sda, rmsd_cutoff=12.0):

    global cluster_dict
    global seed_list

    for item in seed_list:
        cluster_dict[item] = []

    for i in xrange(0, object_sda.orientation_n):
        min_val = 10.0e20
        # if seed_list.count(i) == 0:
        for item in seed_list:
            if object_sda.RMSD_MAT[0][i, item] < min_val:
                min_val = object_sda.RMSD_MAT[0][i, item]
                minI = i
                clust_item = item
        if object_sda.RMSD_MAT[0][minI, clust_item] < rmsd_cutoff:
            cluster_dict[clust_item].append(minI)

# k-means clustering main function


def k_means_clustering(object_sda, max_iteration):
    global cluster_dict
    global seed_list
    prev_cluster_dict = []
    #print cluster_dict

    for n in xrange(0, max_iteration):
        prev_cluster_dict.append(cluster_dict)

        # Find the representative in each cluster and update the seed list
        seed_list_new = []
        for item in seed_list:
            min_val = 10.0e20
            for i in xrange(0, len(cluster_dict[item])):
                sum_rmsd = 0.0
                for j in xrange(0, len(cluster_dict[item])):
                    sum_rmsd += object_sda.RMSD_MAT[0][cluster_dict[item]
                                                       [i], cluster_dict[item][j]]
                if sum_rmsd < min_val:
                    min_val = sum_rmsd
                    minI = cluster_dict[item][i]
            seed_list_new.append(minI)
        seed_list = deepcopy(seed_list_new)
        # find the members of each of the new clusters
        cluster_dict = {}
        cluster_first_step(object_sda)
        #print cluster_dict
        for l in range(0, len(prev_cluster_dict)):
            if prev_cluster_dict[l] == cluster_dict:
                #print "HERE"
                return 0
    return 0

# Write the cluster representatives to PDB files


def write_rep_pdb(object_sda):
    global rep_list
    for item in rep_list:
        atom_n, coord_pdb = object_sda.protein.extract_coordinates(1)
        coord = object_sda.structure_build(item, [coord_pdb], atom_n)
        object_sda.protein.write_pdb(coord, item, 1)

# Calculate the cluster statistics and write into an output file
# Not sure if 'RepRMSD' and 'CLFRMSD' correspond to those in average-linkage implementation!


def output(object_sda):
    global seed_list
    global rep_list
    global cluster_dict

    cluster_out = open('cluster_info.out', 'w')

    description_text = "Description of columns:\n" + \
                       "No:\t\tCluster Number\n" + \
                       "ClSize:\t\tNumber of entries in the complex file used in the cluster\n" + \
                       "ClFSize:\tNumber of representative entries for the cluster\n" + \
                       "Repr:\t\tRepresentative chosen (corresponds to the line number in the complex file)\n" + \
                       "ReprE:\t\tTotal interaction energy of the chosen Representative\n" + \
                       "ClAE:\t\tAverage total energy of all cluster members weighted with the number of representatives.\n" + \
                       "CLAED:\t\tWeighted standard deviation of total energy of cluster entries in the complex file\n" + \
                       "RepRMSD:\tRMSD of the representative to solute 2\n" + \
                       "CLFRMSD:\tAverage RMSD of the cluster to solute 2\n" + \
                       "Ele:\t\tElectrostatic energy of the representative complex\n" + \
                       "ElDesE:\t\tElectrostatic desolvation energy of the representative complex\n" + \
                       "HyDesE:\t\tHydrophobic desolvation energy of the representative complex\n" + \
                       "LjE:\t\tLennard-Jones/Soft-core repulsion energy of the representative complex\n" + \
                       "spread:\t\tarithmetic average of rmsd's of each cluster member from the representative, weighted by occupancy\n" + \
                       "stddev:\t\tStddev of the rmsd's for a given cluster, weighted by occupancy\n" + \
                       "max:\t\tMaximum rmsd within one cluster from the representative"

    print("%4s%7s%10s%6s%10s%10s%10s%10s%10s%10s%10s%10s%10s%10s%10s%10s" %
          ("No",  "ClSize", "ClFSize", "Repr", "ReprE", "ClAE", "ClAED", "RepRMSD",
           "CLFRMSD", "ElE", "ElDesE", "HyDesE", "LjE", "spread", "stddev", "max"), file=cluster_out)

    for i in range(0, len(seed_list)):
        cluster_size = 0
        weight_total = 0

        ClFSize = 0
        ClAE = 0.0
        CLAED = 0.0
        RepRMSD = 0.0
        CLFRMSD = 0.0
        ElE = 0.0
        ElDesE = 0.0
        HyDesE = 0.0
        LjE = 0.0
        spread = 0.0
        stddev = 0.0
        max_r = 0.0

        for item in seed_list:
            if len(cluster_dict[item]) > cluster_size:
                cluster_size = len(cluster_dict[item])
                max_size = item
        seed_list.remove(max_size)
        rep_list.append(max_size)

        rep_energy = object_sda.cmx_10[max_size]
        ElE = object_sda.cmx_11[max_size]
        ElDesE = object_sda.cmx_12[max_size]
        HyDesE = object_sda.cmx_13[max_size]
        LjE = object_sda.cmx_14[max_size]

        RepRMSD = rmsd(
            object_sda.protein.trajectory[max_size], object_sda.protein.coordinates[0])

        std_energy_list = []
        std_rmsd_list = []
        weight_list = []

        member_count = 0

        for member in cluster_dict[max_size]:

            member_count += 1
            weight_total += object_sda.cmx_15[member]
            #ClFSize      += object_sda.nrcmx[member] * object_sda.cmx_15[member]
            ClAE += object_sda.cmx_10[member] * object_sda.cmx_15[member]
            CLFRMSD += rmsd(object_sda.protein.trajectory[member],
                            object_sda.protein.coordinates[0])

            spread += object_sda.RMSD_MAT[0][max_size,
                                             member] * object_sda.cmx_15[member]

            std_energy_list.append(object_sda.cmx_10[member])
            std_rmsd_list.append(object_sda.RMSD_MAT[0][max_size, member])
            weight_list.append(object_sda.cmx_15[member])

            if (object_sda.RMSD_MAT[0][max_size, member]) > max_r:
                max_r = object_sda.RMSD_MAT[0][max_size, member]

        std_energy_list = NP.array(std_energy_list)
        std_rmsd_list = NP.array(std_rmsd_list)
        weight_list = NP.array(weight_list)

        ClFSize = weight_total
        ClAE /= weight_total
        spread /= weight_total

        CLFRMSD /= member_count

        CLAED = weighted_avg_and_std(std_energy_list, weight_list)
        stddev = weighted_avg_and_std(std_rmsd_list, weight_list)

        print("%4d%7d%10d%6d%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f" % (i+1,
                                                                                                         cluster_size, ClFSize, max_size+1, rep_energy, ClAE, CLAED, RepRMSD,
                                                                                                         CLFRMSD, ElE, ElDesE, HyDesE, LjE, spread, stddev, max_r), file=cluster_out)

    print("\n\n", file=cluster_out)
    print(description_text, file=cluster_out)

    cluster_out.close()

# Cluster main function for SDA7 input. (urrently no MD trajectory input is available)


def sda_clust(pdb_file_name, complexes_file_name, seed_n, atom_set, rmsd_mat, r_seed):
    global cluster_dict
    global seed_list

    # Create the sda object
    sda_comp = sda(complexes_file_name, atom_set)
    sda_comp.__assoc_pdb__(pdb_file_name)

    build_rmsd_matrix(sda_comp, rmsd_mat)
    write_rmsd_matrix(sda_comp)

    # while r_seed != -1:
    # create initial seed list
    seed_list = Seeds_random(sda_comp, seed_n, r_seed)
    # define the cluster members for each of the seed
    cluster_first_step(sda_comp)
    # k-means clustering main function
    k_means_clustering(sda_comp, 1000)
    # write the stats to output file
    output(sda_comp)
    os.system('cat cluster_info.out')

    #r_seed = int(raw_input("Enter a new seed number: "))
    #print r_seed
    #x = raw_input("Press Enter")
    # end of while

    # write PDB files for representatives
    write_rep_pdb(sda_comp)

    del sda_comp
    return 0


def md_clust(trajectory_file_name, Seed_Num):
    return 0


def usage():
    usage_str = "USAGE:\n" + \
                "python ./kmeans.py -pdb p2.pdb -comp complexes.comp_cluster -cln 5"
    help_str = "\n" + \
        "Option\t Opt?\t Description\n" + \
        7*'-' + 6*'-' + 50*'-' + "\n" + \
        "-pdb \t No  \t The name of the PDB file\n" + \
        "-comp\t No  \t The name of the complexes file\n" + \
        "-rmat\t Yes \t The name of the matrix file. (If previously computed!)\n" + \
        "-cln \t Yes \t Number of clusters requested\n" + \
        "     \t     \t Default value is 5\n" + \
        "-atom\t Yes \t Selection of atoms from the PDB file\n" + \
        "     \t     \t Available options are: 'all' for all atoms, \n" + \
        "     \t     \t 'bb' for backbone atoms and 'ca' for CA atoms.\n" + \
        "     \t     \t Default option is 'all'.\n" + \
        "-seed\t Yes \t Seed for the random number generator\n" + \
        "     \t     \t Default seed number is 255.\n"
    print(usage_str)
    print(help_str)


def main():

    # GLOBAL VARIABLES!!!
    global seed_list
    global rep_list
    rep_list = []
    global cluster_dict
    cluster_dict = {}

    md = 0
    sda = 1
    Seed_Num = 255
    cluster_n = 5
    atom_set_s = 'ca'
    rmsd_mat = ''

    # Read the input arguments
    arguments_l = len(sys.argv)
    for item in range(arguments_l):
        if sys.argv[item] == '-h':
            usage()
            exit()
        if sys.argv[item] == '-md':
            md = 1
        if sys.argv[item] == '-sda':
            sda = 1
        if sys.argv[item] == '-traj':
            trajectory_file_name = sys.argv[item+1]
        if sys.argv[item] == '-pdb':
            pdb_file_name = sys.argv[item+1]
        if sys.argv[item] == '-comp':
            complexes_file_name = sys.argv[item+1]
        if sys.argv[item] == '-cln':
            cluster_n = int(sys.argv[item+1])
        if sys.argv[item] == '-seed':
            Seed_Num = int(sys.argv[item+1])
        if sys.argv[item] == '-atom':
            atom_set_s = sys.argv[item+1]
        if sys.argv[item] == '-rmat':
            rmsd_mat = sys.argv[item+1]

    if md == 1 and sda == 1:
        print("MD or SDA?")
        return 0

    if md == 0 and sda == 0:
        print("MD or SDA?")
        return 0

    if atom_set_s == 'ca':
        atom_set = 3
    elif atom_set_s == 'bb':
        atom_set = 2
    elif atom_set_s == 'all':
        atom_set = 1
    else:
        print("Invalid atom selection! Exiting...")
        exit()
    # Currently not implemented. Should input a trajectory file as well.
    if md == 1:
        print("MD trajectory clustering has not been implemented yet!")
        print("Exiting!")
        exit()
        # if not trajectory_file_name:
        #    print "Trajectory file is missing!"
        #    return 0
        # md_clust(trajectory_file_name,cluster_n)

    # Default option is currently sda
    if sda == 1:
        try:
            pdb_file_name
        except:
            print("PDB file is missing!")
            exit()
        try:
            complexes_file_name
        except:
            print("Complexes file is missing!")
            exit()
        sda_clust(pdb_file_name, complexes_file_name,
                  cluster_n, atom_set, rmsd_mat, Seed_Num)

    return 0


if __name__ == "__main__":
    main()
