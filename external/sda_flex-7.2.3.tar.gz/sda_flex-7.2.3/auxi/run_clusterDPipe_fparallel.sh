

#CLUST_DPIPE_EXE=../../../../bin/cluster
#CLUST_DPIPE_EXE=/exports/scratch/workgroup/sdac/trunk/auxi/clustering/programs/sda/clust/go
#CLUST_DPIPE_EXE=/exports/scratch/workgroup/sda_flex/auxi/clustering/programs/clust/go
CLUST_DPIPE_EXE=/exports/scratch/workgroup/TestFortran90_v4_tparrallel/auxi/clustering/programs/clust/go

P1_root=../../../../Data/Mode1/pqrnoh_mode-7-
P2=../../../../Data/RanGTPase-com-C/pqrnoh_RanGTPase-com-C.pdb

## COMPLEXES=complexes12.comp_cluster

N=1000
N2=10

for i in `seq 15`
do

 ((NOSHIFT=$i-8))
 P1=${P1_root}${NOSHIFT}.pdb
 echo $P1

 mkdir Complexe$i
 cp ../complexes$i Complexe$i

 cd Complexe$i
 ##COMPLEXES=complexes$i

 ## make format cluster
 /exports/scratch/workgroup/TestFortran90_v4_tparrallel/bin/read_record complexes$i -format_cluster
 COMPLEXES=complexes${i}.comp_cluster


 $CLUST_DPIPE_EXE  -cl -n $N -f55 $COMPLEXES -p1 $P1 -p2 $P2 >> out_complexe$i
 $CLUST_DPIPE_EXE  -sc -f55 $COMPLEXES -p1 $P1 -p2 $P2  >> out_complexe$i
 $CLUST_DPIPE_EXE  -an -p -clcl $N2 -f55 $COMPLEXES -p1 $P1 -p2 $P2  >> out_complexe$i
 $CLUST_DPIPE_EXE  -re -clcl $N2 -f55 $COMPLEXES -p1 $P1 -p2 $P2  >> out_complexe$i

 cd ..

done


