//-------------------------------------------------------------------
// 
// Need:
// fort.55 file, protein 1 and 2 files, clustering data file  
//
// What: 
// clustering, printing clustering data, recover representatives
//
// HowTo:
// ./thisProgram --help
//
// 
// DMIssues:
// more flexible treatment of trimmed, excluded residues
//
//
// by D.M. 2005.11
//-------------------------------------------------------------------
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <sstream>
#include <cassert>

#include "sdafort55.h"
#include "clush.h"
#include "pdbin.h"
#include "vector3.h"
#include "pdbout.h"
#include "storage.h"
#include "datain.h"
#include "clp.h"
#include "scorerp.h"
#include "protein.h"
#include "resincont.h"
#include "investscore.h"

using namespace std;



// some possible parameters but not all:-)
  unsigned int _n        = 500;
  
  const string _f55      = "-f55";
  const string _p1       = "-p1";
  const string _p2       = "-p2";
  
  const string _clo      = "-clo";
  const string _cli      = "-cli";
        string clustDat  = "clust.dat";
  
  const string _p        = "-p";
  const string _v        = "-v";
  const string _cy       = "-cy";
  const string _bin      = "-bin";
  const string _clcv     = "-clcv";
  const string _clcl     = "-clcl";
  const string _clcn     = "-clcn";
  const string _clsz     = "-clsz";
  const string _rn       = "-rn";
  const string _out      = "-out";
  
  const string _sci      = "-sci";
        string scoreDat  = "score.dat";
  const string _rpin     = "-rpin";
  const string _cdist    = "-cdist";
        float   cdist    = 5.0f;   //contact distance
  const string _rpdef    = "-rpdef";
        int     rpdef    = 1;    //rp definition
  const string  _add     = "-cadd";
        float    add     = 1.0f;
//==================================================================>
// some foos ------------------------------------------------------->
/*! constructs and returns SDAFort55 object for clustering */
SDAFort55 constructSDAF55(const CLP* clp_);
/*! fills vector 'rp_' with caclculated residue propensities */
void doRPScore(const CLP* clp_, 
               const vector<const string*>& rpFiles_,
               vector<float>& rp_);
/*! recovers representatives into 'repr_' */
void getRepresentatives(const SDAFort55& sdaF55_, vector<int>& repr_,
                        const string& out_);
/*! prints data about clusters at some cycle */
void printClustData(const Cycle* cycle_, 
                    const CLP* clp_, 
                    const ClusterInvest* clInv_);
                    
void printClustData(const Cycle* cycle_, const CLP* clp_,
                    const ClusterInvest* clInv_,
                    const InvestScore* scInv_);             
//------------------------------------------------------------------|
//==================================================================|
                    


int main(int argc, char* argv[]){
  //================================================================>
  // HELP ---> HELP ---> HELP ---> HELP ---> HELP ---> HELP -------->  
  // if second argv is -h or --help print all help and exit
  if (argc == 2) {
    const string _1stPar  = argv[1];
    if (_1stPar == CLP::_h or _1stPar == CLP::_help) {
      CLP *_clpFile    = new CLPFile(argc, argv);
      CLP *_clpCluster = new CLPCluster(argc, argv);
      CLP *_clpAnalyze = new CLPAnalyze(argc, argv); 
      CLP *_clpRecover = new CLPRecover(argc, argv);
      CLP *_clpScore   = new CLPScore(argc, argv);
      cout << endl;
      _clpFile->printHelp(); 
      cout << endl;  
      _clpCluster->printHelp();
      cout << endl;
      _clpAnalyze->printHelp();
      cout << endl;
      _clpRecover->printHelp();
      cout << endl;
      _clpScore->printHelp();
      cout << endl;
      delete _clpFile, _clpCluster, _clpAnalyze, _clpRecover, _clpScore;
      exit(0);
    }
  }
  //----------------------------------------------------------------|
  //================================================================|
  
  
  
  // this is for checking if all inpur files are provided, when 
  // necessary
  CLPFile    *clpFile = new CLPFile(argc, argv);
  
  //================================================================>
  // CLUSTER ---> CLUSTER ---> CLUSTER ---> CLUSTER ---> CLUSTER ---> 
  CLP *clpCl   = new CLPCluster(argc, argv);
  if (clpCl->isRun()) { // if clustering
    clpFile->isRun();   // check files are privided
    
    cout << "CLUSTERING" << endl;
    cout << " 1. reading files..." << endl;   
    SDAFort55 sdaF55 = constructSDAF55(clpCl); // construct SDAFort55
    ClusterEngine clusterEngine; // constsruct ClusterEngine
    int _numbOfProteins = _n; // DEFAULT number of proteins to cluster
    // if -n int option is there cluster specified number of structure
    if (clpCl->isPar(CLP::_n) and clpCl->getVal(CLP::_n) != &CLP::none)
      _numbOfProteins = atoi(clpCl->getVal(CLP::_n)->c_str());
    // if more complex asked then there are in fort.55 just use all
    if (_numbOfProteins > sdaF55.getFort55LineNumber()) 
      _numbOfProteins = sdaF55.getFort55LineNumber(); 
    clusterEngine.setClusters(_numbOfProteins);
    
    cout << " 2. building rmsd matrix for " 
         << _numbOfProteins << " structures..." << endl;
    clusterEngine.setGroups(sdaF55.makePairHalfMatrix(_numbOfProteins));
    
    cout << " 3. clustering ..." << endl;
    while(clusterEngine.getClusterNumb() > 1){
      clusterEngine.runClusteringCycle();

      
    }
    
    cout << " 4. storing clustering data ..." << endl;
    string _clustDat = clustDat;
    // check if asked for specific output file, otherwise use default 
    if (clpCl->isPar(_clo) and clpCl->getVal(_clo) != &CLP::none) {
      _clustDat = *clpCl->getVal(_clo);
    }
    Writer* writer = new Writer(_clustDat);
    clusterEngine.storeClusteringData(*writer);
    delete writer;
    cout << endl;
  }
  delete clpCl;
  //----------------------------------------------------------------|
  //================================================================|
  
  
  //================================================================|
  // SCORE ---> SCORE ---> SCORE ---> SCORE ---> SCORE ---> SCORE --> 
  CLP *clpSc = new CLPScore(argc, argv);
  if (clpSc->isRun()) { // do scoring ?
    // load from clust.dat number of proteins to consider
    
    Reader *reader = new Reader(clustDat);
    *reader >> _n;
    delete reader;
    //
    clpFile->isRun();   // input file check
    // scores ^^^^^^^^^^^^^^^^^^^^^^^^^^
      vector<int> occ;                //
      vector<float> elE;              //
      vector<float> elEAvg;           //
      vector<float> elEDisp;          //
      vector<float> rmsds;            //
      vector<float> desE;             //
      vector<float> hyDe;             //
      vector<float> ljE;              //
      vector<float> coulEC;           //
      vector<float> surDC;            //
      vector<float> elecC;            //
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    // InvestScore object will be used just to load all scores into 
    // it and then store all data into the binary file
    InvestScore is; 
    cout << " 1. reading files..." << endl;
    SDAFort55 sdaF55 = constructSDAF55(clpSc);
    
    cout << " 2. getting occurancies..." << endl;
    occ    = sdaF55.getOccurancies();
    //cout << "size occ: " << sdaF55.getOccurancies().size() << endl;
    //cout << "size occ[0]" << (sdaF55.getOccurancies())[0] <<  " " << (sdaF55.getOccurancies())[1] << endl;
    is.setN(occ.size()); // set number of scored proteins
    is.setOcc(occ);
 
    cout << " 3. getting energies..." << endl;
    elE    = sdaF55.getElEnergies();
    is.setElE(elE);
    elEAvg = sdaF55.getAvgElEnergies();
    is.setElEAvg(elEAvg);
    elEDisp = sdaF55.getElEDisp();
    is.setElEDisp(elEDisp);
    
    desE = sdaF55.getDesE();
    is.setDesE(desE);
    hyDe=sdaF55.getHyDe();
    is.setHyDe(hyDe);
    ljE=sdaF55.getLjE();
    is.setLjE(ljE);
    coulEC=sdaF55.getCoulEC();
    is.setCoulEC(coulEC);
    surDC=sdaF55.getSurDC();
    is.setSurDC(surDC);
    elecC=sdaF55.getElecC();
    is.setElecC(elecC);
      
    cout << " 4. calculating backbone rmsds..." << endl;
    // this will be filed each time with recovered protein coordinates
    for (vector<F55Line>::const_iterator cit = 
         sdaF55.getFort55All()->begin();
         cit != sdaF55.getFort55All()->end();
         ++cit) {
      PdbFileS1 _tmp = sdaF55.recoverProtein(*cit);
      rmsds.push_back(_tmp.backbRmsd(*sdaF55.getProtein2()));
    }
    is.setRmsd(rmsds);
   
    // do rp scoring???     
    if (clpSc->isVal(_rpin)) {
       cout << " 5. residue propensity scoring..." << endl;  
      // get all files where to read residue propensities from
      vector<const string*> _s = clpSc->getAllVal(_rpin);  
      vector<float> _rp;  // residue propensiy vector
      doRPScore(clpSc, _s, _rp); // this foo calculates all rp's
      
      // this cycles loads all calculated rps to InvestScore object
      for (int i = 0; i < _s.size(); ++i) {
        vector<float> f;
        for (int j = i; j < _rp.size();) {
          f.push_back(_rp[j]);
          j = j + _s.size();
        } // for each docked protein rp
        is.setAddRP(f);
      } // for each rp type
    // if no rp calculation provided  
    }// rp scoring
    
    string _scoreDat = scoreDat;
    Writer *writer = new Writer(_scoreDat);
    is.storageWrite(*writer);
    delete writer;
  }
  delete clpSc;
  //----------------------------------------------------------------|
  //================================================================|
  
  
  //================================================================>  
  // ANALYSIS ---> ANALYSIS ---> ANALYSIS ---> ANALYSIS ------------> 
  CLP *clpAn   = new CLPAnalyze(argc, argv);
  // do analysis ?
  if (clpAn->isRun()) {
    // read specified clustering data file, otherwise default
    if (clpAn->isPar(_cli) and
       *clpAn->getVal(_cli) != CLP::none) { 
      clustDat = *clpAn->getVal(_cli);
    }
    if (clpAn->isPar(_sci) and
       *clpAn->getVal(_sci) != CLP::none) {
      scoreDat = *clpAn->getVal(_sci);
    }
    
    Reader* reader = new Reader(clustDat);
    ClusterInvest clusterInvest(*reader);
    
    // -p parameter
    if (clpAn->isPar(string (_p))) { // -p 
      // -p -cy
      
      if (clpAn->isPar(_p, _cy)) {   
        if (*clpAn->getVal(_p, _cy) == CLP::none) {
          clusterInvest.printCycleDataFrom(); // print all
        }else{ // print specified number of last cycles
          clusterInvest.printCycleDataFrom(atoi
          (clpAn->getVal(_p, _cy)->c_str() ) );
        }
      } // end -p -cy
      
      // -p -bin
      if (clpAn->isPar(_p, _bin)) {
        if (*clpAn->getVal(_p, _bin) == CLP::none) {
          clusterInvest.printBinLog(); // pring all
        } else {
          clusterInvest.printBinLog(atoi
          (clpAn->getVal(_p, _bin)->c_str() ) );
        }
      } // end -p -bin
      
      // -p -clcl --->
      if (clpAn->isPar(_p, _clcl) and
         *clpAn->getVal(_p, _clcl) != CLP::none) {
        clpFile->isRun(); // check files
        // prepare investScore object
        Reader *_reader = new Reader(scoreDat);
        InvestScore investScore(*_reader);
        delete _reader;
        
        unsigned int _numb = atoi(clpAn->getVal(_p, _clcl)->c_str());
        Cycle _cycle = *clusterInvest.getCycleWithNumbOfClusters(_numb); 
        // get cycle to analyze
        _cycle.sortClusters();
        printClustData(&_cycle, clpAn, &clusterInvest, &investScore);
      } // <--- -p -clcl
      
      // -p -clcn --->
      if (clpAn->isPar(_p, _clcn) and 
         *clpAn->getVal(_p, _clcn) != CLP::none) { 
        clpFile->isRun(); // check files
        // prepare investScore object
        Reader *_reader = new Reader(scoreDat);
        InvestScore investScore(*_reader);
        delete _reader;
        
        unsigned int _numb = atoi(clpAn->getVal(_p, _clcn)->c_str());
        Cycle _cycle = *clusterInvest.getCycle(_numb); // get cycle to analyze
        _cycle.sortClusters(); 
        printClustData(&_cycle, clpAn, &clusterInvest, &investScore); 
      } // <--- -p -clcn
      
      // -p -clvn --->
      if (clpAn->isPar(_p, _clcv) and
         *clpAn->getVal(_p, _clcv) != CLP::none) {
        clpFile->isRun(); // check files
        // prepare investScore object
        Reader *_reader = new Reader(scoreDat);
        InvestScore investScore(*_reader);
        delete _reader;
        
        const float _val = atof(clpAn->getVal(_p, _clcv)->c_str());
        Cycle _cycle = *clusterInvest.getCycle(_val);
        _cycle.sortClusters();
        printClustData(&_cycle, clpAn, &clusterInvest, &investScore);
      } // <--- -p -clcv
    }// <--- -p 
   
   
   // -v --->
    if (clpAn->isPar(string (_v))) {
      if (clpAn->isPar(_v, _clcn) and
         *clpAn->getVal(_v, _clcn) != CLP::none) { // -v -clcn --->
        Cycle _cycle = 
              *clusterInvest.getCycle(atoi(clpAn->getVal(_v, _clcn)->c_str()));
        _cycle.sortClusters();
        clusterInvest.visualizeClustAt(&_cycle);
      } // <--- -v -clcn
      if (clpAn->isPar(_v, _clcv) and
         *clpAn->getVal(_v, _clcv) != CLP::none) { // -v -clcv --->
        Cycle _cycle =
              *clusterInvest.getCycle(atof(clpAn->getVal(_v, _clcv)->c_str()));
        _cycle.sortClusters();
        clusterInvest.visualizeClustAt(&_cycle);
      } // <--- -v -clcv
    } // <--- -v 
  } // Analyze
  delete clpAn;
  //----------------------------------------------------------------|
  //================================================================|
  
  //================================================================>
  // RECOVER ---> RECOVER ---> RECOVER ---> RECOVER ---> RECOVER ---> 
  CLP *clpRec   = new CLPRecover(argc, argv);
  if (clpRec->isRun()) {
    clpFile->isRun(); // check files

    string _clustDat = clustDat;
    // if provided special input data file, else use default
    if (clpRec->isPar(_cli) and clpRec->getVal(_cli) != &CLP::none) {
      _clustDat = *clpRec->getVal(_cli);
    }  
    // if provided output folder
    string _add = "";
    if (clpRec->isPar(_out) and clpRec->getVal(_out) != &CLP::none) {
      _add = *clpRec->getVal(_out);
    }
    
    //Read first cluster.dat to get the number of initial structures    
    Reader* reader = new Reader(_clustDat);
    ClusterInvest clusterInvest(*reader);
    delete reader;    

    _n = clusterInvest.getProteinNumb(); //
    cout << "Number of initial structures in clust.dat (_n) " << _n << endl; //
    //now can load correctly fort.55
    SDAFort55 sdaF55 = constructSDAF55(clpRec);
    
    unsigned int _numb = 99999, _size = 5;
    // if provided number of clusters to get representatives from
    if (clpRec->isPar(_rn) and clpRec->getVal(_rn) != &CLP::none) 
      _numb = atoi(clpRec->getVal(_rn)->c_str());
    // if provided size of cluster to be considered as big enough
    if (clpRec->isPar(_clsz) and clpRec->getVal(_clsz) != &CLP::none)
      _size = atoi(clpRec->getVal(_clsz)->c_str());
    
    // get representatives at cycle wher number of clusters is -clcl
    if (clpRec->isPar(_clcl) and clpRec->getVal(_clcl) != &CLP::none) {
      unsigned int _cl =
      static_cast<int>(atoi(clpRec->getVal(_clcl)->c_str()));
      Cycle _cycle = 
      *clusterInvest.getCycleWithNumbOfClusters(_cl);
      _cycle.sortClusters();

      //cout << "Test \n getClusterNumb:" << _cycle.getClusterNumb() << endl;
      vector<int> _repr = 
      clusterInvest.getClustReprList(&_cycle, _numb, _size);
      getRepresentatives(sdaF55, _repr, _add);
    }
    
    if (clpRec->isPar(_clcn) and clpRec->getVal(_clcn) != &CLP::none) {
      Cycle _cycle = 
            *clusterInvest.getCycle(atoi(clpRec->getVal(_clcn)->c_str()));
      _cycle.sortClusters();
      vector<int> _repr = clusterInvest.getClustReprList(&_cycle, _numb, _size);
      getRepresentatives(sdaF55, _repr, _add);
    }
    
    
    if (clpRec->isPar(_clcv) and clpRec->getVal(_clcv) != &CLP::none) {
      Cycle _cycle = 
            *clusterInvest.getCycle(atof(clpRec->getVal(_clcv)->c_str()));
      _cycle.sortClusters();
      vector<int> _repr = clusterInvest.getClustReprList(&_cycle, _numb, _size);
      getRepresentatives(sdaF55, _repr, _add);
    }
  }
  delete clpRec;
  //----------------------------------------------------------------|
  //================================================================|
    
  delete clpFile;
  
  return 0;
} 

//==================================================================>
// foo ---> foo ---> foo ---> foo ---> foo ---> foo ---> foo ---> 
void getRepresentatives(const SDAFort55& sdaF55_, vector<int>& repr_,
                        const string& out_) {
  PdbFileOut pOut;
  PdbFileS1* recPdbFile;
  stringstream* ss;
  int _nn = 1;
  // for each representative index
  for (vector<int>::const_iterator citerI = repr_.begin();
       citerI != repr_.end(); ++citerI ) {
    recPdbFile = 
      new PdbFileS1(sdaF55_.recoverProtein(
      (*sdaF55_.getFort55All())[*citerI -1]) ); 
      
    ss = new stringstream;
    *ss << out_ << "cl" << _nn << ".pdb";
    pOut.writePdbFileS1(ss->str(), *recPdbFile);
    delete ss, recPdbFile;
    ++_nn;
  }
}

//void ListStructure()

SDAFort55 constructSDAF55(const CLP* clp_) {
   PdbIn pIn; 
   pIn.openFile(*clp_->getVal(CLPFile::_p1));
   PdbFileS1 pdbFileP1(pIn.getLinesX());
   pIn.openFile(*clp_->getVal(CLPFile::_p2));
   PdbFileS1 pdbFileP2(pIn.getLinesX());


   // load required number of fort.55 lines
   int n = _n; // DEFAULT 500
   if (clp_->isPar(CLP::_n) and clp_->getVal(CLP::_n) != &CLP::none)
     n = atoi(clp_->getVal(CLP::_n)->c_str());
   DataIn dIn;
   vector<string> f55Lines;
   dIn.getFort55All(*clp_->getVal(CLPFile::_f55), f55Lines, n);

   //cout <<  "check getFortAll55All:" << f55Lines[0] << endl;

   // make sdaF55
   SDAFort55 sdaF55;
   sdaF55.setProtein1(pdbFileP1);
   sdaF55.setProtein2(pdbFileP2);
   sdaF55.setFort55All(f55Lines);
   sdaF55.setP1Center(dIn.getFort55Center1(*clp_->getVal(CLPFile::_f55)));
   sdaF55.setP2Center(dIn.getFort55Center2(*clp_->getVal(CLPFile::_f55)));
   // NOTE: 'sdaF55' was constructed from protein files as is in 
   // p1.pdb and p2.pdb no "cleanning" or processing done
   // to have exact recovery of the proteins
   
   //vector<F55Line> f55line_tmp=sdaF55.fort55All;
   //cout <<  "constructSDAF55 check occur" << (sdaF55.fort55All)[0] << endl;
   //cout <<  "check occur:" << f55line_tmp[0].occur << endl;
   return sdaF55;
}  

void doRPScore(const CLP* clp_, 
               const vector<const string*>& rpFiles_, 
               vector<float>& rpScore_) {
  
  // load pdb files 
  PdbIn pIn;
  pIn.openFile(*clp_->getVal(CLPFile::_p1));
  PdbFile pdbFP1(pIn.getLinesX());
  pIn.openFile(*clp_->getVal(CLPFile::_p2));
  PdbFile pdbFP2(pIn.getLinesX()); 
  
  // clean proteins
  pdbFP1.removeHydrogens();
  pdbFP2.removeHydrogens();
  pdbFP1.fixResName("NTR");
  pdbFP2.fixResName("NTR");
  pdbFP1.fixResName("CTR");
  pdbFP2.fixResName("CTR");
  pdbFP1.changeResName("HIE", "HIS");
  pdbFP2.changeResName("HIE", "HIS");
  pdbFP1.changeResName("HID", "HIS");
  pdbFP2.changeResName("HID", "HIS");
  pdbFP1.changeResName("CYX", "CYS");
  pdbFP2.changeResName("CYX", "CYS");
  
  // get coords to vector of Vector3 s
  vector<Vector3> coordP1;
  pdbFP1.getAtomCoord(coordP1); 
  vector<Vector3> coordP2;
  pdbFP2.getAtomCoord(coordP2); 
  
  // load required number of fort.55 lines
  int n = _n; // DAFAULT 500
  if (clp_->isPar(CLP::_n) and clp_->getVal(CLP::_n) != &CLP::none)
    n = atoi(clp_->getVal(CLP::_n)->c_str()); // if provided
  DataIn dIn;
  vector<string> f55Lines;
  dIn.getFort55All(*clp_->getVal(CLPFile::_f55), f55Lines, n);
  
  // make sda Fort55
  SDAFort552 sdaF552;
  sdaF552.setProtein1(coordP1);
  sdaF552.setProtein2(coordP2);
  sdaF552.setFort55All(f55Lines);
  sdaF552.setCenter1(dIn.getFort55Center1(*clp_->getVal(CLPFile::_f55)));
  sdaF552.setCenter2(dIn.getFort55Center2(*clp_->getVal(CLPFile::_f55)));
  
  // SCORING SCORING SCORING SCORING SCORING SCORING SCORING SCORING 
  // prepare all ScoreRP objects
  vector<ScoreRP> _scoreRP;
  for (vector<const string*>::const_iterator cit = rpFiles_.begin();
       cit != rpFiles_.end(); ++cit) {
    map<string, float> _rp;
    // get residue propensities from each file
    dIn.getAAAFloat(*(*cit), _rp);
    // prepare ScoreRP objects for each residue propensity 
    ScoreRP _srp;
    _srp.loadStdRP(_rp);
    _scoreRP.push_back(_srp);
  }
  
  // construct ResidueInContact objec 
  Protein p1(pdbFP1);
  ResInCont ric;
  ric.setProtein1(p1);
  
  // PdbFile object of size of protein 2 PdbFile object
  // will be used to store recovered protein
  PdbFile pdbTmp(pdbFP2);
  vector<Vector3> coordTmp;
  
  // Calculate RP for all scorings
  rpScore_.reserve(coordP2.size() * rpFiles_.size());
  // foreach used line in fort.55
  for (vector<F55Line>::const_iterator cit = 
       sdaF552.getFort55All()->begin();
       cit != sdaF552.getFort55All()->end(); ++cit) {
    
    // recover to coordTmp
    sdaF552.recoverProtein(*cit, coordTmp);
    assert(coordTmp.size() == coordP2.size());
    
    // create PdbFile object
    pdbTmp.setAtomCoord(coordTmp);
    
    // create Protein 2
    Protein p2(pdbTmp);
    
    // reset Protein 2 in ric
    ric.setProtein2(p2);  


    // if contact distance provided, else use default
    if (clp_->isPar(_cdist) and clp_->getVal(_cdist) != &CLP::none) {
      cdist = atof(clp_->getVal(_cdist)->c_str());
    }
    // if add distance provided, else use default
    if (clp_->isPar(_add) and clp_->getVal(_add) != &CLP::none) {
      add = atof(clp_->getVal(_add)->c_str());
    }
    // if contact definition provided, else use default
    if (clp_->isPar(_rpdef) and clp_->getVal(_rpdef) != &CLP::none) {
      rpdef = atoi(clp_->getVal(_rpdef)->c_str());
    }
    if (rpdef == 6) {
      ric.addTrimmedRes("ARG");
      ric.addTrimmedRes("LYS");
      ric.addTrimmedRes("GLU");
      ric.addTrimmedRes("GLN");
    }
    if (rpdef == 5 || rpdef == 4) {
      ric.addExcludedRes("ARG");
      ric.addExcludedRes("LYS");
      ric.addExcludedRes("GLU");
      ric.addExcludedRes("GLN");
    }
   
    ric.findResCont(cdist, rpdef, add);
    
    // calculate the RP score
    for (vector<ScoreRP>::iterator it = _scoreRP.begin();
         it != _scoreRP.end(); ++it) {
      rpScore_.push_back(it->scoreRP(ric.getIntResP1(), ric.getIntResP2()));
    } // 
    
  } // RP scoring done

}

void printClustData(const Cycle* cycle_, 
                    const CLP* clp_,
                    const ClusterInvest* clInv_) {
  SDAFort55 sdaF55       = constructSDAF55(clp_);

  vector<int>   _occur   = sdaF55.getOccurancies();
  vector<float> _elEn    = sdaF55.getElEnergies();
  vector<float> _avgElEn = sdaF55.getAvgElEnergies();
  vector<float> _rmsds   = sdaF55.getRmsds();
  unsigned int _numb = 0; 
  // if -n parameter print specified number of clusters else, all
  if (clp_->isPar(CLP::_n) and *clp_->getVal(CLP::_n) != CLP::none) 
      _numb = atoi(clp_->getVal(CLP::_n)->c_str());
  unsigned int _size = 5;
  if (clp_->isPar(_clsz) and *clp_->getVal(_clsz) != CLP::none)
     _size = atoi(clp_->getVal(_clsz)->c_str());
    clInv_->printClustDataAtCycle(cycle_, &_occur, &_elEn,
                            &_avgElEn, &_rmsds, _numb, _size); 
}

void printClustData(const Cycle* cycle_, const CLP* clp_,
                    const ClusterInvest* clInv_,
                    const InvestScore* scInv_) {
  
  unsigned int _numb = 0;                  
  if (clp_->isPar(CLP::_n) and *clp_->getVal(CLP::_n) != CLP::none) 
      _numb = atoi(clp_->getVal(CLP::_n)->c_str());
  unsigned int _size = 5;
  if (clp_->isPar(_clsz) and *clp_->getVal(_clsz) != CLP::none)
     _size = atoi(clp_->getVal(_clsz)->c_str());
            
  // how many clusters to display
  vector<Cluster>::const_iterator citClFrom, citClTo;
  citClFrom = cycle_->getClusters()->begin();
  if (_numb != 0 and _numb < cycle_->getClusters()->size()) {
    citClTo = cycle_->getClusters()->begin() + _numb;
  } else {
    citClTo = cycle_->getClusters()->end();
  }
  //
  
  Uint _n = 0;
  cout << setw(3) << "No";
  cout << setw(8) << "ClSize";
  cout << setw(8) << "ClFSize";
  cout << setw(8) << "Repr";
  cout << setw(9) << "ReprE";
  cout << setw(9) << "ClAE";
  cout << setw(9) << "CLAED";
  cout << setw(9) << "RepRMSD";
  cout << setw(9) << "CLFRMSD";
  cout << setw(9) << "ElDesE";
  cout << setw(9) << "HyDesE";
  cout << setw(9) << "LjE";
  cout << setw(9) << "CouElE";
  cout << setw(9) << "SuDesE";
  cout << setw(9) << "tElE";
  for (int i = 1; i <= scInv_->getRPN(); ++i) {
    cout << setw(9) << "rpScore";// << i;
    cout << setw(9) << "stdDev";
  }
  cout << endl;
  
  for (vector<Cluster>::const_iterator cit = citClFrom;
       cit != citClTo; ++cit) {
    if (cit->getSize() < _size)
      break;
    ++_n;
    cout << setw(3) << _n;  
    cout << setw(8) << cit->getSize();
    cout << setw(8) << cit->getPropSum(scInv_->getOcc()); 
    unsigned int _rep = clInv_->getRepr(&(*cit));
    cout << setw(8) << _rep;
    cout.setf(ios::right, ios::adjustfield);
    cout.setf(ios::fixed, ios::floatfield);
    cout << setw(9) << setprecision(3)
                    << scInv_->getElE()[_rep - 1];
    cout << setw(9) << setprecision(3)
                    << cit->getFPropAvg(scInv_->getElEAvg(),
                                        scInv_->getOcc());
    cout << setw(9) << setprecision(3)
                    << cit->getFPropStdDeviation(scInv_->getElEAvg(),
                                                 scInv_->getOcc());
    cout << setw(9) << setprecision(3)
                    << scInv_->getRmsd()[_rep - 1];
    cout << setw(9) << setprecision(3)
                    << cit->getFPropAvg(scInv_->getRmsd(),
                                        scInv_->getOcc());
    cout << setw(9) << setprecision(3)
                    << scInv_->getDesE()[_rep -1];
    cout << setw(9) << setprecision(3)
                    << scInv_->getHyDe()[_rep -1];
    cout << setw(9) << setprecision(3)
                    << scInv_->getLjE()[_rep -1];
    cout << setw(9) << setprecision(3)
                    << scInv_->getCoulEC()[_rep -1];
    cout << setw(9) << setprecision(3)
                    << scInv_->getSurDC()[_rep -1];
    cout << setw(9) << setprecision(3)
                    << scInv_->getElecC()[_rep -1];
    for (vector<vector<float> >::const_iterator 
         cit2 = scInv_->getRP().begin();
         cit2 != scInv_->getRP().end(); ++cit2) {
      cout << setw(9) << setprecision(3)
           << cit->getPropAvg(*cit2);
      cout << setw(9) << setprecision(3)
           << cit->getPropStdDeviation(*cit2);
    }
    cout << endl;  
  } 

  cout << endl;
  cout << "Description of columns" << endl;
  cout << "No:        Cluster Number" << endl;
  cout << "ClSize:    Number of entries in the complexes (f55) file used in the cluster" << endl;
  cout << "ClFSize:   Number of representative entries for the cluster" << endl;
  cout << "Repr:      Representative chosen (corresponds to linenumber in the complexes, f55 file)" << endl;
  cout << "ReprE:     Total interaction energy of the chosen Representative" << endl;
  cout << "ClAE:      Average total energy of all cluster members weighted with number of representatives." << endl;
  cout << "CLAED:     Weighted standard deviation of total energy of cluster entries in the complexes (f55) file" << endl;
  cout << "RepRMSD:   RMSD of the representative to solute 2" << endl;
  cout << "CLFRMSD:   Average RMSD of the cluster to solute 2" << endl;
  cout << "ElDesE:    Electrostatic desolvation energy of the representative complex" << endl;
  cout << "HyDesE:    Hydrophobic desolvation energy of the representative complex" << endl;
  cout << "LjE:       Lennard-Jones energy of the representative complex" << endl;
  cout << "CouElE:    Interaction term of the electrostatic energy of the representative complex" << endl;
  cout << "SuDesE:    Surface desolvation energy of the representative complex" << endl;
  cout << "tElE:      Total electrostatic energy of the representative complex" <<endl;
  cout << "           (ElDesE + CouElE + effect of epsilon change due to desolvation for solid state surface calc.)" << endl;

}
