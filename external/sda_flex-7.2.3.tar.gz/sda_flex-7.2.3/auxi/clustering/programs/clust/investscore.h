

#ifndef INVESTSCORE_H
#define INVESTSCORE_H

#include <vector>
#include "storage.h"

using namespace std;

class InvestScore: public Storage {
  public:
    InvestScore(): n(0), rpN(0) {}
    InvestScore(Reader& reader_);

    int                  getN() const {return n;}
    const vector<float>& getTotE() const {return totE;}
    const vector<float>& getElE() const {return elE;}
    const vector<float>& getElEAvg() const {return elEAvg;}
    const vector<float>& getElEDisp() const {return elEDisp;}
    const vector<int>&   getOcc() const {return occ;} 
    const vector<float>& getRmsd() const {return rmsd;}
    int                  getRPN() const {return rpN;}
    const vector<vector<float> >& getRP() const {return rp;}

    const vector<float>& getDesE() const {return desE;}
    const vector<float>& getHyDe() const {return hyDe;}
    const vector<float>& getLjE() const {return ljE;}
    const vector<float>& getCoulEC() const {return coulEC;}
    const vector<float>& getSurDC() const {return surDC;}
    const vector<float>& getElecC() const {return elecC;}
    
    void setN(int n_) {n = n_;}
    void setTotE(const vector<float>& totE_) {totE = totE_;}
    void setElE(const vector<float>& elE_) {elE = elE_;}
    void setElEAvg(const vector<float>& elEAvg_) {elEAvg = elEAvg_;}
    void setElEDisp(const vector<float>& elEDisp_) {elEDisp = elEDisp_;}
    void setOcc(const vector<int>& occ_) {occ = occ_;}
    void setRmsd(const vector<float>& rmsd_) {rmsd = rmsd_;}
    void setRPN(int rpN_) {rpN = rpN_;}
    void setRP(const vector<vector<float> >& rp_) {rp = rp_;}
    void setAddRP(const vector<float>& rp);

    void setDesE(const vector<float>& desE_) {desE=desE_;}
    void setHyDe(const vector<float>& hyDe_) {hyDe=hyDe_;}
    void setLjE(const vector<float>& ljE_) {ljE=ljE_;}
    void setCoulEC(const vector<float>& coulEC_) {coulEC=coulEC_;}
    void setSurDC(const vector<float>& surDC_) {surDC=surDC_;}
    void setElecC(const vector<float>& elecC_) {elecC=elecC_;}
    
    /*! storage format:
      int a -> number of fort.55 lines stored, size of all arrays
      vector<float> -> ElE
      vector<float> -> ElEAvg
      vector<int>   -> Occurancies
      vector<flaot> -> rmsds
      int b -> number of rp score arrays
      vector<float> * int b -> rp arrays  
    */    
    void storageWrite(Writer& write);
  private:
    int n;
    vector<float> totE;
    vector<float> elE;
    vector<float> elEAvg;
    vector<float> elEDisp;
    
    vector<float> desE;
    vector<float> hyDe;
    vector<float> ljE;
    vector<float> coulEC;
    vector<float> surDC;
    vector<float> elecC;

    vector<int> occ;
    vector<float> rmsd;
    int rpN;
    vector<vector<float> > rp;
  

};

#endif


