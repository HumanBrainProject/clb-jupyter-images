#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python
#
# this one goes to folders with printed out results and
# makes a plot with gnuplot,
#
# -------------------------------------------------------------------
# PDPIPE V 1.0
# Author: Domantas Motiejunas, Copyright (c) 2007
# EML Research
# domantas.motiejunas@eml-r.villa-bosch.de
#
# -------------------------------------------------------------------
import os
import sys


def printUsage():
    print("""
  ===================================================================
  USE CASE
    Plot cluster formation info
    
  USAGE
    ./this.py title inputFile outputFile
    
  inputFile  - cluster analysis output (-an -p)
  outputFile - *png image file name
  ===================================================================
  """)


def makeGnuPlotScript(title, fileIn, fileOut, lineNumb):
    return """
set term png
set output '"""+fileOut+"""'
set xrange [0:"""+str(lineNumb)+"""] reverse
set grid
set title '"""+title+"""'
set xlabel 'Number of Clusters'
set ylabel 'Min Distance Between Clusters'
set y2label 'Inter-Cluster distance increase from previous %'
unset key
set xtics 10
set ytics nomirror
set y2tics
plot '< tail -"""+str(lineNumb)+""" """+fileIn+"""' using 1:3 axes x1y1 \
with steps lw 2 lt 1 title 'distance', \
'< tail -"""+str(lineNumb)+""" """+fileIn+"""' using 1:4 axes x1y2 \
with points pt 6 ps 1 lt 3 title ' increace % '
"""


fileOut = 'none'
fileIn = 'none'
title = 'none'
tmpFile = 'tmpGnuplotScript.scr'

try:
    title = sys.argv[1]
    fileIn = sys.argv[2]
    fileOut = sys.argv[3]
except IndexError:
    printUsage()
    sys.exit(1)

fileOutObj = open(tmpFile, 'w')
_file = open(fileIn)
n = 0
for i in _file:
    n += 1
n -= 1
if n > 100:
    n = 100

fileOutObj.write(makeGnuPlotScript(title, fileIn, fileOut, n))
fileOutObj.close()
os.system('gnuplot '+tmpFile)
os.system('rm '+tmpFile)
