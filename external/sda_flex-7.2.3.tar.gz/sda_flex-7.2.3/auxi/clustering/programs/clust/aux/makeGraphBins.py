#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/sw/pub/bin/python
#
# this one goes to folders with printed out results and
# makes a plot with gnuplot,
#
import os
import sys


def makeGnuPlotScript(title, fileIn, fileOut):
    return """
set term png
set output '"""+fileOut+"""'
set grid
set title '"""+title+"""'
set xlabel 'Bins'
set ylabel 'Number of Clusters'
set key top right box
plot '"""+fileIn+"""' with lines
"""
# plot '< tail -100 """+fileIn+"""' with steps lw 2 lt 1
#"""


fileOut = 'none'
fileIn = 'none'
title = 'none'
tmpFile = 'tmpGnuplotScript.scr'

try:
    title = sys.argv[1]
    fileIn = sys.argv[2]
    fileOut = sys.argv[3]
except IndexError:
    print()
    print('USAGE: ')
    print('./thisProgram title inputFile outputFile')
    print()
    sys.exit(1)

fileOutObj = open(tmpFile, 'w')
fileOutObj.write(makeGnuPlotScript(title, fileIn, fileOut))
fileOutObj.close()
os.system('gnuplot '+tmpFile)
os.system('rm '+tmpFile)


print('Done...')
