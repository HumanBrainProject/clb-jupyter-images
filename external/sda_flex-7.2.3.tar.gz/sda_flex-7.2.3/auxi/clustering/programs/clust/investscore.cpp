
#include <cassert>
#include <vector>
#include "investscore.h"


using namespace std;

InvestScore::InvestScore(Reader& read_) {
  read_ >> n;
  elE.reserve(n);
  float _f;
  //get totE
  for (int i = 0; i < n; ++i) {
      read_ >> _f;
      totE.push_back(_f);
  }
  // get elE
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    elE.push_back(_f);
  }
  // get elEAvg
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    elEAvg.push_back(_f);
  }
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    elEDisp.push_back(_f);
  }
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    desE.push_back(_f);
  }
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    hyDe.push_back(_f);
  }
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    ljE.push_back(_f);
  }
/*
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    coulEC.push_back(_f);
  }
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    surDC.push_back(_f);
  }
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    elecC.push_back(_f);
  }
*/
  // get occ
  int _i;
  for (int i = 0; i < n; ++i) {
    read_ >> _i;
    occ.push_back(_i);
  }
  // get rmsds
  for (int i = 0; i < n; ++i) {
    read_ >> _f;
    rmsd.push_back(_f);
  }
  read_ >> rpN;
  for (int i = 0; i < rpN; ++i) {
    vector<float> f; f.reserve(n);
    for (int j = 0; j < n; ++j) { 
      read_ >> _f;
      f.push_back(_f);
    }
    rp.push_back(f);
    f.clear();
  }
}

void
InvestScore::storageWrite(Writer& write_) {
  write_ << n;
  for (int i = 0; i < n; ++i) {
      write_ << totE[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << elE[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << elEAvg[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << elEDisp[i];
  }

  for (int i = 0; i < n; ++i) {
    write_ << desE[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << hyDe[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << ljE[i];
  }
/*
  for (int i = 0; i < n; ++i) {
    write_ << coulEC[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << surDC[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << elecC[i];
  }
*/

  for (int i = 0; i < n; ++i) {
    write_ << occ[i];
  }
  for (int i = 0; i < n; ++i) {
    write_ << rmsd[i];
  }
  write_ << rpN;
  for (int i = 0; i < rpN; ++i) {
    for (int j = 0; j < n; ++j) {
      write_ << rp[i][j];
    }
  }
}

void InvestScore::setAddRP(const vector<float>& rp_) {
  assert(n == rp_.size());
  rpN++;
  rp.push_back(rp_); 
}

























