/*! \file storage.h
//  \brief Storage of data in binary.
//
// What:
// These classe can be used to store and read objects from disk.
// 
// HowTo:
// If your object needs self storage to disk, construct from disk
// capabilities it should subclass Storage class and inplement method
// storageWrite, this object also should (in usuall case) inplement
// a constructor which takes Reader& and constructs itself from 
// the file. In these methods your object should take care of storing
// and reading all its data correctly. If the object has other 
// objects, these objects should inplement their own reading 
// (constructor) and writing (storageWrite) methods which handle 
// their data appropriatelly and so on. In the end you end up with 
// storing just basic data types which can be handled by Writer and
// Reader classes.
//
// by D.M. 2005.11 EML Research
// V0.1
*/

#ifndef STORAGE_H
#define STORAGE_H

#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

/*! \brief Writer class encapsulates writing of primitive data for storage.
*/
class Writer {
  public:
    Writer(const char* fileName_);
    Writer(const string& fileName_);
    ~Writer() {fout.close();}
    // 
    virtual Writer& operator<<(int& data_);
    // michael add unsigned int
    virtual Writer& operator<<(unsigned int& data_);
    // comment size_t
    //virtual Writer& operator<<(size_t& data_);
    virtual Writer& operator<<(float& data_);
    virtual Writer& operator<<(bool& data_);
    virtual Writer& operator<<(double& data_);
    // this stores C string, also use it to store C++ string
    virtual Writer& operator<<(char* data_);
    virtual Writer& operator<<(char& data_);
   
  private:
    ofstream fout;
};
//-------------------------------------------------------------------
/*! \brief Reader class encapsulates reading of primitive data from storage.
*/
class Reader {
  public:
    Reader(const char* fileName_);
    Reader(const string& fileName_);
    ~Reader() {fin.close();}
    //
    virtual Reader& operator>>(int& data_);
    virtual Reader& operator>>(unsigned int& data_);
    //virtual Reader& operator>>(size_t& data_);
    virtual Reader& operator>>(float& data_);
    virtual Reader& operator>>(bool& data_);
    virtual Reader& operator>>(double& data_);
    // this reads C string, also use it to read C++ string
    virtual Reader& operator>>(char*& data_);
    virtual Reader& operator>>(char& data_);
        
  private:
    ifstream fin;
};
//-------------------------------------------------------------------
/*! \brief Storage class is abstract basic for Reader and Writer

  This abstract class should be subclassed by objects which need to 
  be stored onto and read from disk. Derived objects must implement 
  pure firtual function storeageWrite, which takes Writer object as 
  parameter to properly store their data items. 
*/
class Storage {
  public:
    Storage() {}
    Storage(const Reader& reader_) {};
    virtual void storageWrite(Writer& writer_) =0;
  private:
};
//-------------------------------------------------------------------
#endif

