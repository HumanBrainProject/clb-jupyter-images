/*! \file storage.cpp
//
//
// DM comments:
// Writer and Reader inplements basic type for storage and reading
// from binary files. If some basic type (or not very basic:-)) is
// missing y'should implement it here for both classes.
//
//
// by D.M. 2005.11 EML Research
// V0.1
*/

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cstring>
#include "storage.h"

//-------------------------------------------------------------------
// class Writer
Writer::Writer(const char* fileName_) {
  fout.open(fileName_, ios::binary);
  if (!fout.is_open()) {
    cerr << "Failed to open file for writing: " << fileName_ << endl;
    exit(1);
  }
}
Writer::Writer(const string& fileName_) {
  fout.open(fileName_.c_str(), ios::binary);
  if (!fout.is_open()) {
    cerr << "Failed to open file for writing: " << fileName_ << endl;
    exit(1);
  }
}
Writer&
Writer::operator<<(int& data_) {
  fout.write((char*) &data_, sizeof(int));
  return *this;
}
Writer&
Writer::operator<<(unsigned int& data_) {
  fout.write((char*) &data_, sizeof(unsigned int));
  return *this;
}
/*
Writer&
Writer::operator<<(size_t& data_) {
  fout.write((char*) &data_, sizeof(size_t));
  return *this;
}
*/
Writer&
Writer::operator<<(float& data_) {
  fout.write((char*) &data_, sizeof(float));
  return *this;
}
Writer&
Writer::operator<<(double& data_) {
  fout.write((char*) &data_, sizeof(double));
  return *this;
}
Writer&
Writer::operator<<(bool& data_) {
  fout.write((char*) &data_, sizeof(bool));
  return *this;
}
Writer&
Writer::operator<<(char* data_) {
  int _len = strlen(data_);
  fout.write((char*) &_len, sizeof(int));
  fout.write(data_, _len);
  return *this;
}
Writer&
Writer::operator<<(char& data_) {
  fout.write((char*) &data_, sizeof(char));
  return *this;
}
//-------------------------------------------------------------------
// class Reader
Reader::Reader(const char* fileName_) {
  fin.open(fileName_, ios::binary);
  if (!fin.is_open()) {
    cerr << "Failed to open the file for reading: " << fileName_ << endl;
    exit(1);
  }
}
Reader::Reader(const string& fileName_) {
  fin.open(fileName_.c_str(), ios::binary);
  if (!fin.is_open()) {
    cerr << "Failed to open the file for reading: " << fileName_ << endl;
    exit(1);
  }
}
Reader&
Reader::operator>>(int& data_) {
  fin.read((char*) &data_, sizeof(int));
  return *this;
}
Reader&
Reader::operator>>(unsigned int& data_) {
  fin.read((char*) &data_, sizeof(unsigned int));
  return *this;
}
/*
Reader&
Reader::operator>>(size_t& data_) {
  fin.read((char*) &data_, sizeof(size_t));
  return *this;
}
*/
Reader&
Reader::operator>>(float& data_) {
  fin.read((char*) &data_, sizeof(float));
  return *this;
}
Reader&
Reader::operator>>(double& data_) {
  fin.read((char*) &data_, sizeof(double));
  return *this;
}
Reader&
Reader::operator>>(bool& data_) {
  fin.read((char*) &data_, sizeof(bool));
  return *this;
}
Reader&
Reader::operator>>(char* &data_) {
  int _len;
  fin.read((char*) &_len, sizeof(int));
  // !!! following has to be deleted where it is used 
  data_ = new char[_len + 1];
  fin.read(data_, _len);
  data_[_len] = '\0';
  return *this;
}
Reader&
Reader::operator>>(char& data_) {
  fin.read((char*) &data_, sizeof(char));
  return *this;
}
//-------------------------------------------------------------------


