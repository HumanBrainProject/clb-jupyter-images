/*! \file commonfoo.h
    \brief Some commonly used function declarations here
    
*/
#ifndef COMMONFOO_H
#define COMMONFOO_H

#include <vector>
#include <string>
#include <fstream>
using namespace std;

//---inlines--->

/*! Strips string 
    Definition looks like this:
    inline void stripString(string& s_in){
      const string from = " ";
      const string to = "";
      size_t search_here = 0;
      size_t found_here;
      while ((found_here = s_in.find(from, search_here)) != string::npos){
        s_in.replace(found_here, 1, to);
        search_here = found_here;
      }
    }  
*/
inline void stripString(string&);
/*! DM Issue Deprecated? */
//inline void eatLine(ifstream&);

/*! Splits string at delimiter 'delim_', and puts pieces into vector
    of strings 'pieces_'
    
    Definition is:
    inline void BasicIn::splitLine(const string& str_,
                                  vector<string>& pieces_,
                                  const string& delim_){
      // startPost first found "good" char of the token
      // endPost first found "bad" char at the end of token
      string::size_type startPos = str_.find_first_not_of(separators_, 0);
      string::size_type endPos   = str_.find_first_of(separators_, startPos);
      while(endPos != string::npos || startPos != string::npos){
        // token found
        pieces_.push_back(str_.substr(startPos, endPos - startPos));
        startPos = str_.find_first_not_of(separators_, endPos);
        endPos   = str_.find_first_of(separators_, startPos);
      }
    }       
*/
inline void splitLine(const string& str_,
                      vector<string>&  splitStr_,
                      const string& delim_ = " ");
/*! Replaces characters 'from' to characters 'to' in string */
inline void replaceChars(string& str_, char from, char to);
/*! Checks if float is not nan in case there is no function 
    in compiler (in fact in gcc there is isnan in cmath)
    
    DEFINITION:
    inline bool myIsNan(double x)
      return x != x; // because nan not equal to anything including itself
*/
inline bool myIsNan(double);
inline bool myIsNan(float);

/*! Sort the array Ascending */
template<typename T>
void sortArrayA(T* array_, int n) {
  for (int i = 0; i < n; ++i) {
    for (int j = i+1; j < n; ++j) {
      if (array_[i] > array_[j]) {
        T tmp = array_[i];
        array_[i] = array_[j];
        array_[j] = tmp;
      }
    } // j  
  } // i
}

/*! Sort the array Descending */
template<typename T>
void sortArrayD(T* array_, int n) {
  for (int i = 0; i < n; ++i) {
    for (int j = i+1; j < n; ++j) {
      if (array_[i] < array_[j]) {
        T tmp = array_[i];
        array_[i] = array_[j];
        array_[j] = tmp;
      }
    } // j
  } // i
}

/*! Sort Ascending two equal arrays as if they are paired, so actually
    sort the first array and adjust the positions of the second 
    array reletively:-) did ya get it? */
template<typename T>
void sortTwoPairedArraysA(T* array1_, T* array2_, int n) {
  for (int i = 0; i < n; ++i) {
    for (int j = i+1; j < n; ++j) {
      if (array1_[i] > array1_[j]) {
        T tmp1 = array1_[i];
        T tmp2 = array2_[i];
        array1_[i] = array1_[j];
        array2_[i] = array2_[j];
        array1_[j] = tmp1;
        array2_[j] = tmp2;
      } // 
    } // j
  } // i
}

/*! Sort Descending two equal arrays as if they are paired, so actually
    sort the first array and adjust the positions of the second 
    array reletively:-) did ya get it? */
template<typename T>
void sortTwoPairedArraysD(T* array1_, T* array2_, int n) {
  for (int i = 0; i < n; ++i) {
    for (int j = i+1; j < n; ++j) {
      if (array1_[i] < array1_[j]) {
        T tmp1 = array1_[i];
        T tmp2 = array2_[i];
        array1_[i] = array1_[j];
        array2_[i] = array2_[j];
        array1_[j] = tmp1;
        array2_[j] = tmp2;
      } // 
    } // j
  } // i
}


#endif

