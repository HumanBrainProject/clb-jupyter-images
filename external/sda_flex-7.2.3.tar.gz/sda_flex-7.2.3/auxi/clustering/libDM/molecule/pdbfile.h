//-------------------------------------------------------------------
/*! \file protein.h
    \brief Wrapping for pdb file.
    
    Here we have classes that wrap the pdb files. In this case they
    contain vectors of some kind of pdbLine objects which are defined
    in pdbline.h file. 
*/
//-------------------------------------------------------------------

#ifndef PDBFILE_H
#define PDBFILE_H

#include <vector>
#include <string>

#include "pdbline.h"

class Vector3;

typedef vector<PdbLine>::const_iterator CitPL;
typedef vector<PdbLine>::iterator ItPL;


/*! \brief Container for simple pdblineS1 objects.

   this container class to store pdb file in a very simple way
   it uses PdbLinesS1 which have all up to x y z in string,
   x, y, z in float and nothing else
*/
class PdbFileS1 {
  public:
    PdbFileS1() {}
    PdbFileS1(const PdbFileS1& pdbFile_);
    // takes ready vector of PdbLineS1 objects
    PdbFileS1(const vector<PdbLineS1>& pdbLines_);
    // takes vector of strings and makes PdbLineS1 from each
    PdbFileS1(const vector<string>& pdbLines_);
    PdbFileS1(Reader& reader_);
    ~PdbFileS1() {}
    
    PdbFileS1& operator=(const PdbFileS1& pdbFile_);
    bool operator==(const PdbFileS1& pdbFile_) const;
    
    void setPdbLines(const vector<PdbLineS1>* pdbLines_);
    void setPdbLines(const vector<string>& pdbLines_);
    void addPdbLine(const PdbLineS1* pdbLine_);
    
    const vector<PdbLineS1>* getPdbLines() const;
    vector<PdbLineS1>&       accessPdbLines();
    Vector3                  getCenter() const;
    
    
    float backbRmsd(const PdbFileS1& pdbFile_) const;
    void storageWrite(Writer& writer_);
  private:
    vector<PdbLineS1> pdbLines;
};
//-------------------------------------------------------------------
/*! \brief Container for fuller pdb file.

    This container class is to store PdbLine objects, that is fully
    described pdblines up to coordinate entry.
*/
class PdbFile {
  public:
    typedef vector<PdbLine>::const_iterator CiterPL;
    typedef vector<PdbLine>::iterator IterPL;
    PdbFile() {}
    PdbFile(const PdbFile& other);
    PdbFile(const vector<string>& pdbLines_);
    PdbFile(const vector<PdbLine>& pdbLines_);
    
    PdbFile& operator=(const PdbFile& other);
    // get
    const vector<PdbLine>* getPdbLines() const;
    
    /*! Removes hydrogens, that is lines where atom name starts with H, or
        where first charachter is number from 1-5 and secont is H, or
        where first and second character is number from 1-5 and third is H.
    */
    void removeHydrogens();
    /*! Selects specific altLoc and deletes the other. Also altLocation
        identifier itself is removed. It is very simple just leaves altLoc
        with specified letter 'altLoc_' every other altLoc is removed.
        Lines without any altLoc are kept of course.
    */
    void filterAltLoc(const char altLoc_ = 'A');
    /*! Changes residue name from 'from' to 'to' 
    */
    void changeResName(const string& from, const string& to);
    /*! Fixes residue name. This can be used then some atoms in residue
        for whatever reason are named differently from the others. 
        e.g. after UHBD some atoms in N terminal residue are named NTRM
        in C terminal residue CTRM. Such residues can be fixed with this 
        function.
    */
    void fixResName(const string& name_);
    
    /*! Returns all atoms as vector<Vector3> */
    vector<Vector3> getAtomCoord() const;
    void getAtomCoord(vector<Vector3>& atoms_) const;
    vector<PdbLine>& accessPdbLines() {return pdbLines;}
    Vector3 getCenter() const;
    
    void setAtomCoord(const vector<Vector3>& atoms_);
    void setAtomCoord(const vector<float>& atoms_);
    float backbRmsd(const PdbFile& pdbFile_) const;
    
    /*! cuts PdbFile object into two pieces. from begining to 
        'res_' part stays in this object and from 'res_+1' to 
        the end is loaded into 'pdbFile_' object which comes 
        as an argument of this foo
    */
    int cutOffAfterRes(PdbFile& pdbFile_, int res_);
  private:
    vector<PdbLine> pdbLines;
};
//-------------------------------------------------------------------

// Fooos




#endif

