//-------------------------------------------------------------------
/*! \file molgrid.h
    \brief Stuff to put molecules in grids
    
    by D.M. 2006.03 EML Research
    V 0.01
    V 0.02
      -> moved from std to pure arrays
      -> created inheritence
      -> made independent from Access stuff
*/

#ifndef MOLGRID_H
#define MOLGRID_H

#include <vector>
#include <string>
#include "qtable_2.h"
#include "pdbfile_2.h"

using std::vector;
using std::string;

using libDM_SDA::QTable;
using libDM_molecule::PdbFile;

class Vector3;
//______________________MolGrid______________________________________
/*! \brief Base class for molecular grid

    Currently it can not be instantiated, its not virtual (yet)
    but constructors ar protected since I'm not sure if it makes
    sence at this to implement makeGrid() method in this class, which
    only gets coordinates, well anyway...
    
    by D.M. 2006.03 EML Research
    V 0.01

*/
//-------------------------------------------------------------------
class MolGrid {
  public:
    typedef unsigned int Uint;

    /*! loads molecule coordinates and calculates values
        of relevant class member */
    void loadCoord(const PdbFile& pdbFile_);
    void loadCoord(const vector<Vector3>& coord);
    void loadCoord(const vector<float>& coord);
    /*! this should build a grid but currently is not implemented,
        cause I'm not sure if it worth doing it in this base class
        therefore the constructor is moved to protected and this
        class can't be instantiated */
    void makeGrid();
    /*! this finds neighboring grid cell indices to 'cellID_'
        it fills 'neighbors_' array with neighborcell indices
        this array should be not smaller then 27 = 3*3*3 for 3d grid
        function returns int value which is number of neighbors.
        use this together with filled 'neighbors_' array in such thigs
        like for loops 
          cellID_    -> is cell index to search neighbors for
          neighbors_ -> array to store neigboring cell indices, the size
                        is 27 (27 possible naigbors in 3d including itself)
          return     -> is actual number of neighboring cells, if 'cellID_'
                        is at the edge then < then 27:) */
    int findNeighborCells(Uint cellID_, int* neighbors_) const;
    /*! finds atoms which are in cells 'cellNumb_' and puts the indices
        of these atoms (strts from 0) to 'atoms_' array. and returns 
        the number of atoms found int these 'cells_'.
          cells_    -> array of cell indices to search for atoms in them
          cellNumb_ -> size of 'sellNumb_'
          atoms_    -> array to store atom indices found in 'cells_'
          return    -> is number of atoms found in 'cells_' and their 
                       indices put in 'atoms_', so 'atoms_' must be big
                       enough!!!!
        !!! make sure that 'atoms_' array is big enough otherwise it 
        will segfault.
        DM Issue put an exception to this foo then array 'atom_' is not big
        enough to store things
        DM Issue this is slow foo see if something can be done about it?*/
    int findAtomsInCells(const int* cells_, 
                         const int cellNumb_, Uint* atoms_) const;
    /*! like findAtomsInCells but excludes the given thisAtom_, which 
        is relevent in case then you need only neighboring atom to 
        'thisAtom_' in 'cells_'
          cells_    -> array of cell indices to search for atoms in them
          cellNumb_ -> size of 'sellNumb_'
          atoms_    -> array to store atom indices found in 'cells_'
          thisAtom_ -> atom index to exclude
          return    -> is number of atoms found in 'cells_' and their 
                       indices put in 'atoms_', so 'atoms_' must be big
                       enough!!!!
        !!! make sure that 'atoms_' array is big enough otherwise it 
        will segfault.
        DM Issue put an exception to this foo then array 'atom_' is not big
        enough to store things
        DM Issue this is slow foo see if something can be done about it?*/
    int findAtomsInCellsNotThis(const int* cells_, const int cellNumb_, 
                               Uint* atom_, const int thisAtom_) const;
    
    const float* getX() const {return x;}
    const float* getY() const {return y;}
    const float* getZ() const {return z;} 
    const Uint*  getI() const {return i;}
    float getMaxX() const {return maxX;}
    float getMaxY() const {return maxY;}
    float getMaxZ() const {return maxZ;}
    float getMinX() const {return minX;}
    float getMinY() const {return minY;}
    float getMinZ() const {return minZ;}
    Uint  getISize() const {return iSize;}
    Uint  getJSize() const {return jSize;}
    Uint  getKSize() const {return kSize;}
    Uint  getIJSize() const {return ijSize;}
    Uint  getIJKSize() const {return ijkSize;}  
    Uint  getAtomNumb() const {return atomNumb;}
  
  protected: 
    /*! constructor alocates memory for x, y, z, i arrays */
    MolGrid(Uint size_);
    ~MolGrid(); 
    
    /*! dynamic arrays to store atom coordinates */
    float *x, *y, *z;
    /*! dynamic array to store indices of grid cell for atoms */
    Uint  *i;
    Uint atomNumb;
    /*! min max XYZ coords */
    float maxX, maxY, maxZ, minX, minY, minZ;
    /*! grid sizes */
    Uint iSize, jSize, kSize, ijSize, ijkSize;
    
  private:
    MolGrid(const MolGrid& other);
    MolGrid& operator=(const MolGrid& other);
};

//______________________MolGridR_____________________________________
/*! \brief Molecular grid based on atom radii

    This class puts molecule into grid based on its coordinates
    and radii of the atoms. This class has only radii related 
    data members all others are inherited form MolGrid
    
    by D.M. 2006.03 EML Research
    V 0.01
    
*/
class MolGridR: public MolGrid {
  public:
    /*! Calls base constructor and allocates own arrays */
    MolGridR(Uint size_);
    ~MolGridR(); 
    
    /*! loads radii and calculates all relevant values of members
        NOTE -> don't forget to add probe to your radii if its needed
                for your usage here:-) */
    void loadRadii(const vector<float>& radii);
    /*! this makes the grid around molecule based on atom coordinate 
        and atom radii. If molecule is small the grid is at least 
        3*3*3. The cell size here is equal to largest diameter. 
        Once grid size is established each atom is asigned to some
        grid cell index (starts from 1).
    */
    void makeGrid();
    
    const float* getR() const {return r;}
    const float* getR2() const {return r2;}
    const float* getRR() const {return rr;}
    float getMaxR() const {return maxR;}
    float getMinR() const {return minR;}
    float getMaxR2() const {return maxR2;}
    float getMinR2() const {return minR2;}
    float getMaxRR() const {return maxRR;}
    float getMinRR() const {return minRR;}
  
  private:
    MolGridR(const MolGridR& other);
    MolGridR& operator=(const MolGridR& other);
    
    /* dynamic arrays to store radii */
    float *r, *r2, *rr;
    /* min max radii values */
    float maxR, maxR2, maxRR, minR, minR2, minRR;
};

//____________________Helper Foos____________________________________
/*! Extracts radii to 'radii_' vector when 'pdbFile_, object is loaded with
    some pdb and 'data_' is vector of string containing lines of vdw.radii
    file (the one used by NACCESS:-) 
      pdbFile_ -> PdbFile object with loaded and ready:-) molecule (pdb)
      data_    -> lines of vdw.radii file ...which holds radii values
      radii_   -> this will be filled with radii values extracted from
                  data_
    DM Issue it recognize only atom present in vdw.radii file, need to add
      some handling of uncommon atom asign some default readi or smth:-)
*/
void extractRadii(const PdbFile& pdbFile_, 
                  const vector<string>& data_, vector<float>& radii_);
/*! Finds radii value in vdw.radii file lines ('data_') for particular
    residue 'res_' and its atom 'atom_' 
      data_  -> lines of vdw.radii file ...which holds radii values
      res_   -> residue name
      atom_  -> atom name for this residue
      return -> radii
    DM Issue see foo extractRadii documentation :-)*/
float getThatRadii(const vector<string>& data_, 
                   const string& res_, const string& atom_);

#endif
