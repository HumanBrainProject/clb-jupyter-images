//-------------------------------------------------------------------
/*! \file pdbline.cpp

*/

#include <vector>
#include <string>
#include <iostream>
#include <string.h>
#include "pdbline.h"
#include "../common/commonfoo.h"
#include "../3d/vector3.h"

using namespace std;

//---functions--->
//---inlines--->
inline void stripString(string& s_in){
  const string from = " ";
  const string to = "";
  unsigned int search_here = 0;
  unsigned int found_here;
  while ((found_here = s_in.find(from, search_here)) != string::npos){
    s_in.replace(found_here, 1, to);
    search_here = found_here;
  }
}

// PdbLineS1 --------------------------------------------------------
// constructor
PdbLineS1::PdbLineS1(const string& pdbLine_) {
  lineTo30 = pdbLine_.substr(0, 30);
  coord.x  = atof(pdbLine_.substr(30, 8).c_str());
  coord.y  = atof(pdbLine_.substr(38, 8).c_str());
  coord.z  = atof(pdbLine_.substr(46, 8).c_str());
  isBackbone = this->checkAtom(*this);
}
 
PdbLineS1::PdbLineS1(const PdbLineS1& pdbLine_) {
  lineTo30 = pdbLine_.getLineTo30();
  coord    = pdbLine_.getCoord();
  isBackbone = this->checkAtom(*this);
}
PdbLineS1::PdbLineS1(Reader& reader_) {
  char* _cStr;
  reader_ >> _cStr;
  lineTo30 = _cStr;
  delete _cStr; // don't forget its in the heap
  reader_ >> coord.x;
  reader_ >> coord.y;
  reader_ >> coord.z;
  isBackbone = this->checkAtom(*this);
}
// operator
PdbLineS1&
PdbLineS1::operator=(const PdbLineS1& pdbLine_) {
  lineTo30 = pdbLine_.getLineTo30();
  coord    = pdbLine_.getCoord();
  isBackbone = this->checkAtom(*this);
  return *this;
}
bool
PdbLineS1::operator==(const PdbLineS1& pdbLine_) const {
  if (lineTo30 == pdbLine_.getLineTo30() &&
      coord    == pdbLine_.getCoord())
    return true;
  return false;
}
// set
void
PdbLineS1::setCoord(const Vector3& coord_) {
  coord = coord_;
}
// get
const string&
PdbLineS1::getLineTo30() const {
  return lineTo30;
}
const Vector3&
PdbLineS1::getCoord() const {
  return coord;
}
Vector3&
PdbLineS1::accessCoord() {
  return coord;
}
bool
PdbLineS1::checkAtom(const PdbLineS1& line) const {
	const char *line1 = line.lineTo30.c_str()+5;
	const char *line2 = lineTo30.c_str()+5;
	unsigned int pos1, pos2;
    pos1 = (int)(strchr(line1,'C')-line1+1);
    if (pos1>5 and pos1 < 11) {
       pos2 = strchr(line2,'C')-line2;
       if ((pos2 > 5 and pos2 < 11)) return true;
    }
    pos1 = strchr(line1,'O')-line1;
    if (pos1>5 and pos1 < 11) {
       pos2 = strchr(line2,'O')-line2;
       if ((pos2 > 5 and pos2 < 11)) return true;
    }
    pos1 = strchr(line1,'N')-line1;
    if (pos1>5 and pos1 < 11) {
       pos2 = strchr(line2,'N')-line2;
       if ((pos2 > 5 and pos2 < 11)) return true;
    }
/*    pos1 = strcspn(line1," O");
    pos2 = strcspn(line2," O ");
    if ((pos1 >10 and pos1 < 16) and (pos2 > 10 and pos2 < 16)) return true;
    pos1 = strcspn(line1," N ");
    pos2 = strcspn(line2," N ");
    if ((pos1 >10 and pos1 < 16) and (pos2 > 10 and pos2 < 16)) return true;*/
//    cout << line.lineTo30 << "\t"<<lineTo30 << "\n";
	return false;
}
bool
PdbLineS1::isAtom(const string& atomName_) const {
  // searches for atomName_ string in lineTo30 string, if 
  // found returns the index in lineTo30 if not returns
  // string::npos
	const char *a = atomName_.c_str();
	const char *line = lineTo30.c_str();

  unsigned int _pos = strcspn(line,a);
  // if found and if between [12, 15], (not it is -1 since starts from 0)
  // than this line represents atomName_, therefore true
  if (_pos != _pos > 11 && _pos < 16) {
    return true;
  }  
  return false;
}
void
PdbLineS1::storageWrite(Writer& writer_) {
  writer_ << const_cast<char*>(lineTo30.c_str());
  writer_ << coord.x;
  writer_ << coord.y;
  writer_ << coord.z;
}
// ==================================================================

// PdbLine ----------------------------------------------------------
PdbLine::PdbLine(const string& pdbLine_) {
  atom    = pdbLine_.substr(12, 4); stripString(atom);
  altLoc  = *const_cast<char*>(pdbLine_.substr(16, 1).c_str());
  resName = pdbLine_.substr(17, 3); stripString(resName);
  chainID = *const_cast<char*>(pdbLine_.substr(21, 1).c_str());
  resSeq  = atoi((pdbLine_.substr(22, 4)).c_str());
  iCode   = *const_cast<char*>(pdbLine_.substr(26, 1).c_str());
  coord.x = atof((pdbLine_.substr(30, 8)).c_str());
  coord.y = atof((pdbLine_.substr(38, 8)).c_str());
  coord.z = atof((pdbLine_.substr(46, 8)).c_str());
}
PdbLine::PdbLine(const PdbLine& other) {
  atom =    *other.getAtom();
  altLoc =  *other.getAltLoc();
  resName = *other.getResName();
  chainID = *other.getChainID();
  resSeq =  *other.getResSeq();
  iCode =   *other.getICode();
  coord =   *other.getCoord();
}

PdbLine&
PdbLine::operator=(const PdbLine& other) {
  atom =    *other.getAtom();
  altLoc =  *other.getAltLoc();
  resName = *other.getResName();
  chainID = *other.getChainID();
  resSeq =  *other.getResSeq();
  iCode =   *other.getICode();
  coord =   *other.getCoord();
  return *this;
}
bool
PdbLine::operator==(const PdbLine& other) const {
  if (atom    == *other.getAtom() && 
      altLoc  == *other.getAltLoc() &&
      resName == *other.getResName() &&
      chainID == *other.getChainID() &&
      resSeq  == *other.getResSeq() &&
      iCode   == *other.getICode() &&
      coord   == *other.getCoord())
    return true;
  return false;
}
// get stuff
const string*  
PdbLine::getAtom() const{
  return &atom;
}
const char*    
PdbLine::getAltLoc() const{
  return &altLoc;
}
const string*  
PdbLine::getResName() const{
  return &resName;
}
const char*    
PdbLine::getChainID() const{
  return &chainID;
}
const int*     
PdbLine::getResSeq() const{
  return &resSeq;
}
const char*    
PdbLine::getICode() const{
  return &iCode;
}
const Vector3* 
PdbLine::getCoord() const{
  return &coord;
}
// set stuff
void
PdbLine::setAtom(const string& atom_) {
  atom = atom_;
}
void 
PdbLine::setAltLoc(const char& altLoc_) {
  altLoc = altLoc_;
}
void 
PdbLine::setResName(const string& resName_) {
  resName = resName_;
}
void
PdbLine::setChainID(const char& chainID_) {
  chainID = chainID_;
}
void 
PdbLine::setResSeq(const int& ResSeq_) {
  resSeq = ResSeq_;
}
void 
PdbLine::setICode(const char& iCode_) {
  iCode = iCode_;
}
void
PdbLine::setCoord(const Vector3& coord_) {
  coord = coord_;
}
void
PdbLine::setCoord(float x_, float y_, float z_) {
   coord.x = x_;
   coord.y = y_;
   coord.z = z_;
}

void 
PdbLine::translateMe(const Vector3& vector3_){
  coord += vector3_;
}
/*! Checks if this line is for hydrogen atom. Namely checks if the
    first letter is H, or first letter is number from 1 to 5 and
    second letter is H or first and second letters are numbers 
    from 1 to 5 and third is H. (not sure if covers all hydrogens).
*/
bool
PdbLine::isHydrogen() const {
  // if first letter is H
  if (atom[0] == 'H'){ 
    return true;
  // if first letter is 1-5 number and second is H
  } else if (atom[0] == '1' || atom[0] == '2' || atom[0] == '3' ||
             atom[0] == '4' || atom[0] == '5' && atom[1] == 'H') {
    return true;
  // if first and second letter are 1-5 number and third H
  } else if ((atom[0] == '1' || atom[0] == '2' || atom[0] == '3' ||
              atom[0] == '4' || atom[0] == '5') && 
             (atom[1] == '1' || atom[1] == '2' || atom[1] == '3' ||
              atom[1] == '4' || atom[1] == '5') &&   
             (atom[2] == 'H')) {
    return true;
  }
  return false;
}
// ==================================================================


/*
//---methods--->
// makeStuff
void PdbLine::makeAtom(const string& pdbLine_){
// also checks if this atom name is known in constdata.h
	_str = pdbLine_.substr(12, 4);
	stripString(_str);
	atom = _str;
	if (!iKnowThisString(PROTATOMS, ATOMARRAY, _str)){
		cerr << "WARNING: " << _str
		     << " atom is unknown." << endl;
	}
}

void PdbLine::makeAltLoc(const string& pdbLine_){
	_str = pdbLine_.substr(16, 1);
	if (_str != SHOLD1){
		altLoc = *const_cast<char*>(_str.c_str());
		return;
	}
	altLoc = CHOLD1;
}

void PdbLine::makeResName(const string& pdbLine_){
// also checks if this residue is known in constdata.h
	_str = pdbLine_.substr(17, 3);
	resName = _str;
	if (!iKnowThisString(AAA, AAARRAY, _str)){
		cerr << "WARNING: " << _str
		     << " residue is unknown." << endl;
	}
}

void PdbLine::makeChainID(const string& pdbLine_){
	_str = pdbLine_.substr(21, 1);
	if (_str != SHOLD1){
		chainID = *const_cast<char*>(_str.c_str());
		return;
	}
	chainID = CHOLD1;
}

void PdbLine::makeResSeq(const string& pdbLine_){
	resSeq = atoi((pdbLine_.substr(22, 4)).c_str());
}

void PdbLine::makeICode(const string& pdbLine_){
	_str = pdbLine_.substr(26, 1);
	if (_str != SHOLD1){
		iCode = *const_cast<char*>(_str.c_str());
		return;
	}
	iCode = CHOLD1;
}

void PdbLine::makeCoor(const string& pdbLine){
	coor.x = atof((pdbLine.substr(30, 9)).c_str());
	coor.y = atof((pdbLine.substr(38, 9)).c_str());
	coor.z = atof((pdbLine.substr(46, 9)).c_str());
}

/* doesn't work in MCM wirh suknistas old compiler
string PdbLine::makePdbString(int atmID_ = 1){
// makes pdb string the same is in pdbout so this is redundant...
// and not really tested.
	ostringstream _oustr;
	_oustr << ATOM << "  "
	<< setw(5) << setiosflags(ios::right) << atmID_ << " "
	<< (atom.size() < 3 ?
	    atom.size() > 1 ? " "+atom+" " : " "+atom+"  " :
	    atom.size() ==4 ? atom : " "+atom)
	<< altLoc << resName << " " << chainID
	<< setw(4) << setiosflags(ios::right) << resSeq
	<< iCode << "   ";
	_oustr.setf(ios::right, ios::adjustfield);
	_oustr.setf(ios::fixed, ios::floatfield);
	_oustr << setprecision(3)
	<< setw(8) << coor.x
	<< setw(8) << coor.y
	<< setw(8) << coor.z
	<< endl;
	string _res = _oustr.str();
	return _res;
}


// is? stuff
bool PdbLine::isAltLoc(PdbLine& pl_) const{
// checks if lines are for the same atom but different altLoc
	if (*this->getAtom()    == *pl_.getAtom()    &&
	    *this->getResName() == *pl_.getResName() &&
	    *this->getResSeq()  == *pl_.getResSeq()  &&
	    *this->getChainID() == *pl_.getChainID() &&
	    *this->getAltLoc()  != *pl_.getAltLoc() )
		return true;
	return false;
}

bool PdbLine::isSameICode(PdbLine& pl_) const{
// checks if lines are of different (or same) atom but same iCode
	if (*this->getResName() == *pl_.getResName() &&
	    *this->getResSeq()  == *pl_.getResSeq()  &&
	    *this->getICode()   == *pl_.getICode()   &&
	    *this->getChainID() == *pl_.getChainID() )
		return true;
	return false;
}

bool PdbLine::isSameRes(PdbLine& pl_) const{
// checks if lines are of the same residue
	if (*this->getResName() == *pl_.getResName() &&
	    *this->getResSeq()  == *pl_.getResSeq()  &&
	    *this->getChainID() == *pl_.getChainID() &&
	    *this->getICode()   == *pl_.getICode() ){
	    	return true;
	}
	return false;
}

bool PdbLine::isHydrogen() const{
// checks if it is Hydrogen line, not sure if coves all H kinds..
	if (atom[0] == 'H'){
		return true;
	}else if ( (atom[0] == '1' && atom[1] == 'H') ||
		   (atom[0] == '2' && atom[1] == 'H') ||
		   (atom[0] == '3' && atom[1] == 'H') ||
		   (atom[0] == '4' && atom[1] == 'H') ||
		   (atom[0] == '5' && atom[1] == 'H') ){
		return true;
	}
 	return false;
}
*/


