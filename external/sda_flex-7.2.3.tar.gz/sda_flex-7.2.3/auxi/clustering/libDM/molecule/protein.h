//-------------------------------------------------------------------
/*! \file protein.h
    \brief Various classes for protein representation.
    
    by D.M. EML Research
    V0.3 2006.01.19
*/
//-------------------------------------------------------------------
#ifndef PROTEIN_H
#define PROTEIN_H

#include <string>
#include <vector>

#include "../3d/vector3.h"
#include "residue.h"

class PdbLine;
class PdbFile;

using namespace std;


/*! \brief Encapsulates protein chain.
    
    This class is use in Protein class objects to store chains.
*/
class Chain {
  public:
    Chain(): name(' ') {}
    Chain(const Chain& other);
    Chain(const vector<PdbLine>& pdbLines_);
    Chain(const PdbFile& pdbFile_);
    Chain& operator=(const Chain& other);
    bool operator==(const Chain& other) const;
    bool hasResidue(const Residue& residue_) const;
    // get
    const char&             getName() const;
    const vector<Residue>&  getResidues() const;
    vector<Residue>&        accessResidues();
  protected:
  private:
    char  name;
    vector<Residue> residues;
};
/*! \brief Encapsulates protein.

    Use this class to fully encapsulate protein loaded from pdb file
    or other sources. If you do only some geometrical transformations
    or something independent of particular residues and atoms of the
    protein use something else not this class.
*/
class Protein {
  public:
    Protein(): name(" ") {}
    Protein(const vector<PdbLine>& pdbLines_, const string& name_ = " ");
    Protein(const PdbFile& pdbFile_, const string& name_ = " ");
    Protein(const Protein& other);
    Protein& operator=(const Protein& other);
    bool operator==(const Protein& other) const;
    bool hasChain(const Chain& chain_) const;
    
    int                   getResNumb() const;
    const string&         getName() const;
    const vector<Chain>&  getChains() const;
    void      accessCoord(vector<Vector3*>& coord_);
    vector<Chain>&        accessChains();
    
  protected:
  private:
    string name;
    vector<Chain> chains;
   // vector<Vector3*> _coord;
   // vector<Vector3*>* coord;
};
typedef vector<Atom>::const_iterator    CiterA;
typedef vector<Atom>::iterator          IterA;
typedef vector<Residue>::const_iterator CiterR;
typedef vector<Residue>::iterator       IterR;
typedef vector<Chain>::const_iterator   CiterC;
typedef vector<Chain>::iterator         IterC;


#endif
//-------------------------------------------------------------------
// DMIssue
// Concerning this repetetive storage of the same letter and names.
// May be good to create a helper class and force Protein (and other
// component classes) to hold a pointer to such helper class with 
// stable (static?) letters and common names for e.g. residues. Plus
// methods to handle uncommon residue names and such:-)
//
// class PHelper;


/*! makes vector of Residue objects from vector of PdbLine objects */
void pdbLines2Residues(const vector<PdbLine>& pdbLines, 
                             vector<Residue>& residues);                      
/*! makes vector of Residue objects from PdbFile object */
void pdbFile2Residues(const PdbFile& pdbFile, 
                            vector<Residue>& residues);



