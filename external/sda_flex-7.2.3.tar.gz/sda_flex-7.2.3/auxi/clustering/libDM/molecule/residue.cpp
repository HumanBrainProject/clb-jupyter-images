//-------------------------------------------------------------------
/*! \file residue.cpp
    \brief Implementation of residue classes
    
    by D.M. EML Research
    V 0.3
*/
//-------------------------------------------------------------------

#include <iostream>
#include <vector>
#include <cassert>
#include <algorithm>

#include "residue.h"
#include "atom.h"
#include "pdbline.h"
#include "constdata.h"
#include "vector3.h"

using namespace std;

// Residue----------------------------------------------------------
Residue::Residue(const vector<PdbLine>& pdbLines_) {
  name   = *pdbLines_.begin()->getResName();
  resSeq = *pdbLines_.begin()->getResSeq();
  iCode  = *pdbLines_.begin()->getICode();
  vector<PdbLine>::const_iterator ci;
  for (ci = pdbLines_.begin();
       ci !=pdbLines_.end();
       ++ci) {
    assert(name   == *ci->getResName() &&
           resSeq == *ci->getResSeq() &&
           iCode  == *ci->getICode());
    atoms.push_back(Atom(*ci));
  }
  gCenter = 0;
}

Residue::Residue(const Residue& other) {
  name   = other.getName();
  resSeq = other.getResSeq();
  iCode  = other.getICode();
  atoms  = other.getAtoms();
  gCenter= 0;
}
// operator
Residue&
Residue::operator=(const Residue& other) {
  name   = other.getName();
  resSeq = other.getResSeq();
  iCode  = other.getICode();
  atoms  = other.getAtoms();
  gCenter= 0;
  return *this;
}
bool
Residue::operator==(const Residue& other) const {
  if (atoms.size() != other.getAtoms().size())
    return false;
  vector<Atom>::const_iterator ci;
  for (ci = other.getAtoms().begin();
       ci !=other.getAtoms().end();
       ++ci) {
    if (!hasAtom(*ci))
      return false;
  }
  return true;
}   
/*! Checks if this atom is in this residue.
*/

bool
Residue::hasAtom(const Atom& atom_) const {
  vector<Atom>::const_iterator ci;
  for (ci = atoms.begin();
       ci !=atoms.end();
       ++ci) {
    if (*ci == atom_)
      return true;
  }
  return false;
}
bool
Residue::hasAtom(const string& name_) const {
  for (vector<Atom>::const_iterator cit = atoms.begin();
       cit != atoms.end(); ++cit) {
    if (name_ == cit->getName())
      return true;
  }
  return false;
}
bool
Residue::isProtResidue() const {
  // checks if it is one of 20 common residues:-)
  for (int i = 0; i < AAARRAY; ++i){
    if (AAA[i] == name)
      return true;
  }
  return false;
}
 
 
// get
const Atom&
Residue::getAtom(const string& name_) const {
  for (vector<Atom>::const_iterator cit = atoms.begin();
       cit != atoms.end(); ++cit) {
    if (name_ == cit->getName())
      return *cit;
  }
}
const string&
Residue::getName() const {
  return name;
}
int
Residue::getResSeq() const {
  return resSeq;
}
char
Residue::getICode() const {
  return iCode;
}
const vector<Atom>&
Residue::getAtoms() const {
  return atoms;
}
const Vector3&
Residue::getCenter() {
  // if not yet present calculates and returns
  // geometric center of the residue
  if (gCenter == 0) {
    float _x = 0.0f, _y = 0.0f, _z = 0.0f;
    unsigned int _n = 0;
    for (vector<Atom>::const_iterator citA = atoms.begin();
         citA !=atoms.end(); ++citA) {
      _x += citA->getCoord().x;
      _y += citA->getCoord().y;
      _z += citA->getCoord().z;
      ++_n;
    }
    float _1n = 1.0f / _n;
    _gCenter.x = _x*_1n;
    _gCenter.y = _y*_1n;
    _gCenter.z = _z*_1n;
    gCenter = &_gCenter;
  }
  return *gCenter;
}

void 
Residue::setAtoms(const vector<Atom>& atoms_) {
  atoms.clear();
  atoms = atoms_;
}

void trim2CB(Residue& res_) {
  // atoms which should be left in residue
  vector<Atom> newAtoms;
  string atoms[] = {
    "N",   "C",   "O",   "H",
    "OXT", "O2",  "CA",  "CB",
    "HA",  "HB2", "HB3"       };
  int atomNumb = 11;
  for (vector<Atom>::const_iterator cit = res_.getAtoms().begin();
       cit != res_.getAtoms().end(); ++cit) {
    for (int i = 0; i < atomNumb; ++i) {
      if (cit->getName() == atoms[i]) {
        newAtoms.push_back(*cit);
  
      }
    } 
  }
  res_.setAtoms(newAtoms);
}


