//-------------------------------------------------------------------
/*! \file pdbout.cpp
    \brief Classes output PdbFile and PdbLine objects 
    
    by D.M. EML Research
    V0.2 2005.01.19
*/
//-------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>

#include "pdbout.h"
#include "../molecule/pdbfile.h"
#include "../molecule/pdbline.h"



using namespace std;

void
PdbFileOut::writePdbFileS1(const string& fileName_, 
                         const PdbFileS1& pdbFile_) {
  openFile(fileName_);
  for (vector<PdbLineS1>::const_iterator citerPL =
                          pdbFile_.getPdbLines()->begin();
       citerPL != pdbFile_.getPdbLines()->end();
       ++citerPL) {
    writeLine(*citerPL);
  }
}

void
PdbFileOut::writePdbFile(const string& fileName_, 
                         const PdbFile& pdbFile_) {
  openFile(fileName_);
  unsigned int _n = 1;
  for (vector<PdbLine>::const_iterator citPL =                          
       pdbFile_.getPdbLines()->begin(); 
       citPL != pdbFile_.getPdbLines()->end();
       ++citPL) {
    writeLine(*citPL, _n);
    ++_n;
  } 
}

void
PdbFileOut::writeLine(const PdbLineS1& pdbLine_) {
  fou << pdbLine_.getLineTo30();
  fou.setf(ios::right, ios::adjustfield);
  fou.setf(ios::fixed, ios::floatfield);
  fou << setprecision(3)
      << setw(8) << pdbLine_.getCoord().x
      << setw(8) << pdbLine_.getCoord().y
      << setw(8) << pdbLine_.getCoord().z
      << endl;
} 

void 
PdbFileOut::writeLine(const PdbLine& pdbLine_,
                      unsigned int index_) {
// writes pdb line from PdbLine object
  string atom = *pdbLine_.getAtom();
  fou << "ATOM" << "  "
      << setw(5) << setiosflags(ios::right) << index_ << " "
      << (atom.size() < 3 ?
          atom.size() > 1 ? " "+atom+" " : " "+atom+"  " :
          atom.size() ==4 ? atom : " "+atom)
      << *pdbLine_.getAltLoc()
      << *pdbLine_.getResName() << " "
      << *pdbLine_.getChainID()
      << setw(4) << setiosflags(ios::right) 
      << *pdbLine_.getResSeq()
      << *pdbLine_.getICode() << "   ";
  fou.setf(ios::right, ios::adjustfield);
  fou.setf(ios::fixed, ios::floatfield);
  fou << setprecision(3)
      << setw(8) << pdbLine_.getCoord()->x
      << setw(8) << pdbLine_.getCoord()->y
      << setw(8) << pdbLine_.getCoord()->z
      << endl;
}




