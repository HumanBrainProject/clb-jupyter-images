//-------------//
// accessin.h  //
//-------------//
#ifndef ACCESSIN_H
#define ACCESSIN_H

#include "basicin.h"
using namespace std;
class AccessIn: public BasicIn{
	public:
	//---methods--->
		// manage
		virtual ~AccessIn(){};
		virtual void who() const;
		// main
		virtual vector<string> getLinesX();
	private:
		static const string RES;
};

#endif

