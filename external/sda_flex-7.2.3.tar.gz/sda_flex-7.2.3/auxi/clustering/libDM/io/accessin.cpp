//-----------------------------------------------------------------//
// accessin.h                                                      //
//                                                                 //
// class AccesssIn                                                 //
// derived class to read NACCESS output files                      //
//                                                                 //
// libDM V 0.3	2005.05.21                                         //
// D.M.                                                            //
//-----------------------------------------------------------------//

#include <iostream>
#include "accessin.h"

using namespace std;

//===class===>
const string AccessIn::RES = "RES";
//---methods--->
// manage
void AccessIn::who() const{
	cout << "INFO: class AccessIn" << endl;
}
// main
vector<string> AccessIn::getLinesX(){
// returns RES lines as vector of strings
	vector<string> _vs;
	if (!fin.is_open()){
		cout << "ERROR: there is no NACCESS output file opened! " << endl;
		return _vs;
	}
	streampos _sp = 0;
	fin.seekg(_sp);
	string _str;
	while(!fin.eof()){
		getline(fin, _str);
		if (_str.substr(0, 3) != RES)
			continue;
		_vs.push_back(_str);
	}
	return _vs;
}

//===class===>



