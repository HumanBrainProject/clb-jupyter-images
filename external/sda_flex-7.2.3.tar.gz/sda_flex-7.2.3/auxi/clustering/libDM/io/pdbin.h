//----------//
// pdbin.h  //
//----------//
#ifndef PDBIN_H
#define PDBIN_H


#include "basicin.h"
using namespace std;
class PdbIn: public BasicIn{
  public:
  //---methods--->
    // manage
    virtual ~PdbIn(){};
    virtual void who() const;
    // main
    virtual vector<string> getLinesX();
    
  protected:
  private:
    static const string ATOM;
};

#endif

