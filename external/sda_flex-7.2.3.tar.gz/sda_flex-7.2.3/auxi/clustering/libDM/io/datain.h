
#ifndef DATAIN_H
#define DATAIN_H

#include <map>
#include <string>
#include "basicin.h"
#include "vector3.h"
using namespace std;
class DataIn: public BasicIn{
  public:
    virtual ~DataIn(){};
    virtual void who() const;
    virtual vector<string> getLinesX();

    void getFloatColumn(const string&, vector<float>&, const int = 1);
    void getStrings(const string&, vector<string>&, const int = 1);
    void getAAChar(const string&, char[], const int = 1);
    void getAAFloat(const string&, float[], const int = 1);
    void getAA2dMatrix(const string&, float[][20]);
    map<char, float> getAAFloat(const string&);
    void getAAFloat(const string&, map<char, float>*);
    void getAAAFloat(const string&, map<string, float>&);

    
    vector<string> getFort55All(int lineNumb_ = 500);
    Vector3 getFort55Center1(const string& file_);
    Vector3 getFort55Center2(const string& file_);
    void getFort55All(const string& fileName_,
                      vector<string>& data_, 
                      int lineNumb_ = 500);
    vector<float> getFort55One(const string&, const int);
  protected:
  private:
};


#endif

