//-------------------------------------------------------------------
/*! \file pdbout.h
    \brief Classes output PdbFile and PdbLine objects 
    
    by D.M. EML Research
    V0.2 2005.01.19
*/
//-------------------------------------------------------------------


#ifndef PDBOUT_H
#define PDBOUT_H

#include "basicout.h"

class PdbFileS1;
class PdbLineS1;
class PdbFile;
class PdbLine;

/*! \brief Class to print various PdbFile and PdbLine objects.

*/
class PdbFileOut: public BasicOut {
  public:
    PdbFileOut() {};
    void writePdbFileS1(const string& fileName_, const PdbFileS1& pdbFile_);
    void writePdbFile(const string& fileName_, const PdbFile& pdbFile_);
  private:
    void writeLine(const PdbLineS1& pdbLine_);
    void writeLine(const PdbLine& pdbLine_, unsigned int index_ = 1);
};


#endif

