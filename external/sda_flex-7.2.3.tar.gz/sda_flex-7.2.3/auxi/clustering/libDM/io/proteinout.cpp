//-----------------------------------------------------------------------
// proteinout.cpp
//
// this class kindda a printer just submit other stuff to its instance.
//-----------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

#include "proteinout.h"
#include "protein.h"
#include "residue.h"
#include "pdbfile.h"
#include "constdata.h"
#include "vector3.h"


using namespace std;


void
ProteinOut::writeProtein(const string& fileName_, const Protein& prot_) {
  openFile(fileName_);
  unsigned int n = 1;
  for (vector<Chain>::const_iterator citC = prot_.getChains().begin();
       citC != prot_.getChains().end(); ++citC) {
    for (vector<Residue>::const_iterator citR = citC->getResidues().begin();
         citR != citC->getResidues().end(); ++citR) {
      for (vector<Atom>::const_iterator citA = citR->getAtoms().begin();
           citA != citR->getAtoms().end(); ++citA) {
        writeLine(n, *citC, *citR, *citA);
        ++n;
      } // atom
    } // res
  } // chain
}

void
ProteinOut::writeResidues(const string& fileName_,
                          const vector<Residue>& res_) {
  openFile(fileName_);
  unsigned int n = 1;
  for (vector<Residue>::const_iterator citR = res_.begin();
       citR != res_.end(); ++citR) {
    for (vector<Atom>::const_iterator citA = citR->getAtoms().begin();
         citA != citR->getAtoms().end(); ++citA) {
      writeLine(n, *citR, *citA);
      ++n;
    } // atoms
  }  // residues                                    
}

void
ProteinOut::writeResidues(const string& fileName_, 
                          const vector<const Residue*>& res_) {
  openFile(fileName_);
  unsigned int n = 1;
  for (vector<const Residue*>::const_iterator citR = res_.begin();
       citR != res_.end(); ++ citR) {
    for (vector<Atom>::const_iterator citA = (*citR)->getAtoms().begin();
         citA != (*citR)->getAtoms().end(); ++citA) {
      writeLine(n, *(*citR), *citA);
      ++n;
    }
  }
}

void
ProteinOut::writeLine(unsigned int index_, 
                      const Residue& res_, const Atom& atom_) {
        fou << "ATOM  ";
        fou << setw(5) << setiosflags(ios::right) << index_
            << " "
            << (atom_.getName().size() <3 ?
               (atom_.getName().size() >1 ? 
                " "+atom_.getName()+" " : " "+atom_.getName()+"  ") :
               (atom_.getName().size()==4 ? 
                atom_.getName() : " "+atom_.getName()))
            << " "
            << res_.getName()
            << "  "
            << setw(4)
            << res_.getResSeq()
            << "    ";
        // setting stuff for float output
        fou.setf(ios::right, ios::adjustfield);
        fou.setf(ios::fixed, ios::floatfield);
        fou << setprecision(3)
            << setw(8) << atom_.getCoord().x
            << setw(8) << atom_.getCoord().y
            << setw(8) << atom_.getCoord().z
            << endl;
}

void
ProteinOut::writeLine(unsigned int index_, 
                      const Chain& chain_,
                      const Residue& res_, 
                      const Atom& atom_) {
        fou << "ATOM  ";
        fou << setw(5) << setiosflags(ios::right) << index_
            << " "
            << (atom_.getName().size() <3 ?
               (atom_.getName().size() >1 ? 
                " "+atom_.getName()+" " : " "+atom_.getName()+"  ") :
               (atom_.getName().size()==4 ? 
                atom_.getName() : " "+atom_.getName()))
            << " "
            << res_.getName()
            << " "
            << chain_.getName()
            << setw(4)
            << res_.getResSeq()
            << "    ";
        // setting stuff for float output
        fou.setf(ios::right, ios::adjustfield);
        fou.setf(ios::fixed, ios::floatfield);
        fou << setprecision(3)
            << setw(8) << atom_.getCoord().x
            << setw(8) << atom_.getCoord().y
            << setw(8) << atom_.getCoord().z
            << endl;
}
                 
/*
//===class===>
//constructor
void ProteinOut::who() const{
	cout << "INFO: class ProteinOut" << endl;
}
//---methods--->

void ProteinOut::outFProtein(const string& fileName_, Protein& pr_){
	openFile(fileName_);
	vector<Residue>::const_iterator citerVR;
	vector<Atom>::const_iterator citerVA;
	int n = 1;
	for (citerVR = pr_.residues.begin();
	     citerVR !=pr_.residues.end();
	     ++citerVR){
		for (citerVA = citerVR->atoms.begin();
		     citerVA !=citerVR->atoms.end();
		     ++citerVA){
			writeLine(n, &(*citerVR), &(*citerVA));
			++n;
		}
	}
}

void ProteinOut::outFResidues(string& fileName,
			  vector<const Residue*>& residues){
// write vector of residues to file
	openFile(fileName);
	vector<const Residue*>::const_iterator citerVR;
	vector<Atom>::const_iterator citerVA;
	int atomID = 1;
	for (citerVR = residues.begin();
	     citerVR !=residues.end();
	     ++citerVR){
		for (citerVA = (*citerVR)->atoms.begin();
		     citerVA !=(*citerVR)->atoms.end();
		     ++citerVA){
			writeLine(atomID, *citerVR, &(*citerVA));
		}
	}
}


// this template accepts any stream object and prints to it,
// it is private so called by other methods
void ProteinOut::writeLine(int atomID_, const Residue* r_in,
                       const Atom* a_in){
	fou << setw(6) << setiosflags(ios::left) << "ATOM"
	    << setw(5) << setiosflags(ios::right) << atomID_
	    << " "
	    << (a_in->atom.size() <3 ?
	       (a_in->atom.size() >1 ? " "+a_in->atom+" "
	       		: " "+a_in->atom+"  ") :
	       (a_in->atom.size()==4 ? a_in->atom : " "+a_in->atom))
	    << " "
	    << r_in->resName
	    << "  "
	    << setw(4)
	    << r_in->resSeq
	    << "    ";
	// setting stuff for float output
	fou.setf(ios::right, ios::adjustfield);
	fou.setf(ios::fixed, ios::floatfield);
	fou << setprecision(3)
	    << setw(8) << a_in->coor.x
	    << setw(8) << a_in->coor.y
	    << setw(8) << a_in->coor.z
	    << endl;
}

//---class---/
*/
