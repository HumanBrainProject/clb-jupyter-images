/*! \file printout.h
    \brief functions to print out things nicely
    
*/

#ifndef PRINTOUT_H
#define PRINTOUT_H

#include <ostream>
#include <iomanip>


namespace libDM_IO {

using namespace std;

template <typename T1, typename T2>
void printVector(T1& ou_, const vector<T2>& vec_) {
  for(int i = 0; i < vec_.size(); ++i) {
    ou_ << vec_[i] << '\n';
  }
}

template <typename T>
void printF(T& ou_, float f_, bool end = 1) {
  ou_.setf(ios::right | ios::adjustfield);
  ou_.setf(ios::fixed);
  ou_ << setw(8) << setprecision(3) << f_;
  if (end)
    ou_ << endl; 
}

template <typename T>
void printF(T& ou_, float f1_, float f2_, bool end = 1) {   
  ou_.setf(ios::right | ios::adjustfield);
  ou_.setf(ios::fixed);
  ou_ << setw(8) << setprecision(3) << f1_ << " "
      << setw(8) << setprecision(3) << f2_;
  if (end)
    ou_ << endl;
}

template <typename T>
void printF(T& ou_, float f1_, float f2_, float f3_, bool end = 1) {
  ou_.setf(ios::right | ios::adjustfield);
  ou_.setf(ios::fixed);
  ou_ << setw(8) << setprecision(3) << f1_ << " "
      << setw(8) << setprecision(3) << f2_ << " "
      << setw(8) << setprecision(3) << f3_;
  if (end)
    ou_ << endl;
}


template <typename T>
void printI(T& ou_, int i_, bool end = 1) {
  ou_ << setw(8) << i_;
  if (end)
    ou_ << endl;
}

template <typename T>
void printI(T& ou_, int i1_, int i2_, int i3_, bool end = 1) {
  ou_ << setw(8) << i1_ << " "
      << setw(8) << i2_ << " "
      << setw(8) << i3_;
  if (end)
    ou_ << endl;
}

} // libDM_IO
#endif


