//-----------------------------------------------------------------------
// fullpdbout.cpp
//
// this class kindda a printer just submit other stuff to its instance.
//-----------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

#include "fullpdbout.h"
#include "../molecule/fullpdb.h"
#include "../molecule/pdbline.h"
#include "../constdata/constdata.h"

using namespace std;

//===class===>
//constructor
// my_std
void FullPdbOut::who() const{
	cout << "INFO: class FullPdbOut" << endl;
}

//---methods--->

void FullPdbOut::outFFullPdb(const string& fileName, FullPdb& fp){
// writes pdb structure to file from FullPdb object
	openFile(fileName);
	int _i = 1;
	vector<PdbLine>::const_iterator citerVP;
	for (citerVP = fp.pdbLines.begin();
	     citerVP !=fp.pdbLines.end();
	 	++citerVP){
		writePdbLine(_i, *citerVP);
		++_i;
	}
}

void FullPdbOut::writePdbLine(int aID, const PdbLine& pl) {
// writes pdb line from PdbLine object
	string atom = *pl.getAtom();
	//xou.fill('.');
	fou << ATOM << "  "
	    << setw(5) << setiosflags(ios::right) << aID << " "
	    << (atom.size() < 3 ?
	        atom.size() > 1 ? " "+atom+" " : " "+atom+"  " :
	        atom.size() ==4 ? atom : " "+atom)
	    << *pl.getAltLoc()
	    << *pl.getResName() << " "
	    << *pl.getChainID()
	    << setw(4) << setiosflags(ios::right) << *pl.getResSeq()
	    << *pl.getICode() << "   ";
	fou.setf(ios::right, ios::adjustfield);
	fou.setf(ios::fixed, ios::floatfield);
	fou << setprecision(3)
	    << setw(8) << pl.getCoor()->x
	    << setw(8) << pl.getCoor()->y
	    << setw(8) << pl.getCoor()->z
	    << endl;
}

//---class--->
