//-------------//
// basicout.h  //
//-------------//
#ifndef BASICOUT_H
#define BASICOUT_H

#include <fstream>
#include <string>
using namespace std;
class BasicOut{
	public:
	//---methods--->
		// manage
		virtual ~BasicOut(){};
		virtual void who() const;
		// main
		void openFile(const char*);
		void openFile(const string&);
	//---members--->
		string fileName;
	protected:
	//---methods--->
		void writeSimpleString(string&);
	//---members--->
		ofstream fou;
	private:
		//---methods--->
		void clear();
		//---members--->
};
#endif


