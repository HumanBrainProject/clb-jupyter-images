//--------------------------------------------------------------------
// basicout.cpp
//
// class BasicIn
// an abastract class for output
//
// libDM v 0.3 2005.06.10
// D.M.
//--------------------------------------------------------------------

#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>

#include "basicout.h"

using namespace std;

//===class===>
//---methods--->
// manage
void BasicOut::who() const{
	cout << "INFO: class BasicOut" << endl;
}
// main
void BasicOut::openFile(const char* fileName_){
// if file is opened calls clear to reinitialize things before openning new
	if (fou.is_open())
		this->clear();
	fou.open(fileName_);
	if (!fou.is_open()){
		cout << "ERROR: Failed to open the file: " << fileName_ << endl;
		exit(1);
	}
	fileName = fileName_;
}

void BasicOut::openFile(const string& fileName_){
	char* _fileName = const_cast<char*>(fileName_.c_str());
	openFile(_fileName);
	fileName = fileName_;
}

void BasicOut::clear(){
	//fou.clear();
	fou.close();
	fileName = "";
}

void BasicOut::writeSimpleString(string& str_){
	if (!fou.is_open()){
		cout << "WARNING: no file opened for writing" << endl;
	}
	fou << str_ << endl;
}



