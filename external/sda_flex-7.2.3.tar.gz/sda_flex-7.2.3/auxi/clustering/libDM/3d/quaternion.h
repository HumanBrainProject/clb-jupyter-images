//----------
// quqterion - header
//----------

#ifndef QUATERNION_H
#define QUATERNION_H

class Vector3;
class EulerAngles;

// Quaterion class for representing angular displacement (oriendtation) in 3d.
class Quaternion
{
	public:
		float w, x, y, z;
		void identity() { w = 1.0f; x = y = z = 0.0f; }
		// Setup the quaternion to a specific rotation
		void set2RotAboX(float alfa);
		void set2RotAboY(float alfa);
		void set2RotAboZ(float alfa);
		void set2RotAboAxi(const Vector3&, float);
		// Setup to perform object<->inertial rotations,
		// given orientation in Euler angle format
		void set2RotObj2Ine(const EulerAngles&);
		void set2RotIne2Obj(const EulerAngles&);
		// Cross product (multiplication)
		Quaternion operator*(const Quaternion&) const;
		// Multiplication with assignment, as per C++ convention
		Quaternion &operator*=(const Quaternion&);
		// Normalize the quaternion.
		void normalize();
		// Extract and return the rotation angle and axis.
		float getRotAng() const;
		Vector3 getRotAxi() const;
};

// A global "identity" quaternion constant
extern const Quaternion kQuaternionIdentity;
// Quaternion dot product.
extern float dotProduct(const Quaternion&, const Quaternion&);
// Spherical linear interpolation
extern Quaternion slerp(const Quaternion&, const Quaternion&, float t);
// Quaternion conjugation
extern Quaternion conjugate(const Quaternion&);
// Quaternion exponentiation
extern Quaternion pow(const Quaternion&, float);

#endif 

