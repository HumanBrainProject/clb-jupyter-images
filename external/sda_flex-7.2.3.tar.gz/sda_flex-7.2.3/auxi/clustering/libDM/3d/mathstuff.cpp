//--------------------------------------------------------
/*! \file mathstuff.cpp
    \brief Math stuff from 3d Math primer
 
*/
//--------------------------------------------------------

#include <cmath>

#include "mathstuff.h"

// make angle in range [-pi, pi]
float makeNiceAngle(float alfa) {
  alfa += cpi;
  alfa -= floor(alfa * c1Dpi) * c2Mpi;
  alfa -= cpi;
  return alfa;
}
// if y is out of range it is fixed to either -1 or 1

float safeAcos(float y_in) {
  if (y_in <= -1.0f)
    return cpi;
  if (y_in >= 1.0f)
    return 0.0f;
  return acos(y_in);
}



