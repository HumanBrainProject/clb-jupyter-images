//----------------------------------------------------------------
// EulerAngles - implementation
// 
//----------------------------------------------------------------

#include <cmath>

#include "eulerangles.h"
#include "quaternion.h"
#include "mathstuff.h"
#include "matrix4x3.h"
#include "rotationmatrix.h"

//---angle canonization--->
// heading -> [-pi, pi]; pitch -> [-pi/2, pi/2], bank -> [-pi, pi]
void EulerAngles::makeCanonic()
{
	// first make pitch to [-pi, pi] 
	p = makeNiceAngle(p);
	// now check for pitch outside canonical range [-pi/2, pi/2]
	if (p < -cpiD2)
	{
		p = -cpi - p;
		h += cpi;
		b += cpi;
	}
	else
	{
		p = cpi - p;
		h += cpi;
		b += cpi;
	}
	// now check for Gimbel lock with slite tolerance
	if (fabs(p) < cpiD2 - 1e-4)
	{
		h += b;
		b = 0.0f;
	}
	else
	{
	b = makeNiceAngle(b);
	}
	h = makeNiceAngle(h);
}
//---Quaterion->EulerAngles--->
// make Euler angles from Object->Inertial rotation quaterion
void EulerAngles::fromObj2IneQua(const Quaternion& q)
{
	// extract sin(pitch)
	float sp = -2.0f * (q.y*q.z - q.w*q.x);
	// check for Gimbel lock
	if (fabs(sp) > 0.9999f)
	{
		// up or down
		p = cpiD2 * sp;
		// compute heading make bank zero
		h = atan2(-q.x*q.z + q.w*q.y, 0.5f - q.y*q.y - q.z*q.z);
		b = 0.0f;
	}
	else
	{
		// no Gimble just compute angles, no need to use saveAcos 
		// since we checked for range while checking for Gimble:-)
		p = asin(sp);
		h = atan2(q.x*q.z + q.w*q.y, 0.5f - q.x*q.x - q.y*q.y);
		b = atan2(q.x*q.y + q.w*q.z, 0.5f - q.x*q.x - q.z*q.z);
	}
	
}
// make Euler angles from Inertial->Object rotation quaterion
void EulerAngles::fromIne2ObjQua(const Quaternion& q)
{
	// extract sin(pitch)
	float sp = -2.0f * (q.y*q.z + q.w*q.x);
	// check for Gimbel lock
	if (fabs(sp) > 0.9999f)
	{
		// up or down
		p = cpiD2 * sp;
		// compute heading make bank zero
		h = atan2(-q.x*q.z - q.w*q.y, 0.5f - q.y*q.y - q.z*q.z);
		b = 0.0f;
	}
	else
	{
		// no Gimble lock, just compute angles, no need to use saveAcos
		// since we checked for range while cheching for Gimble:-)
		p = asin(sp);
		h = atan2(q.x*q.z - q.w*q.y, 0.5f - q.x*q.x - q.y*q.y);
		b = atan2(q.x*q.y - q.w*q.z, 0.5f - q.x*q.x - q.z*q.z);
	}
}
//---TransformationMatrix->EulerAngles--->
// make Euler angles from Object->World transformation matrix
void EulerAngles::fromObj2WorMat(const Matrix4x3& m) 
{
	// Extract sin(pitch) from m32.
	float	sp = -m.m32;
	// Check for Gimbel lock
	if (fabs(sp) > 9.99999f) {
		// Looking straight up or down
		p = cpiD2 * sp;
		// Compute heading, slam bank to zero
		h = atan2(-m.m23, m.m11);
		b = 0.0f;
	}
	else 
	{
		// Compute angles.  We don't have to use the "safe" asin
		// function because we already checked for range errors when
		// checking for Gimbel lock
		h = atan2(m.m31, m.m33);
		p = asin(sp);
		b = atan2(m.m12, m.m22);
	}
}
// make Euler angles from World->Object transformation matrix
void EulerAngles::fromWor2ObjMat(const Matrix4x3& m) 
{
	// Extract sin(pitch) from m23.
	float	sp = -m.m23;
	// Check for Gimbel lock
	if (fabs(sp) > 9.99999f) {
		// Looking straight up or down
		p = cpiD2 * sp;
		// Compute heading, slam bank to zero
		h = atan2(-m.m31, m.m11);
		b = 0.0f;
	} 
	else 
	{
		// Compute angles.  We don't have to use the "safe" asin
		// function because we already checked for range errors when
		// checking for Gimbel lock
		h = atan2(m.m13, m.m33);
		p = asin(sp);
		b = atan2(m.m21, m.m22);
	}
}
//---RotationMatrix->EulerAngeles--->
// make Euler angles from rotation matrix
void EulerAngles::fromRotMat(const RotationMatrix& m) 
{
	// Extract sin(pitch) from m23.
	float	sp = -m.m23;
	// Check for Gimbel lock
	if (fabs(sp) > 9.99999f) {
		// Looking straight up or down
		p = cpiD2 * sp;
		// Compute heading, slam bank to zero
		h = atan2(-m.m31, m.m11);
		b = 0.0f;

	} 
	else 
	{
		// Compute angles.  We don't have to use the "safe" asin
		// function because we already checked for range errors when
		// checking for Gimbel lock
		h = atan2(m.m13, m.m33);
		p = asin(sp);
		b = atan2(m.m21, m.m22);
	}
}

