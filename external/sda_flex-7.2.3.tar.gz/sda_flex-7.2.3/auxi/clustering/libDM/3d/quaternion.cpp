//----------
// Quaterion implementation
//----------

#include <cmath>
#include <cassert>

#include "quaternion.h"
#include "mathstuff.h"
#include "vector3.h"
#include "eulerangles.h"

//---inlines--->
inline float vectorMag(const Vector3& v){
	return sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
}
// global quaterion identity
const Quaternion kQuaternionIdentity = {1.0f, 0.0f, 0.0f, 0.0f};
//===Quaterion Class===>
//---Rotation about axis--->
// Setup the quaternion to rotate about the specified axis
void Quaternion::set2RotAboX(float alfa) 
{
	// Compute the half angle
	float alfaD2 = alfa * 0.5f;
	// Set the values
	w = cos(alfaD2);
	x = sin(alfaD2);
	y = 0.0f;
	z = 0.0f;
}
void Quaternion::set2RotAboY(float alfa) 
{
	// Compute the half angle
	float alfaD2 = alfa * 0.5f;
	// Set the values
	w = cos(alfaD2);
	x = 0.0f;
	y = sin(alfaD2);
	z = 0.0f;
}
void Quaternion::set2RotAboZ(float alfa) 
{
	// Compute the half angle
	float alfaD2 = alfa * 0.5f;
	// Set the values
	w = cos(alfaD2);
	x = 0.0f;
	y = 0.0f;
	z = sin(alfaD2);
}
void Quaternion::set2RotAboAxi(const Vector3 &axis, float alfa) 
{
	// The axis of rotation must be normalized
	assert(fabs(vectorMag(axis) - 1.0f) < .01f);
	// Compute the half angle and its sin
	float alfaD2 = alfa * .5f;
	float sinalfaD2 = sin(alfaD2);
	// Set the values
	w = cos(alfaD2);
	x = axis.x * sinalfaD2;
	y = axis.y * sinalfaD2;
	z = axis.z * sinalfaD2;
}
//---rotation from given Euler angles --->
// rotate quaterion Object->Inertial
void Quaternion::set2RotObj2Ine(const EulerAngles &orientation) 
{
	// Compute sine and cosine of the half angles
	float sp, sb, sh;
	float cp, cb, ch;
	sinCos(&sp, &cp, orientation.p * 0.5f);
	sinCos(&sb, &cb, orientation.b * 0.5f);
	sinCos(&sh, &ch, orientation.h * 0.5f);
	// Compute values
	w =  ch*cp*cb + sh*sp*sb;
	x =  ch*sp*cb + sh*cp*sb;
	y = -ch*sp*sb + sh*cp*cb;
	z = -sh*sp*cb + ch*cp*sb;
}
// rotate quaterion Inertial->Object
void Quaternion::set2RotIne2Obj(const EulerAngles &orientation) 
{
	// Compute sine and cosine of the half angles
	float   sp, sb, sh;
	float   cp, cb, ch;
	sinCos(&sp, &cp, orientation.p * 0.5f);
	sinCos(&sb, &cb, orientation.b * 0.5f);
	sinCos(&sh, &ch, orientation.h * 0.5f);
	// Compute values
	w =  ch*cp*cb + sh*sp*sb;
	x = -ch*sp*cb - sh*cp*sb;
	y =  ch*sp*sb - sh*cb*cp;
	z =  sh*sp*cb - ch*cp*sb;
}
//---Quaternion operations--->
// operator*
// Quaternion cross product, which concatonates multiple angular
// displacements.  The order of multiplication, from left to right,
// corresponds to the order that the angular displacements are
// applied. 
Quaternion Quaternion::operator*(const Quaternion &q) const 
{
	Quaternion result;
	result.w = w*q.w - x*q.x - y*q.y - z*q.z;
	result.x = w*q.x + x*q.w + z*q.y - y*q.z;
	result.y = w*q.y + y*q.w + x*q.z - z*q.x;
	result.z = w*q.z + z*q.w + y*q.x - x*q.y;
	return result;
}
// combined cross product for c++ convention 
// operator *=
Quaternion& Quaternion::operator*=(const Quaternion &q) 
{
	// Multuiply and assign
	*this = *this * q;
	// Return reference to l-value
	return *this;
}
// Quaternion::normalize
// Note that normally, quaternions are always normalized
// This function is provided primarily to combat floating point "error
// creep," which can occur when many successive quaternion operations
// are applied.
void Quaternion::normalize() 
{
	// Compute magnitude of the quaternion
	float   mag = (float)sqrt(w*w + x*x + y*y + z*z);
	// Check for bogus length, to protect against divide by zero
	if (mag > 0.0f) {
		// Normalize it
		float   oneOverMag = 1.0f / mag;
		w *= oneOverMag;
		x *= oneOverMag;
		y *= oneOverMag;
		z *= oneOverMag;
	} 
	else 
	{
		// if there is a problem
		assert(false);
		// in build, just slam it to something
		identity();
	}
}
// get the rotation angle
float Quaternion::getRotAng() const 
{
	// Compute the half angle.   w = cos(alfa / 2)
	float alfaD2 = safeAcos(w);
	// Return the rotation angle
	return alfaD2 * 2.0f;
}
// get the rotation axis of quaterion
Vector3 Quaternion::getRotAxi() const 
{
	// Compute sin^2(alfa/2).  w = cos(alfa/2), sin^2(x) + cos^2(x) = 1
	float sinalfaD2sq = 1.0f - w*w;
	// Protect against numerical imprecision
	if (sinalfaD2sq <= 0.0f) 
	{
		// Identity quaternion, or numerical imprecision.  Just
		// return any valid vector, since it doesn't matter
		return Vector3(1.0f, 0.0f, 0.0f);
	}
	// Compute 1 / sin(alfa/2)
	float oneDsinalfaD2 = 1.0f / sqrt(sinalfaD2sq);
	// Return axis of rotation
	return Vector3(
		x * oneDsinalfaD2,
		y * oneDsinalfaD2,
		z * oneDsinalfaD2);
}
//==========Quatarion clas==========/

//===non member functions===>
// Quaternion dot product.
float dotProduct(const Quaternion& q1, const Quaternion& q2) 
{
	return q1.w*q2.w + q1.x*q2.x + q1.y*q2.y + q1.z*q2.z;
}
// Spherical linear interpolation - slerp
Quaternion slerp(const Quaternion& q1, const Quaternion& q2, float t) 
{
	// Check for out-of range parameter and return edge points if so
	if (t <= 0.0f) return q1;
	if (t >= 1.0f) return q2;
	// Compute "cosine of angle between quaternions" using dot product
	float cosOmega = dotProduct(q1, q2);
	// If negative dot, use -q1.  Two quaternions q and -q
	// represent the same rotation, but may produce
	// different slerp.  We chose q or -q to rotate using
	// the acute angle.
	float q2w = q2.w;
	float q2x = q2.x;
	float q2y = q2.y;
	float q2z = q2.z;
	if (cosOmega < 0.0f) 
	{
		q2w = -q2w;
		q2x = -q2x;
		q2y = -q2y;
		q2z = -q2z;
		cosOmega = -cosOmega;
	}
	// We should have two unit quaternions, so dot should be <= 1.0
	assert(cosOmega < 1.1f);
	// Compute interpolation fraction, checking for quaternions
	// almost exactly the same
	float k0, k1;
	if (cosOmega > 0.9999f) 
	{
		// Very close - just use linear interpolation,
		// which will protect againt a divide by zero
		k0 = 1.0f-t;
		k1 = t;
	} 
	else 
	{
		// Compute the sin of the angle using the
		// trig identity sin^2(omega) + cos^2(omega) = 1
		float sinOmega = sqrt(1.0f - cosOmega*cosOmega);
		// Compute the angle from its sin and cosine
		float omega = atan2(sinOmega, cosOmega);
		// Compute inverse of denominator, so we only have
		// to divide once
		float oneOverSinOmega = 1.0f / sinOmega;
		// Compute interpolation parameters
		k0 = sin((1.0f - t) * omega) * oneOverSinOmega;
		k1 = sin(t * omega) * oneOverSinOmega;
	}
	// Interpolate
	Quaternion result;
	result.x = k0*q1.x + k1*q2x;
	result.y = k0*q1.y + k1*q2y;
	result.z = k0*q1.z + k1*q2z;
	result.w = k0*q1.w + k1*q2w;
	// Return it
	return result;
}
// Compute the quaternion conjugate.  This is the quaternian
// with the opposite rotation as the original quaternian.
Quaternion conjugate(const Quaternion& q) 
{
	Quaternion result;
	// Same rotation amount
	result.w = q.w;
	// Opposite axis of rotation
	result.x = -q.x;
	result.y = -q.y;
	result.z = -q.z;
	// Return it
	return result;
}
// Quaternion exponentiation.
Quaternion pow(const Quaternion& q, float exponent) 
{
	// Check for the case of an identity quaternion.
	// This will protect against divide by zero
	if (fabs(q.w) > .9999f) 
	{
		return q;
	}
	// Extract the half angle alpha (alpha = theta/2)
	float   alpha = acos(q.w);
	// Compute new alpha value
	float   newAlpha = alpha * exponent;
	// Compute new w value
	Quaternion result;
	result.w = cos(newAlpha);
	// Compute new xyz values
	float   mult = sin(newAlpha) / sin(alpha);
	result.x = q.x * mult;
	result.y = q.y * mult;
	result.z = q.z * mult;
	// Return it
	return result;
}


