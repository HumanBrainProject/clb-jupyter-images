//----------
// matrix4x3 - implementation
//----------

#ifndef MATRIX4X3_H
#define MATRIX4X3_H

class Vector3;
class EulerAngles;
class Quaternion;
class RotationMatrix;

// 4x3 transformation mtrix suitable for any kind of transformation:-)

class Matrix4x3
{
	public:
		// The values of the matrix.  Basically the upper 3x3 portion
		// contains a linear transformation, and the last row is the
		// translation portion.
		float	m11, m12, m13;
		float	m21, m22, m23;
		float	m31, m32, m33;
		float	tx,  ty,  tz;
		//--------->
		void identity();
		void zeroTranslation();
		void setTranslation(const Vector3&);
		void setupTranslation(const Vector3&);
		// Setup the matrix to perform a specific transforms from parent <->
		// local space, assuming the local space is in the specified position
		// and orientation within the parent space.  The orientation may be
		// specified using either Euler angles, or a rotation matrix
		void setupLoc2Par(const Vector3&, const EulerAngles&);
		void setupLoc2Par(const Vector3&, const RotationMatrix&);
		void setupPar2Loc(const Vector3&, const EulerAngles&);
		void setupPar2Loc(const Vector3&, const RotationMatrix&);
		// Setup the matrix to perform a rotation about a cardinal axis
		void setupRotate(int, float);
		// Setup the matrix to perform a rotation about an arbitrary axis
		void setupRotate(const Vector3&, float);
		// Setup the matrix to perform a rotation, given
		// the angular displacement in quaternion form
		void fromQuaternion(const Quaternion&);
		// Setup the matrix to perform scale on each axis
		void setupScale(const Vector3&);
		// Setup the matrix to perform scale along an arbitrary axis
		void setupScaleAlongAxis(const Vector3&, float);
		// Setup the matrix to perform a shear
		void setupShear(int, float, float);
		// Setup the matrix to perform a projection onto a plane passing
		// through the origin
		void setupProject(const Vector3&);
		// Setup the matrix to perform a reflection about a plane parallel
		// to a cardinal plane
		void setupReflect(int, float);
		// Setup the matrix to perform a reflection about an arbitrary plane
		// through the origin
		void setupReflect(const Vector3&);
};

// Operator* is used to transforms a point, and also concatonate matrices.
// The order of multiplications from left to right is the same as
// the order of transformations
Vector3 operator*(const Vector3&, const Matrix4x3&);
Matrix4x3 operator*(const Matrix4x3&, const Matrix4x3&);
// Operator *= for conformance to C++ standards
Vector3& operator*=(Vector3&, const Matrix4x3&);
Matrix4x3& operator*=(const Matrix4x3&, const Matrix4x3&);
// Compute the determinant of the 3x3 portion of the matrix
float determinant(const Matrix4x3&);
// Compute the inverse of a matrix
Matrix4x3 inverse(const Matrix4x3&);
// Extract the translation portion of the matrix
Vector3 getTranslation(const Matrix4x3&);
// Extract the position/orientation from a local->parent matrix,
// or a parent->local matrix
Vector3	getPosPar2LocMat(const Matrix4x3&);
Vector3	getPosLoc2ParMat(const Matrix4x3&);

#endif




