//-------------------------------------------------------------------
/*! \file sdafort55.cpp

*/
//
//
//
//
// by D.M. EML Research 2005.11
// V0.2 - F55Line class added to store fort55 file lines
// V0.1
//-------------------------------------------------------------------
#include <vector>
#include <cassert>
#include <iostream>
#include <stdexcept>
#include <fstream>
#include <cmath>

#include "atom.h"
#include "sdafort55_2.h"
#include "commonfoo.h"
#include "vector3.h"


 
// inlines
inline Vector3
crossProduct(const Vector3& v1, const Vector3& v2){
  return Vector3(v1.y*v2.z - v1.z*v2.y,
                 v1.z*v2.x - v1.x*v2.z,
                 v1.x*v2.y - v1.y*v2.x);
}
inline void 
splitLine(const string& str_,
          vector<string>& pieces_,
          const string& separators_){
// startPost first found "good" char of the token
// endPost first found "bad" char at the end of token
  string::size_type startPos = str_.find_first_not_of(separators_, 0);
  string::size_type endPos   = str_.find_first_of(separators_, startPos);
  while(endPos != string::npos || startPos != string::npos){
  // token found
    pieces_.push_back(str_.substr(startPos, endPos - startPos));
    startPos = str_.find_first_not_of(separators_, endPos);
    endPos   = str_.find_first_of(separators_, startPos);
  }
}
inline bool
myIsNan(float x) {
  return x != x;
}


namespace libDM_sda {
//*******************************************************************
// FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO 
// non_inlines
void
getFort55Lines(const char* fileName_, vector<string>& lines_,
             int lineNumb_) {
             
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return;
  }

  string _str;
  lines_.reserve(lineNumb_);
  
  // iterate through file
  int _num = 0;
  while(!fin.eof()) {
    getline(fin, _str);
    // skip if line is a commnet or empty
    if (_str.substr(0, 1) == "#" or _str.length() == 0) 
      continue;
    
    // This piece of code checks for empty line in fort.55
    vector<string> _pieces;
    splitLine(_str, _pieces, " ");
    if (_pieces[2] == "0.000" &&
        _pieces[3] == "0.000" &&
        _pieces[4] == "0.000")
      break;
    // --------
              
    lines_.push_back(_str);
    ++_num;  
    // if already collected lineNumb_ number of lines, then break
    if (_num >= lineNumb_)
      break;
  }
  fin.close();
}


Vector3
getCenter1FromFort55(const char* fileName_) {
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return Vector3(0.0f, 0.0f, 0.0f);
  }
  
  // BUG_FIX by DM
  // This was old version and didn't work when coordinates where big
  // and no spaces between x, y, z were present in fort.55 file, 
  // so splitting didn't work correctly
  //
  //string _str;
  //vector<string> _splitLine;
  //getline(fin, _str);
  //splitLine(_str, _splitLine);
  //fin.close();
  //return Vector3(atof(_splitLine[1].c_str()), 
  //               atof(_splitLine[2].c_str()),
  //               atof(_splitLine[3].c_str()));

  string _str;
  getline(fin, _str);
  fin.close();
  return Vector3(atof(_str.substr(1, 8).c_str()),
                 atof(_str.substr(9, 8).c_str()),
                 atof(_str.substr(17,8).c_str()));
                  
  
}

Vector3
getCenter2FromFort55(const char* fileName_) {
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return Vector3(0.0f, 0.0f, 0.0f);
  }
  
  // BUG_FIX by DM
  // same as above
  //string _str;
  //vector<string> _splitLine;
  //getline(fin, _str);
  //getline(fin, _str);
  //splitLine(_str, _splitLine);
  //fin.close();
  //return Vector3(atof(_splitLine[1].c_str()),
  //              atof(_splitLine[2].c_str()),
  //               atof(_splitLine[3].c_str()));
  string _str;
  getline(fin, _str); _str.clear();
  getline(fin, _str);
  fin.close();
  return Vector3(atof(_str.substr(1, 8).c_str()),
                 atof(_str.substr(9, 8).c_str()),
                 atof(_str.substr(17,8).c_str()));
}

// FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO 
//*******************************************************************


// class F55Line
//const Uint F55Line::columns = 17; 
//const Uint F55Line::items   = 10;
// constructor
F55Line::F55Line(const F55Line& f55Line) {
  trNumb = f55Line.trNumb;
  stNumb = f55Line.stNumb;
  center = f55Line.center;
  basisX = f55Line.basisX;
  basisY = f55Line.basisY;
  elE    = f55Line.elE;
  desE   = f55Line.desE;
  hDesE  = f55Line.hDesE;
  time   = f55Line.time;
  occur  = f55Line.occur;
  avgElE = f55Line.avgElE;
  elEDisp= f55Line.elEDisp;
}

/* obsolete
F55Line::F55Line(const vector<string>& f55Strings_) {
  assert(f55Strings_.size() == columns);
  trNumb   = atoi(f55Strings_[0].c_str());
  stNumb   = atoi(f55Strings_[1].c_str());
  center.x = atof(f55Strings_[2].c_str()); 
  center.y = atof(f55Strings_[3].c_str());
  center.z = atof(f55Strings_[4].c_str());
  basisX.x = atof(f55Strings_[5].c_str());
  basisX.y = atof(f55Strings_[6].c_str());
  basisX.z = atof(f55Strings_[7].c_str());
  basisY.x = atof(f55Strings_[8].c_str());
  basisY.y = atof(f55Strings_[9].c_str());
  basisY.z = atof(f55Strings_[10].c_str());
  elE      = atof(f55Strings_[11].c_str());
  desE     = atof(f55Strings_[12].c_str());
  time     = static_cast<LUint>(atof(f55Strings_[13].c_str()));
  occur    = static_cast<Uint>(atof(f55Strings_[14].c_str()));
  avgElE   = atof(f55Strings_[15].c_str());
  elEDisp  = atof(f55Strings_[16].c_str());
  if (myIsNan(elEDisp))
    elEDisp = 0.0;
}
*/

F55Line::F55Line(const string& line_) {
  
  // below is a hack to handle different fort.55 versions
  if (line_.length() == 181) { // SDAC5 file with hd
    // DM_dbug cout << '1' << endl;
    
    trNumb  = atoi(line_.substr(0, 8).c_str());
    stNumb  = atoi(line_.substr(8, 8).c_str());
    
    center.x = atof(line_.substr(16, 9).c_str());  
    center.y = atof(line_.substr(25, 9).c_str());
    center.z = atof(line_.substr(34, 9).c_str());
    basisX.x = atof(line_.substr(43, 9).c_str());
    basisX.y = atof(line_.substr(52, 9).c_str());
    basisX.z = atof(line_.substr(61, 9).c_str());
    basisY.x = atof(line_.substr(70, 9).c_str());
    basisY.y = atof(line_.substr(79, 9).c_str());
    basisY.z = atof(line_.substr(88, 9).c_str());
  
    elE      = atof(line_.substr(97, 12).c_str());
    desE     = atof(line_.substr(109,12).c_str());
    hDesE   = atof(line_.substr(121,12).c_str()); 
    time    = static_cast<Uint>(atof(line_.substr(133,12).c_str()));
    occur   = static_cast<Uint>(atof(line_.substr(145,12).c_str()));
    avgElE  = atof(line_.substr(157,12).c_str());
    elEDisp = atof(line_.substr(169,12).c_str());
    if (myIsNan(elEDisp)) // if elEDisp is not a number just set it to 0.0
      elEDisp = 0.0f;
      
      
  } else if (line_.length() == 170) { // SDAC4 final file version with occur
    // DM_dbug cout << '2' << endl;
       
    trNumb  = atoi(line_.substr(0, 10).c_str());
    stNumb  = atoi(line_.substr(10, 10).c_str());
    
    center.x = atof(line_.substr(20, 8).c_str());  
    center.y = atof(line_.substr(28, 8).c_str());
    center.z = atof(line_.substr(36, 8).c_str());
    basisX.x = atof(line_.substr(44, 8).c_str());
    basisX.y = atof(line_.substr(52, 8).c_str());
    basisX.z = atof(line_.substr(60, 8).c_str());
    basisY.x = atof(line_.substr(68, 8).c_str());
    basisY.y = atof(line_.substr(76, 8).c_str());
    basisY.z = atof(line_.substr(84, 8).c_str());
        
    elE     = atof(line_.substr(92,  13).c_str());
    desE    = atof(line_.substr(105, 13).c_str());
    hDesE   = 0.0f;
    time    = static_cast<Uint>(atof(line_.substr(118, 13).c_str()));
    occur   = static_cast<Uint>(atof(line_.substr(131, 13).c_str())); 
    avgElE  = atof(line_.substr(144, 13).c_str());
    elEDisp = atof(line_.substr(157, 13).c_str());
    if (myIsNan(elEDisp))
      elEDisp = 0.0f;
      
  } else { // previous old SDAC4 versions
    // DM_dbug cout << '3' << endl;
    
    trNumb  = atoi(line_.substr(0, 10).c_str());
    stNumb  = atoi(line_.substr(10, 10).c_str());

    center.x = atof(line_.substr(20, 8).c_str());  
    center.y = atof(line_.substr(28, 8).c_str());
    center.z = atof(line_.substr(36, 8).c_str());
    basisX.x = atof(line_.substr(44, 8).c_str());
    basisX.y = atof(line_.substr(52, 8).c_str());
    basisX.z = atof(line_.substr(60, 8).c_str());
    basisY.x = atof(line_.substr(68, 8).c_str());
    basisY.y = atof(line_.substr(76, 8).c_str());
    basisY.z = atof(line_.substr(84, 8).c_str());
        
    elE     = atof(line_.substr(92,  13).c_str());
    desE    = atof(line_.substr(106, 13).c_str());
    time    = static_cast<Uint>(atof(line_.substr(119,13).c_str()));
    
    hDesE   = 0.0f;
    occur   = 0;
    avgElE  = 0.0f;
    elEDisp = 0.0f;
    if (myIsNan(elEDisp))
      elEDisp = 0.0f;
  }
}

F55Line&
F55Line::operator=(const F55Line& f55Line_) {
  trNumb   = f55Line_.trNumb;
  stNumb   = f55Line_.stNumb;
  center   = f55Line_.center; 
  basisX   = f55Line_.basisX;
  basisY   = f55Line_.basisY;
  elE      = f55Line_.elE;
  desE     = f55Line_.desE;
  hDesE    = f55Line_.hDesE;
  time     = f55Line_.time;
  occur    = f55Line_.occur;
  avgElE   = f55Line_.avgElE;
  elEDisp  = f55Line_.elEDisp;
  return *this;
}
// class SDAFort55 ---------------------------------------------------
// constructor
SDAFort55::SDAFort55(const SDAFort55& sdaF55_) {
  p1 = *sdaF55_.getProtein1();
  p2 = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
}
SDAFort55::SDAFort55(const vector<string>& lines_) {
  setFort55All(lines_);
}
SDAFort55::SDAFort55(const vector<string>& lines_,
                     const PdbFileS1& p1_,
                     const PdbFileS1& p2_) {
  setFort55All(lines_);
  setProtein1(p1_);
  setProtein2(p2_);
}
// operator
SDAFort55&
SDAFort55::operator=(const SDAFort55& sdaF55_) {
  p1        = *sdaF55_.getProtein1();
  p2        = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
  return *this;
}
// set
void
SDAFort55::setFort55All(const vector<string>& fort55Data_) {
  fort55All.clear();
  fort55All.reserve(fort55Data_.size());
  for (VStrCI vstrCI = fort55Data_.begin();
       vstrCI != fort55Data_.end(); ++vstrCI) {
    fort55All.push_back(F55Line(*vstrCI));
  }
}
void
SDAFort55::setProtein2(const PdbFileS1& protein2_){
  p2 = protein2_;
}
void
SDAFort55::setProtein1(const PdbFileS1& protein1_){
  p1 = protein1_;
}
// get
const PdbFileS1*
SDAFort55::getProtein1() const {
  return &p1;
}
const PdbFileS1*
SDAFort55::getProtein2() const {
  return &p2;
}
const vector<F55Line>*
SDAFort55::getFort55All() const {
  return &fort55All;
}
//
vector<int>
SDAFort55::getOccurancies() const {
// returns vector of occurancies form fort55 file  
  vector<int> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->occur);
  }
  return _res;    
}
vector<float>
SDAFort55::getElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elE);
  }
  return _res;
}
vector<float>
SDAFort55::getAvgElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->avgElE);
  }
  return _res;
}
vector<float>
SDAFort55::getElEDisp() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elEDisp);
  }
  return _res;
}
vector<float>
SDAFort55::getRmsds() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(p2.backbRmsd(recoverProtein(*vf55CI)));
  }
  return _res;
}

Uint
SDAFort55::getFort55LineNumber() const {
  return fort55All.size();
}

vector<float>
SDAFort55::makePairHalfMatrix(Uint complexNumber_) const {
  //test if there is some date to work on:-)
  assert(fort55All.size() > 1);
  //
  PdbFileS1 *_pA, *_pB, *_pNext;
  int _lines = getFort55LineNumber();
  // consider only specified number of complexes
  if (_lines > complexNumber_)
    _lines = complexNumber_;
  vector<float> _res;
  _res.reserve((_lines * _lines - _lines) / 2);
  _pA = new PdbFileS1(recoverProtein(fort55All[0]));
  // for each first protein in pair while building halfMatrix
  for (int i = 1; i < _lines; ++i){
    _pNext = new PdbFileS1(recoverProtein(fort55All[i]));
    _res.push_back(_pA->backbRmsd(*_pNext));
    // for each second protien in pair 
    for (int j = i + 1; j < _lines; ++j){
        _pB = new PdbFileS1(recoverProtein(fort55All[j]));
        _res.push_back(_pA->backbRmsd(*_pB));
        delete _pB;
    }
    *_pA = *_pNext; // now first protein becomes next
    delete _pNext;
  }
  delete _pA;
  return _res;
}




PdbFileS1
  SDAFort55::recoverProtein(const F55Line& f55Line_) const {
  // makes docked protein conformation based on p1 and p2 centers
  // and fort55 line
  Vector3 _thisCenter(f55Line_.center);
  // basis vectors: x and y from fort55, z crossproducted x y
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  // transforming vectors
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  // now get new coordinates
  PdbFileS1 _res = p2;
  // here we take out reference to PdbFileS1 data, and we'll
  // work on this reference this way changing the object itself 
  vector<PdbLineS1>& _resPdbLines = _res.accessPdbLines();
  // for each PdbLineS1 object in reference to vector of them
  for (vector<PdbLineS1>::iterator iterPL = _resPdbLines.begin();
       iterPL != _resPdbLines.end();
       ++iterPL) {
    // this groovy line makes the transformation in fact  
    iterPL->accessCoord() = 
            trVector(iterPL->accessCoord() -= p2Center,
                     _trx, _try, _trz) + p1Center +
                     _thisCenter;
  }
  return _res;
}

// private:
Vector3
SDAFort55::trVector(Vector3& origin_,
                    Vector3& basisx_,
                    Vector3& basisy_,
                    Vector3& basisz_) const {
  basisx_.normalize();
  basisy_.normalize();
  basisz_.normalize();
  return Vector3(origin_ * basisx_,
                 origin_ * basisy_,
                 origin_ * basisz_);
}



// class SDAFort552 ---------------------------------------------------
// constructor
SDAFort552::SDAFort552(const SDAFort552& sdaF55_) {
  p1        = *sdaF55_.getProtein1();
  p2        = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
  p1Center  = *sdaF55_.getP1Center();
  p2Center  = *sdaF55_.getP2Center();
}

// operator
SDAFort552&
SDAFort552::operator=(const SDAFort552& sdaF55_) {
  p1        = *sdaF55_.getProtein1();
  p2        = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
  p1Center  = *sdaF55_.getP1Center();
  p2Center  = *sdaF55_.getP2Center();
  return *this;
}
// set
void
SDAFort552::setFort55All(const char* fileName_, int lineNumb_) {
  fort55All.clear(); fort55All.reserve(lineNumb_);
  vector<string> _lines; _lines.reserve(lineNumb_);
  getFort55Lines(fileName_, _lines, lineNumb_);
  for (vector<string>::const_iterator cit = _lines.begin();
        cit != _lines.end(); ++cit) {
    fort55All.push_back(F55Line(*cit));     
  }
  p1Center = getCenter1FromFort55(fileName_);
  p2Center = getCenter2FromFort55(fileName_);
}

void
SDAFort552::setFort55All(const vector<string>& fort55Data_) {
  fort55All.clear();
  fort55All.reserve(fort55Data_.size());
  for (VStrCI vstrCI = fort55Data_.begin();
       vstrCI != fort55Data_.end(); ++vstrCI) {
    fort55All.push_back(F55Line(*vstrCI));
  }
}
void
SDAFort552::setProtein2(const vector<Vector3>& protein2_){
  p2 = protein2_;
}
void
SDAFort552::setProtein1(const vector<Vector3>& protein1_){
  p1 = protein1_;
}
void
SDAFort552::setCenter1(const Vector3& c_) {
  p1Center = c_;
}
void 
SDAFort552::setCenter2(const Vector3& c_) {
  p2Center = c_;
}
// access
vector<Vector3>& 
SDAFort552::accessProtein1() {
  return p1;
}

vector<Vector3>&
SDAFort552::accessProtein2() {
  return p2;
}
// get
const vector<Vector3>*
SDAFort552::getProtein1() const {
  return &p1;
}
const vector<Vector3>*
SDAFort552::getProtein2() const {
  return &p2;
}
const vector<F55Line>*
SDAFort552::getFort55All() const {
  return &fort55All;
}
const Vector3*
SDAFort552::getP1Center() const {
  return &p1Center;
}
const Vector3* 
SDAFort552::getP2Center() const {
  return &p2Center;
}
//
vector<int>
SDAFort552::getOccurancies() const {
// returns vector of occurancies form fort55 file  
  vector<int> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->occur);
  }
  return _res;    
}
vector<float>
SDAFort552::getElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elE);
  }
  return _res;
}
vector<float>
SDAFort552::getAvgElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->avgElE);
  }
  return _res;
}
vector<float>
SDAFort552::getElEDisp() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elEDisp);
  }
  return _res;
}
/*
vector<float>
SDAFort552::getRmsds() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(p2.backbRmsd(recoverProtein(*vf55CI)));
  }
  return _res;
}
*/

float
SDAFort552::getRmsd(const vector<Vector3>& pr_) const {
  return vector3Rmsd(p2, pr_);
}

Uint
SDAFort552::getFort55LineNumber() const {
  return fort55All.size();
}

vector<float>
SDAFort552::makePairHalfMatrix(Uint complexNumber_) const {
  //test if there is some data to work on:-)
  assert(fort55All.size() > 1);
  //
  int _lines = getFort55LineNumber();
  // consider only specified number of complexes
  if (_lines > complexNumber_)
    _lines = complexNumber_;
  vector<float> _res;
  _res.reserve((_lines * _lines - _lines) / 2);
  
  vector<Vector3> _pA; _pA.reserve(p2.size());
  recoverProtein(fort55All[0], _pA);
  // for each first protein in pair while building halfMatrix
  for (int i = 1; i < _lines; ++i){
    vector<Vector3> _pNext; _pNext.reserve(p2.size());
    recoverProtein(fort55All[i], _pNext);
    _res.push_back(vector3Rmsd(_pA, _pNext));
    // for each second protein in pair 
    for (int j = i + 1; j < _lines; ++j){
        vector<Vector3> _pB; _pB.reserve(p2.size());
        recoverProtein(fort55All[j], _pB);
        _res.push_back(vector3Rmsd(_pA, _pB));
        _pB.clear();
    }
    _pA = _pNext; // now first protein becomes next
    _pNext.clear();
  }
  _pA.clear();
  return _res;
}

/*
void
SDAFort55::makePairHalfMatrix(Uint complexNumber_, int& size_, float *res_) {
  //test if there is some date to work on:-)
  assert(fort55All.size() > 1);
  //
  int _lines = getFort55LineNumber();
  if (_lines > complexNumber_)
    _lines = complexNumber_;
  
  // get the size of half matrix
  assert(size_ == (_lines * _lines - _lines) / 2);
  
  float *_pA = new float[p2.size()];
  recoverProtein(fort55All[0], _pA, p2.size());
  for (int i = 1; i < _lines; ++i) {
    
  }

}

*/

void
SDAFort552::recoverProtein(const F55Line& f55Line_,
                          vector<Vector3>& pr_) const {
  // makes docked protein conformation based on p1 and p2 centers
  // and fort55 line
  Vector3 _thisCenter(f55Line_.center);
  // basis vectors: x and y from fort55, z crossproducted x y
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  // transforming vectors
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  // now get new coordinates
  pr_ = p2;
  // here we take out reference to PdbFileS1 data, and we'll
  // work on this reference this way changing the object itself 
  // for each PdbLineS1 object in reference to vector of them
  for (vector<Vector3>::iterator itV = pr_.begin();
       itV != pr_.end(); ++itV) {
    // this groovy line makes the transformation in fact    
    *itV = trVector(*itV -= p2Center,
                    _trx, _try, _trz) + p1Center + _thisCenter;
  }
}

/*
void
SDAFort552::recoverProtein(const F55Line& f55Line_, 
                           float* coord_, int size_) const {
  
  Vector3 _thisCenter(f55Line_.center);
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  
  for (vec                           
                           
}
*/

void
SDAFort552::recoverProtein(const F55Line& f55Line_,
                          vector<Vector3*>& pr_) const {
  // makes docked protein conformation based on p1 and p2 centers
  // and fort55 line
  Vector3 _thisCenter(f55Line_.center);
  // basis vectors: x and y from fort55, z crossproducted x y
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  // transforming vectors
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  
  // here we take out reference to PdbFileS1 data, and we'll
  // work on this reference this way changing the object itself 
  // for each PdbLineS1 object in reference to vector of them
  assert(p2.size() == pr_.size());
  vector<Vector3>::const_iterator citV;
  vector<Vector3*>::iterator itV;
  for (citV = p2.begin(), itV = pr_.begin(); 
       citV != p2.end(), itV != pr_.end();
        ++citV, ++itV) {
    // get new coord
    *(*itV) = *citV;
    // this groovy line makes the transformation in fact    
    *(*itV) = trVector(*(*itV) -= p2Center,
                    _trx, _try, _trz) + p1Center + _thisCenter;
  }
}

// private:
Vector3
SDAFort552::trVector(Vector3& origin_,
                     Vector3& basisx_,
                     Vector3& basisy_,
                     Vector3& basisz_) const {
  basisx_.normalize();
  basisy_.normalize();
  basisz_.normalize();
  return Vector3(origin_ * basisx_,
                 origin_ * basisy_,
                 origin_ * basisz_);
}



//===================================================================
// SDAFort55_S1
//===================================================================

const float SDAFort55_S1::_o100[] = {1.0f, 0.0f, 0.0f};
const float SDAFort55_S1::_o010[] = {0.0f, 1.0f, 0.0f};
const float SDAFort55_S1::_o001[] = {0.0f, 0.0f, 1.0f};


SDAFort55_S1::SDAFort55_S1() {
  p1 = 0;
  p1Size = 0;
  p2 = 0;
  p2Size = 0;
  fort55All = 0;
  fort55LineNumb = 0;
  p1Center[0] = 0.0f; p1Center[1] = 0.0f; p1Center[2] = 0.0f;
  p2Center[0] = 0.0f; p2Center[1] = 0.0f; p2Center[2] = 0.0f;
  rmsdHM = 0;
  hmSize = 0;
}

SDAFort55_S1::~SDAFort55_S1() {
  delete [] p1;
  delete [] p2;
  delete [] fort55All;
  delete [] rmsdHM;

}

void
SDAFort55_S1::setFort55All(const char* fileName_, int lineNumb_) {
  
  vector<string> _lines; _lines.reserve(lineNumb_);
  getFort55Lines(fileName_, _lines, lineNumb_);
  
  fort55LineNumb = _lines.size();
  fort55All = new float[fort55LineNumb][12];
  
  for (int i = 0; i < fort55LineNumb; ++i) {
    F55Line _f(_lines[i]);
    fort55All[i][0] = _f.center.x;
    fort55All[i][1] = _f.center.y;
    fort55All[i][2] = _f.center.z;
    fort55All[i][3] = _f.basisX.x;
    fort55All[i][4] = _f.basisX.y;
    fort55All[i][5] = _f.basisX.z;
    fort55All[i][6] = _f.basisY.x;
    fort55All[i][7] = _f.basisY.y;
    fort55All[i][8] = _f.basisY.z;
    
    //cross product
    fort55All[i][9]  = _f.basisX.y*_f.basisY.z - 
                       _f.basisX.z*_f.basisY.y; 
    fort55All[i][10] = _f.basisX.z*_f.basisY.x - 
                       _f.basisX.x*_f.basisY.z;
    fort55All[i][11] = _f.basisX.x*_f.basisY.y - 
                       _f.basisX.y*_f.basisY.x;
  }
    
  Vector3 _c1 = getCenter1FromFort55(fileName_);
  Vector3 _c2 =  getCenter2FromFort55(fileName_);
  p1Center[0] = _c1.x;
  p1Center[1] = _c1.y;
  p1Center[2] = _c1.z;
  p2Center[0] = _c2.x;
  p2Center[1] = _c2.y;
  p2Center[2] = _c2.z;
  
}

void
SDAFort55_S1::setProtein1(const vector<Vector3>& p1_) {
  p1Size = p1_.size()*3;
  p1 = new float[p1Size];
  int _n = 0;
  for(vector<Vector3>::const_iterator cit = p1_.begin();
      cit != p1_.end(); ++cit) {
    p1[_n] = cit->x;
    ++_n;
    p1[_n] = cit->y;
    ++_n;
    p1[_n] = cit->z;
    ++_n;
  }
}

void
SDAFort55_S1::setProtein2(const vector<Vector3>& p2_) {
  p2Size = p2_.size()*3;
  p2 = new float[p2Size];
  int _n = 0;
  for(vector<Vector3>::const_iterator cit = p2_.begin();
      cit != p2_.end(); ++cit) {
    p2[_n] = cit->x;
    ++_n;
    p2[_n] = cit->y;
    ++_n;
    p2[_n] = cit->z;
    ++_n;
  }
}

void
SDAFort55_S1::makePairHalfMatrix(int numb_) {
  // figure out how many orientations to use to build HM
  int _lines = fort55LineNumb;
  if (_lines > numb_)
    _lines = numb_;
  
   
  hmSize = (_lines * _lines - _lines) / 2;
  rmsdHM = new float[hmSize]; 
  
  // --- >
  // first p
  float* _pA = new float[p2Size];
  recoverProtein(0, _pA, p2Size);
  int _n = 0;
  
  for (int i = 1; i < _lines; ++i) {
   
    float* _pNext = new float[p2Size];
    recoverProtein(i, _pNext, p2Size);
    rmsdHM[_n] = getRmsd(_pA, _pNext);
    ++_n;
    
    for (int j = i + 1; j < _lines; ++j) {
      float* _pB = new float[p2Size];
      recoverProtein(j, _pB, p2Size);
      rmsdHM[_n] = getRmsd(_pA, _pB);
      ++_n;
      delete [] _pB;
    }
    
    delete [] _pA; // dangling for a while;-)
    _pA = _pNext;
  }
  
  delete [] _pA;
  // <---
  
}

float 
SDAFort55_S1::getRmsd(float* f1_, float* f2_) const {
  
  float res = 0.0f, dx, dy, dz;
  int n=0;
  
  for (int i = 0; i < p2Size;) {
    dx = f1_[i] - f2_[i]; ++i;
    dy = f1_[i] - f2_[i]; ++i;
    dz = f1_[i] - f2_[i]; ++i;   
    res += (dx*dx + dy*dy + dz*dz);
    ++n;
  }
  
  float _1overN = 1.0f / n;
  return sqrt(res * _1overN);
}

void
SDAFort55_S1::recoverProtein(int idx_, float* pr_, int prSize_) const {
  
  
  float _bX[3] = {fort55All[idx_][3], 
                  fort55All[idx_][4], 
                  fort55All[idx_][5]};
  float _bY[3] = {fort55All[idx_][6], 
                  fort55All[idx_][7], 
                  fort55All[idx_][8]};
  float _bZ[3] = {fort55All[idx_][9], 
                  fort55All[idx_][10], 
                  fort55All[idx_][11]};
  
  float trX[3], trY[3], trZ[3];
  
  trVector(_o100, _bX, _bY, _bZ, trX);
  trVector(_o010, _bX, _bY, _bZ, trY);
  trVector(_o001, _bX, _bY, _bZ, trZ);
  
  assert(p2Size == prSize_);
  for (int i = 0; i < prSize_;) {
    float _t[3];
    _t[0] = p2[i];++i;
    _t[1] = p2[i];++i;
    _t[2] = p2[i];++i;
    
    _t[0] -= p2Center[0];
    _t[1] -= p2Center[1];
    _t[2] -= p2Center[2];

    float _res[3];
    trVector(_t, trX, trY, trZ, _res);
    _res[0] += fort55All[idx_][0] + p1Center[0];
    _res[1] += fort55All[idx_][1] + p1Center[1];
    _res[2] += fort55All[idx_][2] + p1Center[2];
    
    pr_[i-3] = _res[0];
    pr_[i-2] = _res[1];
    pr_[i-1] = _res[2];
  }
                             
}

void 
SDAFort55_S1::trVector(const float* ori_, 
                       float* bX_, float* bY_, float* bZ_,
                       float* res_) const {
  normalize(bX_);
  normalize(bY_);
  normalize(bZ_);
  res_[0] = ori_[0]*bX_[0] + ori_[1]*bX_[1] + ori_[2]*bX_[2];
  res_[1] = ori_[0]*bY_[0] + ori_[1]*bY_[1] + ori_[2]*bY_[2];
  res_[2] = ori_[0]*bZ_[0] + ori_[1]*bZ_[1] + ori_[2]*bZ_[2]; 

}

void
SDAFort55_S1::normalize(float* v) const {
  float msqr = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  if (msqr > 0.00001f) {
    float _f = 1.0f /sqrt(msqr);
    v[0] *= _f;
    v[1] *= _f;
    v[2] *= _f;
  } else {
    cout << "W: division by 0 in normalization!" << endl;
  }
}
//===================================================================
//===================================================================

} // namespace libDM_sda

