//--------------------------------------------//
// configtemplate.h
//
// this is template definition macros
//
// -------------------------------------------//
#ifndef CONFIGTEMPLATE_H
#define CONFIGTEMPLATE_H

#ifdef __COMO__
	#define HAS_EXPORT
 	#undef NEED_TEMPLATE_DEFINITIONS
#endif

#if defined(__BORLANDC__) || defined(__GNUC__)
	#undef HAS_EXPORT
 	#define NEED_TEMPLATE_DEFINITIONS
#endif

#endif
