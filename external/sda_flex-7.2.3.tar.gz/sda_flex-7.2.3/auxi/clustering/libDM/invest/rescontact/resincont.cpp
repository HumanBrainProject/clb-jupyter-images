//-------------------------------------------------------------------
/*! \file resincont.h
    \brief Stuff for finding residues in contact.
    
    ResInCont class to find residues in contact in two proteins.
    
    by D.M. EML Research
    V0.2 2006.01.20
*/
//-------------------------------------------------------------------

#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <cassert>
#include <algorithm>

#include "resincont.h"
#include "protein.h"
#include "residue.h"
#include "vector3.h"
#include "constdata.h"

using namespace std;
//---instances--->
//---inlines--->
inline float dist(const Vector3& v1, const Vector3& v2){
  float dx = v1.x - v2.x;
  float dy = v1.y - v2.y;
  float dz = v1.z - v2.z;
  return sqrt(dx*dx + dy*dy + dz*dz);
}
//===class===>


void 
ResInCont::init(){
  for (int i = 0; i < AAARRAY; ++i){
    resCen2Edge[AAA[i]] = RESCEN2EDGE[i];   
  }
}

void 
ResInCont::findResCont(const float contDist_,
                       const int definition_,
                       const float add_) {
// this one finds residue which are in contact, that is have at least
// two atoms withing distance contDist_
  intResP1.clear();
  intResP2.clear();
  for (vector<Chain>::iterator 
       iCh1 = p1->accessChains().begin();
       iCh1 != p1->accessChains().end(); ++iCh1) {
    for (vector<Chain>::iterator 
         iCh2 = p2->accessChains().begin();
         iCh2 != p2->accessChains().end(); ++iCh2) {          
      for (vector<Residue>::iterator 
           iRe1 = iCh1->accessResidues().begin();
           iRe1 !=iCh1->accessResidues().end(); ++iRe1) {
        for (vector<Residue>::iterator
             iRe2 = iCh2->accessResidues().begin();
             iRe2 !=iCh2->accessResidues().end(); ++iRe2) {       
          // are two residue centers reasonably close?
           if (areCenClose(*iRe1, *iRe2, contDist_, add_)) {
            // are these residues in contact?
            if (isContact(*iRe1, *iRe2, contDist_, definition_))
              updateContact(*iRe1, *iRe2);
           }
        } // residues 2
      } // residues 1
    } // chains 2
  } // chains 1
}

bool 
ResInCont::areCenClose(Residue& r1_, Residue& r2_,
                       float contDist_, float add_) {
  // checks if geometric centers of two residues are reasonably close so that
  // the residues may have a contact?
  // add_ adjust to some value to make sure tha all res which 
  // are potentially close 
  // are include for instance in encounter complex probably 
  // more then 1 is better
//  if (!r1_.isProtResidue()) {
//    cerr << "WARNING: " << r1_.getName()
//         << " residue is unknown and will "
//            "not be considered for contact calculation\n"; 
//    return false;
//  }
//  if (!r2_.isProtResidue()) {
//    cerr << "WARNING: " << r2_.getName()
//         << " residue is unknown and will "
//            "not be considered for contact calculation\n";
//    return false;
//  }
  if (!r1_.isProtResidue() || !r2_.isProtResidue())  
    return false;
  if (dist(r1_.getCenter(), r2_.getCenter()) <
     (resCen2Edge[r1_.getName()] + 
      resCen2Edge[r2_.getName()] +
      contDist_ + add_) ) {
    return true;
  }
  return false;
}

bool
ResInCont::isContact(const Residue& r1_, 
                     const Residue& r2_,
                     float contact_,
                     int   definition_) const {
  switch(definition_) {
    /*! uses loaded trimmed residues differently.
        isContact5() -> used then both residues are trimmed
        isContact6() -> then one of the residues is trimmed
        isContact1() -> then residues are NOT trimmed 
    */
    case 6:
      if (isTrimmedRes(r1_) && isTrimmedRes(r2_)) {
        return isContact5(r1_, r2_, contact_); 
      }
      else if (isTrimmedRes(r1_)) {
        return isContact6(r1_, r2_, contact_); 
      }
      else if (isTrimmedRes(r2_)) {
        return isContact6(r2_, r1_, contact_); 
      }
      else {
        return isContact1(r1_, r2_, contact_);
      }
    /*! excluded residues are not used in contact calculation and
        backbone atoms are not considered as well
    */
    case 5:
      if (isExcludedRes(r1_) || isExcludedRes(r2_)) {
        return false;
      }
      return isContact2(r1_, r2_, contact_);
    /*! excluded residues are not considered for contact calculation 
        simple contact calculation is done for the rest
    */
    case 4:
      if (isExcludedRes(r1_) || isExcludedRes(r2_)) {
        return false;
      }
      return isContact1(r1_, r2_, contact_);
    /*! residues are in contact if CB'as or CA of GLY are in contact */
    case 3:
      return isContact3(r1_, r2_, contact_);
    /*! backbone atoms of the residues are excluded, therefore no GLY
        residues are considered.
    */
    case 2:
      return isContact2(r1_, r2_, contact_);
    /*! All residues are treated the same way */
    case 1:
      return isContact1(r1_, r2_, contact_);
    default:
       cerr << "ERROR: ResInCont:: " 
               "there is no such contact definition: "
            << definition_ << endl;
       exit(0);
  }
}

void 
ResInCont::loadTrimmedRes(const vector<string>& trimmedRes_) {
        trimmedRes = trimmedRes_;
}
void 
ResInCont::loadExcludedRes(const vector<string>& exclRes_) {
        excludedRes = exclRes_;
}


bool 
ResInCont::isTrimmedRes(const Residue& r_) const {
  if (trimmedRes.empty()) {
    cerr << "WARNING: no trimmed residues loaded?\n";
    return false;
  }
  if (find(trimmedRes.begin(), 
           trimmedRes.end(), r_.getName()) != trimmedRes.end()) {
    return true;
  }
  return false;
}

bool 
ResInCont::isExcludedRes(const Residue& r_) const {
  if (excludedRes.empty()) {
    cerr << "WARNING: no residues loaded to exclude?\n";
    return false;
  }
  if (find(excludedRes.begin(),
           excludedRes.end(), r_.getName()) != excludedRes.end()) {
    return true;
  }
  return false;
}

const vector<const Residue*>& 
ResInCont::getIntResP1() const {
  return intResP1;
}
const vector<const Residue*>&
ResInCont::getIntResP2() const {
  return intResP2;
}

void 
ResInCont::updateContact(const Residue& r1_, const Residue& r2_) {
// updates vectors of residues which are in contact if not yet found before
  if (find(intResP1.begin(), intResP1.end(), &r1_) == intResP1.end()){
    intResP1.push_back(&r1_);
  }
  if (find(intResP2.begin(), intResP2.end(), &r2_) == intResP2.end()){
    intResP2.push_back(&r2_);
  }
}

bool 
ResInCont::isContact1(const Residue& r1_, const Residue& r2_,
                      float contDist_) const {
  // searches if there is any atom pair between
  // residues within R2RCONT distance
  for (vector<Atom>::const_iterator citA1 = r1_.getAtoms().begin();
       citA1 != r1_.getAtoms().end(); ++citA1) {
    for (vector<Atom>::const_iterator citA2 = r2_.getAtoms().begin();
         citA2 != r2_.getAtoms().end(); ++citA2) {
      if (dist(citA1->getCoord(), citA2->getCoord()) <= contDist_)
        return true;
    }
  }
  return false;
}

bool 
ResInCont::isContact2(const Residue& r1_, 
                      const Residue& r2_,
                      float contDist_) const {
  // another contact definition excluding backbone
  // note NO GLY INCLUDED THEREFORE
  if (r1_.getName() == "GLY" || r2_.getName() == "GLY")
                return false;
  for (vector<Atom>::const_iterator citA1 = r1_.getAtoms().begin();
       citA1 != r1_.getAtoms().end(); ++citA1) {
    if (citA1->getName() != BACKBONEATOMS[0] &&
        citA1->getName() != BACKBONEATOMS[1] &&
        citA1->getName() != BACKBONEATOMS[2] &&
        citA1->getName() != BACKBONEATOMS[3] ) {        
      for (vector<Atom>::const_iterator citA2 = r2_.getAtoms().begin();
         citA2 != r2_.getAtoms().end(); ++citA2) {
        if (citA2->getName() != BACKBONEATOMS[0] &&
            citA2->getName() != BACKBONEATOMS[1] &&
            citA2->getName() != BACKBONEATOMS[2] &&
            citA2->getName() != BACKBONEATOMS[3] ) {
          if (dist(citA1->getCoord(), citA2->getCoord())
              <= contDist_)
            return true;
          } // 2n residue atom check for backbone
        } // 2nd residue atoms
      } // 1s residue atom check for backbone
  } // 1st residue atoms
  return false;
}


bool 
ResInCont::isContact3(const Residue& r1_, 
                      const Residue& r2_, 
                      float contDist_) const {
// contact definition for only CB'as (CA for GLY)
  const Atom *a1_ = 0 , *a2_ = 0;
  if (r1_.getName() == GLY){
    a1_ = &r1_.getAtom("CA");
    if (a1_ == 0) {
      cerr << "WARNING: this is GLY but has no CA atom?\n";
      return false;
    }
  } else {
    a1_ = &r1_.getAtom("CB");
    if (a1_ == 0) {
      cerr << "WARNING: this residue has no CB atom?\n";
      return false;
    }
  }
  if (r2_.getName() == GLY){
    a2_ = &r2_.getAtom("CA");
    if (a2_ == 0) {
      cerr << "WARNING: this is GLY but has no CA atom?\n";
      return false;
    }
  } else {
    a2_ = &r2_.getAtom("CB");
    if (a2_ == 0) {
      cerr << "WARNING: this residue has no CB atom?\n";
      return false;
    }
  }
  if (dist(a1_->getCoord(), a2_->getCoord()) <= contDist_)
    return true;
  return false;
}


/*! This is then both residues are trimmed only backbone atoms
    and CB will be considered, for both reisudes
*/
bool 
ResInCont::isContact5(const Residue& r1Tr_, 
                      const Residue& r2Tr_, 
                      float contDist_) const {
  for (vector<Atom>::const_iterator citA1 = r1Tr_.getAtoms().begin();
       citA1 != r1Tr_.getAtoms().end(); ++citA1) {
    if (citA1->getName() == BACKBONEATOMS[0] ||
        citA1->getName() == BACKBONEATOMS[1] ||
        citA1->getName() == BACKBONEATOMS[2] ||
        citA1->getName() == BACKBONEATOMS[3] ||
        citA1->getName() == PROTATOMS[2]       ) {        
      for (vector<Atom>::const_iterator citA2 = r2Tr_.getAtoms().begin();
         citA2 != r2Tr_.getAtoms().end(); ++citA2) {
        if (citA2->getName() == BACKBONEATOMS[0] ||
            citA2->getName() == BACKBONEATOMS[1] ||
            citA2->getName() == BACKBONEATOMS[2] ||
            citA2->getName() == BACKBONEATOMS[3] ||
            citA2->getName() == PROTATOMS[2]       ) {
          if (dist(citA1->getCoord(), citA2->getCoord()) <= contDist_)
            return true;
          } // 2n residue atom check for backbone
        } // 2nd residue atoms
      } // 1s residue atom check for backbone
  } // 1st residue atoms
  return false;               
}                       
                      

/*! This is then one residue is trimmed only backbone atoms
    and CB will be considered, for this reisude, firts argument
*/
bool 
ResInCont::isContact6(const Residue& r1Tr_, 
                      const Residue& r2_, 
                      float contDist_) const {
  for (vector<Atom>::const_iterator citA1 = r1Tr_.getAtoms().begin();
       citA1 != r1Tr_.getAtoms().end(); ++citA1) {
    if (citA1->getName() == BACKBONEATOMS[0] ||
        citA1->getName() == BACKBONEATOMS[1] ||
        citA1->getName() == BACKBONEATOMS[2] ||
        citA1->getName() == BACKBONEATOMS[3] ||
        citA1->getName() == PROTATOMS[2]       ) {        
      for (vector<Atom>::const_iterator citA2 = r2_.getAtoms().begin();
         citA2 != r2_.getAtoms().end(); ++citA2) {
        if (dist(citA1->getCoord(), citA2->getCoord())
              <= contDist_)
            return true;
      } // 2nd residue atoms
    } // 1s residue atom check for backbone
  } // 1st residue atoms
  return false;               
}                       
     





/*
ResiduesInContact::ResiduesInContact(Protein& p1_in, Protein& p2_in){
	p1 = p1_in;
	p2 = p2_in;
	init();
}

void ResiduesInContact::init(){
	for (int i = 0; i < AAARRAY; ++i){
		resCen2Edge[AAA[i]] = RESCEN2EDGE[i];	
	}
}
void ResiduesInContact::who(){
	cout << "INFO: class ResiduesInContact" << endl;
}
//---methods--->
// load
void ResiduesInContact::loadExcludedRes(vector<string>& vs_){
	excludedRes = vs_;
}
void ResiduesInContact::loadTrimmedRes(vector<string>& vs_){
	trimmedRes = vs_;
}
void ResiduesInContact::findResCont(const float contact_,
				    const int definition_,
				    const int add_){
// this one finds residue which are in contact, that is have at least
// two atoms withing distance R2RCONT as defined in constdata.h
	//cout << "CONTACT: " << contact_ << endl;
	for (iterVR1 = p1.residues.begin();
	     iterVR1 !=p1.residues.end();
	     ++iterVR1){
		for (iterVR2 = p2.residues.begin();
		     iterVR2 !=p2.residues.end();
		     ++iterVR2){
		     	// are two residue centers reasonably close?
			if (areCenClose(*iterVR1, *iterVR2, contact_, add_)){
				// are these residues in contact?
				if (isContact(*iterVR1, *iterVR2,
						contact_, definition_)){
					updateContact(*iterVR1, *iterVR2);
				}
			}
		}
	}
}
bool ResiduesInContact::areCenClose(Residue& r1_, Residue& r2_,
		const float contact_, const int add_){
// checks if geometric centers of two residues are reasonably close so that
// the residues may have a contact?
// add_ adjust to some value to make sure tha all res which are potentially close
// 	are include for instance in encounter complex probably more then 1 is better
	
	if (!r1_.isCommonResidue()){
		cerr << "WARNING: " << r1_.resName
		     << " residue is unknown and will \
		     not be considered for contacts." << endl; 
		return false;
	}
	if (!r2_.isCommonResidue()){
		cerr << "WARNING: " << r2_.resName
		     << " residue is unknown and will \
		     not be considered for contacts." << endl;
		return false;
	}
	if (dist(*(r1_.getCenter()), *(r2_.getCenter())) <
	   (resCen2Edge[r1_.resName] + resCen2Edge[r2_.resName] +
	   	contact_ + add_)){
		return true;
	}
	return false;
}
bool ResiduesInContact::isContact(Residue& r1_, Residue& r2_,
		const float contact_,
		const int   definition_){
// residue residue contact definitions:
// 1. any two atoms of two residue are within specified distance
// 2. any tow atoms, EXCEPT backbone (therefor GLY) within some distance
// 3. specified distance between CB'as of two res (CA for GLY)
		switch(definition_){
			case 6:
	// this one uses treats trimmed residues differently, that is
	// it takes into account only atoms up to CB for trimmed residues
				if (isTrimmedRes(r1_) || isTrimmedRes(r2_))
					return isContact6(r1_, r2_, contact_);
				return isContact1(r1_, r2_, contact_);
			case 5:
	// as case 2 but specified residues are excluded
				if (areExcludedRes(r1_, r2_))
					return false;
				return isContact2(r1_, r2_, contact_);
			case 4:
	// as case 1 but specified residues are excluded
				if (areExcludedRes(r1_, r2_))
					return false;
				return isContact1(r1_, r2_, contact_);
			case 3:
	// residues are in contact if CB'as (CA for GLY) are within contact_
				return isContact3(r1_, r2_, contact_);
			case 2:
	// as case 1 but backbone atoms (and therefore GLY) are excluded
				return isContact2(r1_, r2_, contact_);
			case 1:
	// residues are in contact if at least two atom are within contact_
				return isContact1(r1_, r2_, contact_);
			default:
				cout << "ResiduesinContact::"
				     << "isContact you should not be here"
		     		     << endl;
				assert(0);
		}
}

bool ResiduesInContact::isContact6(Residue& r1_, Residue& r2_, const float contact_) const{
	vector<Atom>::const_iterator citerVA1, citerVA2;
	for (citerVA1 = r1_.atoms.begin();
	     citerVA1 !=r1_.atoms.end();
	     ++citerVA1){
		if (citerVA1->atom == BACKBONEATOMS[0] ||
		    citerVA1->atom == BACKBONEATOMS[1] ||
		    citerVA1->atom == BACKBONEATOMS[2] ||
		    citerVA1->atom == BACKBONEATOMS[3] ||
		    citerVA1->atom == PROTATOMS[2]	){
			for (citerVA2 = r2_.atoms.begin();
			     citerVA2 !=r2_.atoms.end();
			     ++citerVA2){
			     	if (citerVA2->atom == BACKBONEATOMS[0] ||
				    citerVA2->atom == BACKBONEATOMS[1] ||
				    citerVA2->atom == BACKBONEATOMS[2] ||
				    citerVA2->atom == BACKBONEATOMS[3] ||
				    citerVA2->atom == PROTATOMS[2]	){
				    	if (dist(citerVA1->coor,
					         citerVA2->coor) <= contact_)
						 	return true;
				}
			}
		}
	}
	return false;
}
bool ResiduesInContact::isContact1(Residue& r1_, Residue& r2_,
		const float contact_){
// searches if there is any atom pair between residues within R2RCONT distance
	//cout << "using 1st definition" << endl;
	for (iterVA1 = r1_.atoms.begin();
	     iterVA1 !=r1_.atoms.end();
	     ++iterVA1){
		for (iterVA2 = r2_.atoms.begin();
		     iterVA2 !=r2_.atoms.end();
		     ++iterVA2){
			if (dist(iterVA1->coor, iterVA2->coor) <= contact_)
				return true;
		}
	}
	return false;
}
bool ResiduesInContact::isContact2(Residue& r1_, Residue& r2_,
		const float contact_){
// another contact definition excluding backbone
// note NO GLY INCLUDED THEREFORE
	//cout << "using 2nd definition" << endl;
	if (r1_.resName == "GLY" || r2_.resName == "GLY")
		return false;
	for (iterVA1 = r1_.atoms.begin();
	     iterVA1 !=r1_.atoms.end();
	     ++iterVA1){
	     	if (iterVA1->atom != BACKBONEATOMS[0] &&
		    iterVA1->atom != BACKBONEATOMS[1] &&
		    iterVA1->atom != BACKBONEATOMS[2] &&
		    iterVA1->atom != BACKBONEATOMS[3] ){
			for (iterVA2 = r2_.atoms.begin();
			     iterVA2 !=r2_.atoms.end();
			     ++iterVA2){
				if (iterVA2->atom != BACKBONEATOMS[0] &&
				    iterVA2->atom != BACKBONEATOMS[1] &&
				    iterVA2->atom != BACKBONEATOMS[2] &&
				    iterVA2->atom != BACKBONEATOMS[3]){
					if (dist(iterVA1->coor, iterVA2->coor)
							<= contact_)
						return true;
				}
			}
		}
	}
	return false;
}
bool ResiduesInContact::isContact3(Residue& r1_, Residue& r2_, 
				const float contact_){
// contact definition for only CB'as (CA for GLY)
	const Vector3* _coor1, * _coor2;
	if (r1_.resName == GLY){
		_coor1 = &((r1_.getAtom("CA"))->coor);
	} else {
		_coor1 = &((r1_.getAtom("CB"))->coor);
	}
	if (r2_.resName == GLY){
		_coor2 = &((r2_.getAtom("CA"))->coor);
	} else {
		_coor2 = &((r2_.getAtom("CB"))->coor);
	}
	if (dist(*_coor1, *_coor2) <= contact_)
		return true;
	return false;
}
bool ResiduesInContact::areExcludedRes(Residue& r1_, Residue& r2_){
	if (excludedRes.empty()){
		cout << "WARNING: no residues loaded to exclude!" << endl;
		return false;
	}
	vector<string>::const_iterator citerVS;
	for (citerVS = excludedRes.begin();
	     citerVS !=excludedRes.end();
	     ++citerVS){
		if (r1_.resName == *citerVS ||
		    r2_.resName == *citerVS)
		    	return true;
	}
	return false;
}
bool ResiduesInContact::isTrimmedRes(Residue& r_) const{
	if (find(trimmedRes.begin(), trimmedRes.end(), r_.resName) != trimmedRes.end())
		return true;
	return false;
}
void ResiduesInContact::updateContact(Residue& r1_, Residue& r2_){
// updates vectors of residues which are in contact if not yet found before
	if (find(intResP1.begin(), intResP1.end(), &r1_) == intResP1.end()){
		intResP1.push_back(&r1_);
	}
	if (find(intResP2.begin(), intResP2.end(), &r2_) == intResP2.end()){
		intResP2.push_back(&r2_);
	}
}

//===class===/
*/
