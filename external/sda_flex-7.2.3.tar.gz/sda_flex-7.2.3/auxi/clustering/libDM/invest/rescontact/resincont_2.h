//-------------------------------------------------------------------
/*! \file resincont_2.h
    \brief Stuff for finding residues in contact.
    
    ResInCont class to find residues in contact in two proteins.
    
    by D.M. EML Research
    V0.2 2006.01.20
*/
//-------------------------------------------------------------------

#ifndef RESINCONT_H_2
#define RESINCONT_H_2


#include <vector>
#include <string>
#include <map>

#include "protein_2.h"

namespace libDM_invest {

using libDM_molecule::Protein;
using libDM_molecule::Residue;



/*! \brief Finds residues in contact.

    This class should be used to find residues which are in contact.
    It uses pointers to Protein objects, and work on them to find which
    residues are in contact. Note pointers are not const since 
    geometric center of residues in Protein object is calculated. 
    Residues found to be in contact are soted as vector of const
    pointers to Residue objects, namely intResP1 and intResP2. 
    Trimmed or/and excluded residues may be loaded, they are used in 
    some specific types of contact calculations (see func descriptions)
    HOWTO: e.g.
      ResInCont ric;
      ric.setProteins(p1, p2);
      ric.loadTrimmedRes(trimmedRes);
      ric.loadExcludedRes(excludedRes);
      ric.findResCont(5.0f, 1);  
*/
class ResInCont {
  public:
    ResInCont(const Protein& p1_, const Protein& p2_);
        
    /*! this is the main foo to find residues in contact.
        contDist_ -> contact distance in A
        definition_ -> type of distance calculation see below
        add_ -> this is added to residue 1 to residue 2 center
          to center distance calculation. First distance between
          residue centers is calculated, so that to see if it is
          reasonable to try to find contacts between these residues
          in the first place, and if center to center distance is
          smaller then standard distances ('resCen2Edge') plus 'add_'
          only then all atoms of these residues are used to check 
          for a contact, so this 'add_' just to be sure that no
          residue is missed just a backup:-)
    */
    void findResCont(float dist_, int def_ = 1, float add_ = 1.0f);     
    
    
    
    /*! this foo is used to load trimmed residues, these residues
        (if loaded) are treated in special way in some contact calculation
        types.
        vector is filled with 3 letter residue names
    */
//    void loadTrimmedRes(const vector<string>& trimmedRes_);
//    void addTrimmedRes(const string& trimmedRes_) 
//                      {trimmedRes.push_back(trimmedRes_);}
    /*! this foo is used to load excluded residues, these residues
        (if loaded) are treated in special way in some contact calculation
        types.
        vector is filled with 3 letter residue names
    */ 
//    void loadExcludedRes(const vector<string>& excludedRes_);
//    void addExcludedRes(const string& excludedRes_)
//                       {excludedRes.push_back(excludedRes_);}
//    bool isExcludedRes(const Residue& r_) const;
//    bool isTrimmedRes(const  Residue& r_) const;
  
    const vector<const Residue*>& getIntResP1() const;
    const vector<const Residue*>& getIntResP2() const;
  private:
    /*! this one is called automatically upon object construction
        it load distances from residue center to furthest atom 
        for all common 20 residues (stored in file constdata.h)
    */
//   void init();
    
    /*! checks if center to center distance in these two residues
       are less then 'contDist_' + 'add_'. Note residue object 
       references are not const since they might need to calculate
       geometric center coordinates for themselfs.
    */   
//    bool areCenClose(Residue& r1_, 
//                     Residue& r2_, 
//                     float contDist_, 
//                     float add_);
                     
    /*! this is top foo for contact calculation it calls specific 
       foo based on 'definition_' value
       constDist_ -> real number in A for distance of contac
       definition_ -> which contact definition to use, see below
    */                 
    bool isContact(const Residue& r1_, const Residue& r2_, 
                   float dis_ =5.0, int def_ = 1) const;
    
    /*! simply runs over all atoms of residue 'r1_' and 'r2_' and
        check if they are as close as 'contDist_'
    */
    bool isContact1(const Residue& r1_, const Residue& r2_, 
                    float dist_) const;
    
    /*! runs over all atoms of residue 'r1_' and 'r2_' EXCLUDING
        backbone atoms (N, C, O, CA) and checks if they are as 
        close as 'contDist_'
        since backbone atoms are not considered, GLY residue
        is not considered.
    */
//    bool isContact2(const Residue& r1_, 
//                    const Residue& r2_, float contDist_) const;
    /*! uses only CB and (CA atom for GLY) to to calculate if 
        they are as close as 'contDist_'
    */
//    bool isContact3(const Residue& r1_, 
//                    const Residue& r2_, float contDist_) const;
    /*! for both 'r1Tr_' and 'r2Tr_' only backbone atoms plus CB
        are considered in contact calculation, are they ads close
        as 'contDist_'
    */
//    bool isContact5(const Residue& r1Tr_, 
//                    const Residue& r2Tr_, float contDist_) const;            
    /*! for 'r1Tr_' residue only backbone atoms plus CB are used
        and for 'r2_' all atoms are used in contact calculatio, 
        are they as close as 'contDist_' ?
    */
//    bool isContact6(const Residue& r1Tr_,
//                    const Residue& r2_,   float contDist_) const;
                   
    /*! if contact is found 
        pointer to 'r1_' is pushed back to intResP1
        pointer to 'r2_' is pushed back to intResP2
    */
    void updateContact(const Residue& r1_, const Residue& r2_);
    
    /*! these are pointers to Protein objects. residues in contac are
        searched in these proteins, so these objects must be alive 
        somewhere while this clas is alive:-)))
        Note pointers are not const since residues in those proteins
        may need to calculate geometric centers for themselfs.
    */
    const Protein* p1;
    const Protein* p2;
    /*! these vectors store pointers to residues which were found to
        be in complex. Make sure you don't kill Proteins where these
        residues live:-))
    */
    vector<const Residue*> intResP1;
    vector<const Residue*> intResP2;
    /*! distances from geometric center of standard residue to furthers
        atom is stored in this map, these are loaded upon object 
        constructions form constdata.h file.
        string -> is 3 letter residue code.
    */
//    map<string, float> resCen2Edge;
    /*! names of trimmed residues are stored here if you load them*/
//    vector<string> trimmedRes;
    /*! names of residues are stored here if you load them */
//    vector<string> excludedRes;
};

} // namespace libDM_invest


#endif



