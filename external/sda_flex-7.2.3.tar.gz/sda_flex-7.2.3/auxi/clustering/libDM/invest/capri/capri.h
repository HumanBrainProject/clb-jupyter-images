//*******************************************************************
//-------------------------------------------------------------------
/*! \file capri.h

*/

#ifndef CAPRI_H
#define CAPRI_H

#include "pdbfile_2.h"

class AmberTopFile;
class AmberCrdFile;
namespace libDM_capri {

using libDM_molecule::PdbResidueId;
using libDM_molecule::PdbFile;
using libDM_molecule::PdbLine;

// 1 -------------------------------------------------------------->
/*! gets vector of pair objects, in pair the first is a PdbResidueId of
    protein 1 and second in pair is a PdbResidueId of protein 2
    these residues have at least one atom within distance dist_
*/
void getResiduesInContact(const PdbFile& pdbFile1_,
                          const PdbFile& pdbFile2_,
        vector<pair<PdbResidueId, PdbResidueId> >& resInCont_, float dist_);

// 2 --------------------------------------------------------------->
/*! make a vector of PdbLine of those residues which are in res_ 
*/
void makeInterfacePdbLines(
       const vector<pair<PdbResidueId, PdbResidueId> >& res_,
       const PdbFile& pf1_, const PdbFile& pf2_,
       vector<PdbLine>& pdbLinesP1_, vector<PdbLine>& pdbLinesP2_);
 
// 3 --------------------------------------------------------------->
/*! get percentage of native contacts in docked vs. bound structure */     
float getNatCont(const vector<pair<PdbResidueId, PdbResidueId> >& crB_,
                 const vector<pair<PdbResidueId, PdbResidueId> >& crU_);
       
// 4 --------------------------------------------------------------->
/*! get capri evaluation*/
char getCapriEval(float nc_, float rmsdFull_, float rmsdIner_);

// 5 --------------------------------------------------------------->
/*! checks if all residues in vector<pair<, > > appear in PdbFile
    objects p1_ and p2_, this can be used to check if there are 
    residues missmatches in say bound and unbound structure
*/
vector<pair<PdbResidueId, PdbResidueId> >
checkResidueMissmatch(
     const vector<pair<PdbResidueId, PdbResidueId> >& resInCont_, 
     const PdbFile& p1_, 
     const PdbFile& p2_);
     
// 6 --------------------------------------------------------------->
/*! Makes a PdbFile object from AmberTopFile and AmberCrdFile objects  
*/
void makePdbFile(AmberTopFile& top_, AmberCrdFile& crd_, PdbFile& pdbFile_);

} // namespace libDM_capri

#endif

//-------------------------------------------------------------------
//*******************************************************************




