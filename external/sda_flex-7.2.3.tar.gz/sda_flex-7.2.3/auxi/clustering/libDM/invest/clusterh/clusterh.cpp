//____________________________________________________________________
//
// class Cluster, class Group, class ClusterEngine implementation
//____________________________________________________________________

#include <iostream>
#include <string>
#include <cassert>
#include <iomanip>
#include <algorithm>
#include <cmath>

#include "clusterh.h"

using namespace std;
inline bool isNan(float x){
	return x != x;
}
//____________________________________________________________________
//******************* Cluster ****************************************
// DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB 
void Cluster::who() const{
	cout << "class Cluster " << endl;
}
void Cluster::printValues() const{
	vector<int>::const_iterator citerI;
	for (citerI = members.begin();
	     citerI !=members.end();
	     ++citerI){
	     	cout << *citerI << " ";
	}
}
void Cluster::visualizeMe() const{
	for (int i = 0; i < members.size(); ++i){
		cout << "=";
	}
	cout << endl;
}
// CONSTRUCT CONSTRUCT CONSTRUCT CONSTRUCT CONSTRUCT CONSTRUCT
Cluster::Cluster(int _i){
	members.push_back(_i);
}
Cluster::Cluster(vector<int> members_){
	members = members_;
}
// GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET
int Cluster::getMemberNum() const{
	return members.size();
}
const vector<int>* Cluster::getMembers() const{
	return &members;
}

// IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS IS
bool Cluster::isEmpty() const{
	if (members.size() == 0)
		return true;
	return false;
}
// OPERATOR OPERATOR OPERATOR OPERATOR OPERATOR OPERATOR OPERATOR  
Cluster Cluster::operator+(const Cluster& cl_) const{
	vector<int> _res = this->members;
	vector<int>::const_iterator citerI;
	for (citerI = cl_.members.begin();
	     citerI !=cl_.members.end();
	     ++citerI){
		_res.push_back(*citerI);
	}
	return	Cluster(_res);
}
//____________________________________________________________________
//****************** Group *******************************************
// GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET
const Cluster* Group::getCl1() const {
	return cl1;
}
const Cluster* Group::getCl2() const {
	return cl2;
}
float Group::getVal() const{
	return val;
}
// DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO
//____________________________________________________________________
//****************** ClusterEngine ***********************************
// DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB DB
void ClusterEngine::who() const{
	cout << "class ClusterEngine " << endl;
}
void ClusterEngine::printCurrentGroups() const{
	vector<Group>::const_iterator citerG;
	for (citerG = groups.begin();
	     citerG !=groups.end();
	     ++citerG){
	     	cout << "Cl1: " << citerG->getCl1() << " "
		     << "Cl2: " << citerG->getCl2() << " "
		     << "Val: " << citerG->getVal() << endl;
	}
}
void ClusterEngine::printCurrentClustersAddVal() const{
	vector<Cluster>::const_iterator citerC;
	for (citerC = clusters.begin();
	     citerC !=clusters.end();
	     ++citerC){
		cout << &(*citerC) << " ";
		vector<int>::const_iterator citerI;
		for (citerI = (citerC->getMembers())->begin();
		     citerI !=(citerC->getMembers())->end();
		     ++citerI){
		     	cout << *citerI << " ";
		}
		cout << endl;
	}
}
void ClusterEngine::printInitMatrix() const{
	vector<Group>::const_iterator citerG;
	assert(iniGroups.size() == (n * n - n) / 2);
	int _i1 = 1, _i2 = 2, _it = 0;
	for (citerG = iniGroups.begin();
	     citerG !=iniGroups.end();
	     ++citerG){
	     	if (_i2 == n){
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << citerG->getVal() << "\t";
			cout << endl;
			++_i1;
			_i2 = _i1 + 1;
		}
		else{
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << citerG->getVal() << "\t";
			++_i2;
		}

	}
}
void ClusterEngine::printInitMatrixAddress() const{
	vector<Group>::const_iterator citerG;
	assert(iniGroups.size() == (n * n - n) / 2);
	int _i1 = 1, _i2 = 2, _it = 0;
	for (citerG = iniGroups.begin();
	     citerG !=iniGroups.end();
	     ++citerG){
	     	if (_i2 == n){
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << &(*citerG) << "\t";
			cout << endl;
			++_i1;
			_i2 = _i1 + 1;
		}
		else{
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << &(*citerG) << "\t";
			++_i2;
		}

	}
}
void ClusterEngine::printCurrentMatrix() const{
	cout << "------ Group's values ------>" << endl;
	vector<Group>::const_iterator citerG;
	int _n = clusters.size();
	assert(groups.size() == (_n * _n - _n) / 2);
	int _i1 = 1, _i2 = 2, _it = 0;
	for (citerG = groups.begin();
	     citerG !=groups.end();
	     ++citerG){
	     	if (_i2 == _n){
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << citerG->getVal() << "\t";
			cout << endl;
			++_i1;
			_i2 = _i1 + 1;
		}else{
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << citerG->getVal() << "\t";
			++_i2;
		}
	}
	cout << "====== Group's values ======>" << endl;
}
void ClusterEngine::printCurrentMatrixAddress() const{
	cout << "------ Group's addresses ------>";
	vector<Group>::const_iterator citerG;
	int _n = clusters.size();
	assert(groups.size() == (_n * _n - _n) / 2);
	int _i1 = 1, _i2 = 2, _it = 0;
	for (citerG = groups.begin();
	     citerG !=groups.end();
	     ++citerG){
	     	if (_i2 == _n){
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << &(*citerG) << "\t";
			cout << endl;
			++_i1;
			_i2 = _i1 + 1;
		}else{
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "=" << &(*citerG) << "\t";
			++_i2;
		}
	}
	cout << "------ Group's addresses ------>" << endl;
}
void ClusterEngine::printCurrentMatrixClustersAddresses() const{
	cout << "------ Cluster's addresses in groups ------>" << endl;
	vector<Group>::const_iterator citerG;
	int _n = clusters.size();
	assert(groups.size() == (_n * _n - _n) / 2);
	int _i1 = 1, _i2 = 2, _it = 0;
	for (citerG = groups.begin();
	     citerG !=groups.end();
	     ++citerG){
	     	if (_i2 == _n){
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "= (" << citerG->getCl1()
			     << ", "  << citerG->getCl2() << ")" << "\t";
			cout << endl;
			++_i1;
			_i2 = _i1 + 1;
		}else{
			cout << "[" << _i1 << "," << _i2 << "]";
			cout << "= (" << citerG->getCl1()
			     << ", "  << citerG->getCl2() << ")" << "\t";
			++_i2;
		}
	}
	cout << "====== Cluster's addresses in groups ======>" << endl;
}
void ClusterEngine::printCycleInfo() const{
	vector<Cycle>::const_iterator citerCy;
	cout << setw(4) << "cyNo"    << " "
	     << setw(4) << "clNo"    << " "
	     << setw(8) << "avgSp"   << " "
	     << setw(8) << "avgSpN"  << " "
	     << setw(8) << "penalty" << " "
	     << setw(8) << "thresh"  << endl;
	for (citerCy = cycles.begin();
	     citerCy !=cycles.end();
	     ++citerCy){
	     	cout << setw(4) << citerCy->id          << " "
		     << setw(4) << citerCy->clNum       << " ";
		cout.setf(ios::right, ios::adjustfield);
		cout.setf(ios::fixed, ios::floatfield);
		cout << setprecision(3)
		     << setw(8) << citerCy->avgSp 	<< " "
		     << setw(8) << citerCy->avgSpNorm 	<< " "
		     << setw(8) << citerCy->penalty 	<< " "
		     << setw(8) << citerCy->thresh	<< endl;
	}
}

void ClusterEngine::printCycleInfo(const Cycle* cy_) const{
	cout << setw(4) << "cyNo"    << " "
	     << setw(4) << "clNo"    << " "
	     << setw(8) << "avgSp"   << " "
	     << setw(8) << "avgSpN"  << " "
	     << setw(8) << "penalty" << " "
	     << setw(8) << "thresh"  << endl;
     	cout << setw(4) << cy_->id          << " "
	     << setw(4) << cy_->clNum       << " ";
	cout.setf(ios::right, ios::adjustfield);
	cout.setf(ios::fixed, ios::floatfield);
	cout << setprecision(3)
	     << setw(8) << cy_->avgSp 		<< " "
	     << setw(8) << cy_->avgSpNorm 	<< " "
	     << setw(8) << cy_->penalty 	<< " "
	     << setw(8) << cy_->thresh		<< endl;
}

void ClusterEngine::printCycleLook(const Cycle* cy_) const{
	cout << endl;
	vector<Cluster>::const_iterator citerC;
	int _n = 0;
	for (citerC = cy_->clusters.begin();
	     citerC !=cy_->clusters.end();
	     ++citerC){
	     	cout << endl;
		_n = 0;
		while(_n < citerC->getMemberNum()){
			cout << "=";
			++_n;
		}
	}
	cout << endl;
}

// INIT INIT INIT INIT INIT INIT INIT INIT INIT INIT INIT INIT INIT
void ClusterEngine::initClusters(int i_){
// push_back s i_ number of clusters
	n = i_;
	++i_;
	for (int i = 1; i < i_; ++i){
		clusters.push_back(Cluster(i));
	}
}
void ClusterEngine::initGroups(const vector<float>& matrix_){
// constructs initial "matrix" of group it actually just puts
// each item of precalculated matrix into Group object, puts
// pointers of specific clusters to this group and adds this
// group to initGropus and groups vector.
	vector<float>::const_iterator citerF;
	int _tmp1 = 0, _tmp2 = 1;
	for (citerF = matrix_.begin();
	     citerF !=matrix_.end();
	     ++citerF){
		if (_tmp2 == n){
			++_tmp1;
			_tmp2 = _tmp1 + 1;
			iniGroups.push_back(Group(&clusters[_tmp1],
					       &clusters[_tmp2], *citerF));
			++_tmp2;
		} else {
			iniGroups.push_back(Group(&clusters[_tmp1],
					       &clusters[_tmp2], *citerF));
			++_tmp2;
		}
	}
	groups = iniGroups;
}
// GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET
float ClusterEngine::getInitGroupVal(const int* i1_, const int* i2_) const{
// this finds an initial group holding distance between initial
// clusters i1_ and i2_
// x(i, j) = ( SUM(n=1: n<i){N-i} ) + (j - i - 1), then i < j
	unsigned int _i1, _i2, _index = 0;
	if (*i1_ < *i2_){
		_i1 = *i1_;
		_i2 = *i2_;
	} else if (*i1_ > *i2_){
		_i1 = *i2_;
		_i2 = *i1_;
	} else {
		//cout << "ERROR: No point to call "
		//     << "this for the same clusters" << endl;
		//exit(1);
		return 0.0f;
	}
	for (int i = 1; i <  _i1; ++i){
		_index += (n - i);
	}
	return (iniGroups[_index + (_i2-_i1 - 1)]).getVal();
}
int ClusterEngine::groupNum() const{
	return groups.size();
}
int ClusterEngine::clusterNum() const{
	return clusters.size();
}
const ClusterEngine::Cycle* ClusterEngine::getBestCycle() const{
// finds cycle with smallest penalty and returns its clusters
	float _penalty = 9999.9f;
	const Cycle* _res;
	vector<Cycle>::const_iterator citerCy;
	for (citerCy = cycles.begin();
	     citerCy !=cycles.end();
	     ++citerCy){
		if (citerCy->penalty < _penalty){
			_penalty = citerCy->penalty;
			_res = &(*citerCy);
		}
	}
	return _res;
}
const ClusterEngine::Cycle* ClusterEngine::getThatCycle(float thresh_) const{

	float _dif = 99.9f;
	const Cycle* _res;
	vector<Cycle>::const_iterator citerCy;
	for (citerCy = cycles.begin();
	     citerCy !=cycles.end();
	     ++citerCy){
	       	if (fabs(citerCy->thresh - thresh_) < _dif){
			_dif = fabs(citerCy->thresh - thresh_);
			_res = &(*citerCy);
		}
	}
	return _res;
}

vector<int> ClusterEngine::getRepresentatives(const vector<Cluster>* clusters_) const{
// this returns vector of ints where int are indexes of complexes which
// are the representatives of clusters, representative is this structure
// which is closest to all other structures in the cluster
	vector<Cluster>::const_iterator citerC;
	vector<int>::const_iterator citerI1;
	vector<int>::const_iterator citerI2;
	vector<int> _res;
	const vector<int>* _members;
	// foreach cluster
	for (citerC = clusters_->begin();
	     citerC !=clusters_->end();
	     ++citerC){
	     	_members = citerC->getMembers();
		float _val = 9999.9f;
		int _id  = 0;
		// for each member of cluster
		for (citerI1 = _members->begin();
		     citerI1 !=_members->end();
		     ++citerI1){
			float _sum = 0;
		     	for (citerI2 = _members->begin();
			     citerI2 !=_members->end();
			     ++citerI2){
				_sum +=
				getInitGroupVal(&(*citerI1), &(*citerI2));
			}
			if (_sum < _val){
				_id = *citerI1;
				_val = _sum;
			}
		}
		_res.push_back(_id);
	}
	return _res;
}
// DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO DO
const Group* ClusterEngine::findClosest() {
// finds group with smallest distance
	float _val = 9999.0f;
	const Group* _res;
	vector<Group>::const_iterator citerG;
	for (citerG = groups.begin();
	     citerG !=groups.end();
	     ++citerG){
		if (citerG->getVal() < _val){
			_val = citerG->getVal();
			_res = &(*citerG);
		}
	}
	// add this cycle
	addCycle(_val);
	return _res;
}
void ClusterEngine::mergeClusters(const Group* group_){
// merges clusters of the grou_ and updates clusters member
	Cluster _newCluster = (*group_->getCl1() + *group_->getCl2());
	vector<Cluster> _res;
	_res.reserve(clusters.size()-1);
	for (vector<Cluster>::const_iterator citerC = clusters.begin();
	     citerC != clusters.end();     ++citerC){
		if (&(*citerC) != group_->getCl1() &&
		    &(*citerC) != group_->getCl2())
		    	_res.push_back(*citerC);
	}
	_res.push_back(_newCluster);
	clusters = _res;
	groups.clear();
}
void ClusterEngine::recalculateGroups(unsigned int distType_){
// recalculates distance matrix after chnging some clusters
	assert(groups.size() == 0);
	vector<Group> _res;
	_res.reserve((clusters.size() * clusters.size() - clusters.size()) / 2);
	vector<Cluster>::const_iterator citerC1;
	vector<Cluster>::const_iterator citerC2;
	for (citerC1 = clusters.begin();
	     citerC1 !=(clusters.end()-1);
	     ++citerC1){
	  	   for (citerC2 = citerC1 + 1;
		        citerC2 !=clusters.end();
			++citerC2){
				groups.push_back(
				Group(&(*citerC1), &(*citerC2),
				getDist(&(*citerC1), &(*citerC2), distType_)) );
		}

	}
}
float ClusterEngine::getDist(const Cluster* cl1_, const Cluster* cl2_, unsigned int dT_){
// returns intercluster distance based on required method
	switch(dT_){
		case 1:
		// distAverageLinkage
			return distAverageLinkage(cl1_, cl2_);
		default:
			cout << "no such distance calculation" << endl;
			exit(1);
	}
}

void ClusterEngine::addCycle(float val_){
	Cycle _res;
	_res.id = cycles.size();
	_res.clNum = clusters.size();
	_res.thresh = val_;
	_res.clusters = clusters;
	cycles.push_back(_res);
}
void ClusterEngine::makeSpread(){

	vector<Cycle>::iterator iter;
	vector<Cluster>::const_iterator citerC;
	vector<int>::const_iterator citerI1, citerI2;
	// foreach Cycle
	for (iter = cycles.begin();
	     iter != cycles.end(); 	
	     ++iter){
	float _spreadSum = 0.0f;
	// foreach Cluster
	for (citerC = iter->clusters.begin();
	     citerC !=iter->clusters.end();     ++citerC){
	       	float _spread = 0.0f;
	     	for (citerI1 = (citerC->getMembers())->begin();
		     citerI1 !=(citerC->getMembers())->end();
		     ++citerI1){
		     	for (citerI2 = citerI1 + 1;
			     citerI2 !=(citerC->getMembers())->end();
			     ++citerI2){
		     		_spread += getInitGroupVal(&(*citerI1), &(*citerI2));
			}
		}
		_spread = _spread / (citerC->getMemberNum() * (citerC->getMemberNum() - 1)
			  * 0.5);
		if (isNan(_spread))
			_spread = 0.0f;
		_spreadSum += _spread;
	}
	float _1overN = 1.0f / iter->clusters.size();
	iter->avgSp = _spreadSum * _1overN;
	}
}
void ClusterEngine::normalizeAvgSp(){
// calculates normalized average spread
	float _minAvgSp = 9999.9f , _maxAvgSp = -9999.9f;
	vector<Cycle>::const_iterator citerCy;
	// first find max and min average spread
	for (citerCy = cycles.begin();
	     citerCy !=cycles.end();
	     ++citerCy){
	     	if (citerCy->avgSp > _maxAvgSp){
			_maxAvgSp = citerCy->avgSp;
		}
		if (citerCy->avgSp < _minAvgSp){
			_minAvgSp = citerCy->avgSp;
		}
	}
	vector<Cycle>::iterator iterCy;
	for (iterCy = cycles.begin();
	     iterCy !=cycles.end();
	     ++iterCy){
	     	float _1overN = 1.0f / (_maxAvgSp - _minAvgSp);
		iterCy->avgSpNorm =
		((n - 2) * _1overN) * (iterCy->avgSp - _minAvgSp) + 1;
	}
}
void ClusterEngine::calcPenalties(){
	vector<Cycle>::iterator iterCy;
	for (iterCy = cycles.begin();
	     iterCy !=cycles.end();
	     ++iterCy){
	     	iterCy->penalty = iterCy->clNum + iterCy->avgSpNorm;
	}
}

float ClusterEngine::distAverageLinkage
		(const Cluster* cl1_, const Cluster* cl2_) const{
// unweighted avertade linkage type inter cluster distance calculation
	vector<int>::const_iterator citerI1, citerI2;
	float _res = 0.0f;
	int _tmp = 0;
	for (citerI1 = cl1_->getMembers()->begin();
	     citerI1 !=cl1_->getMembers()->end();
	     ++citerI1){
		for (citerI2 = cl2_->getMembers()->begin();
		     citerI2 !=cl2_->getMembers()->end();
		     ++citerI2){
			++_tmp;
			_res += getInitGroupVal(&(*citerI1), &(*citerI2));
		}
	}
	float _1overN = 1.0f / _tmp;
	return (_res * _1overN);
}
float ClusterEngine::distSingleLinkage(
		const Cluster* cl1_, const Cluster* cl2_) const{
// single linkage type inter cluster distance calculation
	vector<int>::const_iterator citerI1, citerI2;
	float _res = 9999.9f;
	for (citerI1 = cl1_->getMembers()->begin();
	     citerI1 !=cl1_->getMembers()->end();
	     ++citerI1){
		for (citerI2 = cl2_->getMembers()->begin();
		     citerI2 !=cl2_->getMembers()->end();
		     ++citerI2){
			if (getInitGroupVal(&(*citerI1), &(*citerI2)) < _res)
				_res = getInitGroupVal(&(*citerI1), &(*citerI2));
		}
	}
	return _res;
}
float ClusterEngine::distCompleteLinkage(
		const Cluster* cl1_, const Cluster* cl2_) const{
// single linkage type inter cluster distance calculation
	vector<int>::const_iterator citerI1, citerI2;
	float _res = -9999.9f;
	for (citerI1 = cl1_->getMembers()->begin();
	     citerI1 !=cl1_->getMembers()->end();
	     ++citerI1){
		for (citerI2 = cl2_->getMembers()->begin();
		     citerI2 !=cl2_->getMembers()->end();
		     ++citerI2){
			if (getInitGroupVal(&(*citerI1), &(*citerI2)) > _res)
				_res = getInitGroupVal(&(*citerI1), &(*citerI2));
		}
	}
	return _res;
}
//____________________________________________________________________
// END END END END END END END END END END END END END END END END END
//



