//-------------------------------------------------------------------
/*! \file clush.cpp

*/
// Implementation of :
// class Cluster, class Group, class Cycle, class ClusterEngine
// class ClusterInvest
//
//
// by D.M. EML Reserach
// V0.1
//-------------------------------------------------------------------

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <cassert>
#include <cmath>
#include <algorithm>

#include "clush.h"
#include "mymath.h"

using namespace std;

// class Cluster -----------------------------------------------------
// constructor
Cluster::Cluster(int num_) {
  members.push_back(num_);
}
Cluster::Cluster(vector<int> nums_) {
  members = nums_;
}
Cluster::Cluster(const Cluster& clust_) {
  members = *clust_.getMembers();
}
Cluster::Cluster(Reader& reader_) {
  unsigned int _st;
  reader_ >> _st;
  members.reserve(_st);
  int _tmp = 0;
  for (unsigned int i = 0; i < _st; ++i) {
    reader_ >> _tmp;
    members.push_back(_tmp);
  }
}
// operator
Cluster&
Cluster::operator= (const Cluster& clust_) {
  members = *clust_.getMembers();
  return *this;
}
Cluster
Cluster::operator+ (const Cluster& clust_) const {
  vector<int> _res = this->members;

  for (vector<int>::const_iterator citerI = clust_.members.begin();
       citerI !=clust_.members.end();
       ++citerI) {
    _res.push_back(*citerI);
  }
  return Cluster(_res);
}
bool
Cluster::operator==(const Cluster& clust_) const {
  if (members == *clust_.getMembers())
    return true;
  return false;
}
bool 
Cluster::operator<(const Cluster& clust_) const {
  if (members.size() == clust_.getMembers()->size()) {
    if (*members.begin() < *clust_.getMembers()->begin()) 
      return true;
    return false;
  }
  if (members.size() <  clust_.getMembers()->size())
    return true;
    
  return false;
}
//return the average distance of the given member (num_) to all other
//cluster members
float Cluster::getAvgDistance(const ClusterInvest* clInv, int num_,const vector<int>& occ_) const {
	long double sumsq = (long double)0.0f;
	long double sum = (long double)0.0f;
	long double sumf = (long double)0.0f;
	int n = 0;
//        cout << "\n#" <<num_ << "=====================================\n";
	for (vector<int>::const_iterator citerI = members.begin();
	   citerI != members.end(); ++citerI) {
//       if (num_ == *citerI) continue;
       sumsq +=(long double)clInv->getDistBetweenComplexes(num_,*citerI)*
    		   (long double)clInv->getDistBetweenComplexes(num_,*citerI)*
    		   occ_[*citerI-1];
       sum += (long double)clInv->getDistBetweenComplexes(num_,*citerI)*
    		   occ_[*citerI-1];
       sumf+= (long double)occ_[*citerI-1];
//       cout << "\tcluster "<<*citerI<<" dist: "<<clInv->getDistBetweenComplexes(num_,*citerI)<<" occur: "<<occ_[*citerI-1]<<"\n";
       n++;
	}
//       cout << "#"<<num_<<"\tSum Sq (num):"<< sumsq << "\n";
	long double dist = 0;
	if (n>0) dist = sum/((long double)sumf);
//        cout << "\tTot Occ:"<<sumf<<"\n";
//        cout << "\tAvg:"<<sqrt(dist)<<"\n\n";
	return dist;
}

float Cluster::getStdOfCluster(const ClusterInvest* clInv, int num_,const vector<int>& occ_) const {
  long double _res = 0.0f;
  long long _sum  = 0;
  long long _size = 0;
  long double mean = getAvgDistance(clInv,num_,occ_);
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
//       if (num_ == *citerI) continue;
      _res += (long double)occ_[*citerI-1]*(((long double)clInv->getDistBetweenComplexes(num_,*citerI) -mean) * 
              ((long double) clInv->getDistBetweenComplexes(num_,*citerI)-mean));
      _sum += (long long)occ_[*citerI - 1];
  }
  return sqrt(_res/((long double)_sum));
}

float Cluster::getMaxDist(const ClusterInvest* clInv, int num_,const vector<int>& occ_) const {
  long double dist = 0.0f;
  long double _res = 0.0f;
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
      _res = (long double)clInv->getDistBetweenComplexes(num_,*citerI);
      if (_res > dist) dist = _res;
  }
  return dist;
}   

std::string Cluster::getDetails(
		const vector<float>& ele_,
		const vector<int>& occ_,
		const vector<float>& eleAv,
		const vector<float>& eLj,
		const vector<float>& rmsd,
		const ClusterInvest* clInv, int num_) const {
	char *tmp = new char[100];

    std::string s("");
	Uint _sizee = ele_.size();
	Uint _sizeo = occ_.size();
	s += "#No\tE\tOCCUR\ttElE\tLjE\tRMSD\tdist_to_rep\n";
	for (vector<int>::const_iterator citerI = members.begin();
	   citerI != members.end(); ++citerI) {
	   std::sprintf(tmp, "%d", *citerI);
       s += tmp;
       s += "\t";
       std::sprintf(tmp, "%f", ele_[*citerI-1]);
       s += tmp;
       s += "\t";
       std::sprintf(tmp, "%d", occ_[*citerI-1]);
       s += tmp;
       s += "\t";
       std::sprintf(tmp, "%f", eleAv[*citerI-1]);
       s += tmp;
       s += "\t";
       std::sprintf(tmp, "%f", eLj[*citerI-1]);
       s += tmp;
       s += "\t";
       std::sprintf(tmp, "%f", rmsd[*citerI-1]);
       s += tmp;
       s += "\t";
       std::sprintf(tmp, "%f", clInv->getDistBetweenComplexes(*citerI,num_));
       s += tmp;
       s += "\n";
	}
    s += "\n\n\t";
	for (vector<int>::const_iterator citerI = members.begin();
			   citerI != members.end(); ++citerI) {
		s+="'";
		std::sprintf(tmp,"%d",*citerI);
		s+=tmp,
	    s+="'\t";
    }
	s+="\n";
	for (vector<int>::const_iterator citerI = members.begin();
			   citerI != members.end(); ++citerI) {
		s+="'";
		std::sprintf(tmp,"%d",*citerI);
		s+=tmp;
		s+="'\t";
		for (vector<int>::const_iterator citerI2 = members.begin();
			   citerI2 != members.end(); ++ citerI2) {
	  		  if (*citerI==*citerI2) {
	  			  std::sprintf(tmp,"%f",0.0f);
	  			  s+=tmp;
	  			  s+="\t";
	  		  } else {
                  std::sprintf(tmp,"%f",clInv->getDistBetweenComplexes(*citerI,*citerI2));
                  s+=tmp;
                  s+="\t";
	  		  }
		}
		s+="\n";
    }
	s+="\n";
    return s;
}


// get
float
Cluster::getPropAvg(const vector<float>& prop_) const {
  long _size = prop_.size();
  vector<long double> _res;
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
    assert(*citerI <= _size);
    _res.push_back(prop_[*citerI - 1]);
  }
  return libDM_math::average(&_res);
}
float
Cluster::getPropStdDeviation(const vector<float>& prop_) const {
  long long _size = prop_.size();
  vector<float> _res;
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
    assert(*citerI <= _size);
    _res.push_back(prop_[*citerI - 1]);
  }
  return libDM_math::stdDeviation(&_res);
}
float
Cluster::getFPropAvg(const vector<float>& prop_,
                     const vector<int>& freq_) const {
  long double _res = 0.0f;
  long long _sum  = 0;
  long long _size = prop_.size();
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
    assert(*citerI <= _size);
    if (freq_[*citerI - 1] != 0) {
      _res += (prop_[*citerI - 1] * freq_[*citerI - 1]);
      _sum += freq_[*citerI - 1];     
    }
    else {
      _res += prop_[*citerI - 1];
      ++_sum;
    }
  }
  long double _1over = ((long double)1.0f) / _sum;
  return _res * _1over;
}
float
Cluster::getFPropStdDeviation(const vector<float>& prop_,
                     const vector<int>& freq_) const {
  long double _res = 0.0f;
  long long _sum  = 0;
  long long _size = prop_.size();
  long double mean = getFPropAvg(prop_,freq_);
/*  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
    assert(*citerI <= _size);
      _sum += (long long) freq_[*citerI - 1];
  }
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
      _res += ((long double)prop_[*citerI - 1] *  (long long)freq_[*citerI - 1])*((long double)prop_[*citerI - 1] *  (long long)freq_[*citerI - 1]);
      _sum += (long long)freq_[*citerI - 1];
  }
*/
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
      _res += (long double)freq_[*citerI-1]*(((long double)prop_[*citerI - 1] -mean) * ((long double)prop_[*citerI - 1] -mean));
      _sum += (long long)freq_[*citerI - 1];
  }
  return sqrt(_res/((long double)_sum));
}

Uint
Cluster::getPropSum(const vector<int>& prop_) const {
  Uint _res = 0;
  Uint _size = prop_.size();
  for (vector<int>::const_iterator citerI = members.begin();
       citerI != members.end(); ++citerI) {
    assert(*citerI <= _size);
    _res += prop_[*citerI - 1];
  }
  return _res;
}
unsigned int
Cluster::getSize() const {
  return static_cast<unsigned int>(members.size());
}
const vector<int>*
Cluster::getMembers() const {
  return &members;
}
//
void
Cluster::storageWrite(Writer& writer_) {
  unsigned int _st = members.size();
  writer_ << _st;
  for (vector<int>::iterator citerI = members.begin();
       citerI != members.end();
       ++citerI) {
     writer_ << *citerI;
   }
}

// class Group -------------------------------------------------------
// constructor
Group::Group(const Group& group_) {
  cl1 = group_.getCluster1();
  cl2 = group_.getCluster2();
  val = group_.getVal();
}
// operator
Group&
Group::operator= (const Group& group_) {
  cl1 = group_.getCluster1();
  cl2 = group_.getCluster2();
  val = group_.getVal();
  return *this;
}
// get
float
Group::getVal() const {
  return val;
}
const Cluster*
Group::getCluster1() const {
  return cl1;
}
const Cluster*
Group::getCluster2() const {
  return cl2;
}
// class Cycle -------------------------------------------------------
// constructor
Cycle::Cycle(const Cycle& cycle_) {
  id          = cycle_.getId();
  thresh      = cycle_.getThresh();
  clusters    = *cycle_.getClusters();
}
Cycle::Cycle(Reader& reader_) {
  reader_ >> id;
  reader_ >> thresh;
  unsigned int _st;
  reader_ >> _st;
  clusters.reserve(_st);
  for (unsigned int i = 0; i < _st; ++i) {
    Cluster* _cl = new Cluster(reader_);
    clusters.push_back(*_cl);
    delete _cl;
  }
}
// operator
Cycle&
Cycle::operator=(const Cycle& cycle_) {
  id          = cycle_.getId();
  thresh      = cycle_.getThresh();
  clusters    = *cycle_.getClusters();
  return *this;
}
bool
Cycle::operator==(const Cycle& cycle_) const {
  if (id == cycle_.getId() &&
      thresh == cycle_.getThresh() &&
      clusters == *cycle_.getClusters())
    return true;
  return false;
}
// set
void
Cycle::setId(unsigned int cycleNum_) {
  id = cycleNum_;
}
void
Cycle::setThresh(float val_) {
  thresh = val_;
}
void
Cycle::setClusters(const vector<Cluster>& clusters_) {
  clusters = clusters_;
}
//get
int
Cycle::getId() const {
  return id;
}
unsigned int
Cycle::getClusterNumb() const {
  return clusters.size();
}
float
Cycle::getThresh() const {
  return thresh;
}
const vector<Cluster>*
Cycle::getClusters() const {
  return &clusters;
}
std::string Cycle::distanceBetweenClusters(const ClusterInvest* clInv) const {
	std::stringstream oss;
	vector<int> repI = clInv->getClustReprList(this);
    oss << "\nDistance between the chosen representatives of the clusters listed:\n\n";
	oss << "\t";
	for (vector<int>::const_iterator i = repI.begin();
			i != repI.end();++i) {
		oss << "complex_";
		oss << *i ;
		oss << "\t";
	}
	oss << "\n";
	for (vector<int>::const_iterator i = repI.begin();
			i != repI.end();++i) {
		oss << "complex_";
		oss << *i ;
		oss << "\t";
	   	for (vector<int>::const_iterator j = repI.begin();
			j != repI.end();++j) {
	   		oss << clInv->getDistBetweenComplexes(*i,*j);
	   		oss <<"\t";
	    }
	   	oss << "\n";
	}
    return oss.str();
}
//
void
Cycle::storageWrite(Writer& writer_) {
  writer_ << id;
  writer_ << thresh;
  unsigned int _st = clusters.size();
  writer_ << _st;
  for (vector<Cluster>::iterator iterC = clusters.begin();
       iterC != clusters.end();
       ++iterC) {
    iterC->storageWrite(writer_);
  }
}
void
Cycle::sortClusters() {
  sort(clusters.begin(), clusters.end());
  reverse(clusters.begin(), clusters.end());
}
// class ClusterEngine -----------------------------------------------
// constructor
ClusterEngine::ClusterEngine(const ClusterEngine& clustEng_) {
  clusters   = *clustEng_.getClusters();
  groups     = *clustEng_.getGroups();
  initGroups = *clustEng_.getInitGroups();
  cycles     = *clustEng_.getCycles();
}
// operator
ClusterEngine&
ClusterEngine::operator=(const ClusterEngine& clustEng_) {
  clusters   = *clustEng_.getClusters();
  groups     = *clustEng_.getGroups();
  initGroups = *clustEng_.getInitGroups();
  cycles     = *clustEng_.getCycles();
  return *this;
}
// set
void
ClusterEngine::setClusters(int num_){
  proteinNumb = num_;
  clusters.reserve(num_);
  ++num_;
  for (int i = 1; i < num_; ++i){
    clusters.push_back(Cluster(i));
  }
}
// Puts each item of halfMatrix_ into Group object,
// puts pointers of specific clusters to this group
// and adds this group to initGroups and groups
void
ClusterEngine::setGroups(const vector<float>& halfMatrix_) {
  vector<float>::const_iterator citerF;
  int _tmp1 = 0, _tmp2 = 1;
  initGroups.reserve(halfMatrix_.size());
  for (citerF = halfMatrix_.begin();
       citerF !=halfMatrix_.end();
       ++citerF){
    // if true meens that all i are set, so set all i+1
    if (_tmp2 == clusters.size()){
      ++_tmp1;
      _tmp2 = _tmp1 + 1;
      initGroups.push_back(Group(&clusters[_tmp1],
                                &clusters[_tmp2], *citerF));
      ++_tmp2;
    } else {
      initGroups.push_back(Group(&clusters[_tmp1],
                                &clusters[_tmp2], *citerF));
      ++_tmp2;
    }
  }
  groups = initGroups;
}
// get
const vector<Cluster>*
ClusterEngine::getClusters() const {
  return &clusters;
}
const vector<Group>*
ClusterEngine::getGroups() const {
  return &groups;
}
const vector<Group>*
ClusterEngine::getInitGroups() const {
  return &initGroups;
}
const vector<Cycle>*
ClusterEngine::getCycles() const {
  return &cycles;
}
unsigned int
ClusterEngine::getProteinNumb() const {
  return proteinNumb;
}
unsigned int
ClusterEngine::getClusterNumb() const {
  return clusters.size();
}
void
ClusterEngine::runClusteringCycle(unsigned int distType_) {
  // first i merges next closest clusters
  mergeClusters(findClosest());
  // then recalculates new group
  recalculateGroups(distType_);
  // one cycle of clustering is done, now we have clusters -1 cycles +1
}
void
ClusterEngine::storeClusteringData(Writer& writer_) {
  writer_ << proteinNumb;
  unsigned int _st = cycles.size();
  writer_ << _st;
  // stores all cycles
  for (vector<Cycle>::iterator iterC = cycles.begin();
       iterC != cycles.end();
       ++iterC) {
    iterC->storageWrite(writer_);
  }
  _st = initGroups.size();
  writer_ << _st;
  // sotres initail groups that is half matrix of distances between
  // data points basically
  for (vector<Group>::iterator iterG = initGroups.begin();
       iterG != initGroups.end();
       ++iterG) {
    float _tmp = iterG->getVal();
    writer_ << _tmp;
  } 
}
// private:
// finds Group with the closest clusters
// !!! wach out this adds a cycle at the end
const Group*
ClusterEngine::findClosest() {
  float _val = 9999.0f;
  const Group* _res;
  vector<Group>::const_iterator citerG;
  for (citerG = groups.begin();
       citerG !=groups.end();
       ++citerG){
    if (citerG->getVal() < _val){
      _val = citerG->getVal();
      _res = &(*citerG);
    }
  }
  // add this cycle to the vector
  addCycle(_val);
  return _res;
}
// merges clusters of the group and updates cluster members
void
ClusterEngine::mergeClusters(const Group* group_){
  Cluster _newCluster = (*group_->getCluster1() +
                         *group_->getCluster2());
  vector<Cluster> _res;
  _res.reserve(clusters.size()-1);
  for (vector<Cluster>::const_iterator citerC = clusters.begin();
       citerC != clusters.end();
       ++citerC) {
    // if true meens that this cluster is merge and will not exist further
    // therefore if true goes to another for loop
    if (&(*citerC) != group_->getCluster1() &&
        &(*citerC) != group_->getCluster2())
      _res.push_back(*citerC);
  }
  // add new cluster at the end:-)
  _res.push_back(_newCluster);
  clusters = _res;
  // !!! group ceared therefor you need to recalculate groups!!!
  groups.clear();
}
// recalculates distance matrix after changing some clusters
void
ClusterEngine::recalculateGroups(unsigned int distType_) {
  // check if groups member is really empty, which is normaly the 
  // case after mergeClusters method was used
  assert(groups.size() == 0);
  vector<Group> _res;
  _res.reserve((clusters.size() * clusters.size() - clusters.size()) / 2);
  // this is basically rebuilding half matrix (groups) after some clustering
  // cycle
  // for each cluster until second to last
  for (vector<Cluster>::const_iterator citerC1 = clusters.begin();
       citerC1 != (clusters.end()-1);
       ++citerC1){
    // for each cluster1+1 to last
    for (vector<Cluster>::const_iterator citerC2 = citerC1 + 1;
         citerC2 !=clusters.end();
         ++citerC2){
      _res.push_back(Group(&(*citerC1), &(*citerC2),
                       getDist(*citerC1, *citerC2, distType_)) );
    }
  }
  groups = _res;
}
// stores the info about current cycle
void
ClusterEngine::addCycle(float distVal_) {
  Cycle _res;
  _res.setId(cycles.size());
  _res.setThresh(distVal_);
  _res.setClusters(clusters);
  cycles.push_back(_res);
}
// returns intercluster distance based on required method
float
ClusterEngine::getDist(const Cluster& clu1_, const Cluster& clu2_,
                       unsigned int distType_) const {
  switch(distType_){
    case 1:
 //      return distAverageLinkage(clu1_, clu2_);
//      return distMaxLinkage(clu1_,clu2_);
//      return distMinLinkage(clu1_,clu2_);
        return distQuadraticLinkage(clu1_, clu2_);
    default:
      cout << "ERROR: no such distance calculation" << endl;
      exit(1);
  }
}
// finds an initail group holding distance between initial
// clusters i1_ and i2_
// x(i, j) = ( SUM(n=1: n<i){N-i} ) + (j - i - 1), then i < j
float
ClusterEngine::getInitGroupVal(const int* iCluster1_,
                               const int* iCluster2_) const {
  int _i1, _i2, _index = 0;
  if (proteinNumb < 2) {
	  return 0.0f;
  }
  if (*iCluster1_ < *iCluster2_){
    _i1 = (*iCluster1_)-1;
    _i2 = (*iCluster2_)-1;
  } else if (*iCluster1_ > *iCluster2_){
    _i1 = (*iCluster2_)-1;
    _i2 = (*iCluster1_)-1;
  } else {
    cout << "ERROR: No point to call "
         << "this for the same clusters" << endl;
    exit(1);
    return 0.0f;
  }
//  for (int i = 1; i <  _i1; ++i) {
//    _index += (proteinNumb - i);
//  }
//  cout << "index: " << _index << "\t";
  // all comparisions
 _index = (proteinNumb*(proteinNumb-1)/2)-((proteinNumb-_i1-1)*(proteinNumb-_i1)/2) + (_i2-1-_i1);
//  cout << "Protein1:\t"<<_i1<<"\tProtein2:\t"<<_i2<<"\tindex:"<< _index <<"size:\t"<<initGroups.size()<<"pNo:"<<proteinNumb <<"\n";
  assert (_i1<proteinNumb-1);
  assert (_i2<proteinNumb);
  assert (_i1<_i2);
//  cout << "index new: " << _index << "\n";
  // this assure that generated index is not bigger then size
  // of initGroups if this fails there may be a missmatch between
  // proteinNumb and halfMatrix size, or something more serious...
  assert(initGroups.size() > _index);
//  return (initGroups[_index + (_i2 -_i1 - 1)]).getVal();
  return (initGroups.at(_index)).getVal();
}
// unweighted average linkage type inter cluster distance calculation
// Namely: average of distances between each member of the two clusters
float
ClusterEngine::distMaxLinkage(const Cluster& clu1_,
		                  const Cluster& clu2_) const {
	  long double _res = 0.0f;
	  long double _max = 0.0f;
	  long long _tmp = 0;
	  for (vector<int>::const_iterator citerI1 = clu1_.getMembers()->begin();
	                                   citerI1 !=clu1_.getMembers()->end();
	                                   ++citerI1){
	    for (vector<int>::const_iterator citerI2 = clu2_.getMembers()->begin();
	                                     citerI2 !=clu2_.getMembers()->end();
	                                     ++citerI2){
	      // make sure its not the same member, same member can't be in different
	      // clusters of course!!
	      assert(*citerI1 != *citerI2);
	      assert(&(*citerI1) != &(*citerI2));
	      ++_tmp;
	       _res = getInitGroupVal(&(*citerI1), &(*citerI2));
	       if (_res>_max) _max=_res;
	    }
	  }
     return _max;
}
float
ClusterEngine::distMinLinkage(const Cluster& clu1_,
		                  const Cluster& clu2_) const {
	  long double _res = 0.0f;
	  long double _min = 9999.0f;
	  long long _tmp = 0;
	  for (vector<int>::const_iterator citerI1 = clu1_.getMembers()->begin();
	                                   citerI1 !=clu1_.getMembers()->end();
	                                   ++citerI1){
	    for (vector<int>::const_iterator citerI2 = clu2_.getMembers()->begin();
	                                     citerI2 !=clu2_.getMembers()->end();
	                                     ++citerI2){
	      // make sure its not the same member, same member can't be in different
	      // clusters of course!!
	      assert(*citerI1 != *citerI2);
	      assert(&(*citerI1) != &(*citerI2));
	      ++_tmp;
	       _res = getInitGroupVal(&(*citerI1), &(*citerI2));
	       if (_res<_min) _min=_res;
	    }
	  }
     return _min;
}
float
ClusterEngine::distAverageLinkage(const Cluster& clu1_,
                                  const Cluster& clu2_) const {
  long double _res = 0.0f;
  long long _tmp = 0;
  for (vector<int>::const_iterator citerI1 = clu1_.getMembers()->begin();
                                   citerI1 !=clu1_.getMembers()->end();
                                   ++citerI1){
    for (vector<int>::const_iterator citerI2 = clu2_.getMembers()->begin();
                                     citerI2 !=clu2_.getMembers()->end();
                                     ++citerI2){
      // make sure its not the same member, same member can't be in different 
      // clusters of course!!
      assert(*citerI1 != *citerI2);
      assert(&(*citerI1) != &(*citerI2));
      ++_tmp;
       _res += getInitGroupVal(&(*citerI1), &(*citerI2));
    }
  }
  long double _1overN = ((long double)1.0f) / _tmp;
  return (_res * _1overN);
}
float
ClusterEngine::distQuadraticLinkage(const Cluster& clu1_,
                                  const Cluster& clu2_) const {
  long double _res = 0.0f;
  long long _tmp = 0;
  for (vector<int>::const_iterator citerI1 = clu1_.getMembers()->begin();
                                   citerI1 !=clu1_.getMembers()->end();
                                   ++citerI1){
    for (vector<int>::const_iterator citerI2 = clu2_.getMembers()->begin();
                                     citerI2 !=clu2_.getMembers()->end();
                                     ++citerI2){
      // make sure its not the same member, same member can't be in different
      // clusters of course!!
//      assert(*citerI1 != *citerI2);
//      assert(&(*citerI1) != &(*citerI2));
      ++_tmp;
//      long double val = getInitGroupVal(&(*citerI1), &(*citerI2));
      long double val = getInitGroupVal(&(*citerI1), &(*citerI2));
       _res += val*val;
    }
  }
  long double _1overN = ((long double)1.0f) /(long double) _tmp;
  return (sqrt(_res * _1overN));
}

// class ClusterInvest ----------------------------------------------
// constructor:
ClusterInvest::ClusterInvest(const ClusterInvest& clusterInvest_) {
  proteinNumb = clusterInvest_.getProteinNumb();
  cycles      = *clusterInvest_.getCycles();
  halfMatrix  = *clusterInvest_.getHalfMatrix();
}
ClusterInvest::ClusterInvest(const ClusterEngine& clusterEngine_) {
  proteinNumb = clusterEngine_.getProteinNumb();
  cycles      = *clusterEngine_.getCycles();
  const vector<Group>* _initGroups = clusterEngine_.getInitGroups();
  halfMatrix.reserve(_initGroups->size());
  for (vector<Group>::const_iterator cit = _initGroups->begin();
       cit != _initGroups->end(); ++cit) {
    halfMatrix.push_back(cit->getVal());
  }
}
ClusterInvest::ClusterInvest(unsigned int proteinNumb_, 
                                    const vector<Cycle>& cycles_) {
  proteinNumb = proteinNumb_;
  cycles      = cycles_;
}
ClusterInvest::ClusterInvest(Reader& reader_) {
  reader_ >> proteinNumb;
  unsigned int _st;
  reader_ >> _st;
  cycles.reserve(_st);
  for (unsigned int i = 0; i < _st; ++i) {
    Cycle* _cycle = new Cycle(reader_);
    cycles.push_back(*_cycle);
    delete _cycle;
  }
  reader_ >> _st;
  halfMatrix.reserve(_st);
  float _tmp = 0.0f;
  for (unsigned int i = 0; i < _st; ++i) {
    reader_ >> _tmp;
    halfMatrix.push_back(_tmp);
    _tmp = 0.0f;
  }
}
// operator
ClusterInvest&
ClusterInvest::operator=(const ClusterInvest& clusterInvest_) {
  proteinNumb = clusterInvest_.getProteinNumb();
  cycles      = *clusterInvest_.getCycles();
  return *this;
}
//get
float
ClusterInvest::getDataSpread() const {
  
  long double _val = 999999.9f;
  int   _id  = 0;
  for (unsigned int i1 = 1; i1 <= proteinNumb; ++i1) {
    long double _sum = 0.0f;
    for (unsigned int i2 = 1; i2 <= proteinNumb; ++i2) {
      if (i1 != i2) 
        _sum += (long double)getDistBetweenComplexes(i1, i2);
    }
    if (_sum < _val) {
      _val = _sum;
      _id  = i1;
    }
  }
  // now _id holds the representative of the data set...:)  
  long double _sum = 0.0f;
  for (unsigned int i = 1; i <= proteinNumb; ++i) {
    if (i != _id) {
      _sum += (long double)getDistBetweenComplexes(i, _id);
    }
  }
  long double _1over = (long double)1.0f /(long double) (proteinNumb-1);
  return _sum * _1over; // this is the spread...
}


unsigned int
ClusterInvest::getProteinNumb() const {
  return proteinNumb;
}
unsigned int
ClusterInvest::getCycleNumb() const {
  return cycles.size();
}
const vector<Cycle>*
ClusterInvest::getCycles() const {
  return &cycles; 
}
const vector<float>*
ClusterInvest::getHalfMatrix() const {
  return &halfMatrix;
}
const Cycle*
ClusterInvest::getCycleWithNumbOfClusters(unsigned int clustNumb_) const {
  assert(clustNumb_ < cycles.size());
  for (vector<Cycle>::const_iterator cit = cycles.begin();
       cit != cycles.end(); ++cit) {
    if (cit->getClusterNumb() == clustNumb_)
      return &(*cit);
    }
  return 0;
}
const Cycle*
ClusterInvest::getCycle(unsigned int cycleNumb_) const {
  assert(cycleNumb_ < cycles.size());
  for (vector<Cycle>::const_iterator citerC = cycles.begin();
       citerC != cycles.end(); ++citerC) {
    if (citerC->getId() == cycleNumb_)
      return &(*citerC);
  }
  return NULL;
}
const Cycle*
ClusterInvest::getCycle(int cycleNumb_) const {
  return getCycle(static_cast<unsigned int>(cycleNumb_));
}
const Cycle*
ClusterInvest::getCycle(float val_) const {
  float _diff = 9999.9f;
  vector<Cycle>::const_iterator _thisCycle;
  for (vector<Cycle>::const_iterator citerC = cycles.begin();
       citerC != cycles.end(); ++citerC) {
    if (fabs(citerC->getThresh() - val_) < _diff) {
      _diff = fabs(citerC->getThresh() - val_);
      _thisCycle = citerC;
    }
  }
  return &(*_thisCycle);
}
const Cycle*
ClusterInvest::getCycle(double val_) const {
  return getCycle(static_cast<float>(val_));
}
Uint
ClusterInvest::getRepr(const Cluster* clust_) const {
  long double _val = 999999.9f;
  int _id = 999999;
  const vector<int>* _members = clust_->getMembers();
  // for each member 
  for (vector<int>::const_iterator citerI1 = _members->begin();
       citerI1 != _members->end(); ++citerI1) {
    long double _sum = 0.0f;
    int n = 0;
    // for each member again
    for (vector<int>::const_iterator citerI2 = _members->begin();
         citerI2 != _members->end(); ++citerI2) {
    	n++;
      // don't need distance for the same
      if (*citerI1 != *citerI2) 
        _sum += getDistBetweenComplexes(*citerI1, *citerI2)*getDistBetweenComplexes(*citerI1, *citerI2);
    } // 2nd for each member
    _sum = sqrt(_sum/(long double)n);
    if (_sum < _val) {
      _id  = *citerI1;
      _val = _sum;
    }
  } // 1st for each member
  return _id;
}

// DMIssue maybe deprecated, or maybe not used in clust for sda stuff
vector<int>
ClusterInvest::getClustReprList(const Cycle* cycle_, 
                                unsigned int numb_,
                                unsigned int size_) const {
  Cycle _cycle = *cycle_;
  // first sort clusters in this cycle big->small
  _cycle.sortClusters();
  // get vector of Clusters from this cycle
  const vector<Cluster>* _clusters = _cycle.getClusters();
  vector<int> _res;
  // for each cluster 
  for (vector<Cluster>::const_iterator citerC = _clusters->begin();
       citerC != _clusters->end(); ++citerC) {    
  // check if to consider one more cluster, and if its big enough
//    if (numb_ > 0 and citerC->getSize() >= size_) {
/*      const vector<int>* _members = citerC->getMembers();
      float _val = 999999.9f;
      int _id = 999999;
      for (vector<int>::const_iterator citerI1 = _members->begin();
           citerI1 != _members->end(); ++citerI1) {
        long double _sum = 0.0f;
        long double _sumsq = 0.0f;
        int n = 0;
        for (vector<int>::const_iterator citerI2 = _members->begin();
             citerI2 != _members->end(); ++citerI2) {
          // don't need distance for the same
          if (*citerI1 != *citerI2) {
            _sum += getDistBetweenComplexes(*citerI1, *citerI2);
            _sumsq = getDistBetweenComplexes(*citerI1, *citerI2)*getDistBetweenComplexes(*citerI1, *citerI2);
          }
          n++;
        } // loop getting distances to each other cluster
        _sumsq = sqrt(_sumsq/(long double)n);
// test the sum sq.
//        if (_sum < _val) {
//          _id = *citerI1;
//          _val = _sum;
//        }
        if (_sumsq < _val) {
          _id = *citerI1;
          _val = _sum;
        } 
      } // loop iteraing over all members of this cluster
*/
      _res.push_back(getRepr(&(*citerC)));
//      --numb_;
//    } // if cluster is to be considered and big enough
  } // loop iterating over all clusters
  return _res;
}

/*! Calculates cluster spread.
    For each cluster in cluster cycle as specified by the arg, 
    it calculates the spread of the cluster and returns as vector<float>
    starting from the biggest first cluster.
    The spread here is done as follows: average (representative) item in 
    cluster is found. Average distance is found from representative item to
    all others...
*/
vector<float>
ClusterInvest::getClustSpreadList(const Cycle* cycle_, 
                                  unsigned int numb_, 
                                  unsigned int size_) const {
  vector<int> repr = getClustReprList(cycle_, numb_, size_);
  vector<float> _res;
  
  Cycle _cycle = *cycle_;
  _cycle.sortClusters();
  const vector<Cluster>* _clusters = _cycle.getClusters();
  
  vector<int>::const_iterator citRepr = repr.begin();
  vector<Cluster>::const_iterator citClust = _clusters->begin();
  for (;citRepr != repr.end() and citClust != _clusters->end();
       ++citRepr, ++citClust) {
    float _sum = 0;
    const vector<int>* _members = citClust->getMembers();
    for (vector<int>::const_iterator citMemb = _members->begin();
         citMemb != _members->end(); ++citMemb) {
      if (*citRepr != *citMemb) {
        _sum += getDistBetweenComplexes(*citRepr, *citMemb);
      }
    }
    float _1over = 1.0f / (citClust->getSize()-1);
    _res.push_back(_sum * _1over);
  }
  return _res;
}



//
void
ClusterInvest::storageWrite(Writer& writer_) {
  writer_ << proteinNumb;
  unsigned int _st = cycles.size();
  writer_ << _st;
  for (vector<Cycle>::iterator iterC = cycles.begin();
       iterC != cycles.end();
       ++iterC) {
    iterC->storageWrite(writer_);
  }
}
// print
void
ClusterInvest::printCycleDataFrom(unsigned int cycle_) const {
  
  if (cycle_ == 0 or cycle_ > cycles.size()) {
    printCycleData(cycles.begin(), cycles.end());
  } else {
    printCycleData(cycles.begin() + cycles.size() - cycle_, cycles.end()); 
  }
}

void
ClusterInvest::printCycleData(vector<Cycle>::const_iterator from_,
                              vector<Cycle>::const_iterator to_) const {
  ostringstream ss;
  ss << setw(5) << "ClNo" << setw(5) << "CyNo"
     << setw(8) << "dist" << setw(8) << "incr%"
     << setw(6) << "MinCl" << setw(6) << "MaxCl"
     << setw(8) << "AvgCl" << endl; 
  for (vector<Cycle>::const_iterator citerC = from_;
       citerC != to_;
       ++citerC) {
    ss << setw(5) << citerC->getClusterNumb();
    ss << setw(5) << citerC->getId();
    ss.setf(ios::right, ios::adjustfield);
    ss.setf(ios::fixed, ios::floatfield);
    ss << setprecision(3) << setw(8)
       << citerC->getThresh() 
       << setprecision(3) << setw(8)
       << getPercentiveDiff(citerC)
       << setw(6)
       << getMinCluster(citerC)
       << setw(6)
       << getMaxCluster(citerC)
       << setprecision(3) << setw(8)
       << getAvgCluster(citerC)
       << endl;   
  }
  cout << ss.str();
}

void
ClusterInvest::printBinLog(int printFrom_, int binNumb_) const {
  // make bins
  float minVal = *min_element(halfMatrix.begin(), halfMatrix.end());
  float maxVal = *max_element(halfMatrix.begin(), halfMatrix.end());
  float piece  = (maxVal - minVal) / (binNumb_ - 1.0f);
  vector<float> bins; bins.reserve(binNumb_);
  vector<int> binLog; binLog.reserve(binNumb_);
  for (int i = 0; i < binNumb_; ++i) {
    bins.push_back(minVal+piece*i);
  }
  int k = 0;

  for (vector<Cycle>::const_iterator cit = cycles.begin();
       cit != cycles.end(); ++cit) {
    while (true) {
      if (cit->getThresh() >= bins[k]) {
        binLog.push_back(cit->getClusterNumb());
        ++k;
      }
      else {
        break;
      }
    } // while loop
  }
  while (binLog.size() < binNumb_) {
    binLog.push_back(1);
  }
  
  if (printFrom_ == 0 or printFrom_ > proteinNumb) {
    for (vector<int>::const_iterator cit = binLog.begin();
         cit != binLog.end(); ++cit) {
      cout << *cit << endl;
    }
  }
  else if (printFrom_ < 0) {
    cout << "ERROR: Number of cycle can't be negative!!!" << endl;
    return;
  }
  else {
    for (vector<int>::const_iterator cit = binLog.begin();
         cit != binLog.end(); ++cit) {
      if (*cit <= printFrom_)
        cout << *cit << endl;
    } 
  } // end of this long elif
}
void
ClusterInvest::printClustDataAtCycle(
               const Cycle*         cycle_,
               const vector<int>*   occur_,
               const vector<float>* elE_,
               const vector<float>* avgElE_,
               const vector<float>* rmsds_,
               Uint num_, Uint size_) const {
  Cycle _cycle(*cycle_);
  _cycle.sortClusters();
  vector<Cluster>::const_iterator citerStart, citerEnd;
  citerStart = _cycle.getClusters()->begin();
  if (num_ != 0 and num_ < _cycle.getClusters()->size()) {
    citerEnd = _cycle.getClusters()->begin() + num_;
  } else {
    citerEnd = _cycle.getClusters()->end();
  }
  Uint _n = 1;
  cout << setw(8) << "No";
  cout << setw(8) << "ClSize";
  cout << setw(8) << "ClFSize";
  cout << setw(8) << "Repr";
  cout << setw(9) << "ReprElE";
  cout << setw(9) << "ClFElE";
  cout << setw(9) << "RepRMSD";
  cout << setw(9) << "ClFRMSD" << endl;
  for (vector<Cluster>::const_iterator citerC = citerStart;
       citerC != citerEnd; ++citerC) {
    if (citerC->getSize() < size_)
      break;
    cout << setw(8) << _n;
    cout << setw(8) << citerC->getSize();
    cout << setw(8) << citerC->getPropSum(*occur_);  
    Uint _rep = getRepr(&(*citerC));
    cout << setw(8) << _rep;
    cout.setf(ios::right, ios::adjustfield);
    cout.setf(ios::fixed, ios::floatfield);
    cout << setw(9) << setprecision(3) 
                    << (*elE_)[_rep - 1];
    cout << setw(9) << setprecision(3) 
                    << citerC->getPropAvg(*avgElE_);
    cout << setw(9) << setprecision(3) 
                    << (*rmsds_)[_rep - 1];
    cout << setw(9) << setprecision(3)
                    << citerC->getFPropAvg(*rmsds_, *occur_);
    cout << endl;
    ++_n;
  }
}
 
void
ClusterInvest::visualizeClustAt(const Cycle* cycle_) const {
  unsigned int _nMax = 0;
  const vector<Cluster>* _clustV = cycle_->getClusters();
  for (vector<Cluster>::const_iterator citerC = _clustV->begin();
       citerC != _clustV->end();
       ++citerC) {
    if (_nMax < citerC->getMembers()->size())
      _nMax = citerC->getMembers()->size();
  }
  float _1overM = 1.0f / _nMax;
  unsigned int _num = 0;
  // now print how all clusters look more or less:-)
  for (vector<Cluster>::const_iterator citerC = _clustV->begin();
       citerC != _clustV->end();
       ++citerC) {
    unsigned int _size = static_cast<unsigned int>
            (floor(citerC->getMembers()->size() * _1overM * 60));
    cout << setw(3) << ++_num;
    cout << setw(5) << citerC->getMembers()->size() << " ";
    while (_size != 0) {
      cout << "=";
      --_size;
    }
    cout << endl;
  }
  cout << "CycleNo:  " << setw(5) << cycle_->getId() << " " << endl;
  cout.setf(ios::right, ios::adjustfield);
  cout.setf(ios::fixed, ios::floatfield);
  cout << "CycleVal: " << setprecision(3) 
       << setw(8) << cycle_->getThresh() << " " << endl;
}

float
ClusterInvest::getPercentiveDiff(vector<Cycle>::const_iterator& item_) const {
  // DM. ISSUE!!! make this _max and _min calculated once and store
  vector<Cycle>::const_iterator _citerC = cycles.begin();
  float _min = _citerC->getThresh();
  _citerC = cycles.end();
  --_citerC;
  float _max = _citerC->getThresh();
  float _1over1pr = 1.0f / ((_max - _min) * 0.01f);
  _citerC = item_;
  if (_citerC != cycles.begin()) {
    return (_citerC->getThresh() - (--_citerC)->getThresh()) * _1over1pr;
  } else {
    return 0.0f;
  }
}
unsigned int
ClusterInvest::getMinCluster(vector<Cycle>::const_iterator& item_) const {
  unsigned int _res = 9999;
  for (vector<Cluster>::const_iterator 
                        citerC = item_->getClusters()->begin();
                        citerC !=item_->getClusters()->end();
                        ++citerC) {
    if (citerC->getMembers()->size() < _res)
      _res = citerC->getMembers()->size();
  }
  return _res;
}
unsigned int
ClusterInvest::getMaxCluster(vector<Cycle>::const_iterator& item_) const {
  unsigned int _res = 0;
  for (vector<Cluster>::const_iterator
                        citerC = item_->getClusters()->begin();
                        citerC !=item_->getClusters()->end();
                        ++citerC) {
    if (citerC->getMembers()->size() > _res)
      _res = citerC->getMembers()->size();
    }
    return _res;
}

float
ClusterInvest::getAvgCluster(vector<Cycle>::const_iterator& item_) const {
  unsigned int _sum = 0;
  for (vector<Cluster>::const_iterator 
                        citerC = item_->getClusters()->begin();
                        citerC !=item_->getClusters()->end();
                        ++citerC) {
    _sum += citerC->getMembers()->size();
  }
  float _1overAll = 1.0f / item_->getClusterNumb(); 
  return (_sum * _1overAll);
}
float
ClusterInvest::getDistBetweenComplexes(unsigned int member1_, 
                                       unsigned int member2_) const {
  unsigned int _i1, _i2, _index = 0;
  if (proteinNumb < 2) {
	  return 0.0f;
  }
  if (member1_ < member2_) {
    _i1 = member1_-1;
    _i2 = member2_-1;
  } else if (member1_ > member2_) {
    _i1 = member2_-1;
    _i2 = member1_-1;
  } else {
	  return 0.0f;
//    cout << "ERROR: No point to call "
//         << "this for the same clusters" << endl;
//    exit(1);
  }
  assert (_i1<_i2);
    _index = (proteinNumb*(proteinNumb-1)/2)-((proteinNumb-_i1-1)*(proteinNumb-_i1)/2) + (_i2-1-_i1);
//     cout << "Protein1:\t"<<_i1<<"\tProtein2:\t"<<_i2<<"\tindex:"<< _index <<"size:\t"<<halfMatrix.size()<<"pNo:"<<proteinNumb <<"\n";
     assert (_i1<proteinNumb-1);
     assert (_i2<proteinNumb);
     assert (_i1<_i2);
   //  cout << "index new: " << _index << "\n";
     // this assure that generated index is not bigger then size
     // of initGroups if this fails there may be a missmatch between
     // proteinNumb and halfMatrix size, or something more serious...
  assert(halfMatrix.size() > _index);
   //  return (initGroups[_index + (_i2 -_i1 - 1)]).getVal();
     return (halfMatrix.at(_index));
}
//-------------------------------------------------------------------


// DMIssue
// check this assertion in following foos:
// getPropSum()
// getFPropAvg()
// getPropAvg()
// I thik its ok to have <= sice cluster numbering starts from 1 but
// vector indexing from 0 , but why didn't I get this assertion error before?
// maybe sdaF55 was constructed with more lines... therefore actually???

