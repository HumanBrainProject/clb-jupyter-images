#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

import os
import sys


class IOOut:
    def getOutput(self, command):
        self.child = os.popen(command)
        self.data = self.child.read()
        self.err = self.child.close()
        return self.data


up1 = "../"
up2 = "../../"
sep = "/"

dirlist = [
    "3d",
    "common",
    "sda",
    "io",
    "molecule",
    "invest/acc",
    "invest/clusterh",
    "invest/rescontact"]
#  "md",
#  "other/datamatrix",
#  "other/gridmap",
#  "other/fortran"]


makeType = input("Input:\n  1  -> for compilation with debuging\n" +
                 "  2  -> for clean compilation\n" +
                 "  3  -> only remove *.o files\n")
if (makeType != 1 and makeType != 2 and makeType != 3):
    print("wrong selection")
    sys.exit(1)

print("Removing object files:\n")
for i in dirlist:
    io = IOOut()
    io.getOutput("rm "+up2+i+sep+"*.o")
    print(('  ->  '+up2+i+sep))
    if makeType == 1:
        os.system("make --file=Makefile -C "+up2+i+sep)
    elif makeType == 2:
        os.system("make --file=Makefile_clean -C "+up2+i+sep)
    elif makeType == 3:
        print("Just deleted *.o files")
