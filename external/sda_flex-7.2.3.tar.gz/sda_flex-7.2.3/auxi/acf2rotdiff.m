function [Drs]=acf2rotdiff(filename,prot_id)
% 
% Paolo Mereghetti
% 20 Jul 2011
%
% Description:
%
% Compute the rotational diffusion coefficient by fitting
% the orientational vectors autocorrelation function 
% computed using sdamm_acf_multiprot
% A single exponential is fitted using Prony's method.
%
%  Usage [Dr]=acf2rotdiff('filename',prot_id)
% 
%   The acf.dat file may contains several columns which
%   correspond to the differen protein types.
%   prot_id specify which acf should be fitted. 
%
%   Eg. only one protein type
%  
%    [Dr]=acf2rotdiff('acf.dat',1)
%
%   Eg. Two protein types
%  
%    [Dr1]=acf2rotdiff('acf.dat',1)
%    [Dr2]=acf2rotdiff('acf.dat',2)
%
%   
%   
%
% 

printf('\n%s %s\n',' Loading ',filename)
acf=load(filename);
if (nargin<2)
 prot_id=1;
end
printf('%s %10i %s\n\n',' ACF of protein ',prot_id,'will be fitted')

% open log file
prot_id_string=num2str(prot_id);
log_name=['acf_orientvector_grid_type_',prot_id_string,'_fit.log']
fid=fopen(log_name,'w');

% number of acf to be fitted (it can be a single average acf or a many acf)
Nacf=size(acf,2)-1;
printf('Nacf %d\n', Nacf);

for iacf=1:Nacf
  acftofit(:,1)=acf(:,1);
  acftofit(:,2)=acf(:,iacf+1);
  %[Dr]=fit_acf(filename,acftofit,prot_id,Nacf,fid);
  [Dr]=fit_acf(filename,acftofit,prot_id,Nacf,fid);
  Drs(iacf)=Dr;
end

meanDrs=mean(Drs);
stdDrs=std(Drs);

printf('\n\n %s %10i %s\n\n','Averages over ',iacf,' acfs')
printf('%s %10.5e %s %10.5e \n', ' [ns] Avg. Rot. diff. coeff. =', meanDrs, '(rad/ns) +/- ', stdDrs)
printf('%s %10.5e %s %10.5e \n', ' [ps] Avg. Rot. diff. coeff. =', meanDrs*1e-3, '(rad/ns) +/- ', stdDrs*1e-3)

fprintf(fid,'%s','##########################################################################')
fprintf(fid,'%s','##########################################################################')
fprintf(fid,'\n\n %s %10i %s\n\n','Averages over ',iacf,' acfs')
fprintf(fid,'%s %10.5e %s %10.5e \n', ' [ns] Avg. Rot. diff. coeff. =', meanDrs, '(rad/ns) +/- ', stdDrs)
fprintf(fid,'%s %10.5e %s %10.5e \n', ' [ps] Avg. Rot. diff. coeff. =', meanDrs*1e-3, '(rad/ns) +/- ', stdDrs*1e-3)



fclose(fid);

end

function [Dr]=fit_acf(filename,acf,prot_id,Nacf,fid)

%col=prot_id;
%+1
%printf('col %d\n', col);
printf('size acttofit %d\n', size(acf(:,1),1) )
%printf('acf(1,1) %e' ,acf(1,1) )
%printf('acf(2,1) %e' ,acf(2,1) )
%printf('acf(1,2) %e' ,acf(2,1) )
% Select positive y region
step=diff(acf(:,1))(1);
x0=min(acf(:,1));
ndx=0;
for i=1:size(acf(:,1),1)
  %if ((acf(i,col)>0) && (acf(i,1)<200.0))
  if ((acf(i,2)>0) && (acf(i,1)<200.0))
  %if ((acf(i,col)>0))
   ndx++;
  else
   break
  end
end

%printf('ndx %d', ndx);
x=acf(1:ndx,1);
%y=acf(1:ndx,col);
y=acf(1:ndx,2);

y=y(:);
x=x(:);


% Fit the function
[alpha,c,rms] = expfit(1,x0,step,y);

% Check fitting
y1=c*exp(alpha.*x);
cc=corrcoef(y,y1);


% Only if is average acf plot the fitted curve

if (Nacf==1) 
 [pre,suf]=strtok(filename,"_");
 [pre,suf]=strtok(suf,"_");
 prot_id_string=num2str(prot_id);
 title_name=['acf.dat\_',pre,' protein type ',prot_id_string];
 png_name=['acf_orientvector_grid_type_',prot_id_string,'_fit.png']
 plot(acf(1:size(x,1),1),acf(1:size(x,1),2),'linewidth',2);
 hold on
 plot(x,y,'*');
 plot(x,y1,'xg','linewidth',2);
 legend('Original ACF','Fitting region','Fitted ACF');
 xlabel ('time (ns)');
 ylabel ('ACF');
 title (title_name);
 set (gca,'fontsize',20);
 print(png_name,'-dpng')
 hold off
end

%printf('%s \n', " Prony's method for non-linear exponential fitting")
%printf('%s \n\n', ' Fit function c*exp(alpha*x)')
%printf('%s \n', '### Fitted parameters ###')
%printf('%s %10i %s %10i %s\n', ' Fitted on positive range ',x(1),'-',x(size(x,1)),'(ns)' )
%printf('%s %10.5f \n', ' c = ',c)
%printf('%s %10.5f \n', ' alpha = ',alpha)
%printf('%s %10.5f \n', ' corr. coeff. = ',cc)
%printf('%s %10.5f \n\n', ' rms. = ',rms)
%
%printf('%s %10.5f %s\n', ' Relaxation time (1/alpha) = ',-1/alpha, '(ns)')
%Dr=-alpha/2;
%printf('%s %10.5e %s \n', ' Rot. diff. coeff. =', Dr, '(rad/ns)')
%printf('%s %10.5e %s \n\n', ' Rot. diff. coeff. =', Dr*1e-3, '(rad/ps)')
%printf('%s %s\n\n', ' This information are also writtin in file ',log_name);
%printf('%s %s\n\n', ' Plot saved as ',png_name);
%
fprintf(fid,'%s \n', ' ')
fprintf(fid,'%s \n', "Prony's method for non-linear exponential fitting")
fprintf(fid,'%s \n\n', ' Fit function c(1)*exp(alpha(1)*x + c(2)*exp(alpha(2)*x)')
fprintf(fid,'%s \n', '### Fitted parameters ###')
fprintf(fid,'%s %10i %s %10i %s\n', ' Fitted on positive range ',x(1),'-',x(size(x,1)),'(ns)' )
fprintf(fid,'%s %10.5f \n', ' c = ',c)
fprintf(fid,'%s %10.5f \n', ' alpha = ',alpha)
fprintf(fid,'%s %10.5f \n', ' corr. coeff. = ',cc)
fprintf(fid,'%s %10.5f \n\n', ' rms. = ',rms)
fprintf(fid,'%s %10.5f %s\n', ' Relaxation time (1/alpha) = ',-1/alpha, '(ns)')
Dr=-alpha/2;
fprintf(fid,'%s %10.5e %s \n', ' Rot. diff. coeff. =', Dr, '(rad/ns)')
fprintf(fid,'%s %10.5e %s \n', ' Rot. diff. coeff. =', Dr*1e-3, '(rad/ps)')
%fclose(fid);


end
