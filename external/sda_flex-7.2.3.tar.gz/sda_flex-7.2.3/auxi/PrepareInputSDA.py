#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

"""
    This script should be run with a complet set of conformations of a solute 
    given as a list pqr files for all conformations of the solutes (only one if not flexible)
    
    It checks the validity of the given pqr files
    It generates an "add_atoms" file if some atoms/ions/ligands are missing readable by SDA 
    for computing the test charges.
    
    It creates a pdb file without hydrogen (by default), with a prefix "pqrnoh_nameconf.pdb" 
    to not overwrite the given pqr and try to set up the termini correctly ( with NTR/CTR/NTN/CTN )
    
    It generates a shell script to compute effective charges, and many grids used by SDA
    
    And finally provides many information in the log file PrepSDA.log

    The pqr files can be in the current directory, or in different ones. In the later case all the
    files are generated in the respective directories (except the log file, in the current one),
    The -merge_addatom option generates a global "add_atoms" file from all the subdirectories.
    
    The tool MergeAddAtoms.py can merge the "add_atoms" files of different proteins in oder to run SDA.
    
    If chain ids are missing, the use of the TER keyword in the pqr is mandatory. You should also use explicitly the -rename_chains option.   
"""

import sys
import os
import logging
import warnings
import argparse

from ModPrepareInputSDA.PQRStructure_Biop import PQRBiopStructure
from ModPrepareInputSDA.GeneratorSDAInput import GeneratorSDAInput
from ModPrepareInputSDA.VdWTC_SDA import VdWTC_SDA

# maybe to include in PQRBioStructure later
from ModPrepareInputSDA.DebyeHuckel import DebyeHuckel

"""
    Script to prepare input files for one solute (include flexibility):
        - apbs
        - ECM
        - ed, hd, ljrep
        
    and generate an unique shell script to be run in the directory name_solute
    
    ./PrepareInput.py -pqr pqr_file(s) -ep -ed -hd -ionic_strength ios -rename_chains 
    
    Michael Martinez 6/11/2013 
"""

# Maximum allowed, otehrwise log an ERROR and exit
# max dimension in Angstrom
#MAX_DIST = 100
MAX_DIST = -1
# to desactivate the limitationput -1
# max number of atom
MAX_ATOM = -1
#MAX_ATOM = 50000


logging.basicConfig(filename='PrepSDA.log', level=logging.DEBUG, filemode="w")
# not working here
# logging.captureWarnings(True)

parser = argparse.ArgumentParser(
    description="Generate input file for the preparation step")

# option flex ? not necessary if more than 1 structure, it is flexible.
parser.add_argument("-pqr", dest="list_pqr", required=True,
                    nargs='+', help="The list of pqr filenames")
parser.add_argument("-ep", dest="ep", action='store_true', default="False",
                    help="Will produce input file for electrostatic calculation")
parser.add_argument("-ed", dest="ed", action='store_true', default="False",
                    help="Will produce input file for electrostatic desolvation calculation")
parser.add_argument("-hd", dest="hd", action='store_true', default="False",
                    help="Will produce input file for nonpolar desolvation calculation")
parser.add_argument("-ljrep", dest="ljrep", action='store_true', default='False',
                    help="Will produce input file for soft-core (LJ) repulsion calculation")
parser.add_argument("-ionic_strength", dest="ios", type=float,
                    default="150.", help="Ionic strength, default 150 mM")
parser.add_argument("-merge_addatom", dest="merge_aa", action='store_true', default="False",
                    help="In case of conformation in subdirectory, additionally merge all add_atoms files into one in the current directory")
# not very logic, want to force as first test
parser.add_argument("-dh_approx", dest="dh", action='store_true', default="False",
                    help="Use a Debye-Huckel approximation to determine the size of the electrostatic box")
parser.add_argument("-hydro_radius", dest="hydro_rad", action='store_true', default="False",
                    help="If exact radius of gyration must be computed. Default use the radius of gyration as approximation")
parser.add_argument("-rename_chains", dest="rename_chains", action='store_true', default='False',
                    help="Will rename the chains present, starting from 0. Necessary if 2 chains without identifiers are present in the PQR file")
parser.add_argument("-delete_H", dest="delH", action='store_false',
                    default="True", help="To delete the hydrogens when generating the pdb file")
parser.add_argument("-temperature", dest="Temp", type=float,
                    default=300., help="Temperature, for apbs calculation")
parser.add_argument("-npbe", dest="npbe", action='store_true', default="False",
                    help="Choose linear or non-linear Poisson-Boltzmann for apbs")

# need to force boolean type !??
parser.set_defaults(delH=True)
parser.set_defaults(ep=False)
parser.set_defaults(ed=False)
parser.set_defaults(hd=False)
parser.set_defaults(ljrep=False)
parser.set_defaults(merge_aa=False)
parser.set_defaults(dh=False)
parser.set_defaults(hydro_rad=False)
parser.set_defaults(rename_chains=False)
parser.set_defaults(npbe=False)

try:
    options = parser.parse_args()
# parse_arg will return an exit
except SystemExit:
    logging.error("reading wrong arguments")
    sys.exit(1)

# name solute can be used to create an unique directory,
# with all conformations, can be done before as well
#logging.info("name_solutes %s" % options.name_solutes)
logging.info("pqr %s " % options.list_pqr)
logging.info("ep  %s " % options.ep)
logging.info("ed  %s " % options.ed)
logging.info("hd  %s " % options.hd)
logging.info("ljrep %s " % options.ljrep)
logging.info("ios %f " % options.ios)
logging.info("debye-huckel %s" % options.dh)
logging.info("hydro_radius %s" % options.hydro_rad)
logging.info("merge_addtoms %s " % options.merge_aa)
logging.info("rename_chains %s " % options.rename_chains)
logging.info("temperature %f " % options.Temp)
logging.info("npbe %s" % options.npbe)
#logging.info("Nterm %s" % options.Nterm)
#logging.info("Cterm %s" % options.Cterm)

print("list pqr ", options.list_pqr)
print("ep ", options.ep)
print("ed ", options.ed)
print("hd ", options.hd)
print("ljrep ", options.ljrep)
print("ios ", options.ios)
#print "delLog ", options.delLog
print("Merge addatoms ", options.merge_aa)
print("Del H ", options.delH)
print("Rename chains ", options.rename_chains)
print("Non-linear Poisson-Boltzmann ", options.npbe)

# of the solutes, used to adjust the grid size
dimension_max = [0., 0., 0.]
nb_max_atoms = 0
max_cutoff_dh = None

# store the sum, print sum / nb_inputs
average_stoke_radius = 0
nb_inputs = len(options.list_pqr)
print("nb pqr inputs ", nb_inputs)


# list of pqrnoh file
dict_files = {}

# optional, make the merging of add_atoms for all conformations
# default, write into the current directory
# otherwise use the tool Merge_addatoms
merged_vdw = None
if options.merge_aa:
    print("merge_add_atoms True")
    # create output directory, maybe check if existing
    # default add_atoms in current directory
    merged_vdw = VdWTC_SDA()  # directory='.', filename='add_atoms'

# we check all input files,
# and, if flexible, get the dimension_max for all the conformations
# this dimension max will be used for all conformations
for pqrfile in options.list_pqr:

    # Quick fix to bug with add_atoms
    (head, tail) = os.path.split(pqrfile)
    print("head ", head)

    # if head == '':
    #    head = '.'
    #    print "correct head ", head

    # no need to delete anymore, bug !
    #print "to delete ", head+ os.sep + "add_atoms"
    # if ( os.path.exists(head+ os.sep +"add_atoms") ):
    #    print "delete it"
    #os.remove(head+ os.sep + "add_atoms")

    print("\n======= Structure %s ==========\n" % pqrfile)

    logging.info("pqr file %s" % pqrfile)
    pqr_struct = None

    # initialize the pqr structure,
    # Check the charge and assign terminal
    # Each residue and full structure) are integer
    try:
        # Add options if change numbering is missing. Biopython crashed. Need TER between the chains
        # could be in the option of the script
        pqr_struct = PQRBiopStructure(
            pqrfile, "pqr", PERMISSIVE=1, QUIET=True, Overwritte_chains=options.rename_chains)
    except Exception as ex:
        print("Got an exception ", ex)
        logging.error("Cannot load the file %s, got exception %s" %
                      (pqrfile, ex))
        # to get all info wit line number
        #exc_type, exc_obj, exc_tb = sys.exc_info()
        #fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        #print(exc_type, fname, exc_tb.tb_lineno)
        # best practice to use slice, not local variable like
        #print ("%s %s %s" % (sys.exc_info()[0].__name__, os.path.basename(sys.exc_info()[2].tb_frame.f_code.co_filename), sys.exc_info()[2].tb_lineno))

        print("Exception in load pqr structure\nFrom PrepareInputSDA, stop the program\n")
        sys.exit(1)

    if (MAX_ATOM > 0) & (pqr_struct.nb_atoms > MAX_ATOM):
        logging.info("Too many atoms %d, maximum allowed %d " %
                     (pqr_struct.nb_atoms, MAX_ATOM))
        print("Too many atoms (max=", MAX_ATOM, ") but still continue")
        sys.exit(1)

    # finalize the construction of the PQR file in computing AND chekcing
    # the sum of charges for each residue and for the complete structure
    # Exception only if total charge is different of zero
    try:
        #pqr_struct.total_charge = int(pqr_struct.compute_total_charge())
        pqr_struct.compute_total_charge()
    except Exception as ex:
        logging.error("%s", ex)
        sys.exit(1)

    print("Total Charge:", pqr_struct.total_charge)
    logging.info("REMARK, pqr = %s, total_charge = %f " %
                 (pqr_struct.full_filename, pqr_struct.total_charge))

    print("\nMolecular Weight")
    MW = 0.
    try:
        MW = pqr_struct.compute_Molecular_Weight()
        logging.info("REMARK, pqr = %s,  MW = %f " %
                     (pqr_struct.full_filename, MW))
    except Exception as ex:
        print("Got Exception %s ", ex)
        logging.error("%s", ex)
        sys.exit(1)

    # rename the terminal
    print("\n Rename terminals ")
    try:
        # test all chains protein/dna
        pqr_struct.rename_terminal()
    except Exception as ex:
        print("Got Exception %s ", ex)
        logging.error("%s", ex)
        sys.exit(1)

    print("\n Update add_atoms file")
    try:
        pqr_struct.update_addatom_file()

        if options.merge_aa:
            print("merge_aa true, merge to main ")
            merged_vdw.MergeWith(pqr_struct.vdw)

        # else:
        #    print "Create independent add_Atom"
        #    merged_vdw = VdWTC_SDA( directory=head, filename='add_atoms' )

    except Exception as ex:
        logging.error("%s" % ex)
        print("Error in updating add atoms file ", ex)
        #print "Got Exception in update_addatom_file "
        sys.exit(1)

    # create the pdb_file, pqrnoh_NAME.pdb, contains NTR, CTR residue
    print("\ndelete hydrogen delH=", options.delH)
    try:
        pqr_struct.delete_hydrogens(options.delH)
    except Exception as ex:
        print("Exception ", ex)
        logging.error("Exception in delete_hydrogens")
        sys.exit(1)

    # Compute distance from pqrnoh files
    pqrnoh_file = pqr_struct.pqrnoh_filename
    if pqr_struct.dirname != '.':
        pqrnoh_file = pqr_struct.dirname + os.sep + pqrnoh_file
    # list_pqrnoh.append(pqrnoh_file)
    dict_files[pqrnoh_file] = pqr_struct.filename

    print("\n prqnoh_file before read", pqrnoh_file)
    try:
        # could be in the option of the script
        pqrnoh_struct = PQRBiopStructure(
            pqrnoh_file, "pdb", PERMISSIVE=1, QUIET=True)
        # total charge needed by debye, not accessible in pqrnoh
        pqrnoh_struct.total_charge = pqr_struct.total_charge

    except Exception as ex:
        print("Got an exception ", ex)
        logging.error("Cannot load the file %s, got exception %s" %
                      (pqrfile, ex))
        sys.exit(1)

    # print info update max number of atoms
    logging.info("REMARK, pqrnoh = %s, nb_atoms = %d " %
                 (pqrnoh_struct.full_filename, pqrnoh_struct.nb_atoms))
    if pqrnoh_struct.nb_atoms > nb_max_atoms:
        nb_max_atoms = pqrnoh_struct.nb_atoms

    try:
        dimension = pqrnoh_struct.get_dimension_and_set_closer_center_atom()
    except Exception as ex:
        logging.error("Cannot find a central atom")
        sys.exit(1)

    logging.info("REMARK, pqrnoh = %s, center_of_mass = %f %f %f " %
                 (pqrnoh_struct.full_filename, pqrnoh_struct.center_of_mass[0], pqrnoh_struct.center_of_mass[1], pqrnoh_struct.center_of_mass[2]))
    #local_closer_at = pqrnoh_struct.indice_closer
    logging.info("REMARK, pqrnoh = %s, closer_atom_center = %d, closer_residue_name = %s, closer_atom_name = %s " % \
                 #(pqrnoh_struct.pqr_full_filename, pqrnoh_struct.indice_closer, "0", "0" )) #, , pqrnoh_struct.get_resnb( local))
                 (pqrnoh_struct.full_filename, pqrnoh_struct.atom_closer["atom_nb"], pqrnoh_struct.atom_closer["res_name"], \
                  pqrnoh_struct.atom_closer["atom_name"],))
    logging.info("REMARK, pqrnoh = %s, dimension = %f %f %f" %
                 (pqrnoh_struct.full_filename, dimension[0], dimension[1], dimension[2]))
    #center_of_mass = pqrnoh_struct.get_cent

    if (MAX_DIST > 0) & (max(dimension) > MAX_DIST):
        logging.info("Too large dimension %f, maximum allowed %f " %
                     (max(dimension), MAX_DIST))
        print("Too large dimension (max=", MAX_DIST, ") but still continue")
        # sys.exit()

    # update dimension_max
    for x in range(3):
        # modify, need 2 times the distance
        dimension_max[x] = max(dimension[x], dimension_max[x])
        # dimension_max[x] = max( 2*abs(dimension[x]), 2*abs(dimension[x]) )

    print("dimension_max of the solutes: ", dimension_max)

    # compute hydrodynamic radius
    try:
        # if specified in input -hydro_radius, full calculation (much longer)
        if options.hydro_rad == True:
            print("Compute hydrodynamic radius")
            logging.info("Compute hydrodynamic radius")
            pqrnoh_struct.compute_hydro_radius()

        # default use radius of gyration as approximation
        else:
            print("Compute radius of gyration")
            logging.info("Compute radius of gyration")
            pqrnoh_struct.compute_radius_gyration()

        print("hydrodynamic radius %f " % pqrnoh_struct.stoke_radius)
        logging.info("REMARK, pqrnoh = %s, stoke_radius = %f" %
                     (pqrnoh_struct.full_filename, pqrnoh_struct.stoke_radius))

        average_stoke_radius += pqrnoh_struct.stoke_radius

    except Exception as ex:
        print("Got exception in compute_hydro_radius ", ex)

    # and debye-huckel approximation if asked
    # size box if debye-huckel, can be integrated in PQRStructure later
    if options.dh:

        try:
            print("DebyeHuckel activated distance hardcoded max 500 Angs")
            print("total charge ", pqrnoh_struct.total_charge)
            # __init__(self, charge, radius_sphere, ionic_strength, bin_width, distance_max)
            debye = DebyeHuckel(pqrnoh_struct.total_charge,
                                pqrnoh_struct.stoke_radius, options.ios/1000, 1, 500)
            debye.compute_debye()
            dict_cutoff_dh = debye.give_cutoffs()
            print("dict cutoff debye ", dict_cutoff_dh)
            logging.debug("dict cutoff debye %s " % (dict_cutoff_dh))

        except Exception as ex:
            print("Exception ", ex)
            logging.error("%s" % (ex))
            sys.exit(1)

        if max_cutoff_dh < dict_cutoff_dh[2]:
            max_cutoff_dh = dict_cutoff_dh[2]
            print("update max_cutoff_dh ", max_cutoff_dh)

    # else will use max_dimension to set up the electrostatic grid size

    # Before here VdW and Tc
    if options.merge_aa:
        print("\nWill write to file merged_vdw  ", merged_vdw)
        # write all the time ?
        merged_vdw.write_file()

    # all cases print in the vdw associated to the strcture
    pqr_struct.vdw.write_file()

# print
print("\nCreate the input files")
# now than pqr files have been checked and
# pqrnoh_NAME.pdb have been created and ( add_atoms updated to do )
logging.info("REMARK, all pqr, overall_max_dimension = %f %f %f" %
             (dimension_max[0], dimension_max[1], dimension_max[2]))
logging.info("REMARK, all pqr, nb_max_atoms = %d " % (nb_max_atoms))
# store only the sum in variable
logging.info("REMARK, all pqr, average_stoke_radius = %f " %
             (average_stoke_radius/nb_inputs))
if options.dh:
    logging.info("REMARK, all pqr, max_cutoff_dh = %f " % max_cutoff_dh)
else:
    logging.info("REMARK, all pqr, debye-huckel not activated")

# Loop to generate the shell script
#print "\nLoop for generator ", options.list_pqr

#print "dict of files: ", dict_files
count = 1  # used as initializer for shell_script, if 1 copy all the templates, otherwise append
for (pqrnoh_file, pqr_file) in list(dict_files.items()):

    print("\npqrnoh file ", pqrnoh_file)
    print("pqr file ", pqr_file)

    # count allows to know if a full initialisation must be done, only for id == 1
    file_generator = GeneratorSDAInput(
        dimension_max, pqrnoh_file, pqr_file,  options.ios, options.Temp, count, options.npbe)

    if options.ep == True:
        # only if ep need additional pqr filename,
        # but easier to set in constructor
        #print "option ep ", options.ep
        logging.debug("options.ep %s", options.ep)

        if max_cutoff_dh:
            print("max_cutoff_dh has been computed %f " % (max_cutoff_dh))
            file_generator.generate_ep(max_cutoff_dh)
        else:
            print("max_cutoff_dh has not been computed")
            file_generator.generate_ep()

    if options.ed == True:
        file_generator.generate_ed()

    if options.hd == True:
        file_generator.generate_hd()

    if options.ljrep == True:
        file_generator.generate_ljrep()

    # once all done, write ouptput to the shell script
    print("Generate shell script for solute %d " % count)
    file_generator.generate_shell_script()

    count += 1

    logging.info('='*30)

logging.info('*'*30)
