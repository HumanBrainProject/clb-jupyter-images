#!/bin/bash

# Download and Install current version of SDA
# Define SDA_HOME as SDA software directory.

export SDA_HOME="/path/to/SDA/installation/directory"

BIN=$SDA_HOME/bin
AUXI=$SDA_HOME/auxi

#==============================================
export BIN AUXI
#==============================================

## SDA 7 uses OpenMP for parallelization, adapt to your system or keep the default (all available CPUs)
# export OMP_NUM_THREADS=2

## The script runs in approx. 15 min. on 2 CPUs

######### Compute the electron transfer rate between cytochrome f and plastocyanin

### run 1 simulation with 

# Generate output files by sda_flex, some (identical) files will be overwritten :
$BIN/sda_flex sda_et.in > sda_out_et;

# Run the bootstrap analysis
$AUXI/Bootstrap_multiCPU.py -i electron_transfer.log -o elect_boot.out -n 100;

exit
