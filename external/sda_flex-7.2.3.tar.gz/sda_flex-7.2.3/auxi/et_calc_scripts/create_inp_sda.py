#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

# read the files of solvent accessibility and T_DA for p1 and p2
# calculate, if ln(T_DA [1]) + ln(T_DA [2]) >= tda_limit
# if yes: write the respective atoms in {...}_sda_et_inp.rxnac

import sys

a = sys.argv

tda_limit = float(a[3])

f1 = file(a[1] + '_acc_TDA.dat', 'r')
g1 = file(a[1] + '.pdb', 'r')
h1 = file(a[1] + '_sda_et_inp.rxnac', 'w')

f2 = file(a[2] + '_acc_TDA.dat', 'r')
g2 = file(a[2] + '.pdb', 'r')
h2 = file(a[2] + '_sda_et_inp.rxnac', 'w')

l_spl1_1 = []  # array for p1: solvent acc and TDA
l_spl1_2 = []  # array of pdb file elements for p1
l_spl2_1 = []  # array for p2: solvent acc and TDA
l_spl2_2 = []  # array of pdb file elements for p2

for line in f1:
    spl = line.split()
    l_spl1_1.append(spl)

for line in f2:
    spl = line.split()
    l_spl2_1.append(spl)

for line in g1:
    l_spl1_2.append(line)

for line in g2:
    l_spl2_2.append(line)

for i in range(0, len(l_spl1_1)):
    for j in range(0, len(l_spl2_1)):
        if ((float(l_spl1_1[i][3]) + float(l_spl2_1[j][3])) >= tda_limit):
            for k in range(0, len(l_spl1_2)):
                if ((l_spl1_1[i][0] == (l_spl1_2[k][12:17].strip())) and (l_spl1_1[i][1] == (l_spl1_2[k][22:26].strip()))):
                    h1.write("{:54s}{:6.2f}{:6.2f}\n".format(
                        l_spl1_2[k][0:54], float(l_spl1_1[i][2]), float(l_spl1_1[i][3])))
            for k in range(0, len(l_spl2_2)):
                if ((l_spl2_1[j][0] == (l_spl2_2[k][12:17].strip())) and (l_spl2_1[j][1] == (l_spl2_2[k][22:26].strip()))):
                    h2.write("{:54s}{:6.2f}{:6.2f}\n".format(
                        l_spl2_2[k][0:54], float(l_spl2_1[j][2]), float(l_spl2_1[j][3])))

f1.close()
g1.close()
h1.close()
f2.close()
g2.close()
h2.close()
