#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

# read the list {...}_tda.dat and store together with solvent accessibility into file {...}_acc_TDA.dat


import subprocess
import sys
import math

a = sys.argv

prot = a[1]

f = open(prot + '_scut.asa', 'r')
h = open(prot + '_tda.dat', 'r')
g = open(prot + '_acc_TDA.dat', 'w')

for line in f:
    sur_atom = line[12:17]
    sur_resid = line[22:26]
    access = float(line[54:62])
    x = h.readline()
    spl2 = x.split()
    tda = float(spl2[0])
    # Removed " / 10" Divide by 10 FOR "tool calc_solvaccess"  ###
    ln_tda = math.log(tda)
    g.write("%5s %5s %6.2f %6.2f \n" % (sur_atom, sur_resid, access, ln_tda))

f.close()
g.close()
h.close()
