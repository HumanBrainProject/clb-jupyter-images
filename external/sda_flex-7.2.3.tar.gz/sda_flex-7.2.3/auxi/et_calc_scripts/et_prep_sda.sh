### To do BEFORE running this script ###

# download pathways plugin for VMD: http://people.chem.duke.edu/~ilya/Software/Pathways/docs/pathways.html
# follow the downloading and installing instructions, most notably:
#  - give user execution rights for pathcore program (chmod u+x pathcore)
#  - link plugin folder to PATH of your system (in .bashrc or .bashrc_user)
 
echo "#######################################";
echo "USE PYTHON VERSION 2.7 or more ";
echo "#######################################";
echo "";

################################
### INPUT #################################################################################

SAC="/hits/fast/mcm/nandekpl/SDA_tests/sda/bin" # path of Solvaccess executable
VMD_PLUGIN="/hits/fast/mcm/buelowsn/plug_vmd/" # path of Pathways vmd plugin

prot1="p1" # pdb file prefix of protein with electron DONOR group
prot2="p2" # pdb file prefix of protein with electron ACCEPTOR group

d_name="FE" # name of donor atom
d_resid="254" # resid of donor (cofactor resid)
a_name="CU" # name of acceptor atom
a_resid="106" # resid of acceptor (cofactor resid)

# define atoms with solvent accessibility > acc_limit as surface atoms

acc_limit="1.0"

# consider only surface atom pairs between both proteins, for which the INTRAprotein T_DA's satisfy the equation:
# ln (T_DA (1)) + ln (T_DA (2)) >= tda_limit
# where T_DA (1) and T_DA (2) are the couplings between donor/acceptor atom and the respective surface atom
# CAUTION: Currently, the number needs to be divided by 10, for backwards compatibility. So, if you want a limit of -8, write -0.8

tda_limit="-8.0" 

# keep debugging info?
debug=1

### run ###################################################################################

echo "protein 1 (donor): ${prot1}"
echo "donor atom: ${d_name} ${d_resid}"
echo "protein 2 (acceptor): ${prot2}"
echo "acceptor atom: ${a_name} ${a_resid}"
echo "min. solvent accessibility of surface atoms: ${acc_limit}"
echo "min. natural log of coupling between donor/acceptor and surface: ${tda_limit}"

# calculate solvent accessible surface with program Solvaccess

echo "calculate solvent accessibility"

${SAC}/calc_solvaccess -i ${prot1}.pdb -o ${prot1}.asa # output is ${prot1}.asa 
${SAC}/calc_solvaccess -i ${prot2}.pdb -o ${prot2}.asa # output is ${prot2}.asa

rm -f ${prot1}.rsa
rm -f ${prot2}.rsa

# sort resulting .asa list from highest to lowest solvent accessibility (9th column) and cut list below s.a. threshold

./sort_asa.py ${prot1} ${acc_limit}
./sort_asa.py ${prot2} ${acc_limit}

# use vmd to create bonds from .pdb files > creates .psf files with bond information

echo "Creating .psf files from .pdb, generating bonds..."

module load vmd &> dump_load.out
rm dump_load.out
sed s/X1/${prot1}/g topo_prep_sda.tcl > topo_${prot1}.tcl
vmd -e topo_${prot1}.tcl -dispdev none > dump_topo.out
sed s/X1/${prot2}/g topo_prep_sda.tcl > topo_${prot2}.tcl
vmd -e topo_${prot2}.tcl -dispdev none > dump_topo_2.out

# calculate T_DA between donor and all surface atoms of donor protein (list of solvent accessible atoms calculated above) using the VMD plugin pathways, called from script sc_prep_sda.tcl
# same for T_DA between surface atoms of second protein and the acceptor

echo "Precalculating intramolecular T_DA values..."
echo "... for protein 1..."
vmd -e sc_prep_sda.tcl -dispdev none > dump_sc1.out -args ${prot1} ${d_name} ${d_resid} 1 ${VMD_PLUGIN}
echo "... for protein 2..."
vmd -e sc_prep_sda.tcl -dispdev none > dump_sc2.out -args ${prot2} ${a_name} ${a_resid} 0 ${VMD_PLUGIN}

# combine solvent accessibility file and T_DA file 

echo "Combining SAS file and T_DA file..."

./asa_to_pw.py ${prot1}
./asa_to_pw.py ${prot2}

# generate the two ET input files (.rxnac) for SDA. Line 1 in the first file is partner of line 1 in the second file etc. So all partner interactions ij of the surface atoms are in these files

echo "Creating SDA7 input files..."
./create_inp_sda.py ${prot1} ${prot2} ${tda_limit} 

# clean-up

if [ ${debug} != 1 ]
then
  rm -f topo_${prot1}.tcl
  rm -f topo_${prot2}.tcl
  rm -f ${prot1}_s.asa
  rm -f ${prot2}_s.asa
  rm -f dump_sc1.out
  rm -f dump_sc2.out
  rm -f dump_topo.out
  rm -f dump_topo_2.out
fi

echo "ALL DONE!"

