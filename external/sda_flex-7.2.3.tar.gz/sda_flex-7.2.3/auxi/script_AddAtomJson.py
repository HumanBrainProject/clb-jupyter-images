#!/usr/bin/python
#!>  \version{version 7.2.3 (2019)}
#!!
#!>  Copyright (c) 2009, 2010, 2015, 2016, 2019
#!>  Heidelberg Institute of Theoretical Studies (HITS, www.h-its.org)
#!>  Schloss-Wolfsbrunnenweg 35
#!>  69118 Heidelberg, Germany
#!>
#!>  Please send your contact address to get information on updates and
#!>  new features to "mcmsoft@h-its.org". Questions will be
#!>  answered as soon as possible.
#!>
#!>  References: see also http://mcm.h-its.org/sda7/do:c/doc_sda7/references.html:
#!>
#!>  Brownian dynamics simulation of protein-protein diffusional encounter.
#!>  (1998) Methods, 14, 329-341.
#!>
#!>  SDA 7: A modular and parallel implementation of the simulation of 
#!>  diffusional association software.
#!>  Journal of computational chemistry 36.21 (2015): 1631-1645.
#!>
#!> Authors: M.Martinez, N.J.Bruce, J.Romanowska, D.B.Kokh, P.Mereghetti, 
#!>          X. Yu, M. Ozboyaci, M. Reinhardt, P. Friedrich,
#!>          R.R.Gabdoulline, S.Richter and R.C.Wade
#!>
#!>------------------------------------------------------------------------
#!>
#!/usr/bin/python

""" Script to transform add_atoms to a Json file,
    and opposite read a Json file to update add_atoms

    Used for Web-SDA

    json output, fixed, add_atoms.json
    json input, fixed, tmp.json and output add_atoms
"""

import sys
import os
import logging
import argparse

from ModPrepareInputSDA.VdWTC_SDA import *

parser = argparse.ArgumentParser(
    description="Script to transform add_atoms to/from Json file")

parser.add_argument("-MkJson", dest="mkjson", action='store_true',
                    default="False", help="Create a Json file from add_atoms file")
parser.add_argument("-SetJson", dest="setjson", action='store_true',
                    default="False", help="Update add_atoms file from tmp.json")
parser.add_argument("-input_dir", dest="input_dir", default="./",
                    help="directory where add_atoms/tmp.json input is present")
parser.add_argument("-output_dir", dest="output_dir", default="./",
                    help="directory where add_atoms/tmp.json input will be written")

# need to force boolean type !??
parser.set_defaults(mkjson=False)
parser.set_defaults(setjson=False)

try:
    options = parser.parse_args()
# parse_arg will return an exit
except SystemExit:
    logging.error("ERROR in reading arguments")
    sys.exit(1)

# if options.delLog:
if os.path.exists("AddAtomJson.log"):
    os.remove("AddAtomJson.log")

logging.basicConfig(filename='AddAtomJson.log', level=logging.DEBUG)

logging.info("mkjson %s " % options.mkjson)
logging.info("setjson  %s " % options.setjson)
logging.info("input dir  %s " % options.input_dir)
logging.info("output dir  %s " % options.output_dir)


# Check argument, only one set to true
if ((options.mkjson | options.setjson) == False) | \
   ((options.mkjson & options.setjson) == True):
    logging.error("Need to select only one option")
    print("Need to select one option -MkJson or -SetJson")

main_vdw = VdWTC_SDA(options.input_dir)

if options.mkjson:
    print("MkJson")
    #main_vdw = VdWTC_SDA( options.input_dir )
    main_vdw.MakeJson(options.output_dir)

if options.setjson:
    print("SetJson")
    # read 'tmp.json' by default
    main_vdw.ReadJson()
    # append add_atoms by default, and overwritte 'add_atoms'
    main_vdw.write_file()
