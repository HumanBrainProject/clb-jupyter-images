



// singleton pattern from book
var builder = function() {
	
	// here are our private methods and variables
	var privateVariable = 'something private';
	function showPrivate(){
	   console.log( privateVariable );
	}
	
	// public variables and methods (which can access private variables and methods )
	return {
		publicMethod:function(){
			showPrivate();
		},
		update:function( id, name ){
			alert ("in function "+ id + " " + name );
		},
		//solutes_grid:  ko.observableArray(),
		
		create_solgrids:function( nb ) {
			for (var i=0;i<nb;i++) {
				//alert("create new");
				this.solutes_grid.push( {nbsol: 1, pdb: '',electro: '', qeff:'', desolv:'',hydro:'',replj:'', nb_lenjon:0, lenjon:'',
										 iflex:true, isurf:false, irot:true, nb: i, listconf :'list_conformation.dat'} );
			}
			//ko.observalbeArray( this.solutes_grid);
			//alert("solgrid"+ this.solutes_grid);
		},
	    publicVar:'the public can see this!',
	    enum_type_calc:[ {name2 : 'sda_2proteins', id: 0 },
	                     {name2 : 'sda_koff', id: 1 }, 
	                     {name2 : 'sda_energy', id: 2 },
	                     {name2 : 'sdamm', id :3 }
	                   ],
	    // do not manage to make direct selection, checked exist
	    //select_type_calc: ko.observable('1'),
	    select_type_calc: '',      
	    solute:'',
	    electrostatic:'',
	    //nb_solutes: '0',
	    // ok works
	    //solutes_grid: ko.observableArray([ {pdb:'pdb1',electro:'elec1'}, {pdb:'pdb2',electro:'elec2'} ]),
	    solutes_grid:  ko.observableArray(),
	    // works if only one and data
	    //solutes_grid: ko.observable( {pdb: 'pdb1',electro: 'elec1'} ),
	    //type_cacluation
	    total_solutes: ko.observable(0),
	    total_types_solutes: ko.observable(0),
	    //timestep, show timestep visible only when type_calc is full
	    //this.show_timestep 
	    //show_timestep: ko.observable(false),
	    //show_timestep: '',
	    // called once when loaded
	    //show_timestep: ko.computed(function() {
	    //	alert("recomputed "+ ( ((this.total_solutes>1) && (this.total_types_solutes>1)) ) ? true : false );
	    //	return ( ( ((this.total_solutes()>1) && (this.total_types_solutes()>1)) ) ? true : false );
	    //}, this ),
	    timestep_variable: ko.observable(false),
	    
	    dt1: ko.observable(1.0),
	    dt2: ko.observable(20.0),
	    swd1: ko.observable(50.0),
	    swd2: ko.observable(90.0)
	};
	
	//this.show_timestep = ko.computed(function() {
    //	alert("recomputed "+ ( this.total_solutes && this.total_solutes ) ? true : false );
    //	return ( ( this.total_solutes && this.total_solutes ) ? true : false );
    //}, this );
};


var single = builder();


var next_entry = function( id, name ) {
	alert("next_entry name:"+ name + " id:" + id);
	
	if ( name == 'type_calc') {
		
		//alert("value of selected " + single.select_type_calc());
		single.select_type_calc = id;
		alert("value of selected " + single.select_type_calc);
		
		if ( single.select_type_calc != 'sdamm' ) {
			//alert("not sdamm");
			single.total_solutes(2);
			single.total_types_solutes(2);
		} else {
			$('#group_type_calc').show();
		}
		
		if ( ((single.total_solutes() > 1) && (single.total_types_solutes() > 1)) ) {
			$('#group_timestep').show();
			//$('#timestep1').buttonset();
			$('#group_timestep #butcontinue_id2').hide();
		}
		
		
		
		
	} else if ( name == 'timev') {
		//alert('timev');
		if ( id == 'checktime0' ) {
			// need to use setter function, otherwise no update
			//single.timestep_variable = true;
			single.timestep_variable(true);
			//alert ('modif value to true '+ single.timestep_variable );
		} else if ( id == 'checktime1') {
			
			single.timestep_variable(false);
			//alert ('modif value to false '+ single.timestep_variable );
		}
		$('#butcontinue_id2').show();
		
	// deal with all button continue
	} else if ( name == 'continue' ) {
		alert('value of total_solutes '+ single.total_solutes() );
		//alert('value of total_solutes '+ single.total_types_solutes() );
		//alert('value of dt1 '+ single.dt1() );
		if ( id == '1' ) {
			//alert( 'button continue == 1');
			next_entry( single.select_type_calc, 'type_calc' );
		} else if ( id == '2' ) {
			//next_entry( 'group_solutes_grids')
			single.create_solgrids( single.total_types_solutes() );
			$('#group_solutes_grids').show();
			
		} else {
			alert('button other');
		}
	}
};


$(document).ready(function() {
	//alert("sda_builder");
	//$("#radioset").buttonset();
	// do not work, here
	//$("#radioset2").buttonset();
	
	
	$('.latent').hide();
	
	//var single = builder();
	//alert ( single.enum_type_calc );
	
	ko.applyBindings( single );
	//ko.observable( single.timestep_variable);
	
	// can apply to all even before if it is hidden
	//$("#radioset2").buttonset();
	//$('#timestep1').buttonset();
	$('.radiotobutton').buttonset();
	
	// all radio type will react, we can get id and name on receipt
	$('.radio_type').click(function() {
	//$(":radio").click(function() {
	//$('class'^⁼'radio_type').click(function() {
		var id = this.id;
		var name = this.name;
		//alert("button clicked: "+ id + " " + name );
		
		// can call both
		//single.update( id, name );
		next_entry( id, name );
	});
	
	//ko.applyBindings( single );
	
	
	
	//single.publicMethod();  // logs 'something private'
	//console.log( single.publicVar ); // logs 'the public can see this!'
	//alert( single.publicVar );
	//alert('nb_solute'+ single.nb_solutes);
	
	// works only here
	//$("#radioset2").buttonset();
	
});




