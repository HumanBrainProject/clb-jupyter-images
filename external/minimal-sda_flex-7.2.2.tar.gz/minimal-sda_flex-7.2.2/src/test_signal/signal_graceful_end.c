
#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<math.h>

/* gcc -o signal_graceful_end -lm signal_graceful_end.c
*/


int loop = 1;

void sig_handler(int signo)
{
	printf("received signal %d\n", signo);
	loop = 0;
}

int main(int argc, char **argv)
{
	if (signal(SIGUSR2, sig_handler) == SIG_ERR)
		printf("\ncan't catch SIGUSR2\n");
	// A long long wait so that we can easily issue a signal to this process
	double x = 0;
	while(loop) {
		x = sin(x);
	}
	printf("graceful termination, loop=%d\n", loop);
	return 0;
}

