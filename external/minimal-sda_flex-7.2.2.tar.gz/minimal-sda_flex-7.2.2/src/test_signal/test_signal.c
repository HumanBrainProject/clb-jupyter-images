#include <stdio.h>
#include <unistd.h>
#include <signal.h>
 
/*
 * To compile
 * gcc -c csignum.c
 * gcc -o ctest_signal test_signal.c
 * run and in another console
 * kill -s INT 27931
 *
 */
 void handler_function(int);
 
 int main()
 {
     /*
      * attach handler for SIGINT
      */
     signal(SIGINT,handler_function);
 
     while(1)
     {
         printf("Program executing (1s delay between updates)...\n");
         sleep(1);
     }
 
     return(0);
 }
 
 
 void handler_function(int signum)
 {
     printf(">>> Caught signal: %d; executing handler <<<\n", signum);
 }
