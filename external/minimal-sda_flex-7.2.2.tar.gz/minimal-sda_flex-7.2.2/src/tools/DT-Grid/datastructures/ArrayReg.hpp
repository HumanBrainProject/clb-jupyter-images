/*! \file ArrayReg.hpp
 *  \brief Define arrays of regular type used in any of the DT-Grid layers.
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 * 
 *  \class ArrayReg 
 *  
 *  Used for storing values of input_data type
 *  Value_List_3D array is created using this class
 */

#ifndef ARRAYREG_HPP_
#define ARRAYREG_HPP_

template<typename T>
class ArrayReg {
	~ArrayReg();

public:

	void Set_Regular_Array_Values(T*,int);
	void Reset_Regular_Array_Values(void);

	template <class M, class H>
	friend class DTGrid2D;
	template <class M, class H>
	friend class DTGrid3D;
	friend class DTGrid3Dex;
	template <class M, class H>
	friend class DTGrid1D;

private:

	T *Array;
	T *Array_Copy; //! copy of the original pointer address.

};

//! ArrayReg destructor
template<typename T>
ArrayReg<T>::~ArrayReg()
{
	delete[] Array;
	//delete[] Array_Copy;
}

//! Array setup
/*!
 *
 * Read the 'value' array and store.
 * \param array pointer to the array that stores the 'value' array.
 * \param I length of the 'value' array.
 */
template<typename T>
void ArrayReg<T>::Set_Regular_Array_Values(T* array,int I){

	Array = new (std::nothrow) T [I];
	for (int i =0;i<I;i++)  {
		Array[i]=array[i];
	}
	Array_Copy = Array;
}

//! Reset pointer to the array
/*!
 *
 * This function resets the pointer back to its original value!
 * It does not reset the values that the pointer originally points to!
 * Currently not used!
 */
template<typename T>
void ArrayReg<T>::Reset_Regular_Array_Values(void){
	Array_Copy = Array;
}


#endif /* ARRAYREG_HPP_ */
