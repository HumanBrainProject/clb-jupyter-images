/*! \file ArrayPtr.hpp
 *  \brief Define the array for storing pointers into ArrayPrs
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 *  
 *  ArrayPtr class is used for storing pointers to ArrayPrs objects
 *  The class is used by acc pointer arrays (Ptr_List_3D, Ptr_List_2D, Ptr_List_1D)
 *  DTGrid paper by Nielsen, does not mention about this data structure (?) 
 *  Instead of using pointers numerical indices are kept in the original work
 *  Nevertheless using pointers seems more efficient
 */

#ifndef ARRAYPTR_HPP_
#define ARRAYPTR_HPP_
#include "ArrayPrs.hpp"
using namespace std;

template<typename T, typename K>
class ArrayPtr {
	
	~ArrayPtr();
	ArrayPtr();

public:

	template <class M, class H>
	friend class DTGrid2D;
	template <class M, class H>
	friend class DTGrid3D;
	friend class DTGrid3Dex;
	template <class M, class H>
	friend class DTGrid1D;

	//typedef ArrayPrs<K>* newtype;
	void Set_Pointer_Array_Values(typename ArrayPrs <K>::PairArray *,K *,int, int);
	void Set_Pointer_Array_Values(T *,K *,int, int);
	void Reset_Set_Pointer_Array_Values(void);

private:

	int alloc_size1;
	int alloc_size2;
	
	typename ArrayPrs <K>::PairArray **PtrArray;
	typename ArrayPrs <K>::PairArray **PtrArray_Copy; //! copy of the original pointer address.

	T ** PtrArrayReg;
	T ** PtrArrayReg_Copy; //! copy of the original pointer address.
};

//! ArrayPtr constructor
/*!
 * input void
 */
template<typename T, typename K>
ArrayPtr<T,K>::ArrayPtr(){
	alloc_size1 = 0;
	alloc_size2 = 0;
}

//! ArrayPtr destructor
/*!
 * \warning Valgrind complains about the parts commented out in this function
 * It does not like the pointers themselves to be deleted!
 */
template<typename T, typename K>
ArrayPtr<T,K>::~ArrayPtr()
{
	/*if (alloc_size1 != 0){
		for (int i = 0; i < alloc_size1; i++){
			delete PtrArray[i];
		}
	}*/
	if (alloc_size1 != 0){
		delete[] PtrArray;
	}
	else{
		//delete PtrArray;
	}
	//delete PtrArray;
	//delete PtrArray_Copy;
	/*if (alloc_size2 != 0){
		for (int i = 0; i < alloc_size2; i++){
			delete PtrArrayReg[i];
		}
	}*/
	if (alloc_size2 != 0){
		delete[] PtrArrayReg;
	}
	else{
		//delete PtrArrayReg;
	}
	//delete PtrArrayReg_Copy;
}

//! Setup the array that stores the IndexPair values.
/*!
 * This function initializes the array for the 'value' array of (N-1) dimensions of type=IndexPair
 * \param pair_array pointer into the icoord array.
 * \param PtArray pointer into another array of type ArrayPtr.
 * \param I length of the pair_array
 * \param J length of the PtArray
 * 
 * \note this function is overloaded. See the other function.
 */
template<typename T, typename K>
void ArrayPtr<T,K>::Set_Pointer_Array_Values(typename ArrayPrs <K>::PairArray *pair_array, K * PtArray, int I, int J){

	alloc_size1 = J;
	PtrArray = new (nothrow) typename ArrayPrs <K>::PairArray * [J];

	int count = J-1;
	for (;count>=0;count--)  {

		//PtrArray[count] = new (nothrow) typename ArrayPrs <K>::PairArray;
		PtrArray[count] = &(pair_array[PtArray[count]]);
	}
	PtrArray_Copy = PtrArray;
}

//! Setup the array that stores the IndexPair values.
/*!
 * This function initializes the array for the 'value' array of (N-1) dimensions of type=IndexPair
 * \param pair_array pointer into the icoord array.
 * \param PtArray pointer into another array of type ArrayPtr.
 * \param I length of the pair_array
 * \param J length of the PtArray
 * 
 * \note this function is overloaded. See the other function.
 */
template<typename T, typename K>
void ArrayPtr<T,K>::Set_Pointer_Array_Values(T *pair_array, K * PtArray, int I, int J){

	alloc_size2 = J;
	PtrArrayReg = new (nothrow) T* [J];

	int count = J-1;
	for (;count>=0;count--)  {

		//PtrArrayReg[count] = new T;
		PtrArrayReg[count] = &(pair_array[PtArray[count]]);
	}
	PtrArrayReg_Copy = PtrArrayReg;
}

//! Reset the address that the pointer stores
/*!
 *
 * This function resets the pointer back to its original value!
 * It does not reset the values that the pointer originally points to!
 */
template<typename T, typename K>
void ArrayPtr<T,K>::Reset_Set_Pointer_Array_Values(void){
	PtrArray_Copy = PtrArray;
	PtrArrayReg_Copy = PtrArrayReg;
}

#endif /* ARRAYPTR_HPP_ */
