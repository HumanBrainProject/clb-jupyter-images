
BIN=../../../bin
AUXI=../../../auxi
GNUPLOT_EXE=gnuplot

#==============================================
export BIN
export AUXI
export GNUPLOT_EXE
#==============================================

#### run the pmf simulation
$BIN/sda_flex sda_prometcs.in > sda.out
$GNUPLOT_EXE make_plot.gp
