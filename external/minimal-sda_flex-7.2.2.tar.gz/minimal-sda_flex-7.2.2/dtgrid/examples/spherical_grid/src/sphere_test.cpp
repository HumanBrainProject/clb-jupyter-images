/*! \file sphere_test.cpp
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 * 
 * Description : This test program creates sphere objects of various different
 *               sizes with the same "shell" thickness, and then compress them into a DT-Grid structure 
 *               and compares the execution times of a simple operation on these DT-Grids.
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <cstdlib>
#include <ctime>
#include <vector>
#include "../../../datastructures/DTGrid3D.hpp"
#include "./geometry.hpp"
#include <limits>

// to add the randomly accessed values
// this sum usually exceeds the limit of maximum stored in a double variable.
typedef std::numeric_limits< long double > ldbl;

// to store the grid information and execution statistics for each grid size tested
struct stats{
    int dimension; // grid dimension (cubic) in number of grid points
    long file_size; // size of the UHBD/DT-Grid files required to store the grids in disk
    float exec_time1; // execution time using direct random access operations
    float exec_time2; // execution time using random cell access operations
};

// Here we test only size of binary files!
// ASCII format files are typically much larger
long size_file(char * file_n){
    std::ifstream is (file_n, std::ifstream::binary);
    long length;

    if (is) {
        // get file length
        is.seekg (0, is.end);
        length = is.tellg();
        is.seekg (0, is.beg);
        is.close();
    }
    return length;
}

// main program call
int main(int argc, char* argv[]) {
    // check the number of arguments provided by the user
    if (argc < 5) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << " Number_of_access_operations Seed_number grid_edge_length skin_thickness" << std::endl;
        std::cerr << "Note:  " << "If the input for the seed number is 0 or smaller, then the clock time will be used!" << std::endl;
        std::cerr << "       " << "Skin thickness should not be larger than half of the size of the grid edge length! " << std::endl;
        return 1;
    } 

    unsigned int num_acc_op;
    int seed, dim;
    int thckns_skn;

    istringstream ss(argv[1]);
    if (!(ss >> num_acc_op))
        std::cerr << "Invalid integer value for: number of access operations to be performed" << argv[1] << std::endl;

    istringstream ss2(argv[2]);
    if (!(ss2 >> seed))
        std::cerr << "Invalid integer value for: a seed for random number generator" << argv[2] << std::endl;
    
    // The dimension provided by the user!
    istringstream ss3(argv[3]);
    if (!(ss3 >> dim))
        std::cerr << "Invalid integer value for: number of grid points that makes a grid edge" << argv[3] << std::endl;
    
    // The thickness in terms of number of points (as for the edge length)
    istringstream ss4(argv[4]);
    if (!(ss4 >> thckns_skn))
        std::cerr << "Invalid integer value for: number of grid points that makes a grid edge" << argv[4] << std::endl;
    
    if (thckns_skn > (dim/2)){
    	std::cerr << "       " << "Skin thickness should not be larger than half of the size of the grid edge length! " << std::endl;
    	return 1;
    }
    
    // provide the seed the random number generator
    if (seed > 0)
        srand ( seed );
    else 
        srand ( static_cast <unsigned> (time(NULL)) );

    int inner_dim, rn1, rn2, rn3;
    //const int thckns_skn = 50; // skin thickness. can be changed to test the results for different interaction 'skin' thicknesses
    const float  PI_F=3.14159265358979f; // pi value
    float co, var;
    double sum1=0.0, sum2=0.0, sum3=0.0;
    double time_val1, time_val2;

    //usefull when multiple grid size tests performed at once.
    stats stats_local;
    std::vector<stats> stats_regular;
    std::vector<stats> stats_dt;

    clock_t init, final; // check the time and store in order to obtain the execution time.

    // grid files will be created and deleted automatically during the program run. 
    // therefore, please do not delete these files during program execution
    char DTFILE [] = "object.dtgrd";
    char uhbdFILE [] = "object.grd";
    char out_file_n [] = "time.txt";

    FILE* output_file;
    output_file = fopen(out_file_n,"a");

    //create a sphere object. can be change to a torus or a cube from the object3D class.
    object3D *sphere;
    float * flist;
    float *** rand_mt = 0;
    float *** rand_m;


    flist = new float [8];
    for (int i= 0; i<8; i++)
        flist[i] = 0.0;


    //Dimension of the cubic grid
    // Could be looped over different grid size:
    // for (dim=100; dim<=800; dim += 100)

    //float *** rand_m;
    // The grid will store random floating point numbers between 0.0 and 1.0
    rand_m = new float ** [dim];
    for (int x=0; x<dim; x++){
    	rand_m[x] = new float * [dim];
    	for (int y=0; y<dim; y++)
    		rand_m[x][y] = new float [dim];
    }

    for (int i = 0;i<dim;i++){
    	for (int j = 0;j<dim;j++){
    		for (int k = 0; k<dim; k++){
    			rand_m[i][j][k] = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
    		}
    	}
    }

    std::cout << "Dimension: " << dim << std::endl;

    //Allocate memory for the matrix and create the shape
    inner_dim = dim - 2 * thckns_skn;
    sphere = new object3D(dim);
    sphere->sphere(dim, inner_dim);
    //Write the grid files into the disk storage.
    sphere->write_dt_file_binary(1, rand_m, dim, dim, dim);
    sphere->write_uhbd_file_binary(dim, dim, dim);
    delete sphere;


    //Delete the random potential matrix before the random access test
    for (int x=0; x<dim; x++){
    	for (int y=0; y<dim; y++)
    		delete[] rand_m[x][y];
    	delete[] rand_m[x];
    }
    delete [] rand_m;

    //Create and initialize the DTGrid3D object
    DTGrid3D <float,int> * dtGrid;
    dtGrid = new DTGrid3D <float,int>(DTFILE, 1.0, 0.0);

    //accessxyz function test
    sum1 = 0.0;
    sum2 = 0.0;

    //start the clock for random access to grid points using DT-Grid
    init=clock();
    //start the random access operations
    for (unsigned int i = 0;i<num_acc_op;i++){
    	rn1 = rand() % (dim-1);
    	rn2 = rand() % (dim-1);
    	rn3 = rand() % (dim-1);
    	sum1 += dtGrid->accessxyz(rn3,rn2,rn1);
    }
    //stop the clock
    final=clock()-init;
    time_val1 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

    //start the clock for random access to grid cells using DT-Grid
    init=clock();
    //start the random cell access operations
    for (unsigned int i = 0;i<num_acc_op;i++){
    	rn1 = rand() % (dim-2);
    	rn2 = rand() % (dim-2);
    	rn3 = rand() % (dim-2);

    	//initialize all the values to zero
    	for (int ifl= 0; ifl<8; ifl++) flist[ifl] = 0.0;

    	dtGrid->getCell2(flist,rn3,rn2,rn1);
    	sum2 += flist[0];
    	sum2 += flist[1];
    	sum2 += flist[2];
    	sum2 += flist[3];
    	sum2 += flist[4];
    	sum2 += flist[5];
    	sum2 += flist[6];
    	sum2 += flist[7];
    }
    //stop the clock
    final=clock()-init;
    time_val2 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

    // We actually don't need this value.
    printf("Sum of the values: %15f %15f\n", sum1, sum2);

    //store the stats for DT-Grid
    stats_local.dimension = dim;
    stats_local.file_size = size_file(DTFILE);
    stats_local.exec_time1 = time_val1;
    stats_local.exec_time2 = time_val2;
    stats_dt.push_back(stats_local);

    //delete the object and remove the grid file from storage
    delete dtGrid;
    remove( DTFILE );

    //Generate a new random number filled matrix for regular grid access operations.
    //float *** rand_m;
    rand_m = new float ** [dim];
    for (int x=0; x<dim; x++){
    	rand_m[x] = new float * [dim];
    	for (int y=0; y<dim; y++)
    		rand_m[x][y] = new float [dim];
    }

    for (int i = 0;i<dim;i++){
    	for (int j = 0;j<dim;j++){
    		for (int k = 0; k<dim; k++){
    			rand_m[i][j][k] = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
    		}
    	}
    }

    // initialize the sums to zero.
	sum1 = 0.0;
    sum2 = 0.0;

    //
	//start the clock for random access to grid points using a regular Cartesian grid
    init=clock();
    //perform the random access operations
    for (unsigned int i = 0;i<num_acc_op;i++){
    	rn1 = rand() % (dim-1); 
    	rn2 = rand() % (dim-1); 
    	rn3 = rand() % (dim-1); 
    	sum1 += rand_m[rn3][rn2][rn1];
    }
    //stop the clock
    final=clock()-init;
    time_val1 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

    //start the clock for random access to grid 8 points that define a cell using regular Cartesian grid
    init=clock();
    //perform the random access operations
    for (unsigned int i = 0;i<num_acc_op;i++){
    	rn3 = rand() % (dim-2);
    	rn2 = rand() % (dim-2);
    	rn1 = rand() % (dim-2);
    	sum2 += rand_m[rn1][rn2][rn3];
    	sum2 += rand_m[rn1][rn2][rn3+1];
    	sum2 += rand_m[rn1][rn2+1][rn3];
    	sum2 += rand_m[rn1+1][rn2][rn3];
    	sum2 += rand_m[rn1][rn2+1][rn3+1];
    	sum2 += rand_m[rn1+1][rn2+1][rn3];
    	sum2 += rand_m[rn1+1][rn2][rn3+1];
    	sum2 += rand_m[rn1+1][rn2+1][rn3+1];
    	}
    	//stop the clock
		final = clock() - init;
    	time_val2 = static_cast <double> (final) / static_cast <double> (CLOCKS_PER_SEC);

    	// We don't need this value.
    	printf("Sum of the values: %15f %15f\n", sum1, sum2);

    	//store the statistics for the regular grid
    	stats_local.dimension = dim;
    	stats_local.file_size = size_file(uhbdFILE);
    	stats_local.exec_time1 = time_val1;
    	stats_local.exec_time2 = time_val2;

    	stats_regular.push_back(stats_local);

    	//fprintf(output_file, "%7d %12d %12f %12f\n", dim, size_file(uhbdFILE), time_val1, time_val2);

    	// remove the UHBD grid file from the disk storage.
    	remove( uhbdFILE );

    	//free the memory allocated for the matrix that store the grid 
    	for (int x=0; x<dim; x++){
    		for (int y=0; y<dim; y++)
    			delete[] rand_m[x][y];
    		delete[] rand_m[x];
    	}
    	delete [] rand_m;

    	//Write the statistics to the output file
    	//fprintf(output_file, "# Dime Size_dt Size_reg Rand_acc_dt Rand_acc_reg Rand_vox_dt Rand_vox_reg\n");
    for (int i = 0;i<stats_regular.size();i++){
        fprintf(output_file, "%4d %12ld %12ld %12f %12f %12f %12f\n",stats_regular[i].dimension, \
        stats_dt[i].file_size, stats_regular[i].file_size, stats_dt[i].exec_time1, \
        stats_regular[i].exec_time1, stats_dt[i].exec_time2, stats_regular[i].exec_time2);
        //stats_regular[i].dimension;
    }

    fclose(output_file);
    return 0;
}
