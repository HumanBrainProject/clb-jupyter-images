/*! \file geometry.cpp
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 * 
 *  \class object3D
 *  Used for storing several different geometrical shapes only for basic test purposes.
 *  Currently, spherical, cubic and toroidal objects can be created.
 */
#include <iostream>
#include <fstream>
#include <math.h>
#include <stdlib.h>
#include "./geometry.hpp"
#include "../../../tools/DTgrd.hpp"

//! object3D constructor
/*!
 * \param dim defines the dimension of a cubic rectangular grid in which the geometrical object will be described/
 */
object3D::object3D(int dim){
	dimension = dim;
	radius = 0; // for a sphere
	separation_distance = 0; // for a double sphere
	side = 0;
	rTorus = 0; // for a torus
	rShape = 0; // for a torus

	grid = Allocate();
}

//! object3D destructor
object3D::~object3D(){
	if (grid){
		Deallocate(grid);
		delete[] grid;
	}
}

//! allocate memory for a regular boolean grid 
/*!
 * This will store a boolean grid for the description of the required shape.
 * The size (in each direction) is defined by "dimension"
 */
bool *** object3D::Allocate(){
	bool *** grd;
	grd = new bool ** [dimension];
	for (int x=0; x<dimension; x++){
		grd[x] = new bool * [dimension];
		for (int y=0; y<dimension; y++)
			grd[x][y] = new bool [dimension];
	}
	for (int x=0; x<dimension; x++){
		for (int y=0; y<dimension; y++){
			for (int z=0; z<dimension; z++){
				grd[x][y][z] = false;
			}
		}
	}
	return grd;
}

//! deallocate memory for the regular boolean grid 
void object3D::Deallocate(bool *** grd)
{
	for (int x=0; x<dimension; x++){
		for (int y=0; y<dimension; y++)
			delete[] grd[x][y];
		delete[] grd[x];
   }
}

//! print a 2D slice from the regular grid
/*!
 * This will allow the user to inspect the shape without a need to print the full grid and visualize with an external software.
 * The occupied volume is represented with an asterisk sign, whereas the rest of the structure with empty space.
 */
void object3D::print_slice(int k){
	for (int i=0; i< dimension; i++){
		for (int j=0; j< dimension; j++){
			if (grid[i][k][j] == true )
				std::cout << "*";
			else
				std::cout << " ";
		}
		std::cout << "\n";
	}
}

//! create a UHBD file (type ASCII) and write the shape grid into it
/*!
 * This is useful only if you want to visualize using a molecular visualization software, e.g. VMD
 * Note that ascii formats, sometimes are not recognized by VMD, in that case you can try the binary version.
 */
void object3D::write_uhbd_file_ascii(int dim_i, int dim_j, int dim_k){

	char output_file_name [] = "object.grd";
	FILE* output_file;
	output_file = fopen(output_file_name,"w");

	//WRITE THE UHBD FILE HEADER
	std::cout << "Writing the UHBD (ascii) to the output file ..." << std::endl;
	fprintf(output_file, "%72s\n", "Sphere                                                                  ");
	fprintf(output_file, "%12.5E%12.5E%7d%7d%7d%7d%7d\n", 1.0, 1.0, 3, 0, 0, 1, 1);
	fprintf(output_file, "%7d%7d%7d%12.5E%12.5E%12.5E%12.5E\n", dim_i, dim_j, dim_k, 0.1, 0.0, 0.0, 0.0);
	fprintf(output_file, "%12.5E%12.5E%12.5E%12.5E\n", 0.0, 0.0, 0.0, 0.0);
	fprintf(output_file, "%12.5E%12.5E%7d%7d\n", 0.0, 0.0, 1, 1);
	//Write the body of the UHBD file
	int counter;
	for (int k=0; k < dim_k ; k++){
		counter = 0;
		fprintf(output_file, "%7d%7d%7d\n", k+1, dim_i, dim_j);
		for (int j=0; j < dim_j ; j++){
			for (int i=0; i < dim_i ; i++){
				fprintf(output_file, "%12.5E", (float) grid[i][j][k]);
				counter++;
				if (counter == 6){
					fprintf(output_file, "\n");
					counter = 0;
				}
			}
		}
		if (counter != 0)
			fprintf(output_file, "\n");
	}
	fclose(output_file);
}

//! create a UHBD file (type binary) and write the shape grid into it
/*!
 * This is useful only if you want to visualize using a molecular visualization software, e.g. VMD
 */
void object3D::write_uhbd_file_binary(int dim_i, int dim_j, int dim_k){
	char output_file_name [] = "object.grd";
	char Title [] = "Sphere                                                                  ";

	float scale = 1.0, spacing = 0.1;
	float dummy1 = 0.0, dummy2 = 0.0, dummy3 = 0.0, dummy4 = 0.0, dummy5 = 0.0, dummy6 = 0.0, dummy7 = 0.0;
	float o_x = 0.0, o_y = 0.0, o_z = 0.0;
	int idummy1 = 0, idummy2 = 0, idummy3 = 0, idummy4 = 0, idummy5 = 0;
	int one = 1, dimi = dim_i, dimj = dim_j, dimk = dim_k;

	FILE* output_file;
	output_file = fopen(output_file_name,"wb");

	//WRITE THE UHBD FILE HEADER
	int binary_uhbd_type = 4;
	int binary_file_vmd_flag = 160;
	std::cout << "Writing the UHBD (binary) to the output file ..." << std::endl;
	fwrite(&binary_file_vmd_flag, sizeof(int),1,output_file);
	fwrite(&Title, sizeof(char), 72, output_file);
	fwrite(&scale, sizeof(float),1,output_file);
	fwrite(&dummy1, sizeof(float),1,output_file);
	fwrite(&binary_uhbd_type, sizeof(int),1,output_file);
	fwrite(&idummy1, sizeof(int),1,output_file);
	fwrite(&idummy2, sizeof(int),1,output_file);
	fwrite(&one, sizeof(int),1,output_file);
	fwrite(&idummy3, sizeof(int),1,output_file);
	fwrite(&dimi, sizeof(int),1,output_file);
	fwrite(&dimj, sizeof(int),1,output_file);
	fwrite(&dimk, sizeof(int),1,output_file);
	fwrite(&spacing, sizeof(float),1,output_file);
	fwrite(&o_x, sizeof(float),1,output_file);
	fwrite(&o_y, sizeof(float),1,output_file);
	fwrite(&o_z, sizeof(float),1,output_file);
	fwrite(&dummy2, sizeof(float),1,output_file);
	fwrite(&dummy3, sizeof(float),1,output_file);
	fwrite(&dummy4, sizeof(float),1,output_file);
	fwrite(&dummy5, sizeof(float),1,output_file);
	fwrite(&dummy6, sizeof(float),1,output_file);
	fwrite(&dummy7, sizeof(float),1,output_file);
	fwrite(&idummy4, sizeof(int),1,output_file);
	fwrite(&idummy5, sizeof(int),1,output_file);

	//Write the body of the UHBD file
	float f_value;
	int i_value;

	i_value = sizeof(char) * 72 + sizeof(int) * 11 + sizeof(float) * 11;
	fwrite(&i_value, sizeof(int),1,output_file);

	for (int k=0; k < dimk ; k++){
		i_value = sizeof(int) * 3;
		fwrite(&i_value, sizeof(int),1,output_file);
		i_value = k+1;
		fwrite(&i_value, sizeof(int),1,output_file);
		fwrite(&dimi, sizeof(int),1,output_file);
		fwrite(&dimj, sizeof(int),1,output_file);
		i_value = sizeof(int) * 3;
		fwrite(&i_value, sizeof(int),1,output_file);
		i_value = sizeof(float) * dimi * dimj;
		fwrite(&i_value, sizeof(int),1,output_file);
		for (int j=0; j < dimj ; j++){
			for (int i=0; i < dimi ; i++){
				f_value = (float) grid[i][j][k];
				fwrite(&f_value, sizeof(float),1,output_file);
			}
		}
		i_value = sizeof(float) * dimi * dimj;
		fwrite(&i_value, sizeof(int),1,output_file);
	}
	fclose(output_file);
}

//! create a DT-Grid file (type binary) and write the shape grid into it
/*!
 * This function may be used for evaluation purposes.
 */
void object3D::write_dt_file_binary(int grid_type_flag, float *** rand_m, int dim_i, int dim_j, int dim_k)
{
	char output_file_name [] = "object.dtgrd";
	FILE* output_file;
	output_file = fopen(output_file_name,"wb");

	DT_FILE<float> * dtfile;
	dtfile = new DT_FILE<float>(grid_type_flag, dim_i, dim_j, dim_k);
	dtfile->Generate_DTGrid(grid,rand_m);
	dtfile->write_dtgrdfile_binary_nouhbd(output_file);
	fclose(output_file);
}

//! create a spherical object and store the shape on a boolean grid
int object3D::sphere(int dia_o, int dia_i){
	int r, r2, half_length;

	if (dia_o > (dimension-8) or dia_o < 0)
		dia_o = dimension - 8; // diameter outside

	if (dia_i < 0 or dia_i > dia_o)
		dia_i = 0; // diameter inside (that define the spherical hollow part inside)

	radius = dia_o/2;
	half_length = dimension / 2;

	// fill in the grid to create a spherical object with a cavity inside
	// space occupied by the object will be marked as "true" and the other parts as "false"
	for (int z=-half_length; z<(dimension-half_length); z++){
		for (int y=-half_length; y<(dimension-half_length); y++){
			for (int x=-half_length; x<(dimension-half_length); x++){
				r2 = (x*x)+(y*y)+(z*z);
				r = (int) (sqrt((double) r2) + 0.5);
				if (r <= radius and r >= (dia_i/2))
					grid[x+half_length][y+half_length][z+half_length] = true;
			}
		}
	}
	return 0;
}

//! create a double-spherical object and store the shape on a boolean grid
int object3D::double_sphere(int rad_o, int rad_i){
	int r, r2, half_length;

	separation_distance = 8; // distance between the spheres

	if (rad_o > ((dimension-4-separation_distance)/4) or rad_o < 0)
		rad_o = (dimension - 4 - separation_distance) / 4; // outer radius of each of the spheres

	if (rad_i < 0 or rad_i > rad_o)
		rad_i = 0; // inner radius of each of the spheres (this defines the spherical cavity inside each of the two spheres)

	radius = rad_o;
	half_length = dimension / 2; //half length of the regular cubic grid

	//compute the shape and store in a boolean type grid
	//Note that the spheres are identical in shape
	for (int z=-half_length; z<0; z++){
		for (int y=-half_length; y<0; y++){
			for (int x=-half_length; x<0; x++){
				r2 = (x*x)+(y*y)+(z*z);
				r = (int) (sqrt((double) r2) + 0.5);
				if (r < radius and r > rad_i){
					grid[x+half_length][y+half_length][z+half_length] = true;
					grid[x+dimension][y+half_length][z+half_length] = true;
				}
			}
		}
	}
	return 0;
}

//! create a toroidal object and store the shape on a boolean grid
int object3D::torus(int rT, int rS){
	rTorus = rT; //thickness of the torus
	rShape = rS; // maximum length of the torus in number of grid points.
	dimension = rShape + 6; // overwrite the dimension size according to the object size 

	int r, r2, half_length;
	half_length = dimension / 2;

	//compute the shape and store in a boolean type grid
	for (int z=-half_length; z<half_length; z++){
		for (int y=-half_length; y<half_length; y++){
			for (int x=-half_length; x<half_length; x++){
				r2 = (rShape - (int) sqrt((float) (x*x + y*y)))*(rShape - (int) sqrt((float) (x*x + y*y))) +(z*z);
				r = (int) (sqrt((double) r2) + 0.5);
				if (r == rTorus)
					grid[x+half_length][y+half_length][z+half_length] = true;
			}
		}
	}
	return 0;
}

//! create a cubical object and store the shape on a boolean grid
/*!
 * create a cubic onject with a cubic cavity inside similar to other objects described here.
 */
int object3D::cube(int si_o, int si_i = -1){

	int i, j, k;
	int margin_o, margin_i;
	bool *** outer_cube; // grid to store the shape for the outer cube
	bool *** inner_cube; // grid to store the shape for the inner cavity

	if (si_o > dimension or si_o < 0)
		si_o = dimension;

	if (si_i < 0 or si_i > si_o)
		si_i = 0;

	side = si_o;

	outer_cube = Allocate();
	inner_cube = Allocate();

	margin_o = (dimension - side) / 2;
	margin_i = (dimension - si_i) / 2;

	for (i=margin_o; i<(side+margin_o); i++){
		for (j=margin_o; j<(side+margin_o); j++){
			for (k=margin_o; k<(side+margin_o); k++){
				outer_cube[i][j][k] = true;
			}
		}
	}
	for (i=margin_i; i<(si_i+margin_i); i++){
		for (j=margin_i; j<(si_i+margin_i); j++){
			for (k=margin_i; k<(si_i+margin_i); k++){
				inner_cube[i][j][k] = true;
			}
		}
	}
	for (i=0; i<dimension; i++){
		for (j=0; j<dimension; j++){
			for (k=0; k<dimension; k++){
				if (outer_cube[i][j][k] == true){
					if (inner_cube[i][j][k] == false){
						grid[i][j][k] = true;
					}
				}
			}
		}
	}

	Deallocate(outer_cube);
	Deallocate(inner_cube);
	delete[] outer_cube;
	delete[] inner_cube;

	return 0;
}
