/*! \file create_sphere.cpp
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 * 
 * 
 * Description : This test program create a data grid which has non-zero data lie on a spherical volume
 *               and produces a uhbd file that can be visualized with the help of a molecular visualization software.
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <cstdlib>
#include "../../../datastructures/DTGrid3D.hpp"
#include "./geometry.hpp"

// main program call
int main(int argc, char* argv[]) {
    // check the number of arguments provided by the user
    if (argc < 3) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << "grid_edge_length skin_thickness" << std::endl;
        return 1;
    } 
    
    int dim, thckns_skn;
    
    // The dimension provided by the user!
    istringstream ss(argv[1]);
    if (!(ss >> dim))
        std::cerr << "Invalid integer value for: number of grid points that makes a grid edge" << argv[1] << std::endl;
    
    // The thickness in terms of number of points (as for the edge length)
    istringstream ss2(argv[2]);
    if (!(ss2 >> thckns_skn))
        std::cerr << "Invalid integer value for: number of grid points that makes a grid edge" << argv[2] << std::endl;
    
    if (thckns_skn > (dim/2)){
    	std::cerr << "       " << "Skin thickness should not be larger than half of the size of the grid edge length! " << std::endl;
    	return 1;
    }
    
    // initialize the random number generator
    srand ( static_cast <unsigned> (time(NULL)) );

    int inner_dim, rn1, rn2, rn3;
    //const int thckns_skn = 50; // skin thickness. can be changed to test the results for different interaction 'skin' thicknesses

    //create a sphere object. can be change to a torus or a cube from the object3D class.
    object3D *sphere;    

    //Allocate memory for the matrix and create the shape
    inner_dim = dim - 2 * thckns_skn;
    sphere = new object3D(dim);
    sphere->sphere(dim, inner_dim);
    sphere->write_uhbd_file_binary(dim, dim, dim);
    delete sphere;
    
    return 0;
}
