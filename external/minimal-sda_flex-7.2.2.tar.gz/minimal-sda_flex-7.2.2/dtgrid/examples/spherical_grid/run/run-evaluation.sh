#==============================================
#### edit these variables according to your needs

BIN=../bin
GNUPLOT_EXE=gnuplot

export BIN
export GNUPLOT_EXE
#==============================================

#==============================================
#### set the command line input
num_of_runs=10000
skin_thickness_length=50
seed=0
#==============================================
rm -f time.txt time_excl.txt
#==============================================
#### run the evaluation calculations for a spherical shell representing a data grid
echo "# Dimension Size_DT-Grid Size_reg Rand_acccess_DT Rand_access_reg Rand_cell_DT Rand_cell_reg" >> time.txt
for d in `seq 100 100 800`;
do
  $BIN/sphere_test $num_of_runs $seed $d $skin_thickness_length
done
#==============================================

#==============================================
#### run the evaluation calculations for a spherical shell representing a data grid
echo "# Dimension Size_DT-Grid Size_reg Rand_acccess_DT Rand_access_reg Rand_cell_DT Rand_cell_reg" >> time_excl.txt
for d in `seq 100 100 800`;
do
  $BIN/sphere_excl_test $num_of_runs $seed $d
done
#==============================================

$GNUPLOT_EXE make_plot.gp
