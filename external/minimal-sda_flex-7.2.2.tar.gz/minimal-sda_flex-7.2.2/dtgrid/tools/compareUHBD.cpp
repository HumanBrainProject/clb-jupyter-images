//============================================================================
// Name        : compareUHBD.cpp
// Author      : Musa Ozboyaci
// Version     :
// Copyright   : Heidelberg Institute for Theoretical Studies (HITS) 2015
// Description : Program to compare two exclusion UHBD files
//============================================================================

// Load the libraries
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <sys/stat.h>
#include "UHBDgrd.hpp"
#include <vector>


int main(int argc, char *argv[]) 
{
	char *PDBFILE  = NULL;
	char *UHBDFILE1 = argv[1];
	char *UHBDFILE2 = argv[2];
	
	int check_flag = 0;
	int val1, val2;
	
	UHBD<double> * ufile1;
	UHBD<double> * ufile2;
	
	//create UHBD object for two of the grids to be compared
	ufile1 = new UHBD<double>(PDBFILE, UHBDFILE1);
	ufile2 = new UHBD<double>(PDBFILE, UHBDFILE2);
	
	if (ufile1->dim.i != ufile2->dim.i) check_flag = 1;
	if (ufile1->dim.j != ufile2->dim.j) check_flag = 1;
	if (ufile1->dim.k != ufile2->dim.k) check_flag = 1;
	
	if (check_flag == 1){
		std::cout << "Dimensions of the two grids do not match!" << std::endl;
		exit(0);
	}
	
	for (int i= 0; i < ufile1->dim.i; i++){
		for (int j= 0; j < ufile1->dim.j; j++){
			for (int k= 0; k < ufile1->dim.k; k++){
				val1 = (int) ufile1->Grid[i][j][k];
				val2 = (int) ufile2->Grid[i][j][k];
				if (val1 != val2)
					std::cout << i << " " << j << " " << k << "\t" << val1 << " " << val2 << std::endl;
			}
		}
	}
	

	std::cout << "Exiting normally" << std::endl;
	return 0;
}
