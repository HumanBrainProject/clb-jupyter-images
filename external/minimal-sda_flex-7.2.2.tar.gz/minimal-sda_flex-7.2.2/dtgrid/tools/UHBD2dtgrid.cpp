/*! \file UHBD2dtgrid.cpp
 *  \brief Main program to convert a UHBD grid file into DT-Grid format file.
 * 
 * This program converts a UHBD grid file into DT-Grid file format.
 * It inputs and outputs both ascii and binary types.
 * Running the program with "-h" option in command line returns the options available for the user.
 * 
 *  \author Musa Ozboyaci
 *  \copyright Heidelberg Institute for Theoretical Studies (HITS) 2016
 */

// Loading the libraries
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <sys/stat.h>
#include "DTgrd.hpp"
#include <vector>

//! help menu function. This returns the options to inform the user about the parameters
void help_menu(void)
{
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "                     UHBD TO DT-GRID FILE CONVERTOR                        " << std::endl;
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "Usage:" << std::endl;
	std::cout << "./UHBD2dtgrid -g 'UHBD_file' -p 'PDB_file' -f 'File_type'" << std::endl;
	std::cout << std::endl;
	std::cout << "Option\t Opt?\t Description" << std::endl;
	std::cout << "-------  ------  ------------------------------------------------------------------------" << std::endl;
	std::cout << "-g\t No\t The UHBD file name to be converted into DT-Grid" << std::endl;
	std::cout << "-p\t No\t The PDB file name to be used to generate the molecular skin" << std::endl;
	std::cout << "-f\t No\t The output file format" << std::endl;
	std::cout << "  \t \t There are two options: Binary and ASCII" << std::endl;
	std::cout << "  \t \t You can save your DT-Grid using the format you want" << std::endl;
	std::cout << "-o\t Yes\t The name of the outputting *.dtgrd file name" << std::endl;
	std::cout << "  \t \t The grid file will be named as 'dt.dtgrid' unless this option is used" << std::endl;
	std::cout << "-s\t Yes\t The thickness of the skin around the surface of the molecule" << std::endl;
	std::cout << "  \t \t A default value of 2.0 Angstrom will be used unless this option is used" << std::endl;
	std::cout << "-sp\t Yes\t The spacing required to build the exclusion grid" << std::endl;
	std::cout << "  \t \t A default value of 0.5 Angstrom will be used unless this option is used" << std::endl;
	std::cout << "-pr\t Yes\t The size of the probe used to compute the molecular skin" << std::endl;
	std::cout << "  \t \t A default value of 1.7 Angstrom will be used unless this option is used" << std::endl;
	std::cout << "-type\t Yes\t Type of grid: exclusion grid (0), normal grid (1). Default value is 1" << std::endl;
	std::cout << "  \t \t No UHBD file is required for an exclusion grid" << std::endl;
	std::cout << "-h\t \t Displays the usage information and terminates the execution!" << std::endl;
	std::cout << std::endl;
}

//! main program call
int main(int argc, char *argv[]) 
{
	char *UHBDFILE = NULL; // uhbd file name input
	char *PDBFILE  = NULL; // pdb file name 
	char *FILETYPE = NULL; // file type: binary, ascii

	char output_file_name [] = "uhbd2.dtgrd"; //Default output name
	char *  OUTPUT ;
	OUTPUT = output_file_name;

	//Default values for the skin and the probe
	float skin_size = 2.0;
	float probe_size = 1.7;
	float spacing = 0.5;

	int grid_type_flag = 1; // excluded volume or data grid.
	bool pqr_type_flag = false; //explicit paramter for PQR files
		
	// Interate over the command line arguments
	for (int c = 1; c < argc; c++)
	{
		if (strcmp(argv[c], "-h") == 0)
		{
			help_menu();
			return 0;
		}
		if (strcmp(argv[c], "--help") == 0)
		{
			help_menu();
			return 0;
		}
		if (strcmp(argv[c], "-g") == 0)
 		{
			UHBDFILE = argv[c+1];
		}
		if (strcmp(argv[c], "-p") == 0)
		{
			PDBFILE = argv[c+1];
		}
		if (strcmp(argv[c], "-f") == 0)
		{
			FILETYPE = argv[c+1];
			if (strcmp(FILETYPE, "ascii") == 0 or strcmp(FILETYPE, "ASCII") == 0 or \
					strcmp(FILETYPE, "Ascii") == 0 or strcmp(FILETYPE, "binary") == 0 or \
					strcmp(FILETYPE, "BINARY") == 0 or strcmp(FILETYPE, "Binary") == 0)
			{
				continue;
			}
			else
				{
					std::cout << "The file type '" << FILETYPE << "' is not supported!" << std::endl;
					std::cout << "Please check your input parameters" << std::endl;
					std::cout << "Try -h option to get the usage information" << std::endl;
					std::cout << "Exiting..." << std::endl;
					return 0;
				}
		}
		//Optional parameters
		if (strcmp(argv[c], "-o") == 0)
		{
			OUTPUT = argv[c+1];
		}
		if (strcmp(argv[c], "-s") == 0)
		{
			skin_size = atof(argv[c+1]);
		}
		if (strcmp(argv[c], "-sp") == 0)
		{
			spacing = atof(argv[c+1]);
		}
		if (strcmp(argv[c], "-pr") == 0)
		{
			probe_size = atof(argv[c+1]);
		}
		if (strcmp(argv[c], "-type") == 0)
		{
			grid_type_flag = atoi(argv[c+1]);
		}
		if (strcmp(argv[c], "-pqr") == 0)
		{
			pqr_type_flag = true;
		}
	}

	if (grid_type_flag == 1 and UHBDFILE == NULL){
		std::cout << "Please input UHBD file name!" << std::endl;
		std::cout << "Try -h option to get the usage information" << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
	if (grid_type_flag == 1 and PDBFILE == NULL){
		std::cout << "Please input PDB file name!" << std::endl;
		std::cout << "Try -h option to get the usage information" << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
    if (grid_type_flag == 0 and PDBFILE == NULL and UHBDFILE == NULL){
        std::cout << "Please input a PDB or an exclusion UHBD file name!" << std::endl;
        std::cout << "Try -h option to get the usage information" << std::endl;
        std::cout << "Exiting..." << std::endl;
        return 0;
    }
	if (FILETYPE == NULL){
		std::cout << "Please input DT-Grid file type!" << std::endl;
		std::cout << "Try -h option to get the usage information" << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
	//Check if the output file already exists?
	std::ifstream infile(OUTPUT);
	if (infile){
		std::cout << "The output file already exists. Please change the file name and try again." << std::endl;
		std::cout << "Exiting..." << std::endl;
		return 0;
	}
	infile.close();
	
	// Print the program information and parameters in terminal for the user.
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "                     UHBD TO DTGRID FILE CONVERTOR                        " << std::endl;
	std::cout << std::endl;
	std::cout << "               Heidelberg Institute for Theoretical Studies               " << std::endl;
	std::cout << std::endl;
	std::cout << "**************************************************************************" << std::endl;
	std::cout << std::endl;
	std::cout << "Program call: ";
	for (int c = 0; c < argc; c++)
		std::cout << argv[c] << " ";
	std:: cout << std::endl << std::endl;
	std::cout << "For further information about the program options" << std::endl;
	std::cout << "please check out the help menu!!!" << std::endl << std::endl;
	std::cout << "Option\t Value" << std::endl;
	std::cout << "-------  -----------------------------------------------------------------" << std::endl;
	if (grid_type_flag == 1) std::cout << "-g\t " << UHBDFILE << std::endl;
	std::cout << "-p\t " << PDBFILE << std::endl;
	std::cout << "-f\t " << FILETYPE << std::endl;
	std::cout << "-o\t " << OUTPUT << std::endl;
	std::cout << "-s\t " << skin_size << std::endl;
	std::cout << "-sp\t " << spacing << std::endl;
	std::cout << "-pr\t " << probe_size << std::endl;
	std::cout << "-type\t " << grid_type_flag << std::endl;
	std::cout << std::endl;

	//if not exclusion
	if (grid_type_flag == 1){
		
		//Initialize the dtGrid object
		DT_FILE<float> * dtfile;
		dtfile = new DT_FILE<float>(grid_type_flag, pqr_type_flag);
		dtfile->UHBD_upload(PDBFILE, UHBDFILE, probe_size, skin_size);

		// Initialize the output *dtgrd file and write the file header part
		FILE* output;
		if (strcasecmp(FILETYPE,"ascii") == 0){
			output = fopen(OUTPUT,"w");
			dtfile->write_dtgrdfile_ascii(output);
			fclose(output);
		}

		if (strcasecmp(FILETYPE,"binary") == 0){
			output = fopen(OUTPUT,"wb");
			dtfile->write_dtgrdfile_binary(output);
			fclose(output);
		}
	}

	// if exclusion
	else if (grid_type_flag == 0) {
		
		// If no excluded volume file is provided then calculate the excluded volume first
        if ( UHBDFILE == NULL ){
        	//Initialize the dtGrid object
            DT_FILE<bool> * dtfile;
            dtfile = new DT_FILE<bool>(grid_type_flag, pqr_type_flag);
            dtfile->exclusion(PDBFILE, probe_size, spacing);

		    // Initialize the output *dtgrd file and write the headers
		    FILE* output;
		    if (strcasecmp(FILETYPE,"ascii") == 0){
			    output = fopen(OUTPUT,"w");
			    dtfile->write_dtgrdfile_ascii(output);
			    fclose(output);
		    }  

		    if (strcasecmp(FILETYPE,"binary") == 0){
			    output = fopen(OUTPUT,"wb");
			    dtfile->write_dtgrdfile_binary(output);
			    fclose(output);
		    }
        }
        // if excluded volume file has been computed and stored in disk before, it can also be used
        else{
        	//Initialize the dtGrid object
            DT_FILE<bool> * dtfile;
            dtfile = new DT_FILE<bool>(grid_type_flag, pqr_type_flag);
            dtfile->exclusion(UHBDFILE);

            // Initialize the output *dtgrd file and write the headers
            FILE* output;
            if (strcasecmp(FILETYPE,"ascii") == 0){
                output = fopen(OUTPUT,"w");
                dtfile->write_dtgrdfile_ascii(output);
                fclose(output);
            }

            if (strcasecmp(FILETYPE,"binary") == 0){
                output = fopen(OUTPUT,"wb");
                dtfile->write_dtgrdfile_binary(output);
                fclose(output);
            }
        }  
	}
	else{
		//no other options yet. For other information grids than excluded volume and data grids.
	}

	std::cout << "Exiting" << std::endl;
	return 0;
}
