#!/usr/bin/python

import sys, os
import logging, warnings

#optparse depreceated
#from optparse import OptionParser
import argparse

from ModPrepareInputSDA.VdWTC_SDA import *

"""
   Merge the different add_atoms files generated for different structure by PrepareInputSDA 
"""

logging.basicConfig(filename='MergeAddAtoms.log',level=logging.DEBUG)
# working here
#logging.captureWarnings(True)

parser = argparse.ArgumentParser(description="Merge all input into one 'add_atoms' file before running SDA")

parser.add_argument("-list_input", dest="list_input", required=True, nargs='+', help="The list of add_atoms files to merge")
parser.add_argument("-out_dir", dest="out_dir", required=False, default='.', help="The directory where to write the final add_atoms file")

try :
    options = parser.parse_args()
# parse_arg will return an exit
except SystemExit:
    logging.error("ERROR in reading arguments")
    sys.exit(1)

## name solute can be used to create an unique directory, 
## with all conformations, can be done before as well
#logging.info("name_solutes %s" % options.name_solutes)
logging.info("input %s " % options.list_input)
logging.info("output  %s " % options.out_dir)
print "input %s " % options.list_input
print "output  %s " % options.out_dir


# create output directory, maybe check if existing
main_vdw = VdWTC_SDA( options.out_dir )

# loop over the input
for file in options.list_input:
    
    print "file ", file
    # check it exists
    if not os.path.exists(file):
        print "file does not exist"
        continue
    
    # check not empty
    if ( os.stat(file).st_size == 0 ):
        print "file empty"
        continue
    
    #ok
    #else: 
    print "create tmp_vdw"
    (head, tail) = os.path.split(file)
    print "head", head
    print "tail", tail
    tmp_vdw = VdWTC_SDA( head )
    
    # copy the content of tmp into main
    main_vdw.MergeWith( tmp_vdw ) 
    
# write final file
main_vdw.write_file()
    
    
