#!/usr/bin/python

# read the files of solvent accessibility and T_DA for p1 and p2
# calculate, if ln(T_DA [1]) + ln(T_DA [2]) >= tda_limit
# if yes: write the respective atoms in {...}_sda_et_inp.rxnac

import sys

a = sys.argv

tda_limit = float(a[3])

f1 = file(a[1] + '_acc_TDA.dat','r')
g1 = file(a[1] + '.pdb','r')
h1 = file(a[1] + '_sda_et_inp.rxnac','w')

f2 = file(a[2] + '_acc_TDA.dat','r')
g2 = file(a[2] + '.pdb','r')
h2 = file(a[2] + '_sda_et_inp.rxnac','w')

l_spl1_1 = [] # array for p1: solvent acc and TDA
l_spl1_2 = [] # array of pdb file elements for p1
l_spl2_1 = [] # array for p2: solvent acc and TDA
l_spl2_2 = [] # array of pdb file elements for p2

for line in f1:
  spl = line.split()
  l_spl1_1.append(spl)

for line in f2:
  spl = line.split()
  l_spl2_1.append(spl)

for line in g1:
  l_spl1_2.append(line)

for line in g2:
  l_spl2_2.append(line)

for i in range(0,len(l_spl1_1)):
  for j in range(0,len(l_spl2_1)):
    if ((float(l_spl1_1[i][3]) + float(l_spl2_1[j][3])) >= tda_limit):
      for k in range(0,len(l_spl1_2)):
        if ((l_spl1_1[i][0] == (l_spl1_2[k][12:17].strip())) and (l_spl1_1[i][1] == (l_spl1_2[k][22:26].strip()))):
          h1.write("{:54s}{:6.2f}{:6.2f}\n".format(l_spl1_2[k][0:54],float(l_spl1_1[i][2]),float(l_spl1_1[i][3])))
      for k in range(0,len(l_spl2_2)):
        if ((l_spl2_1[j][0] == (l_spl2_2[k][12:17].strip())) and (l_spl2_1[j][1] == (l_spl2_2[k][22:26].strip()))):  
          h2.write("{:54s}{:6.2f}{:6.2f}\n".format(l_spl2_2[k][0:54],float(l_spl2_1[j][2]),float(l_spl2_1[j][3])))

f1.close()
g1.close()
h1.close()
f2.close()
g2.close()
h2.close()
