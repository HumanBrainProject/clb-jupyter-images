#!/usr/bin/python

# read the list {...}_tda.dat and store together with solvent accessibility into file {...}_acc_TDA.dat


import subprocess
import sys
import math

a = sys.argv

prot = a[1]

f = open(prot + '_scut.asa','r')
h = open(prot + '_tda.dat','r')
g = open(prot + '_acc_TDA.dat','w')

for line in f:
  sur_atom = line[12:17]
  sur_resid = line[22:26]
  access = float(line[54:62])
  x = h.readline()
  spl2 = x.split()
  tda = float(spl2[0])
  ln_tda = math.log(tda)  # Removed " / 10" Divide by 10 FOR "tool calc_solvaccess"  ### 
  g.write("%5s %5s %6.2f %6.2f \n" %(sur_atom, sur_resid, access, ln_tda))

f.close()
g.close()
h.close()
