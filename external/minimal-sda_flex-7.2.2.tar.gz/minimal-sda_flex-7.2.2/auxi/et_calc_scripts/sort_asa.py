#!/usr/bin/python

# sorts Solvaccess output and only keeps atoms with solvent accessibility > threshold sac

import sys

a = sys.argv

prot = a[1]
acc_limit = float(a[2])

f = open(prot + ".asa", 'r')
g = open(prot + "_scut.asa", 'w')

comb = []

for line in f:
  access = float(line[54:62])
  comb.append([access,line])

s_comb = sorted(comb, reverse=True) 

for i in range(0,len(s_comb)):
  if (s_comb[i][0] >= acc_limit):
    g.write(s_comb[i][1])

g.close()
