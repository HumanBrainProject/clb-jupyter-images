#!/usr/bin/python

############
# the python version of DelRotZ_f55
# modified from Michael's DelRotZ_f55.cpp
# 18.02.2008
# Bingding Huang
#
# modified for SDA 7 release
# 28.10.2013 M.Martinez

from fort55_lib_SDA7 import *
import numpy
from numpy import *
from math import pi
import sys,os

#################
def printUsage():
    print """
    usage:
    ~/thisFile.py complexes  n
    """



fn=""
if len(sys.argv)<3:
    printUsage()
    sys.exit(1)
try:
    Fort55file = open(sys.argv[1],'r')
    fn=sys.argv[1]
    ##check existency of 
except IndexError:
    printUsage()
    sys.exit(1)


Number2print=10 # default 10

try:
    Number2print=int (sys.argv[2])
except IndexError:
    printUsage()
    sys.exit(1)

# skip first two lines
line1_1=Fort55file.readline() # the first line
line2_2=Fort55file.readline() # the second line
#print "header ", line1_1
#print "header 2", line2_2

line1=Fort55file.readline() # the first line
line2=Fort55file.readline() # the second line
#print "line1 ", line1
#print "line2 ", line2

lines=Fort55file.readlines() # start from the third line


Fort55file.close()
lines1=[]
l=""
for l in lines:
    if (l.rfind("NAN") == -1) and (l.rfind("#") == -1):
	lines1.append(l)
	#print l
lines=lines1

if Number2print>len(lines):
    print """
    The number you give is larger than the length of complexes file
    Please give a smaller number which is < %d
    now it continues using the number %d
    """%(len(lines),len(lines))
    Number2print=len(lines)
    
    #sys.exit(1)




F55Lines=[]
num =1
for l in lines[0:Number2print]:
    #print "# of line:", num
    num +=1
    l=l.rstrip()
    
    F55l=F55Line(l)
    hyp=sqrt((F55l.rotX[0])**2+ (F55l.rotX[1])**2)
    
    #print  "angle de rotation acos(alpha): " , acos(F55l.rotX[1]/hyp)
    alpha=acos(F55l.rotX[1]/hyp)
    #print "angle: %.2f"%alpha
    #print "alpha %.2f"%(alpha*180.0/pi)
    
    sinalpha=F55l.rotX[0]/hyp
    
    if sinalpha < 0. :
	alpha *=-1.0

    #print "angle 1: %.2f"%(alpha*180.0/pi)

    #print "cos alpha ", cos(alpha), F55l.rotX[1]/hyp
    #print sin(alpha),F55l.rotX[0]/hyp
    
    matR=zeros([3,3],dtype=float)
    #calpha=F55l.rotX[1]/hyp #cos(alpha)
    calpha=cos(alpha)
    sinalpha=sin(alpha)
    
    matR[0][0]= calpha
    matR[1][1]=calpha
    matR[0][1]=-1.0*sinalpha
    matR[1][0]=sinalpha
    matR[2][2]=1.0
    matR[0][2]=matR[1][2]=matR[2][0]=matR[2][1]=0.0
      
    #print F55l.rotX
    #print F55l.rotY
    #print matR
    
    #print F55l.rotX
    nrotX=[0,0,0]
    nrotY=[0,0,0]
    for i in range(3):
	tmp =0.
	tmp1 =0.
	for j in range(3):
	    tmp =tmp +(matR[i][j]*F55l.rotX[j])
	    
	    tmp1 =tmp1 + (matR[i][j]*F55l.rotY[j])
	    
	nrotX[i]=tmp
	nrotY[i]=tmp1
	#print tmp
	#print tmp1
	
	
    F55l.setRotX(nrotX)
    F55l.setRotY(nrotY)
    
    F55l.normalize()
    #print F55l.rotX
    #print F55l.rotY

  
    
    #print F55l.rotX
    #print F55l.rotY
    #F55l.newRotZ()
    
    #newline="%s%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%s"%(F55l.line[0:16],F55l.trans[0],F55l.trans[1],F55l.trans[2],F55l.rotX[0],F55l.rotX[1],F55l.rotX[2],F55l.rotY[0],F55l.rotY[1],F55l.rotY[2],F55l.line[97:])
    F55l.newLine() # make a new line
    #print F55l.line
    F55Lines.append(F55l)


tags=fn.split(".")
prefix=tags[-1]

fw=open("wtrotz.%s"%prefix,"w")
# add header
fw.write("%s" % (line1_1) )
fw.write("%s" % (line2_2) )
# print cm         
fw.write("%s%8d\n"%(line1[0:25],Number2print))
fw.write(line2)

for F55l in F55Lines:
    fw.write("%s\n"%F55l.line)
fw.close()

    
