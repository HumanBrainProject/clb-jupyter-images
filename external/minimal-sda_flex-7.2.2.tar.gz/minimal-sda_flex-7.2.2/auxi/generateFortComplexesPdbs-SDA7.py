#!/usr/bin/python

"""
generate the first n number pdbs file from complexes
modified from nhis2pdb.f in SDA5
@author: Bingding Huang
@date: 08.02.2008 
"""
import sys
import os



from fort55_lib_SDA7 import *
from math import acos



#################
def printUsage():
    print """
    usage:
    ~/thisFile.py complexes p2.pdb n X

    generate the first n number pdbs file from complexes, X -letter to start pdb file name
    modified from nhis2pdb.f in SDA5
    
    """
    

if len(sys.argv)<4:
    printUsage()
    sys.exit(1)
try:
    Fort55file = open(sys.argv[1],'r')
    ##check existency of 
except IndexError:
    printUsage()
    sys.exit(1)

##check existency of the pdb file
if os.path.isfile(sys.argv[2]):
    #print "OK pdb",sys.argv[2]
    pdbfile=sys.argv[2]

else:
    printUsage()
    print "pdb does not exist"
    sys.exit(1)

Number2print=10

try:
    Number2print=int (sys.argv[3])
except IndexError:
    printUsage()
    sys.exit(1)
   
letter="A"
try:
    letter=sys.argv[4]
except:
    printUsage()
    sys.exit(1)
    


str_bf,coord,str_af=ReadPDBFile(pdbfile)
xc1=[] # geometric (mass) center of p1
xc2=[] # geometric (mass) center of p2
line1=Fort55file.readline()
line2=Fort55file.readline()

for id in line1.split()[1:4]:
    xc1.append(float(id))
    

for id in line2.split()[1:4]:
    xc2.append(float(id))
    

#print xc1
#print xc2
ozz=[1,0,0] # 1,0,0
zoz=[0,1,0] # 0,1,0
zzo=[0,0,1]# 0,0,1
vorig=[]
xv=coord
xv2=[]

for c in xv:  # translation to mass center of p2 (-)
    cc=[]
    
    for i in range(3):
	cc.append(c[i]-xc2[i])
    xv2.append(cc)
    
lines=Fort55file.readlines()
Fort55file.close()


lines1=[]
l=""
for l in lines:
    if l.rfind("NAN") == -1:
	lines1.append(l)
	#print l
lines=lines1


if Number2print>len(lines):
    print """
    The number you give is larger than the length of complexes file
    Please give a smaller number which is < %d
    now continure with %d
    """%(len(lines),len(lines))
    Number2print=len(lines)
    
    
    

num=1
xp=[]
yp=[]
for l in lines[0:Number2print]:
    tags=l.split()
    run=int (tags[0])
    step=int (tags[1])
    tx=float (tags[2])  #translation
    ty=float (tags[3])
    tz=float (tags[4])
    r=[tx,ty,tz]
    #r=[0,0,tz]
    #print "%.3f %.3f %.3f"%(tx,ty,tz)
    rx1=float (tags[5])
    ry1=float (tags[6])
    rz1=float (tags[7])
    xp=[rx1,ry1,rz1]
    #print "xp %.1f"%( rx1**2+ry1**2+rz1**2)
    
    rx2=float (tags[8])
    ry2=float (tags[9])
    rz2=float (tags[10])
    #print "%.3f %.3f %.3f %.3f %.3f %.3f"%(rx1,ry1,rz1,rx2,ry2,rz2)
    yp=[rx2,ry2,rz2]
    #print "yp: %.1f"%( rx2**2+ry2**2+rz2**2)

   
    #norm(xp)
    #norm(yp)
    
    zp=cross(xp,yp)
    norm(zp)
    print xp
    print yp
    print zp
    
    #alpha=acos(dot(yp,zp))
    #print "%d"%(alpha*180/3.14)
	       
    
    xee=tr(ozz,xp,yp,zp)
    yee=tr(zoz,xp,yp,zp)
    zee=tr(zzo,xp,yp,zp)
    #print "xee %.1f"%( xee[0]**2+xee[1]**2+xee[2]**2)
    #print "yee %.1f"%( yee[0]**2+yee[1]**2+yee[2]**2)
    #print "zee %.1f"%( zee[0]**2+zee[1]**2+zee[2]**2)
    
    xt2a=[]
    for i in range(len(xv2)):
	vorig=xv2[i]
	vnew=tr(vorig,xee,yee,zee)  # matrix rotation

	cc=[0,0,0]
	for k in range(3):
	    cc[k]=vnew[k]+r[k]+xc1[k] # translation (+r +xc1)   cc: new coordinate after transformation
	xt2a.append(cc)
	#print cc
    fn="%s%04d.pdb"%(letter,num)
    print num,run,step
    #print xp,yp
    
    
    energy1=tags[11]
    #energy2=tags[12]
    fw=open(fn,"w")
    fw.write("REMARK  energy %s \n"%energy1)
    fw.close()
    
    WritePDBFile(fn,str_bf,xt2a,str_af) # write to the PDB file
    num +=1
   

 
    
