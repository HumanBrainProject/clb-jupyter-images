#!/usr/bin/python

""" Script to transform add_atoms to a Json file,
    and opposite read a Json file to update add_atoms

    Used for Web-SDA

    json output, fixed, add_atoms.json
    json input, fixed, tmp.json and output add_atoms
"""

import sys, os
import logging
import argparse

from ModPrepareInputSDA.VdWTC_SDA import *

parser = argparse.ArgumentParser(description="Script to transform add_atoms to/from Json file")

parser.add_argument("-MkJson", dest="mkjson", action='store_true', default="False", help="Create a Json file from add_atoms file")
parser.add_argument("-SetJson", dest="setjson", action='store_true', default="False", help="Update add_atoms file from tmp.json")
parser.add_argument("-input_dir", dest="input_dir", default="./", help="directory where add_atoms/tmp.json input is present")
parser.add_argument("-output_dir", dest="output_dir", default="./", help="directory where add_atoms/tmp.json input will be written")

## need to force boolean type !??
parser.set_defaults(mkjson=False)
parser.set_defaults(setjson=False)

try :
    options = parser.parse_args()
# parse_arg will return an exit
except SystemExit:
    logging.error("ERROR in reading arguments")
    sys.exit(1)

#if options.delLog:
if os.path.exists("AddAtomJson.log"):
    os.remove("AddAtomJson.log")

logging.basicConfig(filename='AddAtomJson.log',level=logging.DEBUG)

logging.info("mkjson %s " % options.mkjson)
logging.info("setjson  %s " % options.setjson)
logging.info("input dir  %s " % options.input_dir )
logging.info("output dir  %s " % options.output_dir )


#Check argument, only one set to true
if ( (options.mkjson | options.setjson) == False) | \
   ( (options.mkjson & options.setjson) == True): 
    logging.error("Need to select only one option")
    print("Need to select one option -MkJson or -SetJson")

main_vdw = VdWTC_SDA( options.input_dir )

if options.mkjson:
    print "MkJson"
    #main_vdw = VdWTC_SDA( options.input_dir )
    main_vdw.MakeJson( options.output_dir )

if options.setjson:
    print "SetJson"
    # read 'tmp.json' by default
    main_vdw.ReadJson()
    # append add_atoms by default, and overwritte 'add_atoms'
    main_vdw.write_file()

