#!/usr/bin/python

########################################################
########################################################
### Select representative complexes after clustering ###
# This should be used to generate input for sda_energy #
##################### Xiaofeng Yu ######################
##################### 2013.11.26 #######################
########################################################
########################################################

import sys
import os
import os.path

def main (args):
    """Usage: GenerateSDAEnergyRestart <complexes-file> <clustering-output-file> <number-of-clusters-to-write> <ouput-file-name>
    """
    if (len(args) != 5):
        print("\n" + "Usage: GenerateSDAEnergyRestart <complexes-file> <clustering-output-file> <number-of-clusters-to-write> <ouput-file-name>" + "\n" + "\n" \
              + "<complexes-file>                              The output complexes file from sda_docking\n" \
              + "<clustering-output-file>                      The clustering output after sda_docking using the above mentioned complexes file\n" \
              + "<number-of-clusters-to-write>                 The number of top clusters to perform sda_energy calculations\n"
              + "<ouput-file-name>                             Name for your output file  e.g. 'complexes_only_elect_clusters'\n" + "\n");
        return 1

    complexes_infile = sys.argv[1]
    complexes_output_infile = sys.argv[2]
    repnum = int(sys.argv[3])
    output_filename = sys.argv[4]
    ##complexes_infile = "complexes"
    ##complexes_output_infile = "out_clustering"
    ## How many cluster representatives to use?
    ##repnum = 3
    ## Name for the output file?
    ##output_filename = "complexes_only_elect_clusters"

    try:
        complexes_file = open(complexes_infile, "r")
    except:
        print("Error in opening file: ", complexes_file)
        sys.exit()
    complexes = complexes_file.readlines()
    complexes_file.close()
    ##print complexes

    try:
        complexes_output_file = open(complexes_output_infile, "r")
    except:
        print("Error in opening file: ", complexes_output_file)
        sys.exit()
    complexes_output = complexes_output_file.readlines()
    complexes_output_file.close()

    ## Write the first four lines of complexes file
    try:
        output_file = open(output_filename, "w")
    except:
        print("Error in opening file: %s to write! Please check whether you have write permissions!" %complexes_output_file)
        sys.exit()
    print("\n" + "\n" + "Started to select the representative complexes of the first %i clusters to write into a new complex file %s." %(repnum, output_filename) + "\n" + "\n")
    complexes_file_1st4lines = complexes[:4]
    for complexes_file_1st4line in complexes_file_1st4lines:
        output_file.write(complexes_file_1st4line)

    ## Where the cluter records start
    ##cluster_start = ' No  ClSize ClFSize    Repr    ReprE     ClAE    CLAED  RepRMSD  CLFRMSD      ElE   ElDesE   HyDesE      LjE   spread    stddev       max\n'
    ## Not exact matching
    cluster_start = " No  ClSize ClFSize    Repr    ReprE"
    cluster_linenum = []

    def line2write(string, complexes):
        num = int(string)
        complexes_linenum = num + 4 - 1
        line2write = complexes[complexes_linenum]
        return line2write;

    for i in range(len(complexes_output)):
        if complexes_output[i].startswith(cluster_start):
            for j in range( 1,(repnum+1) ):
	        new_linenum = i + j
                cluster_line = complexes_output[new_linenum]
                if cluster_line == "\n":
			print("Sorry, you have requested more clusters than you have got in you 'out_clustering' file!")
                        print("All the available representative complexes have been written to your output file")
                        print("\n" + "\n" + "Finished!")
			return 1
		else:
	        	complexes_linestring = cluster_line.strip().split()[3]
			cluster_linenum.append(complexes_linestring)
	        	##print complexes_linestring
	        	complexes_line2write = line2write(complexes_linestring, complexes)
	        	##print complexes_line2write
	        	output_file.write(complexes_line2write)
                	print("The representative of cluster %i has been written into the output %s" %(j, output_filename))
    
    if not cluster_linenum:
	print("ERROR: There is something wrong, no representative was found from your input!")
        print("ERROR: Please check your input files!" + "\n" + "\n")
        return 1
    
    output_file.close()
    print("\n" + "\n" + "Finished!");

if __name__ == '__main__':
    main(sys.argv) 

