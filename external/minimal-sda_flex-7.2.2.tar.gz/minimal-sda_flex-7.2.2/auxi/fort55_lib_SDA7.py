#!/usr/bin/python

"""@package fort55_lib 
fort.55 file related python functions and classes
the confirmations of p2 from fort.55
modified from nhis2pdbs.f , DelRotZ_f55 and Fusion_f55 at SDA5
@auther: Bingding Huang, @date: 12/02/2008

modified for SDA 7 integration
M.Martinez 28.10.2013
"""

from math import *
import re

CUTTRANS=1.0
CUTROT=0.3
RMSD_THRESHOLD=3.0

class F55Line:
  """
  A class dealing with the line in fort.55 file
  """
  def __init__(self):
    """
    constuct a empty F55Line class
    """
    self.line =""
    self.trans =[0,0,0]
    self.rotX =[0,0,0]
    self.rotY =[0,0,0]
    self.rotZ =[0,0,0]
    
  def __init__(self,line):
    """
    constuct a F55Line class according a line from fort.55 file
    """

    self.line=line
    tags=line.split()
    step1=True
    try:
	step= int(tags[1]) # the nrun and step join together
    except ValueError:
	step1=False
    #print "step1 ", step1
    
    if step1==False:  
    
      self.nrun=int (tags[0][0:2])
      self.step=int (tags[0][2:])
      tx=float (tags[1])  #translation
      ty=float (tags[2])
      tz=float (tags[3])
      rx1=float (tags[4]) #rotation X
      ry1=float (tags[5])
      rz1=float (tags[6])
      rx2=float (tags[7]) #rotation Y
      ry2=float (tags[8])
      rz2=float (tags[9])
      e=float (tags[10]) # total energy
      p=float (tags[15])
      
    else:
      self.nrun=int (tags[0])
      self.step=int (tags[1])
      tx=float (tags[2])  #translation
      ty=float (tags[3])
      tz=float (tags[4])
      rx1=float (tags[5]) # rotation x
      ry1=float (tags[6])
      rz1=float (tags[7])
      rx2=float (tags[8]) # rotation y
      ry2=float (tags[9])
      rz2=float (tags[10])
      e=float (tags[11]) # total energy
      p=float (tags[16]) # occur.
    
    
    #print "total energy ", e, " occ. ", p
    
    self.trans=[tx,ty,tz]
    yp=[rx2,ry2,rz2] # rotY
    xp=[rx1,ry1,rz1] # rotX
    #norm(xp)
    #norm(yp)
    
    zp=cross(xp,yp)
    norm(zp) #rotZ

    self.rotX=xp
    self.rotY=yp
    self.rotZ=zp
    self.energy =  e
    self.population = p
    
  def newRotZ(self):
    """
    The rotX and rotY change, thus rotZ also change
    """
    zp=cross(self.rotX,self.rotY)
    norm(zp) #rotZ
    self.rotZ=zp
  def normalize(self):
    """
    normalize rotX and rotY
    """
    norm(self.rotX)
    norm(self.rotY)
    

  def rotateMatrix(self):
    """
    Transpose the rotation matrix from xp to xee
    """
    ozz=[1,0,0] # 1,0,0
    zoz=[0,1,0] # 0,1,0
    zzo=[0,0,1]# 0,0,1

    xee=[self.rotX[0],self.rotY[0],self.rotZ[0]]  # the same transform as below
    yee=[self.rotX[1],self.rotY[1],self.rotZ[1]]
    zee=[self.rotX[2],self.rotY[2],self.rotZ[2]]

    #xee=tr(ozz,xp,yp,zp) # rotate along X
    #yee=tr(zoz,xp,yp,zp) # rotate along Y
    #zee=tr(zzo,xp,yp,zp) # rotate along Z

    self.rotX=xee  #rotation matrix
    self.rotY=yee
    self.rotZ=zee

  def newLine(self):
    """
    Set to the new when the values in the line change
    """

    self.trans[0]=0.
    self.trans[1]=0.0
    
    #correction: print out all 22  columns instead of only 12
#    newline="%8d%8d%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f"%(self.nrun,self.step,self.trans[0],self.trans[1],self.trans[2],self.rotX[0],self.rotX[1],self.rotX[2],self.rotY[0],self.rotY[1],self.rotY[2], self.energy) #self.line[97:])

    newline="%8d%8d%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%9.3f%s"%(self.nrun,self.step,self.trans[0],self.trans[1],self.trans[2],self.rotX[0],self.rotX[1],self.rotX[2],self.rotY[0],self.rotY[1],self.rotY[2], self.line[97:]) #self.line[97:])

    self.line=newline
    
  def newEnergyLine(self):
    """
    change the total energy to another value (like average energy of cluster
    and print out the new line
    """
    newline="%s%12.4E%s"%(self.line[0:97],self.energy,self.line[109:])
    self.line=newline

  def getLine(self):
    return self.line
  def getTrans(self):
    return self.trans
  def getRotX(self):
    return self.rotX
  def getRotY(self):
    return self.rotY

  def setTrans(self,trans):
    self.trans=trans
  def setRotX(self,rotX):
    self.rotX=rotX
  def setRotY(self,rotY):
    self.rotY=rotY
  def setRotZ(self,rotZ):
    self.rotZ=rotZ

  def __str__(self):
    return "%8d%8d"%(self.nrun,self.step)
  
  def __cmp__(self,other):
    if self.energy<other.energy:
      return -1
    elif self.energy==other.energy:
      return 0
    else:
      return 1
    
  def __eq__(self,other):
    return self.step==other.step
  
  def __hash__(self):
    return hash(self.step)
  



#def dist(x1,y1,z1,x2,y2,z2):
#  return sqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)

def dist(tr1,tr2):
  return sqrt ( (tr1[0]-tr2[0])**2 +(tr1[1]-tr2[1])**2 +(tr1[2]-tr2[2])**2 )


#def rot(v111, v112, v113, v121, v122, v123, v211, v212, v213, v221, v222, v223):

#  return sqrt( (v111-v211)*(v111-v211) + (v112-v212)*(v112-v212) + (v113-v213)*(v113-v213) + (v121-v221)*(v121-v221) + (v122-v222)*(v122-v222) + (v123-v223)*(v123-v223) );

def rot(rotX1,rotY1,rotX2,rotY2):
  return sqrt((rotX1[0]-rotX2[0])**2 + (rotX1[1]-rotX2[1])**2 + (rotX1[2]-rotX2[2])**2+ (rotY1[0]-rotY2[0])**2 + (rotY1[1]-rotY2[1])**2 + (rotY1[2]-rotY2[2])**2)


  
  


def  test_trans( F55l1, F55Lines):
  tr1=F55l1.trans


  #F55l2=F55Line()
  for F55l2 in F55Lines:
    tr2= F55l2.trans
    if ( dist(tr1,tr2) < CUTTRANS ):
      return 0


  return 1


def CA_RMSD(coord1,coord2):
  """
  calculate the Ca atom rmsd bewteen two conformations
  """
  assert(len(coord1)==len(coord2))
  total_dis=0.0
  for i in range(len(coord1)):
    total_dis = total_dis + ((coord1[i][0]-coord2[i][0])**2 + (coord1[i][1]-coord2[i][1])**2 +(coord1[i][2]-coord2[i][2])**2)
  
  total_dis =1.0*total_dis/(1.0*len(coord1))
  rmsd=sqrt(total_dis)
  
  return rmsd
  
def transform(coord, trans, rotX,rotY,rotZ,mc1):
  """
  transform the coord,  first rotate, then translate to 
  rans,then translate to mc1 (p1 mass center)
  """
  newCoord=[]
  rotX1=[rotX[0],rotY[0],rotZ[0]] # transpose matrix
  rotY1=[rotX[1],rotY[1],rotZ[1]]
  rotZ1=[rotX[2],rotY[2],rotZ[2]]
  
  
  
  for i in range(len(coord)):
	vorig=coord[i]
	vnew=tr(vorig,rotX1,rotY1,rotZ1)  # rotate the coord
	cc=[0,0,0]
	for k in range(3):
	    cc[k]=vnew[k]+trans[k]+mc1[k] # translation (+r +xc1)   cc: new coordinate after transformation
	newCoord.append(cc)
  return newCoord


def test_close(coord, F55l1, F55Lines,mc1):
  """
  if two F55l have rmsd below 3.0, then it is closed conformation
  """
  #F55l1=F55Line()
  
  trans1=F55l1.trans
  #print trans1, F55l1.rotX, F55l1.rotY,F55l1.rotZ
  #F55l1.rotateMatrix()
  rotX1=F55l1.rotX
  rotY1=F55l1.rotY
  rotZ1=F55l1.rotZ
  #print trans1, F55l1.rotX, F55l1.rotY, F55l1.rotZ
  
  newCoor1=transform(coord,trans1,rotX1,rotY1,rotZ1,mc1)
  
  closed=False
  #F55l2=F55Line()
  for F55l2 in F55Lines:
    trans2=F55l2.trans
    
    #F55l2.rotateMatrix()
    rotX2 = F55l2.rotX
    rotY2 = F55l2.rotY
    rotZ2=F55l2.rotZ
    newCoor2=transform(coord,trans2,rotX2,rotY2,rotZ2,mc1)
    rmsd=CA_RMSD(newCoor1,newCoor2)
    if rmsd <=RMSD_THRESHOLD:
      closed=True
      #print "rmsd %.2f"%rmsd,  F55l1.line[0:16], F55l2.line[0:16]
      break
    #else:
    #  print "rmsd %.2f"%rmsd, F55l1.line[0:16], F55l2.line[0:16]
    #  print trans1, F55l1.rotX, F55l1.rotY, F55l1.rotZ
    #  print trans2, F55l2.rotX, F55l2.rotY, F55l2.rotZ
      
    
    
  return closed

    
def  test_rot( F55l1, F55Lines):
  rotX1=F55l1.rotX
  rotY1=F55l1.rotY

  #F55l2=F55Line()
  for F55l2 in F55Lines:
    rotX2 = F55l2.rotX
    rotY2 = F55l2.rotY
    
    if ( rot(rotX1,rotY1,rotX2,rotY2)<CUTROT):
      return 0

  return 1



def tr(vorig,x,y,z):
  """
  Transforms a vector from one coordinate system to another.		 
  vorig = vector in original coordinate system			 
  vnew  = resultant vector in new coordinate system			 
  x,y,z = axis vectors of new coordinate system in terms of orig coord 
  syst.
  """

  #first make sure x,y,z are normalized:
  vnew=[0,0,0]

  sumx=0.0
  sumy=0.0
  sumz=0.0
  for i in range(3): #sum
    sumx +=x[i]**2
    sumy +=y[i]**2
    sumz +=z[i]**2
  sumx =sqrt(sumx)
  sumy =sqrt(sumy)
  sumz =sqrt(sumz)


  for i in range(3): #normalized
    x[i] =x[i]/sumx
    y[i] =y[i]/sumy
    z[i] =z[i]/sumz


  # now performa transformation
  vnew[0]=dot(vorig,x)
  vnew[1]=dot(vorig,y)
  vnew[2]=dot(vorig,z)

  return vnew

def dot(a,b):

  c=a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
  return c


def cross(a,b):
  """
  cross product of two vectors
  """
  
  ti=[0,0,0]

  ti[0]=a[1]*b[2]-a[2]*b[1]
  ti[1]=a[2]*b[0]-a[0]*b[2]
  ti[2]=a[0]*b[1]-a[1]*b[0]

  return ti

def norm(wa):
  """
  normalized the vector
  """
  s =wa[0]**2
  s +=wa[1]**2
  s +=wa[2]**2
  s =sqrt(s)
  if s==0:
    print wa
    
  wa[0] =wa[0]/s
  wa[1] =wa[1]/s
  wa[2] =wa[2]/s

def ReadCaAtomPDBFile(pdbfile):
  """
  Read and return the coordinates of CA atom from a PDB file
  """
  coord=[]
  l=""
  for l in open(pdbfile):
    l=l.rstrip()
    if l.startswith("ATOM") or l.startswith("HETATM"):
      atom_name = re.sub("\s", "", l[12:16])
      if atom_name=="CA":
	ids=l[30:54].split()
	c=[]
	for id in ids:
	  c.append(float (id))
	coord.append(c)
  
  return coord
  
def ReadPDBFile(pdbfile):
  """
  Read the strings and the coordinates from a PDB file
  return str_bf, coord, str_af
  """
  str_bf=[]
  str_af=[]
  coord=[]
  l=""
  for l in open(pdbfile):
    l=l.rstrip()
    if l.startswith("ATOM") or l.startswith("HETATM"):
      str_bf.append(l[0:30])
      str_af.append(l[54:])
      ids=l[30:54].split()
      c=[]
      for id in ids:
	c.append(float (id))

      coord.append(c)
      #print "%s%8.3f%8.3f%8.3f%s"%(str_bf[-1], coord[-1][0],coord[-1][1],coord[-1][2],str_af[-1])
  return str_bf,coord,str_af


def WritePDBFile(fn,str_bf,coord,str_af):
  """
  write the strings and the coordinates to a PDB file
  """
  fw=open(fn,"a")
  assert (len(str_bf)==len(coord)==len(str_af)) #make sure their lengths are the same
  for i in range(len(str_bf)):
    fw.write("%s%8.3f%8.3f%8.3f%s\n"%(str_bf[i], coord[i][0],coord[i][1],coord[i][2],str_af[i]))

  fw.close()



def ReadCACoordFromPDBFile(pdbfile):
  """
  Read the CA atom coordinates from a PDB file
  return CA coord
  """
  
  coord=[]
  l=""
  for l in open(pdbfile):
    l=l.rstrip()
    if l.startswith("ATOM"):
      atom_name = re.sub("\s", "", l[12:16])
      if atom_name =="CA": # only the CA atoms

	ids=l[30:54].split()
	c=[]
	for id in ids:
	  c.append(float (id))

	coord.append(c)
      #print "%s%8.3f%8.3f%8.3f%s"%(str_bf[-1], coord[-1][0],coord[-1][1],coord[-1][2],str_af[-1])
  return coord
