#!/usr/bin/python

# @file Bootstrap_multiCPU.py
#
# Compute average and confidence interval from a sda run
# if bootstrap = 1 is specified in the input and you are running one of theses simulations:
#
# - association rate
# - first passage time
# - electron transfert
#
# There is an option to generate histogram from the samples
# but some parts of the code must manually commeted/uncommented
#
# Define a base class Data and derived ones for Assoc,FPT, Electron tranfer(Et)
#
# The bootstrap algorithm is independent of the data :
# - implements simplest estimation of the confidence interval
# - can draw histograms of resampling data (still under development)
#
# The average given in output should be identical to the average given in sda output

import sys
from types import *

import numpy, random
import multiprocessing
import argparse

## split alist into a list of sublist of size wanted_parts
def split_list(alist, wanted_parts=1):
    length = len(alist)
    return [ alist[i*length // wanted_parts: (i+1)*length // wanted_parts]
             for i in range(wanted_parts) ]

## for calling a function method, used for multiprocessing
def unwrap_self_f(arg, **kwarg):
    #return C.f(*arg, **kwarg)
    return Bootstrap.parrallel_loop(*arg, **kwarg)

## test function, read first comment in the log to get the correct data type
# could allocate the Data directly here, like in a factory
def GetDataType( filename ):

    try:
        pfile =open(filename,'r')
    except:
        print "error in opening filename ", filename
        #return -1
        sys.exit(1)

    line = pfile.readline()
    pfile.close()

    return line.split()[1]

## class Bootstrap
#
# General class for bootstraping, implements the algorithms
# delegates specific operation to data object
class Bootstrap:

    # keep size_resample as input, but strongly adviced to use an identical size of the initial data sample
    def __init__(self, data, nb_sample, nb_cpus=0, output_file=None, size_resample=None):

        # could have different method
        #print "constructor bootstrap"
        #self.output_file = output_file
        if output_file == None:
            self.output_file = sys.stdout
        else:
            self.output_file = open( output_file, 'w' )

        #data member
        self.nb_sample = nb_sample

        if nb_cpus == 0:
            self.nb_cpus = multiprocessing.cpu_count()
        else:
            self.nb_cpus = nb_cpus
        print "multithread use %d cores " % self.nb_cpus

        # member of Data, intial and list of resampled data
        self.initial_data = data
        # add the computation of the "real mean" from the initial data
        self.initial_data.Compute_Average()

        # assign size_resample
        if size_resample :
            self.size_resample = size_resample
	    print "use a different size for resampling, maybe not what you want"
        # theoritically should resample with the same size
        else :
            self.size_resample = self.initial_data.GetSize()

        self.list_resample_data = list()

        # for results, it will have the same class than initial data
        self.result_data = None

        print "constructor bootstrap : "
        print "size initial data ", self.initial_data.GetSize()
        print "nb_sample ", self.nb_sample
        print "size_resample ", self.size_resample

        # for test
        # Commented out random seed for production calculations.
        # last test random seed seems not working...
        # random.seed( 10 )

    ## create and return a new data with sampled entry, WITH replacements
    # work for all type of data here
    def __resample_initial_data(self):
        #print "resample initial data"
        # here always same sequence
        #random.seed( 10 )

        # for each resampling, make random selection with replacement for bootstrap
        rand_integer = []
        for i in range(self.size_resample):
            rand_integer.append( random.randint(0, self.initial_data.GetSize()-1) )
#        print "rand_integer ", rand_integer

        # make a copy of the initial data
        new_data = self.initial_data.copy( rand_integer )
        return new_data

    ## run bootstrap algorithm for computing standard error
    #  may have option for different algorithms
    #  parallelised inside this function
    def run(self):  #, b_histogram=False ):

        #print "\nbootstrap run\n"
        #print "generate histogram ", b_histogram

        pool = multiprocessing.Pool(processes=self.nb_cpus) #NB_CPUS)
        #print 'pool = %s' % pool

        # trick with zip([self]*len(names), names)
        # ok works
        result = pool.map ( unwrap_self_f,zip([self]*(self.nb_sample),range(self.nb_sample)))
        #print "result ", result
        #print "result[0]", result[0]

        # all data stored in result
        self.list_resample_data=result

        # can be run here, or called later. until list_resample_data is not deleted
        #if b_histogram:
        #    self.generate_histogram()

        # make a new empty copy for the results, size of nb_sample
        self.result_data = self.initial_data.copy( self.nb_sample )

        # add the average of the resampled data
        compt = 0
        for compt in range(len(self.list_resample_data)):
        	self.result_data.AddData( self.list_resample_data[compt].average, compt )

        #print "test result_array_data ", self.result_data.array_data

        # create new statistics on the Bootstrap samples
        self.result_data.Compute_Average()
        self.result_data.Compute_StdError()

        # print the "real mean" computed from the initial data
        ###self.initial_data.print_result()

        # need to overide the average of the real data before printing the result
        self.result_data.average = self.initial_data.GetAverage()

        # print results (jon edited to print the population mean,
        # not the mean of the resampled populations).
        self.result_data.print_result( self.output_file )


        self.output_file.close()

    # may need argument !!
    def parrallel_loop(self,t):

        #name = multiprocessing.current_process().name
        #print name, 'Starting with ', t

        # get a new object data, of the same class as initial data but sampled
        new_data = self.__resample_initial_data()
        #print "new data.array_data ", new_data.array_data

        # ask for its statistic
        new_data.Compute_Average()
        #print "new_data.average", new_data.average

        # can delete array_data here if not used, save a lots of memory !!
        # but keep average
        del new_data.array_data

        return new_data

    ##
    # @param values : list of couples ( contact/window ), should be checked before the call to the function
    # @param save_png : True write histogram_average.png, False draw only on the screen
    def generate_histogram(self, values, save_png=True ):

        try:
            # to uncomment if a plot to a file is needed
            if save_png==True:
                import matplotlib
                matplotlib.use('Agg')
            import matplotlib.pyplot as plt

        except:
            print "Cannot generate histogram, the module matplotlib is not found"
            return

        print "Entry generate histogram values ", values
        #print "len(list_resample) ", len(self.list_resample_data)

        # size should be checked before
        len_values = len(values) / 2
        # create an array of array of 2 elements
        win_contact = split_list( values, len_values )
        #print "win_contact ", win_contact

        # create array for saving averages
        array_average = numpy.zeros( len(self.list_resample_data), dtype=float )

        # need to setup the global figure, not needed in fact
        #fig = plt.figure()

        # hardcore presentation in row and column
        # default values
        nb_row = 1
        nb_column = 1

        if len_values > 6:
            nb_column = 3
        elif len_values > 1:
            nb_column = 2
        # else default 1
        if len_values > 4:
            nb_row = 3
        elif len_values > 2:
            nb_row = 2

        #print "nb_column ", nb_column
        #print "nb_row ", nb_row

        count_plt = 1
        for elem in win_contact:

            # substract 1 to fit C-style array
            hist_contact = elem[0] - 1
            hist_window = elem[1] - 1

            #print "contact ", hist_contact, " window ", hist_window
            # reinitialize array, not needed because data overwritten
            #array_average = 0.

            compt=0
            for data in self.list_resample_data:

                array_average[compt] = data.GetAverage( hist_contact, hist_window )
                compt+=1

            #print "array_average ", array_average
            #print "real average ", self.initial_data.GetAverage( hist_contact, hist_window )

            #ax = fig.subplot(2,2,count_plt)
            plt.subplot(nb_row, nb_column, count_plt)
            count_plt += 1

            #self.first_window + win * self.width_window
            plt.title( "%d cont. at %5.2f angs" % ( elem[0],
                    self.initial_data.first_window + hist_window * self.initial_data.width_window ))

            plt.hist( array_average, bins=25 ) #, log=True )
            #ax.hist( array_average, bins=25 )
            # draw line for the actual "real average"
            #print "axis ", plt.axis()
            #borne_axis = plt.axis()
            #plt.vlines( self.initial_data.GetAverage()[hist_contact][hist_window], 0, borne_axis[3] )
            plt.axvline( self.initial_data.GetAverage(hist_contact,hist_window), color='r', lw=3.0 )

        # has effect only if use('Agg') is commented
        if save_png:
            # correct only with use('Agg')
            plt.savefig("histogram_average.png")
            #fig.savefig("histogram_average.png")
        else:
            plt.show()


## class DataBase, "Abstract" class for the data
#  group most common, default variables and functions
class DataBase:

    def __init__( self, filename='' ):
        #print "init base class"

        if filename =='':
            #print "not a filename"
            self.filename = None
            #self.output_file = None
        else:
            self.filename = filename
            print "Filename ", self.filename

        self.type=''
        # until now, common to both, may be moved later in derived class
        self.nb_contact=0
        self.nb_window=0
        self.first_window=0
        self.width_window=0
        self.size_sample=0

        # to add self.need_modification_average = False # True for assoc, Et

        # array containing the data
        self.array_data = None
        # save pointer to file
        self.pfile = None

        # member for statistical results, could be in derived class
        self.average = None
        self.std_error = None

    ## read common data from header
    def read_header_log(self):
        #print "read header log BaseClass "

        try:
            pfile =open(self.filename,'r')
        except:
            print "error in opening filename ", filename
            sys.exit(1)

        line = pfile.readline()
        self.type = line.split()[1]

        line = pfile.readline()
        #print "line ", line
        self.nb_contact = int( line.split(":")[1] )
        self.nb_window = int ( pfile.readline().split(":")[1] )
        self.first_window = float ( pfile.readline().split(":")[1] )
        self.width_window = float ( pfile.readline().split(":")[1] )

        print "type", self.type
        print "contact ", self.nb_contact
        print "nb_window ", self.nb_window
        print "width ", self.width_window

        self.pfile = pfile

    ## common function to read the data from the log file.
    #  will call derived reconstruct_data
    def read_data_log(self):

        print "read_data_log in base class "
        # numpy.empty (uninitialized) should be faster
        #self.array_data = numpy.zeros( (self.nb_contact, self.nb_window, self.size_sample),dtype=bool )

        print "size array ", numpy.size(self.array_data), numpy.shape( self.array_data )
        #print self.array_data

        compt = 0
        for line in self.pfile.readlines():
            #print "line", line
            self.array_data[...,compt] = self.reconstruct_data( line.split() )
            #print self.array_data[...,compt]
            compt += 1

    ## default function for reconstructing the data.
    #  just read the data in float, loop over nb_contact, nb_win
    def reconstruct_data(self, list_input ):

        #print "DataBase reconstruct data ", list_input
        tmp_contact_win=[]
        compt = 0

        # keep -1 as default
        for contact in range(self.nb_contact):
            tmp_win = [0.]*self.nb_window

            for win in range(self.nb_window) :
                tmp_win[win] = float(list_input[compt])
                compt += 1

            tmp_contact_win.append(tmp_win)

        #print "tmp_contact_win ", tmp_contact_win
        return tmp_contact_win

    ## copy_common data member
    def copy_common(self, new_data):
        # can copy other data member
        new_data.size_sample = self.size_sample
        new_data.nb_contact = self.nb_contact
        new_data.nb_window = self.nb_window
        new_data.first_window = self.first_window
        new_data.width_window = self.width_window

    ## function copy standard, just copy the data
    # can deal with correct data type, not used yet
    # if list_int is a list, fill the new array with resampled data
    # if list_int is an integer, create allocate new array
    def copy(self,list_int=None):

        #print "entry copy DataBase"
        # Base can create DataEt
        #print "self.__class()__", self.__class__()
        new_data = self.__class__()

        # can test attribute, hasattribute, something like this, group in a list

        #copy common data, then specific
        self.copy_common( new_data )

        # apply resampling to the array_data,
        if type(list_int) is ListType :
            new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, len(list_int)) )

            compt = 0
            for i in list_int :
                new_data.array_data[...,compt] = self.array_data[...,i]
                compt += 1

        # else if integer, only allocate array_data to the given size
        elif type(list_int) is IntType:
            new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, list_int) )
            # overwritte some parameter
            new_data.size_sample = list_int

        else :
            print "\ncopy with wrong  argument !!!!\n"
            sys.exit(1)

        #print "after copy and resampling new_data.array_data ", new_data.array_data
        return new_data

    ## add data to the inital array_data at index i
    def AddData( self, data_to_add, i ):
    	self.array_data[...,i] = data_to_add

    ## get size of array_data
    def GetSize(self):
        #print "GetSize ",(self.array_data.shape)[-1]
        return self.array_data.shape[-1]

    # cannot overload in python
    #def GetAverage(self):
        #print "GetAverage ", self.average
    #    return self.average

    #def GetAverage(self, contact, window ):
    #    return self.average[contact][window]

    def GetAverage(self, contact=None, window=None):

        if contact==None and window==None :
            return self.average
        else:
            return self.average[contact][window]

    ## default function, make a normal average
    #  in some case called by derived::compute_average
    def Compute_Average(self):
    	#print "DataBase Compute_Average"

    	# to compare numpy method
    	#self.average = numpy.mean( self.array_data, axis = 2 )

    	self.average = numpy.zeros( (self.nb_contact, self.nb_window) )
    	for i in range(self.size_sample) :
            self.average += self.array_data[...,i]
        self.average /= self.size_sample

    	#print "self.average ", self.average

    ## same for StdError
    def Compute_StdError(self):
    	#print "DataBase ComputeStdError"

    	# to test, numpy method
    	#self.std_error = numpy.std ( self.array_data, axis = 2 )

    	self.std_error = numpy.zeros( (self.nb_contact, self.nb_window) )

    	for i in range(self.size_sample) :
            self.std_error += (self.array_data[...,i] - self.average)**2
        # normalise
        self.std_error = numpy.sqrt ( self.std_error / (self.size_sample-1) )

    	#print "self.std_error ", self.std_error

    ## works in base class at the moment
    def print_result(self, fout ):
        #print "result  DataBase "

        if ( self.average is None ) & ( self.std_error is None ) :
            print "problem in DataBase.print_result"
            sys.exit(1)

        fout.write("# distance  average  std.deviation")

        #with open(bootstrap.output_file, 'w') as fout:
        # print only average
        if ( self.std_error is None ) :

            for contact in range(self.nb_contact) :
                #fout.write( "\n# %s\n" % str(contact+1) )
                fout.write('\n')
                for win in range(self.nb_window) :
                    #first_window + ( iw - 1.0 ) * width_window
                    # Now prints the population mean, not the mean of the resampled
                    # populations.
                    fout.write( "%6.3f  %12.5e\n" % (
                                                       self.first_window +
                                                       win * self.width_window,
                                                       self.average[contact,win] )
                               )
        # print average and std_error
        else :
            for contact in range(self.nb_contact) :
                #fout.write( "\n# %s\n" % str(contact+1) )
                fout.write('\n')
                for win in range(self.nb_window) :
                    # Now prints the population mean, not the mean of the resampled
                    # populations.
                    fout.write( "%6.3f  %12.5e %12.5e\n" % (
                                                             self.first_window + win * self.width_window,
                                                             self.average[contact,win],
                                                             self.std_error[contact,win] )
                            )

## specialized class for association rate
# reconstruction is different, use only integer as input and need to apply conversion factor with beta
class DataAssoc(DataBase):

    def __init__( self, filename='') :

        #print "init Data class", filename
        DataBase.__init__( self, filename )

        # particular to assoc_rate
        self.b_rate=0
        self.c_rate=0
        # set if boolean or not, first default boolean
        # used when applying factor conversion
        self.boolean = True

        # step function to finalize initialization
        if self.filename :
            self.read_log()

    #specialized, call base class for common data, read specific attributes
    def read_log( self ):

        print "read log derived DataAssoc"
        # read common data, assign self.pfile in base class
        self.read_header_log()

        self.b_rate = float ( self.pfile.readline().split(":")[1] )
        self.c_rate = float ( self.pfile.readline().split(":")[1] )
        self.size_sample = int ( self.pfile.readline().split(":")[1] )

        # create array of bool for DataAssoc
        self.array_data = numpy.zeros( (self.nb_contact, self.nb_window, self.size_sample), dtype=bool )

        print "b_rate ", self.b_rate
        print "c_rate ", self.c_rate
        print "size_sample ", self.size_sample

        # call base class again to fill the array
        self.read_data_log()

    ## specialized function, deal with integer => boolean
    def reconstruct_data(self, list_input ):

        #print "reconstruct_data DataAssoc "
        #print list_input

        tmp_contact_win=[]
        for contact in list_input:

            tmp_win = [True]*self.nb_window

            # default sda bootstrap == 0 if never satisfied
            # modified now it is -1 !!
            #if int(contact) != 0 :

            # bug correct first version 2118, modified now it is -1 !!
            #if int(contact) != -1 :

            # 31/05/14 with signal handling 0 is printed when traj not finished
            # reproduce rate, but modify standard deviation, not equivalent to -1
            if ( int(contact) != -1 ) and ( int(contact) != 0 ) :
            	for win in range(int(contact)-1, self.nb_window):
                 	tmp_win[win] = False

            #print "tmp_win ", tmp_win
            tmp_contact_win.append(tmp_win)

        #print "tmp_contact_win", tmp_contact_win
        return tmp_contact_win

    ## copy the full object, resampling the data
    # if list_int is a list, fill the new array with resampled data
    # if list_int is an integer, create allocate new array
    def copy (self, list_int=None ):
        #print "entry copy DataAssoc "

        #new_data = DataAssoc()
        new_data = self.__class__()

        #copy common data, then specific
        self.copy_common( new_data )
        new_data.b_rate = self.b_rate
        new_data.c_rate = self.c_rate

        # apply resampling to the array_data
        if type(list_int) is ListType :
            new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, len(list_int)),dtype=bool )

            compt = 0
            for i in list_int :
                new_data.array_data[...,compt] = self.array_data[...,i]
                compt += 1

        # else if integer, only allocate array_data to the given size
        # here the input data are the first average, so real
        elif type(list_int) is IntType :
        	new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, list_int) )

        	# overwrite some parameters
        	new_data.size_sample = list_int
        	new_data.boolean = False

        else :
            print "\ncopy with wrong  argument !!!!\n"
            sys.exit(1)

        return new_data

    # compute beta as intermediate
    def Compute_Average(self):

        #print "Compute average python DataAssoc"
        #print "b rate ", self.b_rate
        #print "c rate ", self.c_rate
        #print "boolean entry ", self.boolean

        # second step in bootstrap, data are real values
        if self.boolean == False :
        	DataBase.Compute_Average( self )
        	#print "self.average ", self.average
        	return

        self.average = numpy.zeros( (self.nb_contact, self.nb_window) )

        # python normal style, total 14s
        for contact in range(self.nb_contact) :
            for win in range(self.nb_window) :
                sum = 0.
                for ntraj in range(self.size_sample):
                    sum += float ( self.array_data[contact,win,ntraj] )

                # equivalent to sda, beta
                self.average[ contact, win ] = 1. - sum / self.size_sample

                #rate = beta * b / ( 1 - ( 1- beta ) * b/c )
                self.average[ contact, win ] = self.average[ contact, win ] * self.b_rate / \
                                            ( 1 - ((1 -self.average[ contact, win ]) * self.b_rate / self.c_rate ) )

            # apply to the full array
            #self.average = self.average * self.b_rate / \
            #               ( 1 - ((1 -self.average) * self.b_rate / self.c_rate ) )

        #print "self.average ", self.average


# second derived class for First-time-passage
class DataFPT(DataBase):

    def __init__(self,filename=''):
        #print "init DataFPT"
        DataBase.__init__( self, filename )

        # finalize initialization
        if self.filename :
            self.read_log()

    #specialized, call base class for common data, read specific attributes
    def read_log( self ):

        print "read log init DataFPT "
        # read common data, assign self.pfile in base class
        self.read_header_log()
        self.size_sample = int ( self.pfile.readline().split(":")[1] )
        print "size_sample ", self.size_sample

        # can create array
        self.array_data = numpy.zeros( (self.nb_contact, self.nb_window, self.size_sample) )

        # call base class again
        self.read_data_log()

        #print "end read_log DataFPT"

    ## just read the data, could be default in BaseClass
    def reconstruct_data(self, list_input ):

        #print "DataFPT reconstruct data ", list_input
        tmp_contact_win=[]
        compt = 0

        # keep -1 as default
        for contact in range(self.nb_contact):
            tmp_win = [0.]*self.nb_window

            for win in range(self.nb_window) :
                tmp_win[win] = float(list_input[compt])
                compt += 1

            tmp_contact_win.append(tmp_win)

        #print "tmp_contact_win ", tmp_contact_win
        return tmp_contact_win

    # function copy completely standard, could be in DataBase
    def copy(self,list_int=None):

        #print "entry copy DataFPT"
        new_data = self.__class__()

        #copy common data, then specific
        self.copy_common( new_data )

        # apply resampling to the array_data,
        if type(list_int) is ListType :
            new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, len(list_int)) )

            compt = 0
            for i in list_int :
                new_data.array_data[...,compt] = self.array_data[...,i]
                compt += 1

        # else if integer, only allocate array_data to the given size
        elif type(list_int) is IntType:
        	new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, list_int) )
        	# overwritte some parameter
        	new_data.size_sample = list_int

        else :
            print "\ncopy with wrong  argument !!!!\n"
            sys.exit(1)

        #print "after copy and resampling new_data.array_data ", new_data.array_data
        return new_data

    # need specialisation for FPT, take into account -1 never reached
    def Compute_Average(self):

        #print "Compute average DataFPT "
        #print "self.array_data ", self.array_data

        self.average = numpy.zeros( (self.nb_contact, self.nb_window) )

        for contact in range(self.nb_contact) :
            for win in range(self.nb_window) :
                sum = 0.
                nb_recorded = 0
                for ntraj in range(self.size_sample):

                    # do not account for non-reactive trajectory
                    if self.array_data[contact,win,ntraj] != -1. :
                        sum += self.array_data[contact,win,ntraj]
                        nb_recorded += 1

                if nb_recorded > 0:
                    self.average[contact,win] = sum / nb_recorded
                else:
                    self.average[contact,win] = -1.

        #print "average ", self.average

    # same, need to check -1
    def Compute_StdError(self):

        #print "DataFPT Compute_StdError"

        self.std_error = numpy.zeros( (self.nb_contact, self.nb_window) )

        for contact in range(self.nb_contact):
            for win in range(self.nb_window):
                compt=0
                sum=0.
                for ntraj in range(self.size_sample):
                    if self.array_data[contact,win,ntraj] != -1. : #& ( self.average[contact,win] !=-1. ) ) :
                        sum += ( self.array_data[contact,win,ntraj] - self.average[contact,win] )**2
                        compt +=1

                    # test, should never appear ??
                    if (( self.average[contact,win] ==-1. ) & (self.array_data[contact,win,ntraj] != -1.)):
						print " !!!!!!!! need to check average also "
						sys.exit(1)

                if compt > 0:
                    self.std_error [contact,win] = sum / (compt-1)
                else:
                    self.std_error [contact,win] = -1.
        #
        #print "self.result_data.std_error ", self.result_data.std_error
        self.std_error=numpy.sqrt(self.std_error)
        #print "self.std_error ", self.std_error



    # works in base class at the moment
    # need to check for -1
    def print_result(self):
        #print "print result DataFPT"

        if ( self.average is None ) & ( self.std_error is None ) :
            print "problem in DataFPT.print_result"
            sys.exit(1)


        #with open(bootstrap.output_file, 'w') as fout:
        # print only average
        if ( self.std_error is None ) :

            for contact in range(self.nb_contact) :
                #fout.write( "\n# %s\n" % str(contact+1) )
                fout.write('\n')

                for win in range(self.nb_window) :

                    #first_window + ( iw - 1.0 ) * width_window
                    if self.average[contact,win] != -1 :
                        fout.write( "%6.3f  %12.5e\n" % ( self.first_window +  win * self.width_window,
                                                          self.average[contact,win] ) )
                    else:
                        fout.write( "%6.3f  %d\n" % ( self.first_window +  win * self.width_window, 0 ) )

        # print average and std_error
        else :
            for contact in range(self.nb_contact) :
                #fout.write( "\n# %s\n" % str(contact+1) )
                fout.write('\n')
                for win in range(self.nb_window) :

                    if self.average[contact,win] != -1. :
                        fout.write( "%7.3f  %12.5e %12.5e\n" % (self.first_window +  win * self.width_window,
                                                                self.average[contact,win],
                                                                self.std_error[contact,win]) )
                    else:
                        fout.write( "%6.3f  %6d %6d\n" % ( self.first_window +  win * self.width_window, 0, 0 ) )

## class for electron transfer
class DataEt(DataBase):

    def __init__( self, filename='' ) :
        #print "init DataEt ", filename
        DataBase.__init__( self, filename )

        # particular to assoc_rate and electron transfer
        self.b_rate=0
        self.c_rate=0

        # set if boolean or not, first default boolean
        # used when applying factor conversion
        self.need_beta = True

        # step function to finalize initialization
        if self.filename :
            self.read_log()

    # specialized, call base class for common data, read specific attributes
    def read_log( self ):

        print "read log derived DataEt"
        # read common data, assign self.pfile in base class
        self.read_header_log()

        self.b_rate = float ( self.pfile.readline().split(":")[1] )
        self.c_rate = float ( self.pfile.readline().split(":")[1] )
        self.size_sample = int ( self.pfile.readline().split(":")[1] )

        # create array of bool for DataEt
        self.array_data = numpy.zeros( (self.nb_contact, self.nb_window, self.size_sample) )
        #print "type self.array_data ", self.array_data.dtype

        print "b_rate ", self.b_rate
        print "c_rate ", self.c_rate
        print "size_sample ", self.size_sample

        # call base class again to fill the array
        self.read_data_log()



    # compute with beta as intermediate
    def Compute_Average(self):

        #print "Compute average python DataEt"
        #print "b rate ", self.b_rate
        #print "c rate ", self.c_rate
        #print "boolean entry ", self.need_beta
        #print "type self.average ", type(self.average)

        # second step in bootstrap, data are real values
        if self.need_beta == False :
            DataBase.Compute_Average( self )
            #print "self.average ", self.average
            return

        self.average = numpy.zeros( (self.nb_contact, self.nb_window) )

        # python normal style, total 14s
        for contact in range(self.nb_contact) :
            for win in range(self.nb_window) :
                sum = 0.
                for ntraj in range(self.size_sample):
                    sum += float ( self.array_data[contact,win,ntraj] )

                # equivalent to sda, beta
                self.average[ contact, win ] = 1. - sum / self.size_sample

                #rate = beta * b / ( 1 - ( 1- beta ) * b/c )
                self.average[ contact, win ] = self.average[ contact, win ] * self.b_rate / \
                                            ( 1 - ((1 -self.average[ contact, win ]) * self.b_rate / self.c_rate ) )

        # print "self.average ", self.average

    # need for setting need_beta to False, should find a common variable
    def copy (self, list_int=None ):

        # print "entry copy DataEt "

        # create a new object
        new_data = self.__class__()

        #copy common data, then specific
        self.copy_common( new_data )
        new_data.b_rate = self.b_rate
        new_data.c_rate = self.c_rate

        # apply resampling to the array_data,
        if type(list_int) is ListType :
            new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, len(list_int)) )

            compt = 0
            for i in list_int :
                new_data.array_data[...,compt] = self.array_data[...,i]
                compt += 1

        # else if integer, only allocate array_data to the given size
        elif type(list_int) is IntType:
            new_data.array_data = numpy.zeros( (self.nb_contact, self.nb_window, list_int) )
            # overwritte some parameter
            new_data.size_sample = list_int
            new_data.need_beta = False

        else :
            print "\ncopy with wrong  argument !!!!\n"
            sys.exit(1)

        #print "after copy and resampling new_data.array_data ", new_data.array_data
        return new_data

############ Main ############

# To be able to print out the help menu and then the error message
# we need to create a new class and overide the error def.
class MyParser(argparse.ArgumentParser):
    def error(self, message):
        self.print_help()
        sys.stderr.write('\nerror: %s\n\n' % message)
        sys.exit(1)

# Then just instantiate MyParser instead of argparse.ArgumentParser.
parser=MyParser(add_help=True, description="""Bootstrap_multiCPU.py
                            calculates the standard error on the mean for each
                            data point in an SDA output for either association rate,
                            mean first passage time or electron transfer rate.
                                    """)

parser.add_argument("-i", "--assoc_log", dest="file_str", type=str,
                        default="", required=True,
                        help="""assoc_log is the log file for association,
                            first_passage_time, or electron_transfer from an
                            SDA calculation.  Default names are: assoc_bootstrap.log,
                            fpt_bootstrap.log and electron_transfer.log)""")
parser.add_argument("-o", "--output_file", dest="output_file", type=str,
                        #default=None,
                        #required=True,
                        help="""The name of the file that the results are written to.""")
parser.add_argument("-n", "--nb_sample", dest="nb_sample", type=int, default="100",
                        help="""nb_sample is the number of resampled populations
                            (resampled with replacement) of size nrun to create.
                            nb_sample is independent of the value of nrun. nb_sample
                            is typically in the range of 50 - 200, but a range of
                            values should be tested to ensure that the values of the
                            standard error do not vary significantly, as the value of
                            nb_sample is increased, indicating that the calculation
                            is converged.""")
parser.add_argument("-H","--Histogram", dest="histo_values", type=int, nargs='+', default=None,
                        help="""will print an histogram of the average values of the
                             nb_sample. Expects a list of couple integer values corresponding to
                             the contact number and window number.\n
                             Ex. -H 1 20 2 25 \n 2 histograms: 1 contact at window 20 and 2 contact at window 25
                             """)
parser.add_argument("-nc", "--number_cores", dest="NB_CPUS", type=int, default=0,
                        help="""the number of cores to use, default:
                            the number of available system cores.""")

options = parser.parse_args()


try:
    file_str = options.file_str
    nb_sample = options.nb_sample
    output_file = options.output_file
    nb_cpus = options.NB_CPUS
    histo_values = options.histo_values

except:
    print """
    Bootstrap.py -i assoc_log nb_sample output_file

    Where:
    assoc_log is the log file for association, first_time_passage,
    or electron_transfer from an SDA calculation.  Default names are:
    assoc_bootstrap.log, fpt_bootstrap.log or electron_transfer.log

    nb_sample is the number of resampled populations (resampled with
    replacement) of size nrun to create. nb_sample is independent of the
    value of nrun. nb_sample is typically in the range of 50 - 200, but
    a range of values should be tested to ensure that the values of the
    standard error do not vary significantly, as the value of nb_sample
    is increased, indicating that the calculation is converged.

    output_file is the name of the file that the results are written to.
    """
    sys.exit(0)


print "histo_values "
print histo_values

if histo_values != None :
    ## test multiple of 2 for histogram values
    if len(histo_values) % 2 != 0 :
        print "error with -H : a multiple of 2 arguments is necessary contact / window "
        sys.exit(1)

    if len(histo_values) > 18:
        print "error with -H : by default a maximum of 9 histograms are possible "
        print "you may modify the layout in Bootstrap.generate_histogram()"
        sys.exit(1)

#sys.exit()

# get correct data type from the log file
# could allocate the correct Object in the function
data_type = GetDataType(file_str)
if data_type == -1:
    print "error in reading log file"
elif data_type == 'association_rate':
    print "Type association rate, init correct data"
    initial_data = DataAssoc ( file_str )
elif data_type == 'first_time_passage':
    print "Type first time passage, init correct data"
    initial_data = DataFPT ( file_str )
elif data_type == 'electron_transfer':
    print "Type electron transfer, init correct data"
    initial_data = DataEt ( file_str )


## can test directly and compare with sda output
# need to uncomment these lines
# initial_data.Compute_Average()
# initial_data.print_result( output_file )
# sys.exit()

# init and run Bootstrap, optional size of the resampling, default same as initial
bootstrap = Bootstrap ( initial_data, nb_sample, nb_cpus, output_file )

# compute average and standard error from nb_sample resampling
bootstrap.run()

if histo_values != None :
    # if option -H draw or save histogram
    if len(histo_values) >=2 :
        # save_png is True by default. False draw directly on the screen.
        bootstrap.generate_histogram( histo_values, True )
