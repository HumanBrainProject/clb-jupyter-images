#!/usr/bin/python


""" Return Add atoms content in Json format
 
    Need directory where add_atoms file is present
"""

import sys
#import json
from ModPrepareInputSDA.VdWTC_SDA import *


#print "Content-type: application/json"
#print 
#response={'Price':54,'Cost':'99'}
#print(json.JSONEncoder().encode(response))

print "arguement ", sys.argv[1]

path = sys.argv[1]

main_vdw = VdWTC_SDA( path )

main_vdw.GetJson()

output = sys.argv[1]+"/add_atoms.json"
with open(output, 'wb') as fp:
	json.dump(main_vdw.GetJson(), fp, indent=2)
	fp.close()



