#!/usr/bin/python

"""
    Script to generate a pqr file compatible with PrepareInputSDA.py
    
    Easier to split, later could mix both scripts...
    
    Biopython used as default parser, should write all binding to other objects.
    Possibble  strategies:
    
    Simple way, still flexible for charges with OpenBabel and avoid Mol2 files:
    - Split ligands, and compute charges and PQR files (PDB2PKA, PROPKA, OpenBabel)
    - Compute PQR file of the protein.
    - Merge the final result.
    
    Try to integrate Mol2 files to use PDB2PKA, possible later to use with PROPKA 3.1:
    - More tests needed, combining mol2
     
    NMR structures should be usable, the different models will be split into different PQR files
    Chains should be in the selection
"""

import sys, os
import logging, argparse

# import all Biopython modules
from ModPrepareInputSDA.PDBStructure_Biop import PDBBiopStructure
print "After import of PDBStructure_Biop "

logging.basicConfig(filename='PDB2PQR_sda.log',level=logging.DEBUG, filemode="w")

parser = argparse.ArgumentParser(description="Generate a PQR file compatible for SDA")

parser.add_argument("-pdb", dest="list_pdb", required=True, nargs='+', help="The list of pdb filenames")
parser.add_argument("-chain", dest="list_chain", default=None, nargs='+', help="If present, select only the chains")
parser.add_argument("-charge", dest="charge_method", type=str, default="eem", help="method for charge calculation with obabel")
## not logic for the moment
parser.add_argument("-split_ligand", dest="split_ligand", action='store_true', default="True", help="if yes, ligands charges and protonation will be computed in solvent")
parser.add_argument("-ff", dest="ff", default="amber", help="force field for pdb2pqr, default amber")
parser.add_argument("-propka", dest="propka", action='store_true', default="False", help="If propka nust be used, incompatible with babel methods")

parser.add_argument("-pH", dest="pH", type= float, default=7.4, help="pH of the solution for the protonation state")

parser.set_defaults(split_ligand=True)

try :
    options = parser.parse_args()
# parse_arg will return an exit
except SystemExit:
    logging.error("Reading wrong arguments")
    sys.exit(1)
    
logging.info("pdb %s" % options.list_pdb )
logging.info("chain %s" % options.list_chain)
logging.info("charge method %s " % options.charge_method)
logging.info("split_ligand %s " % options.split_ligand)
logging.info("ff %s " % options.ff)
logging.info("Propka %s " % options.propka )
logging.info("pH %f" % options.pH)

print "\n== Input parameters =="
print "list pdb %s" % options.list_pdb
print "list_chain %s" % options.list_chain
print "charge method %s " % options.charge_method
print "force field %s " % options.ff
print "split_ligand %s " % options.split_ligand
print "propka %s " % options.propka
print "pH %3.1f" % options.pH
print "==End input parameters=="

for pdbfile in options.list_pdb:
    
    print "\n== Prepare PDB file %s ==" % (pdbfile)
    
    
    ## Read the pdb structure and select the chains
    try :
        # argument may be used in this program
        pdb_struct = PDBBiopStructure( pdbfile, options.list_chain, options.pH, \
                                       PERMISSIVE=1, QUIET=True, Overwritte_chains=False )
        
        pdb_struct.select_chains()
        # only for test
        # for debugging, function to improve with new data member (pqr stuffs)
        #pdb_struct.print_info_structure()
    
    except Exception as ex:
        print "Exception in parsing the PDB"
        print ex
        logging.error("ERROR: Cannot read the PDB file")
        sys.exit(1)
    
    print "== End Prepare PDB file =="
    #sys.exit()
    
    try :
        pdb_struct.treat_ligands( options.propka, options.split_ligand, options.charge_method )
        
    except Exception as ex:
        print "Exception in dealing with ligand-ion %s" % ex
        logging.error("ERROR: In dealing with ligand %s" % ex )
        sys.exit(1)
    
    #for tests
    #pdb_struct.print_info_structure()
    #sys.exit()
    
    try:
        pdb_struct.AddHydrogens()
    except Exception as ex:
        print "Exception in adding hydrogen %s" % ex
        logging.error("ERROR: In adding hydrogens %s" % ex )
        sys.exit(1)
        
    #for tests check all the structure and exit
    #pdb_struct.print_info_structure( False ) # True )
    
    try:
        pdb_struct.make_PQRStructure()
        pdb_struct.writePQR()
        
    except Exception as ex:
        print "Exception in writing make PQRStrcuture: %s" % ex
        logging.error("ERROR: In writing PQR %s" % ex )
        sys.exit(1)
        
    # Ends correctly
    print "\n=== PDB2PQR_SDA finishes correctly ===\n"
    logging.info("=== PDB2PQR_SDA finishes correctly ===")
    logging.info("**********************************")