#!/usr/bin/python

"""
modified from myFusion_f55.py, 
clustering based on CA atom RMSD, using single-linkage method
do the clustering, output the number in the cluster and the average energy 
in the end 'commplexes'-like  "mycluster.55"  file
for the protein-surface case, the DelRotZ_f55.py should be used before
and input the wtrotz.complexes file
Default RMSD cutoff value is 3.0
@author: Bingding Huang
@date: 07.03.2008
"""

from fort55_lib_SDA7 import *
import os,sys

#################
def printUsage():
    print """
    usage:
    ~/thisFile.py filename  p2.pdb n
    """
    

fn=""
if len(sys.argv)<4:
    printUsage()
    sys.exit(1)
try:
    Fort55file = open(sys.argv[1],'r')
    fn=sys.argv[1]
    
    ##check existency of 
except IndexError:
    printUsage()
    sys.exit(1)

if os.path.exists(sys.argv[2]):
    #print "OK pdb",sys.argv[2]
    pdbfile=sys.argv[2]

else:
    printUsage()
    print "pdb does not exist"
    sys.exit(1)
Number2print=10

try:
    Number2print=int (sys.argv[3])
except IndexError:
    printUsage()
    sys.exit(1)
    


ca_coord=ReadCaAtomPDBFile(pdbfile) # the CA atom coord from pdbfile

# read header SDA 7
line1h=Fort55file.readline()
line2h=Fort55file.readline()

xc1=[] # geometric (mass) center of p1
xc2=[] # geometric (mass) center of p2
line1=Fort55file.readline()
line2=Fort55file.readline()

for id in line1.split()[1:4]:
    xc1.append(float(id))
    

for id in line2.split()[1:4]:
    xc2.append(float(id))


ca_coord2=[]

for c in ca_coord:  # translation to mass center of p2 (-)
    cc=[]
    
    for i in range(3):
	cc.append(c[i]-xc2[i])
    ca_coord2.append(cc)
    
ca_coord=ca_coord2

    
lines=Fort55file.readlines()
Fort55file.close()
lines1=[]
l=""
for l in lines:
    if l.rfind("NAN") == -1:
	lines1.append(l)
	#print l
lines=lines1

if Number2print>len(lines):
    print """
    The number you give is larger than the length of complexes file
    Please give a smaller number which is < %d
    now it continues using the number %d
    """%(len(lines),len(lines))
    Number2print=len(lines)
    


F55Lines=[]

for l in lines[0:Number2print]: # start from the second line
    l=l.rstrip()
    F55l=F55Line(l)
    F55Lines.append(F55l)

    
# now do the clustering
from sets import Set

print os.getcwd()


print "before clustering ", len(F55Lines)
name=Set([])
clusterF55lines={}
RMSD_CUTOFF=3.0


#for f551 in F55Lines:
for i in range(len(F55Lines)):
    f551=F55Lines[i]
    #print f551.step
    if not f551 in name:
	clusterF55lines[f551]=Set([])
	trans1=f551.trans
	rotX1=f551.rotX
	rotY1=f551.rotY
	rotZ1=f551.rotZ
	newCoor1=transform(ca_coord,trans1,rotX1,rotY1,rotZ1,xc1)
	clusterF55lines[f551].add(f551)
	name.add(f551)
	#print f551.step
	#for f552 in F55Lines:
	for j in range(i+1,len(F55Lines)):
	    f552=F55Lines[j]
	    if not f552 in name: 
		if (f551.step !=f552.step):
		    trans2=f552.trans
		    rotX2 = f552.rotX
		    rotY2 = f552.rotY
		    rotZ2 = f552.rotZ
		    newCoor2=transform(ca_coord,trans2,rotX2,rotY2,rotZ2,xc1)
		    rmsd=CA_RMSD(newCoor1,newCoor2)
		    if rmsd<=RMSD_CUTOFF:
			name.add(f552)
			clusterF55lines[f551].add(f552)

			
		

print "After clustering: ", len(clusterF55lines.keys())	
#print name
    
#print clusterF55lines.values()

tags=fn.split(".")
prefix=tags[-1]

fw=open("mycluster.%s"%prefix,"w")

# michael add header
fw.write("%s" % (line1h))
fw.write("%s" % (line2h))

fw.write("%s%8d\n"%(line1[0:25],len(clusterF55lines)))
fw.write(line2)



keys=clusterF55lines.keys()
keys.sort()
#keys.reverse()

i=1
print "%4s  %8s  %4s  %5s  %12s"%("N","step","cl_ size","energy","cl_size with SDA")
for F55l in keys:

    avr_energy=.0
    clust_popul = 0
    for f in clusterF55lines[F55l]:
	avr_energy +=f.energy
#	if (clust_popul == 0):
#	  print "Cluster  "+str(i)+"; population of the first cluster member is "+str(f.population)
#	  print "orig. lines is: ",f,f.population
	clust_popul += f.population
#	print f.energy, f.population
    avr_energy /=len(clusterF55lines[F55l])
    # print out the size of cluster and its average energy and also population from SDA!
    print "%4d  %8d  %4d    %7.3e  %12.6e "%( i,F55l.step, len(clusterF55lines[F55l]), avr_energy,clust_popul)
    i +=1
    #F55l.energy=avr_energy
    #F55l.newEnergyLine()
    fw.write("%s  %4d    %7.3e   %12.6e  \n"%(F55l.line,len(clusterF55lines[F55l]),avr_energy,clust_popul))
    
    
fw.close()
