******Python Script to generate reaction criteria file for association rate calculations in SDA.*******

    
    It defines reaction criteria on the basis of:
    
    1) H-bonding contacts (donor-acceptor pairs) between protein and ligand molecules.
    2) Chlorine-pi interactions .
    3) pi-pi interactions between protein and ligand.



USAGE:

       python  ReactionCriteria.py  protein_pdb  ligand_pdb   distance  ligand_mol2


           protein_pdb -     Name of PDB file of the protein with .pdb extension
           ligand_pdb -      Name of the PDB file of the ligand with .pdb extension
           distance -        Distance criteria to include in reaction criteria file (integer number)
           ligand_mol2 -     Name of the Mol2 file of the ligand with .mol2 extension





*** Test run of this script can be found in the TestRun directory in the same folder ***

*** REFER to  Usage.doc for detailed description of this script *** 
