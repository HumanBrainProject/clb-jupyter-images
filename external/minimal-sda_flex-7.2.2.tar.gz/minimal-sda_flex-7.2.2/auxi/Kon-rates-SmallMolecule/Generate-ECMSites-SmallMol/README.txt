***** This Python script generate test charge file (.tcha file) with ECM sites that is required by the SDA 
      software to calculate Effective Charges for Macromolecules (ECM) for small molecules. ****



USAGE:
         
	python  ECM_ligand.py  ligand_pqr  number_sites

		
		ligand_pqr  - 	Name of PQR file for the ligand with .pqr extension 
		number_sites  - Number of ECM sites (optional parameter) 




**** By default, the particular number of these ECM sites are calculated depending upon the size of the ligand and the 
     distribution of charge across the structure of molecule, e.g. a positively charged ligand will get a higher number 
     of positive ECM sites to maintain the total overall charge. 


     Default number of ECM sites is given as: 


                   nsites= (Total number of atoms)/4 +  2x (total charge on ligand).



**** In case the charge fitting after effective charge calculation with default number of ECM sites is not satisfactory, 
     it is recommended to recalculate effective charges by changing the number of ECM sites by ± 2 and total number of 
     desired ECM sites can be specified using 2nd input parameter.  ****
