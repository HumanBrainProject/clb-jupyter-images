__author__ = 'Gaurav'

import math
import sys
import os



# This function prints information about the script

def printUsage():

    print """
    
    NAME
         ECM_Ligand.py

    DESCRIPTION

         Python script to generate .tcha file with ecm sites that are used for calculation of Effective Charges for Macromolecules (ECM) for small molecules(Ligand)in SDA.
         It takes PQR file of small molecule (ligand) as input and number of ecm sites can also be provided as an optional parameter. 
         By default, number of ecm sites will be calculated depending upon size of the ligand and the overall net charge on the ligand

    
    USAGE

         ECM_ligand.py    ligand_pqr    number_ecm_sites (optional)

         ligand_pqr  -          Name of PQR file for the ligand with .pqr extension
         number_ecm_sites  -    Number of ecm sites (optional parameter)
                                By default, number of ecm sites will be calculated depending upon size of ligand

	 PQR file for ligand can be generated using AMBER as follows:
	   
                                    ambpdb -p ligand.prmtop -pqr < ligand.inpcrd > ligand.pqr


    EXAMPLE
 
	1. Python ECM_ligand.py RIV.pqr
	2. Python ECM_ligand.py RIV.pqr 10


    OUTPUT

	Test Charge File is generated in the same directory where the ligand_pqr file is located with name: ligand_pqr.tcha

     """

if(len(sys.argv)<2):
  printUsage()
  sys.exit(1)


""" A class to deal with x,y and z coordinates of Different atoms
    Calculates distance between any two atoms """

class point:
    x=99999.0
    y=99999.0
    z=99999.0

    def __init__ (self, x, y ,z):
        self.x = x
        self.y = y
        self.z = z

    def print_coors(self):
        print (str(self.x)+"\t"+str(self.y)+"\t"+str(self.z))

    def dist_to(self,apoint):
        return math.sqrt(math.pow(self.x - apoint.x,2) + math.pow(self.y - apoint.y,2) + math.pow(self.z - apoint.z,2))

    def average_with(self, other_point):
        return point((self.x + other_point.x) / 2.0, (self.y + other_point.y) / 2.0, (self.z + other_point.z) / 2.0)

    def length(self):
        return self.dist_to(point(0.0,0.0,0.0))

    def minus(self, other_point):
        return point(self.x - other_point.x, self.y - other_point.y, self.z - other_point.z)

    def plus(self, other_point):
        return point(self.x + other_point.x, self.y + other_point.y, self.z + other_point.z)


# an atom object
class atom:

    def __init__ (self):
        self.atomname = ""
        self.resid = 0
        self.chain = ""
        self.resname = ""
        self.coordinates = point(99999, 99999, 99999)
        self.undo_coordinates = point(99999, 99999, 99999)
        self.element = ""
        self.PDBIndex = ""
        self.line=""
        self.IndicesOfAtomsConnecting=[]
        self.charge= 0.00
        self.radius= 0.00


    # Reads text (PQR format) into an atom object
    # Requires: A string containing the PQR line

    def ReadPQRLine(self, Line):
        self.line = Line
        self.atomname = Line[11:16].strip()
        self.chain = Line[21:22]
        self.resid = int(Line[22:26])

        self.coordinates = point(float(Line[30:38]), float(Line[38:46]), float(Line[46:54]))
        self.element = Line[76:79].strip().upper()
        self.PDBIndex = Line[6:12].strip()
        self.resname = Line[16:20]
        if self.resname.strip() == "": self.resname = " MOL"
        self.charge = Line[55:62]
        self.charge = float(self.charge)
        self.radius = Line[62:70]
        if self.element == "":
            #elif self.element == "": # try to guess at element from name

            two_letters = self.atomname.strip().upper()[0:2]

            # Any number needs to be removed from the element name
            two_letters = two_letters.replace('0','')
            two_letters = two_letters.replace('1','')
            two_letters = two_letters.replace('2','')
            two_letters = two_letters.replace('3','')
            two_letters = two_letters.replace('4','')
            two_letters = two_letters.replace('5','')
            two_letters = two_letters.replace('6','')
            two_letters = two_letters.replace('7','')
            two_letters = two_letters.replace('8','')
            two_letters = two_letters.replace('9','')

            if two_letters=='BR':
                self.element='BR'
            elif two_letters=='CL':
                self.element='CL'
            elif two_letters=='BI':
                self.element='BI'
            elif two_letters=='AS':
                self.element='AS'
            elif two_letters=='AG':
                self.element='AG'
            elif two_letters=='LI':
                self.element='LI'
            elif two_letters=='MG':
                self.element='MG'
            elif two_letters=='RH':
                self.element='RH'
            elif two_letters=='ZN':
                self.element='ZN'
            else: #So, just assume it's the first letter.
                self.element = self.atomname.strip().upper()

                # Any number needs to be removed from the element name
                self.element = self.element.replace('0','')
                self.element = self.element.replace('1','')
                self.element = self.element.replace('2','')
                self.element = self.element.replace('3','')
                self.element = self.element.replace('4','')
                self.element = self.element.replace('5','')
                self.element = self.element.replace('6','')
                self.element = self.element.replace('7','')
                self.element = self.element.replace('8','')
                self.element = self.element.replace('9','')

                self.element = self.element[0:1]



    # Creates a Test_Charge line from the atom object
    # Returns: String
    def Create_Test_Charge_Line(self):

        output = "ATOM "
        output = output + self.PDBIndex.rjust(6) + self.atomname.rjust(5) + self.resname.rjust(4)
        output = output + self.chain.rjust(2)
        output = output + str(self.resid).rjust(4)
        output = output + ("%.3f" % self.coordinates.x).rjust(12)
        output = output + ("%.3f" % self.coordinates.y).rjust(8)
        output = output + ("%.3f" % self.coordinates.z).rjust(8)

        return output

    #Add indexes of neighbor atoms to a list: will be used later to determine atoms with only 1 neighbors
    def AddNeighborAtomIndex(self, index):
        if not (index in self.IndicesOfAtomsConnecting):
            self.IndicesOfAtomsConnecting.append(index)


    #Returns the number of neighbors of any atom
    def NumberOfNeighbors(self):
        return len(self.IndicesOfAtomsConnecting)

""" PQR class
    Load the PQR from a file """

class PQR:


    def __init__ (self):

        self.AllAtoms={}
        self.resids = []


    # Loads a PQR from a file
    # Requires: trajectory_filename, a string containing the trajectory_filename
    def LoadPQR_FromFile(self, trajectory_filename):
        # Now load the file into a list
        file = open(trajectory_filename,"r")
        lines = file.readlines()
        file.close()
        self.LoadPQR_FromArray(lines)

    def LoadPQR_FromArray(self, lines):

        autoindex = 1

        self.__init__()

        for t in range(0,len(lines)):
            line=lines[t]
            if len(line) >= 7:
                if line[0:4]=="ATOM" or line[0:6]=="HETATM": # Load atom data (coordinates, etc.)
                    TempAtom = atom()
                    TempAtom.ReadPQRLine(line)

                    if not TempAtom.resid in self.resids: self.resids.append(TempAtom.resid)

                    self.AllAtoms[autoindex] = TempAtom # because points files have no indices
                    autoindex = autoindex + 1


#Main function which assigns effective charge sites and create a test charge file

def calculate_test_charges(ligand_filename):


    lig = PQR() #Assign a PQR class object
    dipole=[]   # A list to store indices of atoms which form dipole
    positive=[] # A list to store indices of atoms with positive partial charges
    negative=[] # A list to store indices of atoms with negative partial charges
    pos_charges=[] # A list to store charges for atoms with positive partial charges
    neg_charges=[] # A list to store charges for atoms with negative partial charges
    total_charge= 0.0
    lig.LoadPQR_FromFile(ligand_filename)  # function call to load PQR from file

    keys = list(lig.AllAtoms.keys())

    #Caculation of total charge of the ligand
    for index1 in range(0, len(keys)):
            key1 = keys[index1]
            atom = lig.AllAtoms[key1]
            total_charge = total_charge + atom.charge

    print ("The total charge on the ligand is %f \n")%(total_charge)

    #Calculation of additional positive or negative sites to maintain overall charge of ligand in output .tcha file
    positive_sites= 0
    negative_sites= 0
    if total_charge >= 0.5:
        positive_sites= int(total_charge/0.45)
        print ("Since the ligand is positively charged, the output test charge file has %d extra positively charged atoms to maintain a total charge of %f")%(positive_sites,total_charge)

    elif total_charge <= -0.5:
        negative_sites= int(abs(total_charge)/0.45)
        print ("Since the ligand is negatively charged, the output test charge file has %d extra negatively charged atoms to maintain a total charge of %f")%(negative_sites,total_charge)

    else:
        print ("The ligand is neutral and therefore the output test charge file has equal number of positive and negative charged atoms")


    #Calculate neighbors of each atom
    for index1 in range(0, len(keys)-1):
            key1 = keys[index1]
            atom1 = lig.AllAtoms[key1]

            for index2 in range(0, len(keys)):

                key2 = keys[index2]
                atom2 = lig.AllAtoms[key2]
                dist = atom1.coordinates.dist_to(atom2.coordinates)
                if dist > 0.4 and dist < 1.3:  # Distance of heavy atom-hydrogen bond is between 0.4 and 1.2 Angstrom

                    if atom1.element != "H" and atom2.element == "H":

                        temp= atom1.charge + atom2.charge
                        # Replace the charge of heavy atom with the new cumulative charge
                        atom1.charge= temp


                elif dist > 0.4 and dist <= 1.9:   # Distance of C-C, C-O, C-N,C=C bond is between 0.4 and 1.9 Angstrom
                    if atom1.element != "H" and atom2.element != "H":

                        atom1.AddNeighborAtomIndex(index2)


    # separates positive and negative charged atoms
    for index in range(0, len(keys)):
        key3= keys[index]
        atom= lig.AllAtoms[key3]

        if atom.charge > 0.0 and atom.element!= "H":
            positive.append(key3)
            pos_charges.append(atom.charge)

        elif atom.charge < 0.0 and atom.element!= "H":
            negative.append(key3)
            neg_charges.append(atom.charge)


    #Determines the atoms which form dipole and therefore should not be assigned as effective charge sites
    for index3 in lig.AllAtoms:
        atom_c= lig.AllAtoms[index3]
        if atom_c.NumberOfNeighbors()==1:
            index4= atom_c.IndicesOfAtomsConnecting[0]
            key_n= keys[index4]

            atom_n= lig.AllAtoms[key_n]
            if(index3 in positive and key_n in negative)or (index3 in negative and key_n in positive):
                    #if charges of dipole atoms are of same magnitude, they would cancel out their charge
                    if(abs(atom_c.charge - atom_n.charge)<= 0.05):
                        dipole.append(index3) #Add the index of atoms which form dipole to a separate list dipole[]
                        dipole.append(key_n)


    #Removes the dipole forming atoms from list of positive and negatively charged residues
    for index5 in dipole:
        atom=lig.AllAtoms[index5]
        if index5 in positive:

            positive.remove(index5)
            pos_charges.remove(atom.charge)

        elif index5 in negative:

            negative.remove(index5)
            neg_charges.remove(atom.charge)

    #Sort the list of positive and negative charges

    pos_charges= sorted(pos_charges)
    neg_charges= sorted(neg_charges)


    if len(sys.argv)==3:
        num_sites= int(sys.argv[2])
    else:

        num_sites= (len(positive)+ len(negative))/4    # Determine the number of effective charge sites

	num_sites= max(num_sites,6)
    #Extract last elements equal to num_sites: Atoms with maximum positive and maximum negative charges
    pos_charges= pos_charges[-(num_sites/2+ positive_sites):]
    neg_charges= neg_charges[:(num_sites/2 + negative_sites)]


    file= open(ligand_filename.split('.')[0]+".tcha",'w') #open the test charge file

    #Write the test charge file
    for index6 in lig.AllAtoms:
        atom= lig.AllAtoms[index6]
        if atom.charge in pos_charges:

            file.write(atom.Create_Test_Charge_Line()+ "        0.500\n")

        elif atom.charge in neg_charges:

            file.write(atom.Create_Test_Charge_Line()+ "       -0.500\n")


    file.close()


#Generate test charge file by calling the main function
calculate_test_charges(sys.argv[1])
print "\nThe name of output file is: " + sys.argv[1].split('.')[0].split('/')[-1]+".tcha  (can be found in the same directory)"
