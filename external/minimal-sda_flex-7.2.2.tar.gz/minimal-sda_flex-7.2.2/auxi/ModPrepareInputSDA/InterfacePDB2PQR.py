
import sys,logging, imp

## needed for runPDB2PQR
import string
import time
import copy

## it is the missing import
from src.hydrogens import *
#from src.aconf import *
#from StringIO import *

# for printPQRHearder, working !
from main import *

"""
    Interface to the software version 1.8(.2), not clear what to use, make apart of PDBStructure_Biop/ModAddH at the moment
    
    May fluctuate a lot if different propka / pdb2pqr version
"""

## here sure to load pdb2pqr, need to be in PYTHONPATH
fp, pathname, description = imp.find_module('pdb2pqr')
logging.info("tuple %s %s %s", fp, pathname, description)
pdb2pqr_mod = imp.load_module ( 'pdb2pqr', fp, pathname, description )
logging.info("pb2pqr_mod %s", pdb2pqr_mod)

# refer to pdb2pqr.src
from src import *
#from src.utilities import *

# pdb2pka hydrogenRoutines, in fact src/hydrogen.py, to delete these imports
from pdb2pka import *
#import pdb2pka
#from pdb2pka.pka_routines import *
import extensions

logging.info("loaded correctly Interface PDB2PQR")

## it is a function, no class to derive from...
## simple copy of the main routine from PDB2PQR, easier to modify / to plit
def runPDB2PQR(pdblist, ff,
               outname = "",
               ph = None,
               # default in pdb2pqr after the comment #
               # False, modified default value
               verbose = True,
               selectedExtensions = [],
               extensionOptions = utilities.ExtraOptions(),
               propkaOptions = None,
               clean = False,
               neutraln = False,
               neutralc = False,
               ligand = None,
               assign_only = False,
               chain = False,
               debump = True,
               opt = True,
               typemap = False,
               userff = None,
               usernames = None,
               ffout = None):
    """
        Run the PDB2PQR Suite
 
        Arguments:
            pdblist: The list of objects that was read from the PDB file
                     given as input (list)
            ff:      The name of the forcefield (string)
         
        Keyword Arguments:
            outname:       The name of the desired output file
            ph:            The desired ph of the system (float)
            verbose:       When True, script will print information to stdout
                             When False, no detailed information will be printed (float)
            extensions:      List of extensions to run
            extensionOptions:optionParser like option object that is passed to each object. 
            propkaOptions:optionParser like option object for propka30.
            clean:         only return original PDB file in aligned format.
            neutraln:      Make the N-terminus of this protein neutral
            neutralc:      Make the C-terminus of this protein neutral
            ligand:        Calculate the parameters for the ligand in mol2 format at the given path.
            assign_only:   Only assign charges and radii - do not add atoms, debump, or optimize.
            chain:     Keep the chain ID in the output PQR file
            debump:        When 1, debump heavy atoms (int)
            opt:           When 1, run hydrogen optimization (int)
            typemap:       Create Typemap output.
            userff:        The user created forcefield file to use. Overrides ff.
            usernames:     The user created names file to use. Required if using userff.
            ffout:         Instead of using the standard canonical naming scheme for residue and atom names,  +
                           use the names from the given forcefield
             
        Returns
            header:  The PQR file header (string)
            lines:   The PQR file atoms (list)
            missedligandresidues:  A list of ligand residue names whose charges could
                     not be assigned (ligand)
    """
     
    logging.debug("Run a copy of runPDB2PQR()")
    # list of src.pdb.ATOM
    #print "pdblist ", pdblist
    
    #print "ff ", ff
    #print "outname ", outname
    
    pkaname = ""
    outroot = ""
    lines = []
    Lig = None
    atomcount = 0   # Count the number of ATOM records in pdb
     
    period = string.rfind(outname,".")
     
    if period > 0: 
        outroot = outname[0:period]
    else: 
        outroot = outname
 
    if not ph is None:
        pka = True
        pkaname = outroot + ".propka"
        #TODO: What? Shouldn't it be up to propka on how to handle this?
        if os.path.isfile(pkaname): 
            os.remove(pkaname)
    else: 
        pka = False
 
    start = time.time()
 
    if verbose:
        logging.info("Beginning PDB2PQR...")
 
    myDefinition = definitions.Definition()
    #print "after definition init"
    if verbose:
        logging.info("Parsed Amino Acid definition file.")
 
    # Check for the presence of a ligand!  This code is taken from pdb2pka/pka.py
 
    if not ligand is None:
        from pdb2pka.ligandclean import ligff
        myProtein, myDefinition, Lig = ligff.initialize(myDefinition, ligand, pdblist, verbose)        
        for atom in myProtein.getAtoms():
            if atom.type == "ATOM": 
                atomcount += 1
    else:
        logging.info("InterfacePDB2PQR::runPDB2PQR, creates a new protein with:")
        # pdblist is a list of src:pdb:ATOM (Atom class of pdb2pqr)
        #print "pdblist ", pdblist
        # define all strange resiudes names... not clear for now
        #print "myDefinition ", myDefinition
    
    # strange resiude name
    #print "definiton.map ", myDefinition.map
    #print "definition patches ", myDefinition.patches
    
        # pdb2pqr:protein:Protein
        myProtein = protein.Protein(pdblist, myDefinition)
        #print "after Protein init()"
 
    if verbose:
        logging.info("Created protein object -")
        logging.info("\tNumber of residues in protein: %s", myProtein.numResidues())
        logging.info("\tNumber of atoms in protein   : %s", myProtein.numAtoms())
     
    # accept definition, but not used here
    # seems very important for the rest
    myRoutines = routines.Routines(myProtein, verbose)
 
    for residue in myProtein.getResidues():
        multoccupancy = 0
        for atom in residue.getAtoms():
            if atom.altLoc != "":
                multoccupancy = 1
                logging.warning("multiple occupancies found: %s in %s", atom.name, residue)
        if multoccupancy == 1:
            myRoutines.warnings.append("WARNING: multiple occupancies found in %s,\n" % (residue))
            myRoutines.warnings.append("         at least one of the instances is being ignored.\n")
 
    myRoutines.setTermini(neutraln, neutralc)
    myRoutines.updateBonds()
 
    if clean:
        header = ""
        lines = myProtein.printAtoms(myProtein.getAtoms(), chain)
       
        # Process the extensions
        for ext in selectedExtensions:
            module = extensions.extDict[ext]
            tempRoutines = copy.deepcopy(myRoutines)
            module.run_extension(tempRoutines, outroot, extensionOptions)
     
        if verbose:
            logging.info("Total time taken: %.2f seconds", (time.time() - start))
         
        #Be sure to include None for missed ligand residues
        return header, lines, None
     
    #remove any future need to convert to lower case
    if not ff is None:
        ff = ff.lower()
    if not ffout is None:
        ffout = ffout.lower()
 
    if not assign_only:
        # It is OK to process ligands with no ATOM records in the pdb
        if atomcount == 0 and Lig != None:
            pass
        else:
            myRoutines.findMissingHeavy()
        myRoutines.updateSSbridges()
 
        if debump:
            myRoutines.debumpProtein()  
 
        if pka:
            myRoutines.runPROPKA(ph, ff, outroot, pkaname, propkaOptions)
 
        myRoutines.addHydrogens()
        #myhydRoutines = pka_routines.hydrogenRoutines(myRoutines)
        myhydRoutines = hydrogenRoutines(myRoutines)
        #print "after pdb2pka hydrogenRoutines init()"
 
        if debump:
            myRoutines.debumpProtein()  
 
        if opt:
            myhydRoutines.setOptimizeableHydrogens()
            myhydRoutines.initializeFullOptimization()
            myhydRoutines.optimizeHydrogens()
        else:
            #myhydRoutines = hydrogenRoutines(myRoutines)
            myhydRoutines.initializeWaterOptimization()
            myhydRoutines.optimizeHydrogens()
 
        # Special for GLH/ASH, since both conformations were added
        myhydRoutines.cleanup()
 
 
    else:  # Special case for HIS if using assign-only
        for residue in myProtein.getResidues():
            if isinstance(residue, HIS):
                myRoutines.applyPatch("HIP", residue)
 
    myRoutines.setStates()
 
    myForcefield = Forcefield(ff, myDefinition, userff, usernames)
    hitlist, misslist = myRoutines.applyForcefield(myForcefield)
   
    ligsuccess = 0
     
    if not ligand is None:
        # If this is independent, we can assign charges and radii here 
        for residue in myProtein.getResidues():
            if isinstance(residue, LIG):
                templist = []
                Lig.make_up2date(residue)
                for atom in residue.getAtoms():
                    atom.ffcharge = Lig.ligand_props[atom.name]["charge"]
                    atom.radius = Lig.ligand_props[atom.name]["radius"]
                    if atom in misslist:
                        misslist.pop(misslist.index(atom))
                        templist.append(atom)
 
                charge = residue.getCharge()
                if abs(charge - int(charge)) > 0.001:
                    logging.warning("PDB2PQR could not successfully parameterize the desired ligand; it has been left out of the PQR file.")
                    # Ligand parameterization failed
                    myRoutines.warnings.append("WARNING: PDB2PQR could not successfully parameterize\n")
                    myRoutines.warnings.append("         the desired ligand; it has been left out of\n")
                    myRoutines.warnings.append("         the PQR file.\n")
                    myRoutines.warnings.append("\n")
                     
                    # remove the ligand
                    myProtein.residues.remove(residue) 
                    for myChain in myProtein.chains:
                        if residue in myChain.residues: myChain.residues.remove(residue)
                else:
                    ligsuccess = 1
                    # Mark these atoms as hits
                    hitlist = hitlist + templist
     
    # Temporary fix; if ligand was successful, pull all ligands from misslist
    if ligsuccess:
        templist = misslist[:]
        for atom in templist:
            if isinstance(atom.residue, (Amino, Nucleic)): 
                continue
            misslist.remove(atom)
 
    # Create the Typemap
    if typemap:
        typemapname = "%s-typemap.html" % outroot
        myProtein.createHTMLTypeMap(myDefinition, typemapname)
 
    # Grab the protein charge
    reslist, charge = myProtein.getCharge()
 
    # If we want a different naming scheme, use that
 
    if not ffout is None:
        scheme = ffout
        userff = None # Currently not supported
        if scheme != ff: 
            myNameScheme = Forcefield(scheme, myDefinition, userff)
        else: 
            myNameScheme = myForcefield
        myRoutines.applyNameScheme(myNameScheme)
 
    #print "Before printPQRHeader"
    header = printPQRHeader(misslist, reslist, charge, ff, myRoutines.getWarnings(), ph, ffout)
    #logging.info("REMARK, forcefield = %s " % ff)
    #logging.info("REMARK, charge_protein = %f" % charge)
    lines = myProtein.printAtoms(hitlist, chain)
    #print "Header PDB2PQR ", header
    #print "misslist ", misslist
    #print "myProtein ", myProtein
    #print "reslist ", reslist
    #print "charge ", charge
    #print "ff ",ff
    #print "ph ", ph
    #print "ffout ",ffout
    #print "outname ", outname
    #print "hitlist ", hitlist
    
    #print "lines ", lines
 
    # Determine if any of the atoms in misslist were ligands
    missedligandresidues = []
    for atom in misslist:
        if isinstance(atom.residue, (Amino, Nucleic)): 
            continue
        if atom.resName not in missedligandresidues:
            missedligandresidues.append(atom.resName)
 
    # Process the extensions
    for ext in selectedExtensions:
        module = extensions.extDict[ext]
        tempRoutines = copy.deepcopy(myRoutines)
        module.run_extension(tempRoutines, outroot, extensionOptions)
 
    if verbose:
        logging.info("Total time taken: %.2f seconds", (time.time() - start))
    #return header, hitlist, missedligandresidues
    
    logging.info("Header generated by PDB2PQR:\n%s", header)
    ## try to work with myProtein rather than all the lines
    return myProtein, hitlist, missedligandresidues
