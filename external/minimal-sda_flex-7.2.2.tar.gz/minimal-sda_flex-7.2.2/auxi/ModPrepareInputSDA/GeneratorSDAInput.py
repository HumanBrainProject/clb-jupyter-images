
import sys, os, re
import logging
import fileinput
import shutil

"""
    Class for generating input files for the tools : apbs, ecm, ed, hd, lj_rep
    
    Use templates files in a predefined directory ModulesTemplates_PrepareInputSDA/
    Can make better ?
    
"""

class GeneratorSDAInput:
    
    ## stupid, recopy same as in PQRStructure_Biop ! need Utils
    regex = re.compile("([\\w\\\\-]*)\\.pqr$")
    PATH_TEMPLATE= os.path.dirname(__file__) + os.sep + 'Templates'
    #print "path ", PATH_TEMPLATE
    
    def __init__(self, distance_max, pqrnoh_filename, pqr_filename, ios, temp, id, npbe):
        
        #print "init Generator local file "
        #print "pqrnoh_filename ", pqrnoh_filename
        #print "pqr_filename ", pqr_filename   
        
        #self.dirname = None
        self.dirname = '.'
        (head, tail) = os.path.split(pqrnoh_filename)
        #print "head ", head
        #print "tail ", tail
        if head:
            #print "dirname ", head #dirname
            #self.split_directories = True
            self.dirname = head
            self.pqrnoh_filename = tail
        else:
            self.dirname = '.'
            self.pqrnoh_filename = pqrnoh_filename
            
        #else:
        #    print "dirname empty"
            # can still force with an option if wanted, but need a name
                     
        self.pqr_filename = pqr_filename
        # ionic strength
        self.ios = ios
        self.temp = temp
        
        ## extract name information
        m = GeneratorSDAInput.regex.match(self.pqr_filename)
        ## check validity
        #if m:
        #    print 'Match found: ', m.group()
        #    print "group 1: ", m.group(1)
        #else:
        #   print 'No match'
        
        #self.pqrnoh_filename = "pqrnoh_"+m.group(1)+".pdb"
        self.echa_filename = "pqrnoh_"+m.group(1)+".echa"
        self.root_filename = "pqrnoh_"+m.group(1)
        # moved above, get only
        #self.pqrnoh_filename = pqrnoh_filename
        
        #logging.debug("pqr_filename: %s" % (self.pqr_filename))
        logging.debug("root_name: %s" % (self.root_filename))
        logging.debug("self.pqrnoh_filename %s " % (self.pqrnoh_filename))
        logging.debug("self.ios %f" % self.ios )
        #logging.debug("self.dh %s" % self.dh )
        #logging.debug("self.echa_filename %s " % (self.echa_filename))
        
        self.distance_max = distance_max
        #print "distance_max ", distance_max
        
        self.id = id
        self.npbe = npbe
        
        ## create shell_script from a template, 
        ## only for the first loop, will append after
        if ( id == 1 ) | ( self.dirname != '.' ):
            #print "id == 1 copy shell script"
            #print "cp %s/shell_template %s/run_prepare_grids_and_ecm.sh" % (GeneratorSDAInput.PATH_TEMPLATE, self.dirname)
            shutil.copyfile(GeneratorSDAInput.PATH_TEMPLATE + os.sep + "shell_template", self.dirname + os.sep + "run_prepare_grids_and_ecm.sh");
            ## need to make executable for apache common, even for normal execution
            os.system("chmod 777 %s/run_prepare_grids_and_ecm.sh" % (self.dirname) );

        self.line_mk_grid=""
        self.ep = False
        self.ed = False
        self.hd = False
        self.ljrep = False
            
    def generate_shell_script(self):
        """ generate the content and write to the shell script
            expects the script already exists 
        """
            
        logging.debug('generate_shell_script()')
        #print "generate_shell_script()"
        
        ## open the file in append mode, whatever the id
        #print "%s/run_prepare_grids_and_ecm.sh" % (self.dirname)
        self.shell_script = open(("%s" + os.sep + "run_prepare_grids_and_ecm.sh") % (self.dirname),"a")
        
        self.shell_script.write("\n\n###### Preparation of conformation %d #####\n" % self.id )
        ## output for apbs
        if ( self.ep ):
            self.shell_script.write("## compute apbs grid\n")
            self.shell_script.write("cp %s ep_tmp.pqr \n" % self.pqr_filename )
            self.shell_script.write("$APBS apbs.in > apbs%d.ou \n" % self.id )
            self.shell_script.write("cat io.mc >> apbs%d.ou \n" % self.id )
            self.shell_script.write("\n## convert from kT to kcal/mol\n")
            self.shell_script.write("$BIN/convert_grid ep_tmp.grd %s_ep.grd -scale 0.6 -convert > convert_grid%d.ou \n" % (self.root_filename, self.id))
            
            ## make effective charge, could be optional
            self.shell_script.write("\n## compute effective charges\n")
            self.shell_script.write("cp %s tmp.pdb \n" % self.pqrnoh_filename )
            self.shell_script.write("$BIN/ecm_all -fp tmp.pdb -fg %s_ep.grd -is %f -rc 1.0 -fe %s.echa > ecm%d.ou" % \
                                    ( self.root_filename, self.ios, self.root_filename, self.id))
            self.shell_script.write("\n## delete tmp file\nrm ep_tmp.grd ep_tmp.pqr tmp.pdb\n")
            
            
        ## output for other grids
        if ( self.ed | self.hd | self.ljrep ):
            
            self.shell_script.write("\n\n## compute at least one of ed, hd or lj_rep grid\n")
            self.shell_script.write("cp %s ljrep_tmp.pqr \n" % self.pqr_filename )
            self.shell_script.write("cp %s tmp.pdb \n" % self.pqrnoh_filename )
            self.shell_script.write("${BIN}/make_edhdlj_grid %s > make_edhdlj%d.ou \n" % (self.line_mk_grid, self.id ))
            if self.ed:
                self.shell_script.write("mv tmp_ed.grd %s_ed.grd\n" % self.root_filename )
            if self.hd:
                self.shell_script.write("mv tmp_hd.grd %s_hd.grd\n" % (self.root_filename) )
            if self.ljrep:
                self.shell_script.write("mv tmp_ljrep.grd %s_ljrep.grd\n" % (self.root_filename) )
            self.shell_script.write("## delete tmp file\nrm tmp.pdb ljrep_tmp.pqr")
            
        ## close the file after writting
        self.shell_script.close()
    
    ## functions to create specific output files ecm.in, ed.in, hd.in..
    ## and append data to the shell script
    def  generate_ep( self, opt_sizedh=None ):
        """ generate output for apbs and effective charge run """
        
        logging.info("generate_ep sizedh %s", opt_sizedh )
        #self.line_mk_grid += " gen_ep \n"
        #print "generate ep self.dirname ", self.dirname
        if ( self.id == 1 ) | (self.dirname != '.'):
            #print "id == 1 copy shell script"
            shutil.copy(GeneratorSDAInput.PATH_TEMPLATE + os.sep + "apbs.in", self.dirname),
            
            #print "distance_max ", self.distance_max
            #distance_grid = 4  * self.distance_max
            
            # if available use the debye-huckel approximation, 
            # The radius is stored in opt_sizedh, so multiply by 2 
            if opt_sizedh:
                distance_grid = [ 2*opt_sizedh ] * 3 
            # else 2 * the size of the grid
            else:
                distance_grid = [x * 2 for x in self.distance_max]
            logging.info("distance grid %s", distance_grid)
            
            ## apbs has some limitation for grid size
            for i in range(len(distance_grid)):
                # smaller than 129
                if int(distance_grid[i]) < 129:
                    distance_grid[i] = 129
                
                elif (int(distance_grid[i]) < 161):
                    
                    if int(distance_grid[i]) < 150:
                        distance_grid[i] = 129
                    else:
                         distance_grid[i] = 161
                elif (int(distance_grid[i]) < 193):
                    if int(distance_grid[i]) < 180:
                        distance_grid[i] = 161
                    else:
                         distance_grid[i] = 193
                         
                elif (int(distance_grid[i]) < 280):
                    if int(distance_grid[i]) < 225:
                        distance_grid[i] = 193
                    else:
                         distance_grid[i] = 257
                ### large system, add 20 more and wait for apbs rounding
                else:
                    distance_grid[i] = int(distance_grid[i] + 20)
                    
            #logging.info("distance grid ep ", distance_grid)
            logging.info("REMARK distance_grid, EP = %f %f %f", int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) )
            
            # need to adapt the size of the grid in apbs.in
            try :
                #print "Read apbs dir"
                #local_file = fopen("ecm.in")
                #lines = fopen.xreadlines()
                for line in fileinput.input( self.dirname + os.sep + "apbs.in", inplace=True):
                    #print "line ", line
                    if line == "dime 129 129 129\n":
                        logging.info("dime %d %d %d" % ( int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) ))
                    elif line == "ion charge 1 conc 0.150 radius 1.500\n":
                        logging.info("ion charge 1 conc %4.3f radius 1.500" % (self.ios / 1000.))
                    elif line == "ion charge -1 conc 0.150 radius 1.500\n":
                        logging.info("ion charge -1 conc %4.3f radius 1.500" % (self.ios / 1000.))
                        
                    ## add temrature
                    elif line == "temp 298.15\n":
                        logging.info("temp %6.2f" % ( self.temp ))
                        
                    elif line == "lpbe\n" and self.npbe:
                        logging.info("npbe")
                         
                    else:
                        logging.info(line.strip())
                    #print "%d: %s" % (fileinput.filelineno(), line)
                    
            except Exception as ex:
                logging.error("Cannot read apbs.in , ex %s", ex)
                ## or better raise exception to main script
                sys.exit(1)
                
        self.ep = True
        return
    
    def generate_ed(self):
        """ generate ed, fill string for mk_grid """
        
        if ( self.id == 1 ) | (self.dirname != '.'):
            ##os.system("cp %s/ed.in %s" % (GeneratorSDAInput.PATH_TEMPLATE,self.dirname))
            shutil.copy(GeneratorSDAInput.PATH_TEMPLATE + os.sep + "ed.in", self.dirname);
            ## need to adjust the size, ionic strength
            #self.line_mk_grid += "-ed ed.in "
            
            distance_grid = [x * 1.5 for x in self.distance_max]
            #print "distance grid ed ", distance_grid
            logging.info("REMARK distance_grid, ED = %f %f %f", int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) )
            
            # need to adapt the size of the grid in apbs.in
            try :
                #local_file = fopen("ecm.in")
                #lines = fopen.xreadlines()
                for line in fileinput.input(self.dirname + os.sep + "ed.in", inplace=True):
                    #print "line ", line
                    if line == "1.0, 110,110,110\n":
                        logging.info("1.0, %d, %d, %d" % ( int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) ))

                   #NJB: electrostatic desolvation grids always calculated at an ionic strength of zero.
                   # elif line == "100.  78.  1.5\n":
                   #     print "%4.1f  78.  1.5" % (self.ios)
                    #elif line == "ion charge -1 conc 0.100 radius 1.500\n":
                    #    print "ion charge -1 conc %4.3f radius 1.500" % (self.ios / 1000.)
                    else:
                        logging.info(line.strip())
                    #print "%d: %s" % (fileinput.filelineno(), line)
            except Exception as ex:
                logging.error("Got exception: %s", ex)
                raise
        
        # need to apply to all, not only 1
        self.line_mk_grid += "-ed ed.in "
        self.ed = True 
    
    def generate_hd(self):
        """ generate hd, fill string for mk_grid """
        
        if ( self.id == 1 ) | (self.dirname != '.') :
            #self.line_mk_grid += "-hd hd.in "
            ##os.system("cp %s/hd.in %s" % (GeneratorSDAInput.PATH_TEMPLATE, self.dirname ))
            shutil.copy(GeneratorSDAInput.PATH_TEMPLATE + os.sep + "hd.in", self.dirname);
            ## need to adjust the size, ionic strength
            
            distance_grid = [(x + 15.) for x in self.distance_max]
            #print "distance grid hd ", distance_grid
            logging.info("REMARK distance_grid, HD = %f %f %f", int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) )
            
            try :
                #local_file = fopen("ecm.in")
                #lines = fopen.xreadlines()
                for line in fileinput.input(self.dirname + os.sep + "hd.in", inplace=True):
                    #print "line ", line
                    if line == "1.0, 110, 110, 110\n":
                        logging.info("1.0, %d, %d, %d" % ( int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) ))
                    else:
                        logging.info(line.strip())
                    #print "%d: %s" % (fileinput.filelineno(), line)
            except Exception as ex:
                logging.info("Got execption: %s", ex)
                raise
         
        self.line_mk_grid += "-hd hd.in "  
        self.hd = True
        return
    
    def generate_ljrep(self):
        """ generate lj_rep. fill string for ljrep """
        
        if ( self.id == 1 ) | (self.dirname != '.') :
            
            ##os.system("cp %s/lj_rep.in %s" % (GeneratorSDAInput.PATH_TEMPLATE, self.dirname))
            shutil.copy(GeneratorSDAInput.PATH_TEMPLATE+ os.sep + "lj_rep.in", self.dirname);
            
            # need to adjust the size
            distance_grid = [(x*1.5) for x in self.distance_max]
            #print "distance grid lj_rep ", distance_grid
            logging.info("REMARK distance_grid, LJREP = %f %f %f", int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) )
            
            try :
                for line in fileinput.input(self.dirname + os.sep + "lj_rep.in", inplace=True):
                    #print "line ", line
                    if line == "1.0, 60,60,60\n":
                        logging.info("1.0, %d,%d,%d" % ( int(distance_grid[0]),int(distance_grid[1]), int(distance_grid[2]) ))
                    else:
                        logging.info(line.strip())
                    #print "%d: %s" % (fileinput.filelineno(), line)
            except Exception as ex:
                logging.info("Got Exception: %s", ex)
                raise
          
        self.line_mk_grid += "-ljrep lj_rep.in "
        self.ljrep = True
        
        return
    
