
import sys,logging
import Bio.PDB

from openbabel import *

## really need to repeat what is in InterfacePDB2PQR ?
## here sure to load pdb2pqr, need to be in PYTHONPATH
import imp
fp, pathname, description = imp.find_module('pdb2pqr')
print "tuple ", fp, pathname, description
pdb2pqr_mod = imp.load_module ( 'pdb2pqr', fp, pathname, description )
print "pb2pqr_mod ", pdb2pqr_mod

# refer to pdb2pqr.src
from src import *

""" Utility function to transform Atoms, Residues,...
    From Biopython to Openbabel object
"""

# only static function or not ?
class Transformers:
    
    @staticmethod
    def Atoms_BioToObabel ( bioAtoms, obMol ):
        """
            Transform Biopython atoms to Obabel atoms
            Used first for setting obabel ligand
            Can be extended
        
            Need to send ObMol object, not a residue
            
            Creation from scratch, see:
            http://sourceforge.net/p/openbabel/mailman/message/8532252/
        """
        
        logging.debug("Entry Transformers : Atom_BioToObabel")
        ## input 
        logging.debug("size bioatoms %d" % len ( bioAtoms ))
        #logging.debug("bioatoms %s", bioAtoms)
        
        ## declare an object for accessing AtomicNumber in openbabel
        etab = OBElementTable()

        # taken from PDBFormat::ReadMolecule, necessary ??
        obMol.SetChainsPerceived()
        obMol.SetChiralityPerceived()
        ## seems important when it needs to be modified
        obMol.BeginModify()
        
        ## assume only one residue, creates inside this function, 
        ## or outside, better set num, id,... outside
        #this is wrong !
        obres = obMol.GetResidue( 0 )
        
        for atom in bioAtoms:
            #print "atom ", atom.get_full_id()
            
            obatom = OBAtom()
            ## copy all data
            #print "bio coord ", atom.get_coord()
            #print "bio name ", atom.get_name()
            #print "bio element ", atom.element
            #print "bio serial_number ", atom.get_serial_number()
            #print "bio residue ", atom.get_parent().__repr__()
            #print "bio_residue ", atom.get_parent().get_id()
            
            obatom.SetVector( float( atom.get_coord()[0] ), float(atom.get_coord()[1]), float(atom.get_coord()[2]) )
            # name does not work here CA
            #obatom.SetType( atom.get_name() )
            
            ## atom.SetAtomicNum(etab.GetAtomicNum(element.c_str())); openbabel/mol.h:  EXTERN  OBElementTable   etab;
            obatom.SetAtomicNum( etab.GetAtomicNum( atom.element ) )
            #print "bioatom get_serial_number ", atom.get_serial_number()
            obatom.SetId( int(atom.get_serial_number()) )
            
            # It was the missing call !! 3 weeks to find !
            # defined in include/openbabel/atom.h, just set a flag..
            obatom.ForceImplH();
            
            # need one value ?
            #obatom.SetImplicitValence()
            
            # associate correclty atom to obmol and residues
            obMol.AddAtom( obatom )
            ## inside set obatom->SetResidue
            obres.AddAtom( obatom )
            obatom.SetResidue( obres )
            
            # pybel code
            #res->SetSerialNum(atom, atoi(serno.c_str()));
            #res->SetAtomID(atom, sbuf.substr(6,4));
            #res->SetHetAtom(atom, hetatm); # bool
            obres.SetHetAtom( obatom, True)
            
            #obres.SetAtomID( obatom, atom.get_fullname() );
            obres.SetAtomID( obatom, atom.get_name() );
            
            obres.SetSerialNum( obatom, atom.get_serial_number() );
            
            # check data are ok
            #print "ob coord %f", obatom.GetVector()
            #print "ob AtomicNum %d " % obatom.GetAtomicNum()
            # type is setup automatically with SetAtomicNum
            #print "ob type %s " % obatom.GetType()
            #print "ob Id %d " % obatom.GetId()
            # not assigned yet
            #print "ob ImplicitValence %d " % obatom.GetImplicitValence()
            #print "ob GetMass %f " % obatom.GetExactMass()
            
        
        # from http://baoilleach.blogspot.co.uk/2010/04/plug-cclib-into-avogadro.html
        # not sure if necessary       
        obMol.ConnectTheDots()
        obMol.PerceiveBondOrders()
        #obMol.SetTotalSpinMultiplicity(data.mult)
        #obMol.SetTotalCharge(data.charge)
        
        obMol.EndModify()
        
        logging.debug("\nAfter Transform ")
        # summary after modification/assignation of atoms
        # now it is correct, atom type was the limitation
        # not fully, still missing some initialization
        logging.debug("size obmol num bonds= %d" % obMol.NumBonds() )
        logging.debug("size bioatoms = %d" % len ( bioAtoms ) )
        logging.debug("size obmol num residues = %d" % obMol.NumResidues() )
        logging.debug("size obmol num atoms = %d" % obMol.NumAtoms() )
        logging.debug("size obres num atoms = %d" % obres.GetNumAtoms() )  
    
    @staticmethod
    def Atoms_ObabeltoBio ( obMol, struct_builder_pqr, list_atom_names ):
        """
            Inverse of previous, given openbabel molecule/ligand return a list a biopython atoms
        """

        #print "\n=== Entry Atoms_ObabeltoBio ===\n"        
        #print "obMol ", obMol
        #print "obMo.NumResidues ", obMol.NumResidues()
        #print "obMol.GetResidues[0] ", obMol.GetResidue(0)
        #print "obMol.GetResidues[0] ", obMol.GetResidue(0).GetNum()
        resnum = obMol.GetResidue(0).GetNum()
        
        
        #print "struct_builder ", struct_builder_pqr
        #print "list_atom_names ", list_atom_names
        
        etab = OBElementTable()
        # to assign the correct name of atom ( original name from pdb, H+counter_H for hydrogens )
        counter_names = 0
        # rename hydrogens H1,H2...
        counter_H = 1
        
        for obatom in OBMolAtomIter( obMol ):
            
            # check data are ok
            #print "ob coord %f", obatom.GetVector()
            #print "ob AtomicNum %d " % obatom.GetAtomicNum()
            # type is setup automatically with SetAtomicNum
            #print "ob type %s " % obatom.GetType()
            #print "ob Id %d " % obatom.GetId()
            # assigned if correctly read
            #print "ob ImplicitValence %d " % obatom.GetImplicitValence()
            #print "ob GetMass %f " % obatom.GetExactMass()
        
            ## coordonnee special vector in obabel
            coord = [ obatom.GetVector().GetX(), obatom.GetVector().GetY(), obatom.GetVector().GetZ() ]
            #print "coord ", coord
            
            # Used OBElementTable::GetVdwRad(int atomicnum)
            vdw = etab.GetVdwRad ( obatom.GetAtomicNum() )
            #print "VdW ", vdw
            
            atom_id = obatom.GetType()
            #print "atom id", atom_id
            # rename to avoid same name in a residue, biopython limitation
            if atom_id[0] != 'H':
                atom_id = list_atom_names[ counter_names ]
                counter_names += 1
            else:
                atom_id = 'H'+str(counter_H)
                counter_H += 1
                
            
            # name does not contain blank character
            name=atom_id
            # fullname, specific with blanks character, used to print out
            # ok makes the job like this ! (need not more than 3 characters, tested with 2 and 3)
            fullname = " %-3s" % name
            #print "name/fullname:!!"+name+"!!!"+fullname+"!!!"
            
            element_char = obatom.GetType()[0]
            #print "element_char!!"+element_char+"!!!"
            
            ## fullname is used for printing, not name !
            # init a PQRatom here
            struct_builder_pqr.init_atom( name, coord, 0., 0., " ", fullname, resnum, obatom.GetPartialCharge(), vdw, element_char)
            #print "after call to init_atom"
        #sys.exit(0)
        
    @staticmethod
    def AtomsBioToPDBQR( bioatoms, pdbqr_atoms ):
        """
            PDB2PQR accept only a line of PDB as initilizers
        """
        #print "Entry AtomsBioToPDBPQR "
        #print "bioatoms ", bioatoms
        
        # use biopython parser
        io = Bio.PDB.PDBIO()
        
        for atom in bioatoms:
            
            #print "atom ", atom
            #print "atom repr ", atom.__repr__()
            #print "atom serial number ", atom.get_serial_number()
            #print "type serial number : ", type ( atom.get_serial_number() )
            
            # a bit stupid, always the same for all atom in the residue...
            #print "atom.get_parent ", atom.get_parent()
            residue = atom.get_parent()
            #print "residue ", residue
            hetflag, resseq, icode = residue.get_id()
            #print "hetflag:!!"+hetflag+"!!"
            #print "residue.get_segid ", residue.get_segid()
            #print "type resseq:", type (residue.get_segid())
            #print "type resseq:", type( resseq )
            #print "chain id", residue.get_parent().get_id()
            
            # function definition
            #line = io._get_atom_line( atom, hetflag, residue.get_segid(), atom.get_serial_number(), \
            #                          residue.get_resname(), residue.get_segid()," ", residue.get_parent().get_id(), " " )
            # hetfield == " " means normal residue other will print HETATM
            line = io._get_atom_line( atom, " ", residue.get_segid(), atom.get_serial_number(), \
                                      residue.get_resname(), resseq, 0 , residue.get_parent().get_id(), " " )
            #print "line ", line
            # call pdb2pqr:pdb:ATOM constructor
            # constructor accept only a string from PDB...so bad...
            pqr_atom = pdb.ATOM( line )
            ## add to the list to return
            pdbqr_atoms.append( pqr_atom )
        
        #print "pdbqr_atoms ", pdbqr_atoms
        
    @staticmethod
    def AtomsPDBQRtoBio( struct_pqr, struct_build_pqr, pdbqr_atoms ):
        """
            Back transform, recreate BioPython list of atoms
        """
        #print "\n== Entry PDBPQToToBio ==\n"
        #print "struct_pqr ", struct_pqr
        #print "struct_build_pqr ", struct_build_pqr
        #print "pdbqr_atoms ", pdbqr_atoms
        
        
         #__init__(self, use_model_flag=0) 
        #io = Bio.PDB.PDBIO()
        
        # loop over pdb2pqrAtom
        for atom in pdbqr_atoms:
            
            #print "atom ", atom
            #print "type atom ", type (atom)
            #print "atom.name ", atom.get("name")
            #print "atom.get_resNname ", atom.get("resName")
            #print "atom.get_type ", atom.get("type")
            #print "atom.get_serial ", atom.get("serial")
    
            #print "bio name", atom.get("name")
            name = atom.get("name")
            coord = list()
            coord.append(atom.get("x"))
            coord.append(atom.get("y"))
            coord.append(atom.get("z"))
            #print "coord ",coord
            fullname = " %-3s" % name
            
            #print "atom.get_resSeq ", atom.get("resSeq")
            resnum = atom.get("resSeq")
            
            #print "atom.charge ", atom.get("ffcharge")
            charge = atom.get("ffcharge")
            #print "atom.get_radius", atom.get("radius")
            vdw = atom.get("radius")
            #print "element %s" % atom.element
            element = atom.element
           
            #print "before Transformers:AtomsPDBPQToBio:struct_build_pqr.init_atom" 
            struct_build_pqr.init_atom( name, coord, 0., 0., " ", fullname, resnum, charge, vdw, element)
            #print "after Transformers:AtomsPDBPQToBio:struct_build_pqr.init_atom"
            
        #print "\n == End Transformers:AtomsPDBQRtoBio ==\n"
        