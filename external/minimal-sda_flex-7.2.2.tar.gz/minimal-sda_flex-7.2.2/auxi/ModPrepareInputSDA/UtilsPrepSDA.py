

import logging

from PQR import *

"""
    Functions used by the PrepareInputGridSDA module
"""


def get_central_atom( list_atom ):
    """ given a list atom, return the atom which is closest to the geometric center """
    
    print "Entry Utils.get_central_atom()"
    
    return list_atom[0]
    
        

 