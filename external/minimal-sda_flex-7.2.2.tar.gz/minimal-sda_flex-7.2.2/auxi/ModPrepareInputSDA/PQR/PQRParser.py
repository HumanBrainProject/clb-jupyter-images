
""" PQRParser, derive from PDBParser """
import os, sys, numpy
import logging
from Bio.PDB import PDBParser
from Bio.PDB.PDBExceptions import \
        PDBConstructionException, PDBConstructionWarning
        

class PQRParser(PDBParser):
    
    def __init__(self, PERMISSIVE=True, get_header=False,
                   structure_builder=None, QUIET=False):
        
        #not sure if necessary        
        PDBParser.__init__( self, PERMISSIVE, get_header, structure_builder, QUIET )
        
        #print "PQRParser init"
        #print "access parent self.header ", self.header
        #print "access parent ", self.structure_builder
        #print "Quiet ", self.QUIET
        
    def set_overload_chains(self, bool_over ):
        
        self.overload_chainid = bool_over
        if bool_over :
            logging.info("Will reassign a new name to the chains, must be split with TER")
            
    def create_structure( self, id ):
        """
            Similar to get structure, but creates from scratch
        """
        
        logging.info("Entry create_structure ")
        # Make a StructureBuilder instance (pass id of structure as parameter) 
        self.structure_builder.init_structure(id)
        
        # Return the Structure instance 
        structure = self.structure_builder.get_structure()
        
        return structure 
        
    def _parse_coordinates(self, coords_trailer):
        "Parse the atomic data in the PDB file."
        
        #print "_parse coordinates PQR "
        local_line_counter=0
        structure_builder=self.structure_builder
        current_model_id=0
        # Flag we have an open model
        model_open=0
        # try other, avoid ' '
        #current_chain_id=None
        current_chain_id = "-1"
        
        current_segid=None
        current_residue_id=None
        current_resname=None
        
        # Case of reading NTR (first atom or CTR, normally not last)
        # First by default make a new residue
        postpone_res = False
        bTER = False
        
        #print "coords_trialer ", len(coords_trailer)
        for i in range(0, len(coords_trailer)):
            line=coords_trailer[i]
            
            #print "line ", line
            record_type=line[0:6]
            
            global_line_counter=self.line_counter+local_line_counter+1
            structure_builder.set_line_counter(global_line_counter)
            
            #print "record_type!!!%s!! " % record_type
            
            if(record_type=='ATOM  ' or record_type=='HETATM'):
                # Initialize the Model - there was no explicit MODEL record
                if not model_open:
                    #print "init model"
                    structure_builder.init_model(current_model_id)
                    current_model_id+=1
                    model_open=1
                    
                fullname=line[12:16]
                
                # get rid of whitespace in atom names
                split_list=fullname.split()
                if len(split_list)!=1:
                    # atom name has internal spaces, e.g. " N B ", so
                    # we do not strip spaces
                    name=fullname
                else:
                    # atom name is like " CA ", so we can strip spaces
                    name=split_list[0]
                
                altloc=line[16:17]
                resname=line[17:20]
                chainid=line[21:22]
                
                if postpone_res:
                    #print "new resname ", resname, chainid
                    #structure_builder.rename_first_residue(current_chain_id, resname)
                    # assign the new name
                    structure_builder.residue.resname = resname
                    postpone_res = False
                
                # first time set both
                if self.overload_chainid:
                    
                    if chainid != " ":
                        logging.warning("You should not use -rename_chains if they are present in the PQR file !!!")
                         
                    if (current_chain_id == "-1"):
                        chainid = "0" #here different the first time
                        logging.info("Will assign automatically chain numbers start with 0")
                    ## else copy value of current, new chain if TER
                    
                    else:
                        if ( bTER ):
                            int_chain = int ( current_chain_id )
                            int_chain = int_chain + 1;
                            # update chainid to be different of current
                            chainid = str(int_chain)
                            bTER = False
                            logging.info("update chainid %s", chainid)
                            #chainid = current_chain_id + 1
                        else:
                            chainid = current_chain_id
                            #print "Other re-assign current ", current_chain_id
                
                # what is serial number
                try:
                    serial_number=int(line[6:11])
                except:
                    serial_number=0
                    
                resseq=int(line[22:26].split()[0])   # sequence identifier   
                icode=line[26:27]           # insertion code
                
                if record_type=='HETATM':       # hetero atom flag
                    if resname=="HOH" or resname=="WAT":
                        hetero_flag="W"
                    else:
                        hetero_flag="H"
                        
                else:
                    hetero_flag=" "
                residue_id=(hetero_flag, resseq, icode)
                # atomic coordinates
                try:
                    x=float(line[30:38]) 
                    y=float(line[38:46]) 
                    z=float(line[46:54])
                except:
                    #Should we allow parsing to continue in permissive mode?
                    #If so what coordindates should we default to?  Easier to abort!
                    raise PDBConstructionException(\
                        "Invalid or missing coordinate(s) at line %i." \
                        % global_line_counter)
                    
                #print "coordinates ", x, y, z
                coord=numpy.array((x, y, z), 'f')
                # occupancy & B factor
                try:
                    #occupancy=float(line[54:60])
                    #occupancy=float(line[54:62])
                    occupancy = 0.
                    charge = float(line[54:62])
                except:
                    self._handle_PDB_exception("Invalid or missing charge",
                                               global_line_counter)
                    occupancy = 0. #Is one or zero a good default?
                    charge = 0.
                    
                try:
                    #bfactor=float(line[60:66])
                    #bfactor=float(line[63:68])
                    bfactor = 0.
                    vdw_radius = float(line[63:68])
                    
                except:
                    self._handle_PDB_exception("Invalid or missing vdw radius",
                                               global_line_counter)
                    bfactor = 0. #The PDB use a default of zero if the data is missing
                    vdw_radius = 0.
                
                #print "occup, bfactor ", occupancy, bfactor
                
                ### all has been extracted
                
                # What do they try to read ??
                segid=line[72:76]
                element=line[76:78].strip()
                
                if current_segid!=segid:
                    #print "different segid"
                    current_segid=segid
                    structure_builder.init_seg(current_segid)
                    
                if current_chain_id != chainid:
                    logging.info("different chain id %s %s", current_chain_id, chainid)
                    current_chain_id=chainid
                    structure_builder.init_chain(current_chain_id)
                    current_residue_id=residue_id
                    current_resname=resname
                    
                    # only the case of N terminal and first atom in the chain   
                    if (current_resname[:2] == "NT"): #or (current_resname[:2] == "CT"):
                        logging.info("Found a first terminal at begin of a chain", current_resname)
                        logging.info("postpone init set to True")
                        postpone_res = True
                        
                    try:
                        structure_builder.init_residue(resname, hetero_flag, resseq, icode)
                    except PDBConstructionException, message:
                        self._handle_PDB_exception(message, global_line_counter)
                        
                #elif current_residue_id!=residue_id or current_resname!=resname:
                elif current_residue_id != residue_id:
                    #print "different residue id or current_resname ", residue_id, current_resname
                    current_residue_id=residue_id
                    current_resname=resname
                    
                        
                    try:
                        structure_builder.init_residue(resname, hetero_flag, resseq, icode)
                    except PDBConstructionException, message:
                        self._handle_PDB_exception(message, global_line_counter)
                        
                #print "all case try to insert atom" 
                # init atom
                try:
                    structure_builder.init_atom(name, coord, bfactor, occupancy, altloc,
                                                fullname, serial_number, charge, vdw_radius, element)
                except PDBConstructionException, message:
                    self._handle_PDB_exception(message, global_line_counter)
            elif(record_type=='ANISOU'):
                anisou=map(float, (line[28:35], line[35:42], line[43:49], line[49:56], line[56:63], line[63:70]))
                # U's are scaled by 10^4 
                anisou_array=(numpy.array(anisou, 'f')/10000.0).astype('f')
                structure_builder.set_anisou(anisou_array)
            elif(record_type=='MODEL '):
                try:
                    serial_num=int(line[10:14])
                except:
                    self._handle_PDB_exception("Invalid or missing model serial number",
                                               global_line_counter)
                    serial_num=0
                structure_builder.init_model(current_model_id,serial_num)
                current_model_id+=1
                model_open=1
                current_chain_id=None
                current_residue_id=None
            elif(record_type=='END   ' or record_type=='CONECT'):
                # End of atomic data, return the trailer
                self.line_counter=self.line_counter+local_line_counter
                return coords_trailer[local_line_counter:]
            elif(record_type=='ENDMDL'):
                model_open=0
                current_chain_id=None
                current_residue_id=None
            elif(record_type=='SIGUIJ'):
                # standard deviation of anisotropic B factor
                siguij=map(float, (line[28:35], line[35:42], line[42:49], line[49:56], line[56:63], line[63:70]))
                # U sigma's are scaled by 10^4
                siguij_array=(numpy.array(siguij, 'f')/10000.0).astype('f')   
                structure_builder.set_siguij(siguij_array)
            elif(record_type=='SIGATM'):
                # standard deviation of atomic positions
                sigatm=map(float, (line[30:38], line[38:45], line[46:54], line[54:60], line[60:66]))
                sigatm_array=numpy.array(sigatm, 'f')
                structure_builder.set_sigatm(sigatm_array)
                
            ## Michael, add TER marker, to deal with many chains not marked
            elif (record_type[:3]=='TER'):
                #print "Meet TER chainid ", chainid
                #print "Meet TER chainid ", current_chain_id
                
                #if ( chainid == current_chain_id == ' ' ):
                if ( self.overload_chainid ):
                    # If still an other chain, TER will be set to mark it, if not do nothing
                    bTER = True
                    #print "Got TER Force a new chain current chainid", current_chain_id, chainid
                    
            local_line_counter=local_line_counter+1
            
        # EOF (does not end in END or CONECT)
        self.line_counter=self.line_counter+local_line_counter
        
        #print "total chain number "
        #for chain in structure_builder.get_chains():
        #    print "chain ", chain.__repr__()
        
        return []