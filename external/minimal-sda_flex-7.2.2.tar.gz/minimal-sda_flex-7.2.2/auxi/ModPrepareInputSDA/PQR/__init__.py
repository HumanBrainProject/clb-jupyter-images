
""" Module to extend PDB 

"""

#import  Bio
# better like this, import PQR
from Bio.PDB import *

# add class to derive
from PQRParser import PQRParser
from PDB_SDAParser import PDB_SDAParser

from PDBIO_SDA import *
from PQRIO import *

from PQRAtom import PQRAtom
from PQRResidue import PQRResidue

#from StructureBuilderPQR import StructureBuilderPQR
#from StructureBuilder2 import StructureBuilder2
from PQRStructureBuilder import PQRStructureBuilder

