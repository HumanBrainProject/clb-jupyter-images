

## follow same logic, exception may be important error
## BiopythonWarning are just warning which can be switched off
from Bio import BiopythonWarning

# The PDB file cannot be unambiguously represented in the SMCRA 
# data structure
class PQRConstructionException(Exception):
    pass

# warning can be switched off
class PQRConstructionWarning(BiopythonWarning):
    pass
