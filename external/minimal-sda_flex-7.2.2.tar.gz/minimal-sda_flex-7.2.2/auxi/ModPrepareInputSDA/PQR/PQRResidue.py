
""" PQRParser, derive from PDBParser """
import os, sys, numpy, math
# need ?
from Bio.PDB.Residue import Residue
from Bio.PDB.Entity import Entity

from PQRException import PQRConstructionException, PQRConstructionWarning 

class PQRResidue(Residue):
    
    def __init__(self, id, resname, segid, term=None ):
        
        Residue.__init__( self,id, resname, segid )
        
        #print "init PQRresidue "
        #print "with term:", term
        # will be set later by compute_charge_residue
        self.charge = 0.
        
        # contains keyword, NTR, CTR, NTN, CTN
        self.term_tc = None
        
        ## maybe need additional info ?
        self.ion = False
        self.ligand = False
        
    def add(self, atom):
        """Add an Atom object. 
            Checks for adding duplicate atoms, 
            and raises a PDBConstructionException if so.
            
            Here overwritten but maybe not necessary, mainly test
        """ 
        
        #print "PQRResidue::add overwritten"
        atom_id=atom.get_id()
        #print "atom_id ", atom_id
        if self.has_id(atom_id):
            raise PDBConstructionException( "Atom %s defined twice in residue %s" % (atom_id, self)) 
        
        # same excpetion in Entity.Add
        Entity.add(self, atom)
        #print "End PQRResidue::add overwritten" 
        
    def set_charge(self, total_charge_residue):
        """ Set the total charge for a residue, check if is an integer"""
        self.charge = total_charge_residue
        # test if integer, done before ?
        return True
    
    def get_charge(self):
        """return the total charge of this residue"""
        return self.charge
    
    def compute_charge_residue(self):
        """ Add the charge of all atom of the residue 
            throw PQRConstructionException
        """
        #print "comptue charge_residue()"
        
        tot_charge = 0.
        # marker similar to PQRAtom, apply to the whole residue
        #self.term_tc = None
        
        ## can check VdW more than 0., seems some force field put 0.
        VDW_MIN = 0.0 # can > -0.001
        
        WARN = None
        
        # Check for wrong VdW, only if negative
        # Some FF assign 0 to some Hydrogens
        for atom in self.get_list():
            #print "atom charge ", atom.get_charge()
            tot_charge += atom.get_charge()
            if ( atom.get_radius() < VDW_MIN ):
                print "Error: VdW radius is negative"
                raise PQRConstructionException("VdW radius is too small")
        
        #print "############### Check if total charge is integer #
        # test with 10 digits precision, seems fine
        if ( not( round( tot_charge, 3 ).is_integer()) ):
        #if ( not math.modf(tot_charge)[0] < 0.005 ):
            
            print ("Warning: Charged on residue %s %s is not an integer: %f " % (self.get_resname(), self.get_id()[1], tot_charge))
            #self.set_charge( round(tot_charge) )
            self.set_charge( tot_charge )

            # will print a warning
            WARN = tot_charge
            
            #raise PQRConstructionException("Charged on residue %s %d is not an integer: %f " % (self.get_resname(), self.get_id()[1], tot_charge) )
            #raise PQRConstructionWarning("Charged on residue %s %d is not an integer: %f " % (self.get_resname(), self.get_id()[1], tot_charge) )
            #warnings.warn("Warning not an integer",PQRConstructionWarning)
        
        else :
            # assign the integer charge
            #self.set_charge( int(tot_charge) ), int round to 0
            self.set_charge( round(tot_charge) )
        
        return WARN
    
    def assign_ligand_ion(self):
        """Assign ligand and ion flag to residues
           Important for adding VdW and TestCahrges later on
        """
        
        #print "assign ligand/ion marker"
        #print "len(get_list) ", len(self.get_list())
        
        ## if size of the residue == 1, it is a ion,
        ## will assign Test charges more easily
        if len(self.get_list()) == 1:
            print "Assign ion to the residue %s" % self.get_resname()
            self.ion = True
            
        elif len(self.get_list()) > 1:
            print "Assign ligand to the residue %s" % self.get_resname() 
            self.ligand = True
            
        else:
            print "ERROR: Cannot assign ion or ligand"
        
    
    def make_terminal(self, str_term ):
        """Make terminal for SDA computation, add NTR and CTR respectively to the first and last residue"""
        
        #logging.info("make terminal %s" % str_term)
        
        # N-terminus always on the first N atom of the chain
        if  (str_term == "NTR") | (str_term=="NTN"):
            #print "add N-terminal "
            ## consider than N of the backbone is common to all amino-acid
            if self.has_id('N'):
                atom = self['N']
                #print "len of atom selection ", len(atom)
                #print "atom ", atom.get_id()
                #print "atom ", atom.get_coord()
                atom.set_term( str_term )
                self.term_tc = str_term
            #else if self.has_id('')
            #else:
                
            
        # C-terminus always on the 2 last Oxygen atom of the chain
        # Amber O OXT, PARSE O1, O2
        elif (str_term == "CTR") | (str_term=="CTN"):
            
            #print "add C-terminal "
            # maybe should test OXT
            #print "atom fullname OXT", atom.get_fullname()
            if self.has_id('OXT'):
                #print "found OXT, it is amber ff"
                atom = self['OXT']
                atom.set_term( str_term )
                atom = self['O']
                atom.set_term( str_term )
                self.term_tc = str_term
            elif self.has_id('O1'):
                #print "found O1, it is parse ff"
                atom = self['O1']
                atom.set_term( str_term )
                atom = self['O2']
                atom.set_term( str_term )
                self.term_tc = str_term
            
            # or make a default, first two oxygens ?
            else:
                print "Error in make terminal"
                
            #print "atom ", atom.get_id()
            #print "coord ", atom.get_coord()
            #print "new resname ", atom.get_resname()
            
        else:
            print "Error str_term not implemented"
            sys.exit()
    
