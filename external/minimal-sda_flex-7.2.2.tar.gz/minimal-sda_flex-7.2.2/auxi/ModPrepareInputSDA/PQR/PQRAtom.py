
""" PQRParser, derive from PDBParser """
import os, sys, numpy
# need ?
from Bio.PDB.Atom import Atom


class PQRAtom(Atom):

    #print "load PDBParser()"
    #parser = PDBParser()
    
    ## unique identifier
    #id_global = 0
    
    def __init__(self, name, coord, bfactor, occupancy, altloc, fullname, serial_number,
                 charge, radius, element=None):
        
        Atom.__init__( self, name, coord, bfactor, occupancy, altloc, fullname, serial_number,
                       element )
                       #element=None)
        
        #print "init PQRatom "
        self.charge = charge
        self.radius = radius
        
        #print "set atom "
        #print "name ", self.name
        #print "element ", self.element
        #print "self.charge ",self.charge
        #print "self.radius ",self.radius
        self.occupancy = 0.
        self.bfactor = 0.
        #print "self.occupancy ",self.occupancy
        #print "repr ", self.__repr__
        
        # declare marker for Test charges on terminus, used for SDA and ecm tools
        self.term_tc = None
        #self.Cterm = False
    
    def set_charge(self, charge):
        """set the charge """
        self.charge = charge
        
    def get_charge(self):
        """Return occupancy."""
        return self.charge
    
    def set_radius(self, radius):
        """set radius"""
        self.radius = radius
        
    def get_radius(self):
        "Return VdW radius."
        return self.radius
    
    def set_resname(self,res):
        
        self.resname = res
        
    def set_term(self, str):
        """set the terminal, one of the string NTR, NTN, CTR, CTN """
        
        #print "set_term() "
        self.term_tc = str 
        #print "set %s to %s" % ( self.__repr__(), str )
        
    def get_term(self):
        """Return terminal marker, None by default """
        
        return self.term_tc

            
        

    