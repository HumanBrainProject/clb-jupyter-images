
import logging
from Bio.PDB.PDBIO import *

#from PDBIO import *

# strange cannot load this ? copy from PDBIO header
_ATOM_FORMAT_STRING="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%6.2f%6.2f      %4s%2s%2s\n"
##_ATOM_FORMAT_STRING="%s%5i %-4s%c%3s %c%4i%c   %8.3f%8.3f%8.3f%6.2f%6.2f      %4s%2s%2s\n"

class PDBIO_SDA(PDBIO):
    
    def __init__(self, use_model_flag=0):
        """
        @param use_model_flag: if 1, force use of the MODEL record in output.
        @type use_model_flag: int
        """
        PDBIO.__init__(self, use_model_flag)
        
    ## format for SDA output, need marker if termini are charged
    def _get_atom_line(self, atom, hetfield, segid, atom_number, resname, 
        resseq, icode, chain_id, charge="  "):
        """Returns an ATOM PDB string (PRIVATE)."""
        
        #print "_get_atom_line()"
        
        if hetfield!=" ":
            record_type="HETATM"
        else:
            record_type="ATOM  "
        if atom.element:
            element = atom.element.strip().upper()
            
            if element.capitalize() not in atom_weights:
                raise ValueError("Unrecognised element %r" % atom.element)
            element = element.rjust(2)
        else:
            element = "  "
        name=atom.get_fullname()
        altloc=atom.get_altloc()
        x, y, z=atom.get_coord()
        bfactor=atom.get_bfactor()
        occupancy=atom.get_occupancy()
        
        #print "name ", name
        #print "resname ", resname
        #print "get_term ", atom.get_term()
        
        str_term = atom.get_term()
        if str_term:
            logging.debug("modification for charged terminal of res %s to %s" % (resname,str_term) )
            #print "modif terminal for charged terminl of residue ", resname, " to ", str_term
            resname = str_term
            
        args=(record_type, atom_number, name, altloc, resname, chain_id,
            resseq, icode, x, y, z, occupancy, bfactor, segid,
            element, charge)
        return _ATOM_FORMAT_STRING % args
    
    