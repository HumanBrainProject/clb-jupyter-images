

import os, sys
import logging, re, math

from PQR import *

# for Molecular Weight
from Bio.SeqUtils.ProtParam import * #ProteinAnalysis
from Bio.Seq import *
from Bio.PDB.Vector import Vector

from VdWTC_SDA import *
import Polypeptide_DNA

"""
    Specialized class for pqr structure with Biopython
    
    Constructor accpets:
    - pqr files
    - pqrnoh_X.pdb files, pdb files for SDA with indication of the terminal CTR/NTR/NTN/CTN
    
    Michael Martinez 6/11/2013
"""

class PQRBiopStructure:

    ## unique identifier
    id_global = 0
    ## match any_name.pqr, sign "-" was missing, working but not with directory
    ##regex = re.compile("([\\w\\\\-]*)\\.pqr$")
    # seems ok with character /, but do not extract correctly
    #regex = re.compile("([\\w\\\\-\\\\/]*)\\.pqr$")
    

    def __init__( self, file, type="pqr", PERMISSIVE=1, QUIET=True, Overwritte_chains=False ):
        #print "init PQRBiopStructure "
        
        # load the complete pdb file, add an unique identifier
        PQRBiopStructure.id_global = PQRBiopStructure.id_global + 1
        self.id = PQRBiopStructure.id_global
        
        self.dirname = '.'
        # retrun absolute, should be enough
        #dirname = os.path.dirname(pqr_file)
        (head, tail) = os.path.split(file)
        #print "head ", head
        #print "tail ", tail
        #if dirname:
        if head:
            self.dirname = head
        
        # all cases correct filename
        self.filename = tail
        # to use in log, easy to parse
        self.full_filename = file
        # easier if try to extract the root directory
        # pdb file, created from pqr, H deleted
        self.pqrnoh_filename = None
        self.total_charge = None
        
        # object VdWTC_SDA, created only by a function
        self.vdw = None
        
        # store center of geometry, closest atom indoce from the center(needed for reaction criteria if flexible)
        # and the distance max
        self.center_of_mass = None
        self.distance_max = None
        self.stoke_radius = None
        
        # make a small dictionary
        self.atom_closer = { "atom_nb" : -1,
                             "atom_name" : "NULL",
                             "res_nb"    : -1,
                             "res_name"  : "NULL"
                           }
        
        ## Here read correclty the pqrnoh files
        ## force both PDB_SDA and PQR to use sturct_builder for PQR, means call PQR atoms( not very logic )
        struct_build = PQRStructureBuilder()
        parser = None
        # here use derived class
        if ( type == "pqr" ):
            #print "this is a pqr file"
            ## very important to use this modified real PQR parser,
            parser = PQRParser( PERMISSIVE , structure_builder=struct_build, QUIET=True )
            ## implemented for PQRParser at the moment
            parser.set_overload_chains( Overwritte_chains )
        
        ## else read pqrnoh, with specific Nterminal
        elif ( type == "pdb" ):
            #print "this is a pdb file"
            parser = PDB_SDAParser( PERMISSIVE=1 , structure_builder=struct_build, QUIET=True )
        else:
            logger.error("type not found %s", type)
            raise Exception("type %s of files not implemented " % type)

        ##print "pqr_filename ", self.pqr_filename
        logging.debug("read filename self.filename %s of type %s", self.filename, type)
        #print "in directory ", self.dirname
        # file has the complet path
        self.pqr = parser.get_structure ( self.id, file ) #self.filename )
        
        #print "after get_structure"
        at = 0
        for atom in self.pqr.get_atoms():
            at = at+1
        self.nb_atoms = at
        logging.info("nb atoms: %d" % self.nb_atoms)
        # need to check if alternative conformation ?
        
        # assign ion/ligand, simple: if HETATM and size is 1 (ion) or more (ligand)
        # case water not considered yet
        for res in self.pqr.get_residues():
            #print "res", res.__repr__()
            hetflag, resseq, icode=res.get_id()
            #print "hetflag ", hetflag
            if hetflag != ' ':
                #print "check for assing ligands or ions res", res.__repr__()
                res.assign_ligand_ion()
        
        ## assign the type of the structure, to each chain independently
        #print "set type protein/dna"
        self.set_type()

    def set_type(self):
        """ Set the type of the structure, now protein or dna/rna.
            Use sequence to choose between them.
            Check chain by chain.
        """
        
        #print "set type"
        for chain in self.pqr.get_chains():
            print "new chain ", chain.__repr__()
            seq =''
            ppb=Polypeptide.CaPPBuilder()
            #pp = ppb.build_peptides(self.pqr ) ## option  aa_only= 1 or True
            #for pp in ppb.build_peptides(self.pqr ):

            for pp in ppb.build_peptides( chain, aa_only=0):
                seq = pp.get_sequence()
                logging.info("sequence aa_only=0: %s", seq)
        
            ## need to return if ok, to improve
            if seq != '':
                logging.info("I am a protein")
                chain.type = 'protein'
                continue
                
                
            ppb=Polypeptide_DNA.DNABuilder()
            for pp in ppb.build_peptides( chain ):
                seq = pp.get_sequence()
                logging.info("get sequence dna: %s", seq)
        
            if seq != '':
                logging.info("I am a dna")
                chain.type = 'dna'
                continue
                #return
            
            if seq == '':
                logging.warning("Could not determine protein or dna  for chain %s", chain.__repr__())
                #return
        
        ##end loop chains
        #print "end loop"
        #sys.exit()
        return
       
    def compute_total_charge(self):
        """ Add the charge of all atoms for each residue and of the structure
            call compute_charge residue, and PQR residue total charge.
            
            Catch and raise PQRConstructionException
        """
        
        #print "compute total charge"
        
        list_model = self.pqr.get_list()
        #print "Number of models ", len(list_model)

        tot_charge = 0.
        warning = None
        
        # loop over model, certainly not necessary, but later for NMR, just test
        for model in list_model:
            list_chain = model.get_list()
            
            # loop over chains
            for chain in list_chain:
                
                # loop over residue
                for res in chain.get_list():
                    warning = None
                    #print "res ", res.get_full_id()[3][1]
                    #print "res ", res.get_id()[1]
                    #print "resname ", res.get_resname()
                    #print "segid ", res.get_segid()

                    # method from PQRResidue throw an exception, now will return a warning
                    # because do not want to stop the program, check about try/catch/finally... 
                    #try :
                    warning = res.compute_charge_residue()
                    #except PQRConstructionException as ex :
                    #raise
                    if warning != None:
                        logging.warning("Total charge of the residue %s has not a total charge: %f" % (res.get_resname(), warning ))
                        
                    # finally
                    # tot_charge += res.charge
                    tot_charge += res.charge
        
        # to test http://docs.python.org/2/library/decimal.html
        # print "total charge ", tot_charge
        # print "round (tot_charge, 10 ", round( tot_charge, 10 )
        if ( not( round( tot_charge, 3 ).is_integer()) ):
        #if ( not( math.modf(tot_charge)[0] < 0.005 ) ):
            #print "Not an integer for the total charge"
            #raise PQRConstructionException("Total charge of the solute is not an integer %f" % tot_charge)
            #print "Warning: Total charge of the solute is not an integer %f" % tot_charge
            logging.warning("Total charge of the solute is not an integer %f" % tot_charge)
        
        #self.total_charge = round( tot_charge, 10 )
        self.total_charge = round( tot_charge, 2 )
        return tot_charge
        
    def get_dimension_and_set_closer_center_atom( self ):
        """ Return the tuple with distance max of one solute 
            Set in class members : center_of_mass, distance_max, closer atoms to center_of_mass(with KDTree)
            
            Version using kdtree
        """
        
        logging.debug("Entry get_distance_and_closer ")
        
        coord_max = [-999., -999., -999.]
        coord_min = [ 999.,  999.,  999.]
        
        list_atom = list()
        for atom in self.pqr.get_atoms():
            list_atom.append(atom) 
        
        # compute the center of mass of the given list, and the indice of the closest atom
        # indic_min not used here
        (center_of_mass, atom_closer, indic_min) = self.compute_central_atom( list_atom )
        self.center_of_mass = center_of_mass
        logging.debug("get center %f %f %f" % (center_of_mass[0],center_of_mass[1],center_of_mass[2] ))
        
        # extract all data of this atom
        #self.indice_closer = indice_closer
        if atom_closer != None:
            self.atom_closer["atom_nb"] = atom_closer.get_serial_number()
            self.atom_closer["atom_name"] = atom_closer.get_name()
            self.atom_closer["res_name"] = atom_closer.get_parent().get_resname()
            self.atom_closer["res_nb"] = atom_closer.get_parent().get_segid()
            #print "fullid, chain ", atom_closer.get_parent().get_full_id(),"/", atom_closer.get_parent().get_full_id()[2]
            self.atom_closer["chain"] = atom_closer.get_parent().get_full_id()[2]
        else:
            
            logging.warning("Could not find a central atom close to the center with a 10 A cutoff, try 1000. Will use all atoms, check your structure.")
            
            (center_of_mass, atom_closer, indic_min) = self.compute_central_atom( list_atom, 1000. )
            
            if atom_closer != None:
                self.atom_closer["atom_nb"] = atom_closer.get_serial_number()
                self.atom_closer["atom_name"] = atom_closer.get_name()
                self.atom_closer["res_name"] = atom_closer.get_parent().get_resname()
                self.atom_closer["res_nb"] = atom_closer.get_parent().get_segid()
                #print "fullid, chain ", atom_closer.get_parent().get_full_id(),"/", atom_closer.get_parent().get_full_id()[2]
                self.atom_closer["chain"] = atom_closer.get_parent().get_full_id()[2]
                
            else:
                logging.error("Error cannot find a central atom")
                raise Exception("Cannot find a central atom");
            
        #indice_closer = atom_closer.get_serial_number()
        #print "indice_closer", indice_closer
        #print "self.atom_closer", self.atom_closer
        #logging.debug("get indice closer %d" % indice_closer)
        
        # get dimension
        for atom in self.pqr.get_atoms():
#            
            coord = atom.get_coord()      
#            # not working like this 
#            #coord_min = (min (coord_min, coord ))
#            #coord_max = (max (coord_max, coord. ))
#            
            for x in range(3):
                if (coord_min[x] > coord[x]):
                    coord_min[x] = coord[x]
#                    
                if (coord_max[x] < coord[x]):
                    coord_max[x] = coord[x]
        
        ## max distance from the center
        #self.distance_max = ( coord_max[0]-self.center_of_mass[0], coord_max[1]-self.center_of_mass[1], \
        #                      coord_max[2]-self.center_of_mass[2] )
        #print "return new distance "
        #self.distance_max = ( 2.0*abs(coord_max[0]-self.center_of_mass[0]), 2.0*abs*(coord_max[1]-self.center_of_mass[1]), \
        #                      2.0*abs(coord_max[2]-self.center_of_mass[2]) )
        self.distance_max = ( coord_max[0] - coord_min[0], coord_max[1]-coord_min[1], coord_max[2]-coord_min[2] )
        
        # indice closer maybe not needed
        return self.distance_max
        
    def rename_terminal(self): 
        """ By default rename first terminal (of every chains) with N NTR/NTN
            and last terminal with O CTR/CTN, 
            if HETATM at the end of the chain check for previous residues
        """
            
        logging.info("rename terminal ")

        # initialize and read add_atoms content if already existing
        # no exception from it
        if not self.vdw:
            #print "initialize VdWTC_SDA"
            self.vdw = VdWTC_SDA( self.dirname )
            
        list_chain = self.pqr.get_chains()
        #print "size list_chains ", len(list_chain)
        
        # loop over all chains
        count_chain = 0
        for chain in list_chain:
            
            if chain.type == 'dna':
                logging.debug('dna continue')
                continue
            
            #print "chain %d %s" % count_chain, chain.__repr__()
            logging.info("chain %s %s", count_chain, chain.__repr__())
            
            list_res = chain.get_list()
            #print list_res.__repr__()
            nb_residue = len(list_res)
            #print "nb_residue ", len(list_res)
            
            # case ligand, only one residue, nothing to mark
            # test if ligand residue or ion
            hetflag, resseq, icode=list_res[0].get_id()
            #print "hetflag ", hetflag
            if hetflag != ' ':
                logging.info("hetflag found")
                continue
            
            # need tests
            first_residue =  list_res[0]
            #print "first_residue ", first_residue
            #print "first_residue ", first_residue.get_resname()
            #print "resseq ", resseq
            #print "charge res ", first_residue.get_charge()
            
            # check if present, counting for a p possible protonation of +1
            b_term = self.vdw.is_terminal_charged(first_residue.get_resname(), \
                                                  first_residue.get_charge(), 1 )
            #print "b_term ", b_term
            if b_term == True:
                logging.info("REMARK Make Nterminal as charged with NTR, %i %s" % \
                             ( resseq,first_residue.get_resname() ))
                first_residue.make_terminal("NTR")
       
            else:
                logging.info("REMARK Make Nterminal as neutral with NTN, %i %s" % \
                             ( resseq,first_residue.get_resname() ))
                first_residue.make_terminal("NTN")
                    
            ######## Make C-terminal
            
            # Search for C-terminal     
            # start from the last position 
            i = -1
            # check if not an HETATM, miss 
            hetflag, resseq, icode=list_res[-1].get_id()
            #print "hetflag ", hetflag
            
            # need to check if it does not get the first residue at some point! abs(i) < nb_residue
            # avoid out of range, and overwrittes of the first residue
            while (hetflag[:2] == 'H_') & (abs(i) < nb_residue):
                # check for the previous one in the chain
                i = i-1
                hetflag, resseq, icode=list_res[i].get_id()
                #print "hetflag ", hetflag
                    
            if abs(i) < nb_residue:
                
                b_term = self.vdw.is_terminal_charged(list_res[i].get_resname(), \
                                                      list_res[i].get_charge(), -1 )
                
                if b_term == True:
                    logging.info("REMARK Make Cterminal as charged with CTR, %i %s" % \
                                 ( resseq, list_res[i].get_resname()) )
                    list_res[i].make_terminal("CTR")
                else:
                    logging.info("REMARK Make Cterminal as neutral with CTN, %i %s" % \
                                 (resseq,list_res[i].get_resname()) )
                    list_res[i].make_terminal("CTN")
                    
            # else error somewhere
            else:
                logging.warning("Cannot find a C-terminal")
                raise PQRConstructionWarning("Cannot find a C-Terminal")
            
            count_chain += 1
        
    def delete_hydrogens(self, delH ):
        """delete hydrogens from the pqr file,  and rename
           the file pqrnoh_NAME.pdb """
           
        ## delete hydrogen to write
        ##m = PQRBiopStructure.regex.match(self.filename)
        
        ## check validity
        #if m:
        #    print 'Match found: ', m.group()
        #    print "group 1: ", m.group(1)
        
        ##if not m:
        solute_name = self.filename.split(".pqr")[0]
        if not self.filename.endswith(".pqr"):
            logging.error("No match with the filename %s, should be any_name_without_dot.pqr. will stop", self.filename)
            raise PQRConstructionWarning("No match with the filename %s, should be any_name_without_dot.pqr. will stop" % self.filename)
        
        if self.dirname:
            #output =  self.dirname+"/pqrnoh_"+m.group(1)+".pdb"
            output =  self.dirname+"/pqrnoh_"+solute_name+".pdb"
        else:
            ##output = "pqrnoh_"+m.group(1)+".pdb"
            output = "pqrnoh_"+solute_name+".pdb"
            
        ##self.pqrnoh_filename = "pqrnoh_"+m.group(1)+".pdb"
        self.pqrnoh_filename = "pqrnoh_"+solute_name+".pdb"
        logging.debug("output file %s " % output ) #(self.pqrnoh_filename))
        
        ## make new structure without hydrogens. define internal class for the selection
        class NotHydrogen(Select):
            def accept_atom(selfself, atom):
                return not (atom.element == "H" or atom.get_id()[0] == "H")
        # save the structure in pdb format
        # modified to add CTR and NTR residue name
        io=PDBIO_SDA()
        io.set_structure(self.pqr)
        
        if delH:
            #io.save(self.pqrnoh_filename, select=NotHydrogen())
            io.save(output, select=NotHydrogen())
        else:
            #io.save(self.pqrnoh_filename)
            io.save(output)
            
    def compute_Molecular_Weight (self):
        """ Compute the molecular weight of the structure
            
            Transform structure into Polypeptide, and compute MW
            No data member saved in first implementation
        
            - Limited to Amino-acid / RNA-DNA to test, for Ligand maybe other module OpenBabel
            - Seems to not know about HID, so split the sequence into artificial sequences
              Should be run on a standard PDB file, not on a PQR (FF dependent name)
        """
        
        MW = 0.
        # test chain by chain
        for chain in self.pqr.get_chains():
            
            if chain.type == 'protein':
                # Using C-N, default 1 A 
                ppb=PPBuilder()
                #or Using CA-CA distance criteria
                #ppb = CaPPBuilder()
                # split if multi chain ?
                for pp in ppb.build_peptides( chain ): # option  aa_only=False, but crash in MW if HETATM
                                                       # would need to delete from sequence
                    logging.info("protein sequence: %s", pp.get_sequence())
                    pa = ProteinAnalysis( str(pp.get_sequence()) ) #pp.get_sequence() )
                    MW += pa.molecular_weight()
                
                
            elif chain.type == 'dna':
                ppb = Polypeptide_DNA.DNABuilder()
                for pp in ppb.build_peptides( chain ): 
                
                    logging.info("dna sequence %s", pp.get_sequence())
                    MW += 330.0 * len ( pp.get_sequence() )
                    logging.info("MW dna: 330 Daltons by pair, nb pairs %d, total %f", len( pp.get_sequence()), MW )
        
        logging.info("MW protein (Da) : %s", MW)
        return MW
    
    
    def compute_hydro_radius(self):
        """
           Compute the hydrodynamic radius, similar to stoke radius definition.
           Need as input for debye-huckel.
           
           Algorithm is long, double loop over the atoms ( 1 minute for 2300 atoms )
           
           definition taken from wikipedia:
           http://en.wikipedia.org/wiki/Hydrodynamic_radius
        """
        
        logging.info("Entry compute hydrodynamic radius nb_atoms %s", self.nb_atoms)
        
        tmp_sum = 0
        counter = 0
        #nb_atoms = len( self.pqr.get_atoms() )
        # loop over all different atoms 
        for atom1 in self.pqr.get_atoms():
            for atom2 in self.pqr.get_atoms():
                
                # loop over distanct atoms
                if atom1 != atom2:
                    
                    counter += 1
                    #print "get_coord atom1 ", atom1.get_coord()
                    #print "get_vector atom1 ", atom1.get_vector()
                    #print "get coord atom2 ", atom2.get_coord()
                    #print "get coord atom2 ", atom2.get_vector()
                   
                    # The minus operator for atoms has been overloaded to return the distance between two atoms (bipopython)
                    dist = atom1 - atom2
                    #print "dist2 ", dist
                     
                    tmp_sum += 1.0 / dist
                # for tests
                #else:
                #    print "same atoms ", atom1, atom2
                #    print "get_vector atom1 ", atom1.get_vector()
                #    print "get coord atom2 ", atom2.get_vector()
        
        #print "tmp_sum ", tmp_sum
        #print "counter ", counter
        tmp_sum /= counter
        logging.debug("average tmp_sum %s", tmp_sum)
        
        self.stoke_radius = 1.0 / tmp_sum #( tmp_sum / (self.nb_atoms*self.nb_atoms) )
        logging.debug("self.stoke_radius %s", self.stoke_radius)
        
    def compute_radius_gyration(self):
        """ Compute the radius of gyration, single loop over atoms 
            Much faster than hydrodynamic radius, to test accuracy
        """
        
        logging.info("Entry compute radius gyration ")
        
        vec_cm = Vector ( self.center_of_mass[0], self.center_of_mass[1], self.center_of_mass[2] )
        logging.debug("vector cm %s", vec_cm)
        
        tmp_sum = 0
        counter = 0
        
        # loop over all different atoms 
        for atom1 in self.pqr.get_atoms():
            
            tmp_vec = atom1.get_vector() - vec_cm
            norm = tmp_vec.norm()
            tmp_sum +=  norm
            
        logging.debug("tmp_sum %s", tmp_sum)
        logging.debug("nb atoms %s", self.nb_atoms)
        logging.info("radius gyration %s", tmp_sum / self.nb_atoms)
        self.stoke_radius = tmp_sum / self.nb_atoms
        
    def update_addatom_file( self, optH = False ):
        """update add_atom file, do not include hydrogens
           check the charge of all residues are consistent with test_charges
        """
        
        # initialize and read add_atoms content if already existing
        # no exception from it
        if not self.vdw:
            logging.debug("Self VdW ob PQRStructure was not initialized")
            self.vdw = VdWTC_SDA( self.dirname )
        
        logging.info("Check for VdW")
        # Check new VdW, atom by atom is enough
        for atom in self.pqr.get_atoms():
            
            #print "atom name", atom.__repr__()
            # for now discard H by default
            if (atom.element == "H") or (atom.get_id()[0] == "H"):
                if optH == False:
                    continue
                # else to see
            
            #print "atom name", atom.__repr__()
            #print "atom id", atom.get_id()
            #print "atom full_id", atom.get_full_id()
            #print "atom.element", atom.element
            #print "atom.radius ",atom.radius
            #print "atom.parent.get_id ", atom.get_parent().get_id()
            hetflag = atom.get_parent().get_id()[0]
            #print "hetflag ", hetflag
            
            # if heterogen atom, possiblity of wrong name, Na changed to N...
            # in this case send the id, which is correct but trouble with already defined atoms
            if hetflag != ' ':
                
                #print "atom.element ", atom.element
                #print "parent res.ion ", atom.get_parent().ion
                #print "parent res.ligand ", atom.get_parent().ligand
                #print "update_addatom VdW heterogen atom, ion or ligand ", atom.get_id()
                #for ligand wants element, not get_id()
                
                ## if ion keep the total id, because Na interpreted as N as element
                if atom.get_parent().ion == True:
                    #print "Found ion element ", atom.get_id()
                    element = atom.get_id()
                    
                ## if ligand search if element already exists 
                # choosed fullname to insert, but test only on element    
                elif atom.get_parent().ligand == True:
                    #print "Found ligand element ", atom.element
                    element = atom.element
                    
                else:
                    logging.warning("Error logic, residue HETATM, neither ligand or ion")
            ## default use element
            else :
                element = atom.element
                #print "not hetatm element: ", element
            
            # check if already present in dictionaries
            if not self.vdw.has_atomvdw( element, atom.radius):
                logging.debug("element not in VdW %s will be added", element)
                
                if atom.get_parent().ligand or atom.get_parent().ion: 
                    self.vdw.add_atomvdw( atom.get_id(), atom.radius )
                    logging.info("REMARK AddToVdW, vdw_element = %s, radius = %f" % (atom.get_id(), atom.radius) )
                else:
                    self.vdw.add_atomvdw( element, atom.radius )
                    logging.info("REMARK AddToVdW, vdw_element = %s, radius = %f" % (element, atom.radius) )                    
                self.vdw.need_to_rewrite = True
                 
        #print "after filling self.vdw.dict_VdW\n\n", self.vdw.dict_VdW
        #print "self.vdw.dict_Tc\n", self.vdw.dict_Tc
        
        ##############
        logging.info("Check for test charges")
        # Check for new test charges, need a loop over residues
        # do not make explicit check for dna, may have strangee dna
        for res in self.pqr.get_residues():
            
            #print "res", res.__repr__() 
            #print "res get_id ", res.get_resname(),res.get_id(), "term ", res.term_tc, res.get_charge()
            hetflag, resseq, icode=res.get_id()
            #print "total charge residue", res.get_charge()
            #print "term ", res.term_tc
            #print "ion ", res.ion
            #print "ligand ", res.ligand
            # return protein/dna
            #print "res.get_parent().type ", res.get_parent().type return protein/dna
            
            ## need to correct the value in case of charged terminal
            ## to check the residue charge is identical to the default in SDA
            charge_residue = res.get_charge()
            #print "charge_residue ", charge_residue
            
            # in case pqr generated charged termini but we want
            # only one charged terminal, an error will be generated 
            # b_resid_term indicates the error to not be throw
            b_resid_term = False
            
            # in case of ligand, assign the total charge to the atom closest to the geometric center
            # it indicates the number in the list of element
            nb_porter_charge = -1
            
            # the point here is to correct the charge of the residue if it is a terminal
            # try to get NTN, CTN as well in this case
            if res.term_tc != None:
                #print "It is a terminal residue"
                b_resid_term = True
                
                # correct the charge on the terminal
                if res.term_tc == "NTR":
                    charge_residue -= 1
                elif res.term_tc == "CTR":
                    charge_residue += 1
                # else it is a neutral atom
                # no shift
                
                #print "It is a terminal residue %s, charge residue corrected %f" % (res.get_resname(), charge_residue)
           
            # check if already present 
            # and if test charges are compatible with standard in SDA or already added elements
            # otherwise (default with wrong charges) raise exception/warning
            try :
                #print "check for charge_residue ", charge_residue
                present = self.vdw.has_residue_tc( res.get_resname().strip(), charge_residue )
                #print "present ", present
            except PQRConstructionException as ex :
                #print "Got PQRException in checking has_residue_tc: ", ex
                # always print warning
                logging.warning("Got PQRException: %s", ex)
                # if a terminal maybe more difficult to deal with
                #print "b_resid_term ", b_resid_term
                #b_resid_term = True
                
                if b_resid_term:
                    logging.warning("It is a terminal residue, the exception will be ignored")
                    present = True
                    pass
                else:
                    logging.warning("It is not a terminal residue, raise exception" )
                    raise 
                
            except Exception as ex:
                logging.warning("Got normal exception in checking has_residue_tc, maybe should not pass here: %s", ex)
                
                if b_resid_term:
                    logging.warn("It is a terminal residue, the exception will be ignored")
                    pass
                else:
                    logging.warn("It is not a terminal residue, raise exception" )
                    raise
             
            # need to assign a new residue in test charges
            # simply assign the total charge to the closest atom of the geometric center 
            # but add entries for all atoms, easy to modify manually/interactively
            # apply only if charge is different of 0, miss strong dipole
            if (present == False) & (charge_residue != 0):
                
                #print "to add in dict_TC residue ", res.get_resname()
                # need the list of all atoms
                list_element = []
                
                # if ions or ligand, send all atoms (with fullname)
                if hetflag != ' ': # eqivalent if ion or ligand
                    logging.debug("ion or ligand")
                    
                    # new added, if hydrogens are present numbering is wrong, maybe can do better
                    list_atom_noh = list()
                    #print "after compute_central_atom: ", center_geom, nb_porter_charge
                    for atom in res.get_list():
                        # element not enought for ligand, not considered as Hydrogen by biopython
                        if (atom.element != 'H') and (atom.get_id()[0] != 'H'):
                           # list_element.append ( atom.get_id() )
                           list_atom_noh.append( atom )
                    
                    # expects tuple: center of geometry and the indice of the closest atom in the residue
                    # raise exeption if nothing is found (need to increase cutoff)
                    try:
                        #center_geom and atom_center not used here
                        # original problem if Hydrogens are present, need to filter hydrogens 
                        #(center_geom, atom_closer, indic_min) = self.compute_central_atom( res.get_list() )
                        (center_geom, atom_closer, indic_min) = self.compute_central_atom( list_atom_noh )
                        logging.info("get center atom of res %s %s %s %s", res.__repr__(),center_geom, atom_closer, indic_min)
                        #print "charge of this resiude ", res.get_charge()
                        
                        # check valid output
                        if indic_min != -1:
                            #nb_porter_charge = atom_closer.get_serial_number()
                            nb_porter_charge = indic_min
                            #print "case ligand or ion nb_porter_charge ", nb_porter_charge
                            #print "full id", atom_closer.get_full_id()
                            #print "get id", atom_closer.get_id()
                        else:
                            nb_porter_charge = -1
                            logging.warning("Could not find nb_porter_charge of a ligand")
                            
                    except Exception as ex:
                        logging.error("PQRStructure Line 701, could not find center throw exception")
                        raise 
                    
                    # original code filter H atom, new code filter before !
                    #print "after compute_central_atom: ", center_geom, nb_porter_charge
                    for atom in res.get_list():
                        # element not enought for ligand, not considered as Hydrogen by biopython
                        if (atom.element != 'H') and (atom.get_id()[0] != 'H'):
                            list_element.append ( atom.get_id() )
                    
                
                # else it is a particular/unfrequent amino-acid       
                # send only concerned atoms Oxygen or Nitrogen, or P, but with their full name : ND1,..
                # a priori only +1 added to N:NH3 and -1 added to O or P: COO-
                # need specific case if not integer: CYS+HEM, need new full HETATM 
                else:
                    already_assigned = False
                    
                    #print "new residue create already_assigned ", res.__repr__(), already_assigned
                    #print "Full residue ", charge_residue, self.type
                    for atom in res.get_list():
                   
                        #print "id ", atom.get_id(), " ", atom.element
                        # here may improve the rule with experience/time     
                        #if charge_residue >= 1:
                        if charge_residue > 0.:
                            #print "Total charge is 1 ", atom.element
                            
                            # we do not want the backbone atom
                            if atom.element == 'N':
                                if atom.get_id() != 'N':
                                    list_element.append( atom.get_id() )
                                
                        #if charge_residue <= -1:
                        if charge_residue < 0.:
                            
                            ## need to rewrite here, search for O or P,
                            ## which case was problematic ??
                            if res.get_parent().type == 'protein':
                                #print "Total charge is -1", atom.element
                                if (atom.element == 'O'):  #| (atom.element == 'P') :
                                    if atom.get_id() != 'O':
                                        try :
                                            list_element.append( atom.get_id() )
                                        except Exception as ex:
                                            logging.error("Got exception, no atom in the list: %s", ex)
                                            raise
                                        
                            # only for dna terminal
                            if res.get_parent().type == 'dna':
                                
                                if ( ( atom.element == 'P' ) | ( atom.element == 'O' ) ): #'O'):
                                     
                                    # assign only once, P first 
                                    #print "DNA, search for P first res.already_assigned ", already_assigned
                                    
                                    if already_assigned == False:
                                        
                                        if ( atom.element == 'P' ):
                                            #print "DNA search for P"
                                            # no check for id, only one per residue ??
                                            try :
                                                list_element.append( atom.get_id() )
                                                already_assigned = True
                                            except Exception as ex:
                                                logging.error("Got exception, no P atom in the list for dna, Cannot find default atom for dna")
                                                raise
                                    
                                        # or use 
                                        elif ( atom.element == 'O' ):
                                            
                                            #print "id ", atom.get_id()
                                            #print "DNA, search O5'"
                                            if atom.get_id() == "O5'":
                                                try :
                                                    list_element.append( atom.get_id() )
                                                    already_assigned = True
                                                    #print "assinged O5'"
                                                except Exception as ex:
                                                    logging.error("ot exception, no atom in the list for dna. Cannot find default atom for dna %s", ex)
                                                    raise
                                     
                    ## end loop over residue
                    #print "end loop residue"
                                
                #print "after construction list_element ", list_element
                #print "before add_residue_tc nb_porter_charge ", nb_porter_charge
                logging.info("REMARK Add_ToTestCharges, res = %s, charge_residue = %f,  list_atom = %s" % \
                             (res.get_resname(),charge_residue, list_element ))
                
                # maybe need to add in defaut mod_van RU,RA,...
                
                # can check here if list_element is null, second chance to correct
                # maybe should reprot a warning only
                if len ( list_element) == 0:
                    #logging.error("list element size == 0, cannot proceed furthter")
                    raise Exception("list element size == 0, cannot proceed furthter")
                
                try :
                    self.vdw.add_residue_tc( res.get_resname(), charge_residue, list_element, nb_porter_charge )
                    # set flag for overwriting add_atoms
                    logging.debug("set need to write to True")
                    self.vdw.need_to_rewrite = True
                except Exception as ex:
                    logging.error("Cannot add residue tc, no atom in the list for dna")
                    raise
            
        logging.debug("self.vdw.dict_Tc: %s", self.vdw.dict_Tc)
        #self.vdw.write_file()
        
    def compute_central_atom( self, list_atom, cutoff = 10. ):
        """ given a list of atom, return a tuple with:
            the center of geometry and the index atom which is closest of the geometric center
        """
    
        from Bio.KDTree.KDTree import KDTree
        import numpy as np
        
        #print "Entry compute_central_atom()"
        #print "list_atom ", list_atom
        #print "size list_atom ", len(list_atom)
        
        coord_np = np.zeros((len(list_atom),3))
        
        # fill array, certainly better way to do
        count = 0
        for atom in list_atom:
            coord_np[count] = atom.get_coord()
            count += 1
         
        # compute center with numpy
        center_np = coord_np.mean(axis=0)
        #print "center_np ", center_np
        
        # initialize kdtree effective search algorithm
        kdtree = KDTree(3)
        kdtree.set_coords(coord_np)
        
        try:
            # search closest atom from the atom, 10 A by default
            kdtree.search( center_np, cutoff )
            list_indices = kdtree.get_indices()
            list_radii = kdtree.get_radii()
            #print "list_indices ", list_indices
            #print "list radii ", list_radii
            
        except Exception as ex:
            logging.error("Exception in get_central_atom %s", ex)
            raise "Exception in KDTree"
        
        if len(list_indices) == 0:
            #print "Warning: Could not determine the central_atom, list neighbourg is empty "
            return ( center_np, None, -1)
        
        #print "computed indice closest to center ", list_indices #list_atom[0]
        #print "computed radii ", list_radii
        #print "list_indices ", list_indices
        
        # store indice with min radii
        radii_min = 11.
        indic_min = -1
        
        ## search indice with minimum distance
        for item_nb in range(len(list_indices)):
            
            indic = list_indices[item_nb]
            radii = list_radii[item_nb]
            #print "item radii ", item_nb, radii
            if radii < radii_min:
                #print "one min found ", radii, item_nb
                radii_min = radii
                indic_min = item_nb
        
        atom_min_indice = list_indices[indic_min]
        #print "atom_min_indice ", atom_min_indice
        # atom is correct, but indic_min seems wrong
        #return (center_np, list_atom[atom_min_indice], indic_min)
        return (center_np, list_atom[atom_min_indice], atom_min_indice)
        
        
        
    def test_function(self):
        """ Only for testing purpose of Biopython methods """
        
        print "#### Test Structure, Entity methods "
        print "structure.get_id  ", self.pqr.get_id()
        print "structure.get_full_id  ", self.pqr.get_full_id()
        
        # error, it is a generator
        #print "len(structure.get_get_chains) ", len(self.pqr.get_chains())
        
        for chain in self.pqr.get_chains():

            print "\n### Chain ", chain.__repr__
            print "id ", chain.get_id()
            print "full ", chain.get_full_id()
            print "len(get_list) ", len(chain.get_list())
            
            list_res = chain.get_list()
            
            for res in list_res:
                print "\n##### Residue ", res.__repr__
                print "id ", res.get_id()
                print "full_id ",res.get_full_id()
                print "resname ", res.get_resname()
                print "charge ",res.get_charge()
                
                list_atom = res.get_list()
                
                for atom in list_atom:
                    print"\n######## Atom ", atom.__repr__
                    print "id ", atom.get_id()
                    print "full_id ", atom.get_full_id()
                    print "name ", atom.get_name
                    print "fullname ", atom.get_fullname()
                    print "charge ", atom.get_charge()
                    print "VdW radius ", atom.get_radius()
                    print "bfactor ", atom.get_bfactor
                
       
        
    
    
