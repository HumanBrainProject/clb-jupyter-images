
import os,logging

import warnings, json
from PQR.PQRException import *

from PQR.PQRException import  PQRConstructionException, \
                    PQRConstructionWarning

# very generic name, but easy to use
#import UtilsPrepSDA as Utils


class VdWTC_SDA:
    """Class for dealing with the 'add_atom' file,
       register VdW radius and TestCherges for SDA
       
       Should be opened everytime, if it exists, 
       and add data for all solutes before run_prep.sh to be executed
       
       independent of other class or in PQRStructure_Biop ?
       First test independent
    """
    
    """define the known atom types by SDA, residues in VdW are not taken into account in release 1.0
       these atoms does not need to be modified
       In practice apply only for ions
    """
    # here apply default for all atoms, but will override of 'add_atom' value by SDA
    VdWSDA_default = {'C' : ['C*',1.9],
                      'N' : ['N*',1.625],
                      'O' : ['O*',1.48],
                      'H' : ['H*',1.2],
                      'P' : ['P*',1.9],
                      'S' : ['S*',1.85]
                     }
    
    """ Test chagres are defined by two keys: atom and residue, make residue as first key
        but default is safe, no charge"""
    TestCharge_default = {'NTR' : [['N',  'NTR', 1.0]],
                          'CTR' : [['O',  'CTR', -0.5],['OXT','CTR',-0.5]],
                          'HIP' : [['ND1','HIP',  0.5],['NE1','HIP', 0.5]],
                          'HI2' : [['ND1','HI2',  0.5],['NE1','HI2', 0.5]],
                          'LYS' : [['NZ','LYS',   1.0]],
                          'ARG' : [['NH1','ARG',  0.5],['NH2','ARG',  0.5]],
                          'ASP' : [['OD1','ASP', -0.5],['OD2','ASP', -0.5]],
                          'GLU' : [['OE1','GLU', -0.5],['OE2','GLU', -0.5]],
                          ## RNA/DNA
                          'A'   : [['P'  , 'A' , -1.0]],
                          'T'   : [['P'  , 'T' , -1.0]],
                          'G'   : [['P'  , 'G' , -1.0]],
                          'C'   : [['P'  , 'C' , -1.0]],
                          'U'   : [['P'  , 'U' , -1.0]],
                          # new format amber
                          'DA'   : [['P'  , 'DA' , -1.0]],
                          'DT'   : [['P'  , 'DT' , -1.0]],
                          'DG'   : [['P'  , 'DG' , -1.0]],
                          'DC'   : [['P'  , 'DC' , -1.0]],
                          'DU'   : [['P'  , 'DU' , -1.0]]
                         }
    
    """Not defined in SDA mod_van.f90, record most common uncharged residues,
       avoids warning about unknown residues when assigning the charges"""
    Neutral_residues = [ "ALA","ASN","GLY","SER","PHE","GLY","HIS","HID","HIE","CYS","ILE","LEU","MET", \
                         "PRO","GLN","THR","VAL","TRP","TYR" ]
    # to assert total charge due to rounding error
    EPS = 0.01
    
    def __init__(self, directory='.', filename='add_atoms'):
        """Constructor, try to load data from an existing add_atoms file
           or cretae an new one"""
        
        logging.debug("init VanTc_SDA")    
        self.dict_VdW=dict()
        self.dict_Tc=dict()
        # set flag if at a least one new entry was found
        # otherwise let unchanged
        self.need_to_rewrite = False
        
        #print "init Van dir", directory
        self.directory = directory
        
        # try to open and read an existing file
        if os.path.exists(self.directory + os.sep + "add_atoms"):
            #print "read content file of existing add_atoms_file"
            self.file = open(self.directory + os.sep + "add_atoms",'r+')
            # read content of the file, file self.dictX
            self.read_content_file()
           
            #print "VdW dictionary ", self.dict_VdW
            #print "TestCharges dictionary\n", self.dict_Tc
        else:
            # create a new file
            logging.info("Create a new empty add_atoms file: %s", self.directory + os.sep + filename)
            self.file = open(self.directory + os.sep + filename,'w')
            # nothing to read
        
        #print "self.dictVdW"
        #print self.dict_VdW
        #print "self.dictTc"
        #print self.dict_Tc
    
    def read_content_file(self):
        """Read the actual content of the add_atoms file"""
        
        logging.debug("read_content_file ")
        
        #if file is empty, just return, could be tested before opening
        if ( os.stat(self.directory + os.sep + "add_atoms").st_size == 0 ):
            return
        
        lines = self.file.xreadlines()
        #print lines
        
        bVdW = False
        bTC = False
        
        for line in lines:
            # read a comment
            if (line[0] == "#") | (len(line)==1) :
                continue
            # open a group
            if line[:5] == "GROUP":
                if line[:11] == "GROUP = VdW":
                    bVdW = True
                elif line[:19] == "GROUP = TestCharges":
                    bTC = True
                
                continue
            # close all groups
            elif line[:9] == "END GROUP":
                bTC = False
                bVdW = False
                continue
            
            #print "read something usefull for VdW"
            if bVdW==True:
                #print "extract VdW ", line
                fields = line.split()
                (name, res, radius ) = line.split()
                self.dict_VdW[name] = [name,float(radius)]
                
            if bTC==True:
                #print "extract TC ", line
                (name, res, radius ) = line.split()
                #if residue name exists append to the list value
                if self.dict_Tc.has_key(res):
                    self.dict_Tc[res].append([name, res, float(radius)])
                    
                # else create a new key, and a new list
                else:
                    self.dict_Tc[res] = [[name, res, float(radius)]]
            
            
    def has_atomvdw( self, element, radius): #, opt_element=None ):
        """Check if the element exists in dictionnary
           element is the type by default: N, C,..
           or the fullnamw if ion: Na, Na+ like we want
           For ligand free choice, choose to test on the element to reduce number, but can change to fullname
        """
        
        #print "has_atomvdw() ", element, radius #, opt_element    
        
        # check first in memory dict
        if self.dict_VdW.has_key( element ):
             
            descp = self.dict_VdW[element]
            #print "found element with descp", descp
            #print "descp[1] ", descp[1]
            
            # in memory, take the largest ? make a warning ?
            #if ( radius != descp[1] ):
                #print "Warning: key exists but with a different radius in memory dictionary %f %f " % (radius, descp[1])
                
                #warnings.warn("Biopython warning, key exists but with a different radius", PDBConstructionWarning)
                #msg = "key exists but with a different radius in memory dictionary %f %f " % (radius, descp[1])
                #warnings.warn(msg, PDBConstructionWarning)
                #warnings.showwarning()
                # in memory, take the largest ? 
                 
            # keep first read
            return True
        
        # then check in defaut SDA
        if VdWTC_SDA.VdWSDA_default.has_key(element):
            descp = VdWTC_SDA.VdWSDA_default[element]
            #print "found element with descp", descp
            #print "descp[1] ", descp[1]
            #if ( radius != descp[1] ):
                #print "Warning: key exists but with a different radius in default SDA %f %f " % (radius, descp[1])
                
                #msg = "key exists but with a different radius in default SDA %f %f " % (radius, descp[1])
                #warnings.warn(msg, PQRConstructionWarning)
                # in default, keep the default ?
            
            # keep default
            return True
        
        ## if not found
        return False
    
    def add_atomvdw(self, element, radius):
        """Add to the VdW dictinnary
           Consider check has been done before, 
           but easier and less risky, if check is performed here
        """
        #print "add_atomvdw()"
        self.dict_VdW[element] = [element, radius]
    
    def is_terminal_charged( self, resname, tot_charge, value_term ):
        """Check if the terminal is charged or not
           If present in the dictionary, correct with the value_term (0,-1 or 1)
           If not present, a priori 0 net charge, so consider relative to value_term
           If > 2, problem or < -2 
        """
        #print "Entry is terminal charged resname/tot_charge/value_term ", resname, tot_charge, value_term
        
        # check in memory first
        if self.dict_Tc.has_key(resname):
            #print "found resname in memory dict_Tc"
             
            ## test first zero,
            ok = self.check_charge_tc( tot_charge, VdWTC_SDA.TestCharge_default[resname] )
            if ok :
                #print "ok is True with no shift, it is uncharged "
                return False
            
            # test with a shift
            ok = self.check_charge_tc( tot_charge - value_term, VdWTC_SDA.TestCharge_default[resname] )
            #print "ok is True with shift corrected it is charged ", ok
            if ok == True:
                #print "terminal is charged "
                return True
                
            ## if here error ?
            logging.error("Error tot_charge, dict %s %s", tot_charge, VdWTC_SDA.TestCharge_default[resname])
            #raise "Error cannot find correspondance for the terminal "
                ## 
        
        # check default 
        elif  VdWTC_SDA.TestCharge_default.has_key(resname):
            #print "found resname in default dict_Tc"
            
            ## test first zero shift, test for uncharged
            ok = self.check_charge_tc( tot_charge, VdWTC_SDA.TestCharge_default[resname] )
            if ok :
                #print "ok is True with no shift, it is uncharged "
                return False
        
            # test with
            ok = self.check_charge_tc( tot_charge - value_term, VdWTC_SDA.TestCharge_default[resname] )
            if ok == True:
                #print "terminal is charged "
                return True
            
            ## if here error ?
            logging.error("Error tot_charge, dict %s %s", tot_charge, VdWTC_SDA.TestCharge_default[resname])
        
        # check for uncharged residues
        elif resname in VdWTC_SDA.Neutral_residues:
            # test first zero shift
            
            if tot_charge == 0:
                logging.info("ok is True with no shift, it is a neutral residue uncharged ")
                return False
            
            else:
                logging.info("terminal is charged, it is a neutral residue charged with %s", tot_charge)
                return True

        else:
            logging.warning("%s not found in dictionary ", resname )
            
            if tot_charge == value_term:
                #print "tot_charge == value_term "
                logging.warning("%s is certainly an uncharged residue in terminal, check the structure by yourself ", resname )
                
                return True
                
            
        #print "not found correspondance, return False"

        logging.warning(" %s not found in dictionnary and total charge %f is different of a normal terminal %f", \
                        resname,tot_charge,value_term)
        return False
        
    def has_residue_tc(self, resname, tot_charge ): # b_resid_term):
        """Check if already present, and if the total charge is compatible with default.
            The input, tot_charge, has been corrected before in case of a terminal.
           
           return True / False
           Throw exception if resname found in dictionatry with a different charge
           Exeption will be discarded if it is terminal residue, done by the calling function
        """
        
        #print "has_residue_tc() !",resname, "!!! corrected tot_charge ", tot_charge
        ok = False
	          
	    # check first in memory dictionary
        if self.dict_Tc.has_key(resname):
            #print "found key in memory resname:", resname, " value in dict ", self.dict_Tc[resname]
            
            #try : cannot use exception here, used by code which needs to test different tot_charge
            ok = self.check_charge_tc( tot_charge, self.dict_Tc[resname] )
            #except Exception as ex:
                
            #if b_resid_term == False:
            #print "Got exception from check_charge_tc resname ", resname
            if ok == False:
                string_except = "2 residues with same name %s: and different charges" % (resname)
                #string_except += ex.__str__()
                #print "full exception " 
                raise PQRConstructionException( string_except )
                        
            #return True
            return True
        
        # check second in default array
        if VdWTC_SDA.TestCharge_default.has_key(resname):
            #print "found key default ", resname, " value ", VdWTC_SDA.TestCharge_default[resname]
            
            #try :
            ok = self.check_charge_tc( tot_charge, VdWTC_SDA.TestCharge_default[resname] )   
            #except Exception as ex:
            
            if ok == False :
                string_except = "2 residues with same name %s and different charges: " % (resname)
                #string_except += ex.__str__()
                #print "full exception " 
                raise PQRConstructionException( string_except )
            # else True   
            return True
        
        ## if here return False, not known atom
        return False
    
    def add_residue_tc(self, resname, tot_charge, list_atom, nb_porter_charge):
        """ Add a new ion or ligand or residue to the test charge dictionary
            In case of ligand, central_atom is the atom number in the list which should have the total charge
            In case of residue, nb_porter == -1, assign to N or O 
        """
        
        #print "add_residue_tc() ", resname, tot_charge, list_atom, nb_porter_charge 
        #print "nb_porter_charge ", nb_porter_charge
        
        # case of only one atom, ion, all charges assign to it
        if len(list_atom) == 1:
            #print "add a single entry"
            #logging.info("REMARK add TestCharge %s %s %f" % (list_atom[0], resname, tot_charge ))
            array_tc = [list_atom[0], resname, tot_charge ]
            self.dict_Tc[ resname ] = [array_tc]
            
        # easy if split residue (nb_porter_charge = -1) and ligand
        elif nb_porter_charge != -1:
            logging.debug("add multiple entry, new ligand resname:%s list_atom: %s", resname, list_atom)

            count = 0
            for atom in list_atom:
                
                # assign the total charge to the central atom
                if count == nb_porter_charge:
                    logging.debug("found porter charge count element %d %s %f " % (count, atom, tot_charge))
                    array_tc=[atom, resname, tot_charge]
                else:
                    array_tc=[atom, resname, 0.]
                
                #print "append to dict Tc ", array_tc
                if ( not self.dict_Tc.has_key(resname) ):
                    logging.debug("create the key resname %s", resname)
                    self.dict_Tc[ resname ] = list()
                    #print "after create the key"
                    
                self.dict_Tc[ resname ].append(array_tc)
                #print "self.dict_Tc[ resname ]", self.dict_Tc[ resname ]
                
                count += 1
        
        # nb_porter_charge == -1, it is not a ligand, so a new residue
        # distribute total charges on N, or O
        else :
            logging.debug("add multiple entries, new residue resname: %s, tot_charge: ", resname, tot_charge)
            #print "add multiple entries, new residue %f " % tot_charge
            #print "length list_atom ", len(list_atom)
            
            partial_charge = tot_charge / len(list_atom)
            #print "partial_charge ", partial_charge
            logging.debug("partial charge %f" % partial_charge)
            
            for atom in list_atom:
                
                #print "atom: ", atom, resname, partial_charge
                # check maybe not necessary
                if ( not self.dict_Tc.has_key(resname) ):
                    self.dict_Tc[ resname ] = list()
                    
                array_tc = [atom, resname, partial_charge]
                #print "array_tc", array_tc
                
                self.dict_Tc[ resname ].append(array_tc)
                #print "self.dict_Tc[ resname ]", self.dict_Tc[ resname ]
                
        
    def check_charge_tc( self, tot_charge, value_dict ):
        """ Check total charge corresponds 
            Can be used in loop to test different values
        """    
        #print "check_charge_tc(), tot_charge ", tot_charge
        #print "check_charge_tc(), value dict ", value_dict
        
        #sum_in_dictionary
        charge_in_dict = self.sum_charge( value_dict )
        #print "charge_in_dict ", charge_in_dict
        diff = tot_charge - charge_in_dict
        
        # need to account for rounding, defuault 0.01
        #if tot_charge == charge_in_dict:
        if ( abs( diff ) <= VdWTC_SDA.EPS ):
            return True
        else:
            return False
       
    def sum_charge(self, value_dict):
        """Compute the sum of the charges for a given value of one of the dictionary"""
        
        #print "sum_charge() ", value_dict
        charge = 0.
        for values in value_dict:
            charge += values[2]
            
        return charge
    
    def MergeWith (self, tmp_vdw):
        """Copy the element of tmp_vdw into self"""
        
        ## loop over VdW
        for atom_vdw in tmp_vdw.dict_VdW:
            #print "atom_vdw ", atom_vdw
            #print "radius ", tmp_vdw.dict_VdW[atom_vdw][1]
            
            if not self.has_atomvdw( atom_vdw,tmp_vdw.dict_VdW[atom_vdw][1] ):
                logging.info("element not in VdW %s will be added", atom_vdw)
                self.add_atomvdw( atom_vdw, tmp_vdw.dict_VdW[atom_vdw][1] )
            
        
        ## loop over TestCahrges
        for resid_tc in tmp_vdw.dict_Tc:
            #print "tmp Tc", resid_tc
            
            tot_charge = tmp_vdw.sum_charge(tmp_vdw.dict_Tc[resid_tc])
            #print "tot_charge ", tot_charge
            
            #if self.has_residue_tc(atom_tc, tot_charge, False):
            try :
                present = self.has_residue_tc( resid_tc, tot_charge) #, b_resid_term = False )
                #print "present ", present
            except PQRConstructionException as ex :
                logging.error("Got PQRException: %s", ex)
                raise 
            except Exception as ex:
                logging.error("Got Exception %s", ex)
                raise
            
            # a priori no need to check for charges, if already in add_atoms
            if present == False:
                #print "Merge residue ", resid_tc
                logging.debug("To merge %s", tmp_vdw.dict_Tc[resid_tc])
                #for array_tc in tmp_vdw.dict_Tc[resid_tc]:
                #    print "array_tc", array_tc
                    #self.dict_Tc
                self.dict_Tc[resid_tc] = tmp_vdw.dict_Tc[resid_tc]
                self.need_to_rewrite = True
                 
        logging.debug("After Merge %s", self.dict_Tc)
            
    # could add filename, but SDA reads only add_atoms,
    # so should make a copy before, an add_atoms.backup ( in java )
    def write_file(self):
        """Write content of arrays in add_atoms file
           Need to rewrite only if something new was found
        """
        __format_str_vdw="%-2s   %-3s %6.2f\n"
        __format_str_tc= "%-3s  %-3s %6.2f\n"
        
        logging.info("Entry write_file in VdW %s %s",  self.dict_VdW, self.dict_Tc)
        
        ## need to test if rewrittng is necessary
        if self.need_to_rewrite == False:
            logging.debug("No need to rewrite add_atoms, just close it")
            self.file.close()
            return
        
        logging.debug("need to write add_atoms to disk %s" % self.dict_VdW)
        logging.debug("size VdW %d" % (len(self.dict_VdW.keys())) )
        logging.debug("size Tc %d" % (len(self.dict_Tc.keys())) )
        logging.debug("will delete previous content of add_atoms")
        # make empty file and rewrites complete output
        self.file.seek(0)
        self.file.truncate()
        
        self.file.write("\n## add_atoms file automaticaly generated by python script\n")
        
        if len(self.dict_VdW.keys()) > 0:
            self.file.write("# declare VdW radius\n")
            self.file.write("GROUP = VdW\n")
            for (key,value) in self.dict_VdW.items():
                #print "value ", value
                args=(value[0],value[0],value[1])
                string= __format_str_vdw % args
                #print "string ", string
                self.file.write(string)
                 
            self.file.write("END GROUP\n\n")
        
        if len(self.dict_Tc.keys()) > 0:
            logging.debug("something to print")
            self.file.write("# declare Test charges\n")
            self.file.write("GROUP = TestCharges\n")
            for (key,value) in self.dict_Tc.items():
                logging.debug("value: %s", value)
                #print "len(value)", len(value)
                for i in range(len(value)):
                    args=(value[i][0],value[i][1],value[i][2])
                    string= __format_str_tc % args
                    self.file.write(string)
        
            self.file.write("END GROUP\n")
        
        self.file.close()
        
        
    def MakeJson(self, outdir='.' + os.sep):
        """ Try to send data as Json """
         
        ## print "Content-type: application/json"
        ## print(json.JSONEncoder().encode(response))
        json_data={ 'dict_vdw': self.dict_VdW,
                   'dict_tc' : self.dict_Tc }

        output = outdir + "add_atoms.json"
        with open(output, 'wb') as fp:
            json.dump(json_data, fp, indent=2)
        fp.close()
        
    def ReadJson(self, jsonfname='tmp.json'):
	
	""" Read a json file and fill dictionaries with data """
        
	json_file=open(jsonfname) #,'r','utf-8')
	json_data = json.load(json_file)
        json_file.close()
        #with open('data.json') as data_file:    
    		#data = json.load(data_file)
        #print "json_data ", json_data
        #print "protein_id", json_data["protein_id"]
        #print "dictVdW ", json_data["vdw"]
        #print "resname ", json_data["res_tc"][0]["resname"]
        #print "dictTc ", json_data["res_tc"][0]["at_tc"]
        #json_file.close()

        #self.dict_VdW = json_data["vdw"]
        for at in json_data["vdw"]:
		tmp_list = [ at["name"], float(at["radius"]) ]
		self.dict_VdW[ at["name"] ] = tmp_list

        for res in json_data["res_tc"]:
		#print "loop residue"
                self.dict_Tc[res["resname"]] = [] #res["at_tc"]
                for at in res["at_tc"]:
                        tmp_list = [ at["name"], res["resname"], float(at["charge"]) ]
			#self.dict_Tc[res["resname"]].append(at)
                        self.dict_Tc[res["resname"]].append( tmp_list )

        #print "dict_vdw ", self.dict_VdW
        #print "dict_tc ", self.dict_Tc

        # always something to write
        self.need_to_rewrite = True
        
