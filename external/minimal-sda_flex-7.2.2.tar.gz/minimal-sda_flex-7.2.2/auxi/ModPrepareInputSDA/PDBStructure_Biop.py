
import os, sys
import logging # re
import inspect

from PQR import *

#from Bio.PDB import *
from Bio.PDB.StructureBuilder import StructureBuilder
from Bio.PDB.PDBParser import PDBParser
from ModAddH import LigandObabel, MolObabel, LigandPDB2PQR, ProteinPDB2PQR

from Transformers import *
""" 
    Specialized class for PDB structure with Biopython
    
    Michael Martinez 20/02/2014
"""

class PDBBiopStructure:
    
    ## unique identifier
    id_global = 0
    
    def __init__(self, file, list_chains= None, pH=7.4, PERMISSIVE=1, QUIET=True, Overwritte_chains=False ):
        
        #print "\n== Init PDBBiopStructure file ==\n", file
        logging.info("PDBBiopStructure file")
        self.id = PDBBiopStructure.id_global
        #print "self.id ", self.id
        
        self.dirname = '.'
        (head, tail) = os.path.split(file)
        #print "head ", head
        #print "tail ", tail
        if head:
            self.dirname = head
        
        # all cases correct filename
        self.filename = tail
        self.list_chains = list_chains
        #print "self.list_chains ", list_chains
        self.pH = pH
        
        ## use the standard Bio.PDB class builder
        struct_build = StructureBuilder()
        parser = PDBParser( PERMISSIVE , structure_builder=struct_build, QUIET=True )

        self.pdb = parser.get_structure ( self.id, file )
        
        resolution = self.pdb.header['resolution']
        #keywords = self.pdb.header['keywords']
        #The available keys are name, head, deposition_date, release_date, structure_method, resolution, structure_reference 
        #(which maps to a list of references), journal_reference, author, and compound (which maps to a dictionary with various information about the crystallized compound).
        logging.info("resolution %s", resolution)
        #print "resolution ", resolution
        logging.info("structure_method %s", self.pdb.header['structure_method'])
        #print "structure_method ", self.pdb.header['structure_method']
        #print "available keywords ", keywords
        
        #print "after get_structure"
        at = 0
        for atom in self.pdb.get_atoms():
            at = at+1
        self.nb_atoms = at
        
        logging.info("number of atoms %s", self.nb_atoms)
        logging.info("REMARK, pdb = %s,  nb atoms = %d" % (self.filename, self.nb_atoms) )
        
        logging.debug("self.dirname %s" % self.dirname) 
        logging.debug("self.filename %s" % self.filename)
        logging.debug("number of atoms %d" % self.nb_atoms )
        
        # list of models:
        if len (self.pdb.get_list()) > 1:
            #print "More than one model, consider as NMR structure"
            logging.info("More than one model, consider as NMR structure : %d" % \
                         len (self.pdb.get_list()) )
        else:
            logging.info("Only one model found")
        
    #def select_chains_ligands( self ):
    def select_chains(self):
        """
            General case, not dependent of other methods
            Make first a selection of the chains, delete the not interesting ones
            Maybe ligand in the same function, or apart because more options
            
            Apply to all models.
            
            By default (it may change) we want to delete:
            -delete disorder residues
            -delete WATER
        """

        models = self.pdb.get_list()
        logging.debug("models: %s" % models)
        logging.debug("nb of models: %d" % len( models ) )
        logging.info("Select chains %s" % (self.list_chains) )
        
        for model in models:
            
            for chain in model.get_list():
                
                #print "chain id ", chain.get_id()
                chain_id = chain.get_id()
                
                # To discard, no need to continue
                if (self.list_chains != None ): #& ( chain_id not in self.list_chains) ):
                    if chain_id not in self.list_chains:
                        #print "Discard the chain %s " % chain_id
                        logging.info("Discard the chain %s " % chain_id ) 
                        
                        # line 113 makesprbroblems
                        # new comemment
                        model.detach_child( chain_id )
                        continue
                # chain must be preserved
                #print "Keep the chain %s " % chain_id
                logging.info("Keep the chain %s ", chain_id )
                
                ## Check residues
                for residue in chain.get_list():
                    
                    # select A conformation, to test
                    if residue.is_disordered():
                        
                        #print "Residue %s is disordered ", residue.get_full_id()
                        logging.info("Residue %s is disordered " % residue.get_full_id())
                        
                        for atom in residue.get_list():
                            if atom.disordered_has_id("A"):
                                atom.disordered_select("A")
                                logging.info("Atom %s is disordered, the A conformation has been chosen" % \
                                             atom.get_full_id() )
                            else:
                                #print("We cannot select the A conformation, correct the PDB manually")
                                logging.warning("We cannot select the A conformation, correct the PDB manually")
                                # Exception to raise here ??
                    
                    # Check for water
                    hetflag = residue.get_id()[0]
                    if hetflag[0] == "W":
                        #print "Delete all waters from the pdb by default "
                        logging.debug("Default delete waters from the pdb")
                        chain.detach_child( residue )
        
    def treat_ligands(self, propka, split_ligand, charge_babel_method):
        """ Treat specifically the ligands. Tricky part because many methods
        
            - options split_ligand True: ligand will be "extracted", and method used to compute charge (obabel, propka)
              Then results will be merged in the pqr after PDB2PQR
            - options  split_ligand False: try to treat uniformaly usefull for propka 3.1, Mol2 necessary ??
              Normally no post-processing
              
            Ligands will be associated to the chain, easier to deal with HEM later
        """
        
        #print "\n== Treat ligand ==\n "
        
        logging.info("== Treat ligand ==")
        logging.debug("Split ligand %s" % (split_ligand) )
        logging.debug("Charge method obabel %s" % (charge_babel_method) )
        logging.debug("propka %s" % (propka) )
        
        ### Should be in main first ?? to send error
        # a priori independent
        self.propka = propka
        self.split_ligand = split_ligand
        
        # here incompatible propka/ obabel for the ligand
        if propka == True:
            self.charge_method = None
        else:
            self.charge_babel_method = charge_babel_method
            
        # loop over residues, search for ligands to store in list_pdbligand
        for residue in self.pdb.get_residues():
            
            descp = residue.get_id()
            
            # check only for hetatm residue
            if descp[0][0] == "H":
                
                #print "Found heterogen residue ", residue.get_id()
                logging.debug("Found heterogen residue %s ", residue.get_id() )
                #logging.debug("parent chain %s" % ( residue.get_parent() ) )
                
                parent_chain = residue.get_parent()
                logging.debug("Contained in chain %s" % ( parent_chain ) )
                
                # check if already exists, easier to create in init
                if not hasattr( parent_chain, 'list_pdbligand' ):
                    
                    logging.debug("Creates only one an list_pdbligand")
                    # easier to keep 2 list in order to recreate a correct PDB at the end
                    # maybe not necessary if all infos are saved ?
                    ## will be a list of residue id/first atom number, enought 
                    parent_chain.list_pdbligand = list()
                    ## will be a PDB2PQR / obabel pqr ligand ?? necessary ??
                    parent_chain.list_pqrligand = list()
                    
                    #logging.debug( "only test "
                    #if hasattr( parent_chain, 'list_pdbligand' ):
                        #logging.debug( "chain %s do nothing" & (parent_chain) )
                    #    print "do nothing"
                        #logging.debug( "Has attribute list_pdbligand\n"
                        
                ## now store using one derived class ligand, PDB2PQR / obabel ??
                ## my ligandbase ??
                
                # test if we use ligand from Propka, can add hydrogen but do not assign charge
                # here redundant, but certainly fine
                if self.propka == True :
                    logging.debug( "Create a Propka ligand" )
                    ## need to create the list pdb2pqr atoms
                    #list_atoms = ExtractPropkaLigand()
                    #parent_chain.list_pdbligand = LigandPDB2PQR( list_atoms, propka, self.pH )
                    
                    
                # or OpenBabel 
                else:
                    #print "residue.get_id ", residue.get_id()
                    logging.log("Create an obabel ligand ")
                    
                    # derive from ObMol, a mol for each ligand if splitted
                    ligObabel = LigandObabel()
                    
                    # will assign every atoms to one residue, moved into Transformer
                    # change nothing
                    #ligObabel.BeginModify()
                    
                    # create a single residue by ligand
                    resObabel = ligObabel.NewResidue()
                    # set residue name
                    resObabel.SetName( residue.get_id()[0] )
                    # set residue number
                    resObabel.SetNum( residue.get_id()[1])
                    #resObabel.SetNumString( residue.get_id()[1] )
                    
                    # change nothing
                    #ligObabel.EndModify()
                    
                    #logging.debug( "resObabel.GetNumAtoms() first ", resObabel.GetNumAtoms()
                    # assign hetatam atom , not really in residue
                    # not needed here, already checks
                    #hetflag, resseq, icode= residue.get_id()
                    #logging.debug( "hetflag ", hetflag
                    #logging.debug( "hetflag[0] ", hetflag[0]
                    
                    ### not really needed, because belong to the the chain already
                    #logging.debug( "assign chain id ", parent_chain.get_id()
                    #resObabel.SetChain( parent_chain.get_id() )
                     
                    # obMol with one residue containing all obabel atom  
                    Transformers.Atoms_BioToObabel( residue, ligObabel )
                    #Transformers.Atoms_BioToObabel( residue, ligObabel, resObabel )
                    ## maybe more complex structure, keep chain, resnumber, resname for propka
                    #logging.debug( "After transformers ", resObabel
                    #print "resObabel.GetNumAtoms() after insertion ", resObabel.GetNumAtoms()
                    
                
                #print "append ligObabel to the parent chain.list_pdbligand "
                parent_chain.list_pdbligand.append( ligObabel  )

        logging.info("== End Treat ligand ==")       
                
    def AddHydrogens( self ):
        """Add Hydrogens and charges depending on the pH
        
            To call only after treat_ligands.
        """
        
        #print "\n== Entry AddHydrogens ==\n"
        logging.debug("Entry AddHydrogens")
        
        if self.split_ligand:
            #print "split ligand is True"
            logging.debug("split_ligand is True")
            
            ### here will call the correct protonation obabel/propka
            for model in self.pdb.get_list():
                for chain in model.get_list():
                    #print " chain bio ", chain      
                    #print "list ligand ", self.list_pdbligand
                    
                    if hasattr( chain, 'list_pdbligand' ):
                        for ligand in chain.list_pdbligand:
                            logging.info("ligand to add H %s", ligand.__repr__())
                            #print "ligand name ", ligand.get_name_ligand()
                            #print "size of GetAtoms() ", len( ligand.)
                            #print "NumResidues() ", ligand.NumResidues()
                            #print "NumAtoms() ", ligand.NumAtoms()
                            #print "NumBonds() ", ligand.NumBonds()
                            
                            
                            # could test the class instance as well
                            if self.charge_babel_method != None:
                                #print "charge obabel method= ",self.charge_babel_method
                                logging.debug("call addH to the ligand with charge obabel method= %s" % self.charge_babel_method )
                                ligand.addH( self.pH, self.charge_babel_method )
                                
                            elif self.propka:
                                #print "propka called to protonate ligands"
                                logging.debug("call addH to the ligand with charge obabel propka")
                    else:
                        logging.info("No ligand in this structure")
            
        else:
            #print "split ligand is False, not implemented"
            logging.debug("split_ligand is False")
        
        ## need test maybe only one ligand in structure     
        #print "\n== Add hydrogens to the protein only PDB2PQR for the moment ==\n"
        logging.info( "Add hydrogens to the protein, only PDB2PQR for the moment" )
        
        ## actually only pdb2pqr with propka30 is implemented
        protein = ProteinPDB2PQR( self.pH )
        
        # Extract all protein atom in list_biotatoms
        list_bioatoms = list()
        #print "list bioatoms ", list_bioatoms
        
        ## assume only one model, loop over all chains a priori
        residues = self.pdb[0].get_residues()
        for residue in residues:
            #print "residue ", residue
            hetflag, resseq, icode = residue.get_id() 
            #print "hetflag ", hetflag
            #print "icode:!!"+icode+"!!!"
            
            # if split ligand use an other tool for protonating ligand, do not include in list_bioatoms
            if (self.split_ligand == True) & ( hetflag[0] == "H"):
                #print "It is a ligand, pass"
                continue
            # else copy
            for atom in residue:
                #print "add atom ", atom
                list_bioatoms.append( atom )
            
        #print "list_bioatoms ", list_bioatoms
        # check list is not empty
        if len( list_bioatoms) == 0:
            #print "WARNING: No residues found, only ligands ??"
            logging.warning("WARNING: No residues found, only ligands ??")
        
        # something to do
        else:
            # will call our own version of PDB2PQR, will transform atom type from biopython to PDB2PQR atoms 
            list_pdbqr_atoms, missedligandresidues = protein.addH( list_bioatoms )
            #print "PDBStructurebiop list_pdbqr_atoms ", list_pdbqr_atoms
            logging.info("PDBStructurebiop  missedligandresidues: ", missedligandresidues)
    
            # save the complete protein, ligands excluded from it
            self.list_pdbqr_atoms = list_pdbqr_atoms
            # for test check missedLigandResidues normally not
        
            # not clear should be here or in make_PQRstructure
            #print "\n need to transfrom back "
            #Transformers.AtomsPDBPQToBio( list_pqr_atoms, )
        
            # much aesier if I store a copy of the protein with H
            self.protein_pqr = protein
            # but need to copy the list_pdbqr_atoms ??
        
                 
        logging.info("== Exit AddHydrogens ==")
        
    def make_PQRStructure( self, PERMISSIVE=1, QUIET=True ):
        """
            Create the PQR structure from the data in self.mol
            
            Follow step in PQRstructureBuilder to create the structure of ligands from scratch
            Protein strcture with H is stored self.list_pdbqr_atoms
        """
        
        logging.info("=== Entry make PQR structure ===")
        
        # name easier to follow
        struct_build_pqr = PQRStructureBuilder()
        
        # similar call to reading the structure from a file
        # here create the structure from scratch
        parser = PQRParser( PERMISSIVE , structure_builder=struct_build_pqr, QUIET=True )
        self.pqr = parser.create_structure( self.id_global )
        
        ## copy protein and ligands
        # follow initial order of residue
        for model in self.pdb.get_list():
            logging.debug("model %s" % model)
            #print "model get_id ", model.get_id()
            struct_build_pqr.init_model( model.get_id() )
            #current_model_id+=1
            
            ## not sure what is segid, necessary
            #struct_build.init_seg("   ") 
            
            for chain in model.get_list():
                print "chain ", chain
                #print " chain get_id ", chain.get_id()
                
                ## not sure what is segid, necessary
                #struct_build.init_seg("   ")
                struct_build_pqr.init_seg( chain.get_id() ) 
                
                struct_build_pqr.init_chain ( chain.get_id() )
                
                for residue in chain.get_list():
                    #print "residue ", residue
                    #print "residue get_id() ", residue.get_id()
                    #print "residue get_full_id() ", residue.get_full_id()
                    #print "residue get_resname() ", residue.get_resname()
                    
                    descp = residue.get_id()
                    # check for hetatm residue
                    if descp[0][0] == "H":
                        print "it is a heterogen residue ", residue.get_id()
                        #print "get resname ", residue.get_resname()
                        
                        # init_residue
                        #struct_build.init_residue( descp[0], descp[0], descp[1], descp[1])
                        struct_build_pqr.init_residue( residue.get_resname(), descp[0], descp[1], "")
                        
                        # need to get the ligand stored in chain.list_pdbligand
                        # could be done just after the obabel creation ? and stored in self.protein_pqr
                        obMol = self.find_ligand_obMol ( chain.get_id(), descp[1] )
                        #print "obMol ligand ", obMol
                        
                        # try to conserve the original atom name for heavy atoms 
                        list_atom_names = list()
                        for atom in residue:
                            list_atom_names.append(atom.get_id() )
                            
                        ## conserv the original name for the pqr output ( pdb not 2 names identical, imposed as well by biopython )
                        ## will call init_atom on struct_build
                        Transformers.Atoms_ObabeltoBio ( obMol, struct_build_pqr, list_atom_names )

                    ## here make only a copy, later get all residues with hydrogen
                    else:
                        #print "It is a normal residue", residue.get_id()
                        #print "get resname ", residue.get_resname()
                        struct_build_pqr.init_residue( residue.get_resname(), descp[0], descp[1], "" )
                        
                        list_pqr_atoms = ProteinPDB2PQR.find_residue_PDBQR( self.protein_pqr, chain.get_id(), residue.get_id()[1] )
                      
                        # only transform for one residue
                        # use same trick, send the pqr_builder as argument
                        Transformers.AtomsPDBQRtoBio( self.pqr , struct_build_pqr, list_pqr_atoms )
                        
        # ligands
        #for ligand in self.li
        print "\n=== End make PQR Structure ====\n"
        
        
    def find_ligand_obMol (self, chain_id, resnum ):
        """
            Find the obMol (or propka) corresponding to the chaind_id and residue number
        """
        
        #print "find_ligand_obMol "
        #print "chain_id ", chain_id
        #print "res number ", resnum
        
        ## assume only one model
        model = self.pdb[0]
        #print "model ", model
        chain = model[ chain_id ]
        #print "chain ", chain
        ##test if not empty ?
        
        #for ligand in self.list_pdbligand:
        for ligand in chain.list_pdbligand:
            #print "ligand number ", ligand.getResnum()
            
            if resnum == ligand.getResnum():
                return ligand
        
        print "ERROR: Cannot find the pqr residue number %d in chain %s " % (resnum, chain_id)
        raise Exception("ERROR: Cannot find the pqr residue number %d in chain %s " % (resnum, chain_id) )
        
    def writePQR ( self ):
        """
            Write the structure in a PQR format, when all hydrogens and charges have been set
            
            Need to combine ligand if split_ligand 
        """
        
        print "\n=== Entry write PDBStructue_biop:writePQR ===\n"
        
        # save the structure in pdb format
        # modified to add CTR and NTR residue name
        #io=PDBIO_SDA()
        io = PQRIO()
        io.set_structure( self.pqr )
        io.save( 'toto.pqr' )
        
                    
    def print_info_structure( self, b_all_atoms = False ):
        """ 
            Print info about the structure model, not in the logging, only for debugging.
        
            To update ligand/pqr structure...
            Test for latter splitting, useful for debugging"
            
        """
    
        print "\nEntry Info Structure\n========================="
        
        models = self.pdb.get_list()
        print "models: ", models
        print "nb of models: ", len( models )
        
        print "assume only one model"
        print "nb chains ", len ( models[0] )
        
        ## assume only one model for now
        for chains in models[0]:
            print "chain: ", chains
            #print "nb of chains ", len ( chains )
            print "nb of residues ", len ( chains.get_list() )
        
            for residue in chains.get_list():
                #print "res ", residue
                #print "res id ", residue.get_id()
                #print "res full_id ", residue.get_full_id()
                
                if residue.get_id()[0][0] == "H":
                    print "The residue is HETATM ", residue.get_id()
                    print "The residue is HETATM ", residue.get_full_id()
                if residue.is_disordered():
                    print "The residue is disordered ", residue.get_id()
                    print "The residue is disordered ", residue.get_full_id()
                        
            ## Check if ligands have been splited
            print "\n chain %s list of pdbligand " % ( chains )
            if hasattr( chains, 'list_pdbligand' ):
                print "size list_pdbligand ", len( chains.list_pdbligand )
                for ligand in chains.list_pdbligand:
                    ## need to call obabel/propka type
                    print "ligand ", ligand
                    ligand.print_info_ligand ( b_all_atoms )
            else:
                print "list_pdbligand not created"
            
        print "\n====End info structure =========\n"

    # not needed info ligand in specialized obabel/propka
    # not used to delete                        
#     def print_info_ligands( self ):
#         """ Print infos about the ligands
#         
#             Developed with split ligands  and obabel in mind
#         """
# 
#         
#         print "\nEntry print info ligand splited_ligand %s", self.split_ligand
#         #self.lisprint_infos_splited_ligands
#         
                     

                        
