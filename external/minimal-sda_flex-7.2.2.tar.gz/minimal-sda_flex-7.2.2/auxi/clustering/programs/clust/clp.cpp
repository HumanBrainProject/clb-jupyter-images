//-------------------------------------------------------------------
// Implementation of classes:
// CLP, CLPCluster, CLPAnalyze
//
// DM issues:
// 1. both CLPRecover and CLPCluster needs to load fort55, p1 and p2
// files, also CLPCluster and CLPAnalyze needs cluster.dat file
// so maybe add one more class which handles file i/o, derive it 
// from CLP and all other from that class: e.g.
// CLP <- CLPFile <- CLPCluster
//                <- CLPAnalyze
//                <- CLPRecover
// 2. IMPORTANT, when -cli fileName option is used program gives
// out of memory error and exits???? whata****???
//
//
// by D.M. EML Research, 2005.11
// v0.1
//-------------------------------------------------------------------

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

#include "clp.h"

using namespace std;

//--- class CLP -----------------------------------------------------
// initialize static members
const string CLP::_h    = "-h";
const string CLP::_help = "--help";
const string CLP::none  = "none";
const string CLP::_n    = "-n";
// constructor
CLP::CLP(int argc_, char* argv_[]) {
  // if no parameters suggest help
  if (argc_ == 1) {
    cout << "\ntry: './thisProgram --help'\n\n";
    exit(1);
  }
  // push all command line parameters to a member vector
  for (int i = 0; i < argc_; ++i) {
    clpList.push_back(string(argv_[i]));
  }
}
CLP::CLP(const CLP& clp_) {
  clpList = clp_.clpList;
}
// print
void 
CLP::printHelp() const {
  cout << "--- Main Help ----------------------------------------\n";
  cout << "This is from abstract class CLP\n";
  cout << "you should not be able to call this\n";
  cout << "======================================================\n";
}
// bool
bool
CLP::isPar(const string& par_) const {
// look if parameter is in the list  
  checkPar(par_);
  CiterS _tmp = find(clpList.begin(), clpList.end(), par_);
  if (_tmp != clpList.end()) 
    return true;
  return false;
}
// other
bool
CLP::isPar(const string& par1_,
           const string& par2_) const {
// look for occurancy of two parameters one after another
  checkPar(par1_); checkPar(par2_);
  for (CiterS citerS1 = clpList.begin();
              citerS1 !=clpList.end(); ++citerS1) {
    if (*citerS1 == par1_) { // if par1_ is found
      CiterS citerS2 = citerS1;
      ++citerS2;
      if (citerS2 != clpList.end() and 
          *(citerS2) == par2_) { // if par2_ follows par1_
        return true;
      }
    }
  }
  return false;
}
bool
CLP::isVal(const string& par_) const {
  if (isPar(par_)) {
    CLP::CiterS _tmp = find(clpList.begin(), clpList.end(), par_);
    ++_tmp;
    if (checkVal(_tmp)) {
      return true;
    }
  }
  return false;
}
bool
CLP::checkPar(const string& par_) const {
  if ((par_)[0] == '-')
    return true;
  return false;
}
const string*
CLP::getVal(const string& par_) const {
// get value after parameter par_
  checkPar(par_);
  CiterS _tmp = find(clpList.begin(), clpList.end(), par_);
  if (checkVal(++_tmp)) 
    return &(*_tmp);
  else
    return &none;
}
vector<const string*>
CLP::getAllVal(const string& par_) const {
  checkPar(par_);
  vector<const string*> _res;
  CiterS _tmp = clpList.begin();
  while (_tmp != clpList.end()) {
    _tmp = find(_tmp, clpList.end(), par_);
    if (_tmp == clpList.end())
      return _res;
    if (checkVal(++_tmp)) {
      _res.push_back(&(*_tmp));
    }
    ++_tmp;
  }  
  return _res; 
}
const string*
CLP::getVal(const string& par1_,
            const string& par2_) const {
// get value after two subsequent parameters
  checkPar(par1_); checkPar(par2_);
  for (CiterS citerS1 = clpList.begin();
  
  
              citerS1 !=clpList.end(); ++citerS1) {
    if (*citerS1 == par1_) {
      CiterS citerS2 = citerS1;
      if (*(++citerS2) == par2_) {
        if (checkVal(++citerS2))
          return &(*citerS2);
      } // par2_ found
    } // par1_ found 
  } // clpList.end()
  return &none;
}   
bool
CLP::checkVal(CLP::CiterS item_) const {
  if (item_ == clpList.end()) {
    return false;
  }
  if (checkPar(*item_) ) {
    return false;
  }
  return true;
}

//--- class CLPFile -------------------------------------------------
// initialize static
const string CLPFile::_f55      = "-f55";
const string CLPFile::_p1       = "-p1";
const string CLPFile::_p2       = "-p2";

//
bool
CLPFile::isRun() const {
  if (clpList[1] == _h or
      clpList[1] == _help ) {
    printHelp();
    exit(1);
  }
  if (!isPar(_f55) or !isVal(_f55)) {
    printHelp();
    exit(1);
  }
  if (!isPar(_p1) or !isVal(_p1)) {
    printHelp();
    exit(1);
  }
  if (!isPar(_p2) or !isVal(_p2)) {
    printHelp();
    exit(1);
  }
  return true;
}
void
CLPFile::printHelp() const {
  cout << "=== File Help ========================================\n";
  cout << " -f55 <string>     complexes file\n"
       << " -p1  <string>     protein 1 pdb file\n"
       << " -p2  <string>     protein 2 pdb file\n"
       << " -cli [string]     clustering data file for input\n"
       << "                   DEFAULT 'clust.dat'\n"
       << " -clo [string]     clustering data file for output\n"
       << "                   DEFAULT 'clust.dat'\n";
  cout << "======================================================\n";

}
//--- class CLPAnalyze ----------------------------------------------
const string CLPAnalyze::_analyze   = "--analyze";
const string CLPAnalyze::_an        = "-an";

bool
CLPAnalyze::isRun() const {
  if (isPar(_an) or isPar(_analyze)) {
    if (isPar(_an, _h) or isPar(_analyze, _help)) {
      printHelp();
      exit(1);
    }
    return true;
  }
  return false;
}
void
CLPAnalyze::printHelp() const {
  cout << "=== Analyzis Help ====================================\n";
  cout << " -an or --analyze switch to analyzis mode\n"
       << " -p               switch to print mode\n"
       << "   -cy   [int]    print info of last int cycles\n"
       << "                  DEFAULT all cycles\n"
       << "   -bin  [int]    print bins of last int cycles\n"
       << "                  DEFAULT all cycles\n"
       << "   -clcl <int>    print cycle where number of clusters is int..\n"
       << "   -clcn <int>    print cluster info of cylce number.. \n"
       << "   -clcv <float>  print cluster info of cycle at value..\n"    
       << "     -clsz [int]  print clusters only of this size or larger..\n"
       << "                  DEFAULT 5\n" 
       << " -v               switch to visualize mode\n"
       << "   -clcn <int>    visualize clusters of cycle number..\n"
       << "   -clcv <float>  visualize clusters of cycle at value..\n"
       << "      -n [int]    number of clusters to show\n.."
       << " \n"
       << " e.g:  ./program -an -p -cy 200\n";
  cout << "======================================================\n";
}
//--- class CLCluster -----------------------------------------------
const string CLPCluster::_cluster = "--cluster";
const string CLPCluster::_cl      = "-cl";

bool
CLPCluster::isRun() const {
  if (isPar(_cl) or isPar(_cluster)) {
    if (isPar(_cl, _h) or isPar(_cluster, _help)) {
      printHelp();
      exit(1);
    }
    return true;
  }
  return false;
}
void
CLPCluster::printHelp() const {
  cout << "=== Cluster Help =====================================\n";
  cout << " -cl or --cluster switch to clustering mode\n"
       << " -n   [int]       number of structures to cluster\n"
       << "                  DEFAULT 500\n"
       << "\n"
       << " e.g.: ./program -cl -n 300\n";
  cout << "======================================================\n";
}
//--- class CLPRecover ----------------------------------------------
const string CLPRecover::_recover = "--recover";
const string CLPRecover::_re      = "-re";

bool
CLPRecover::isRun() const {
  if (isPar(_re) or isPar(_recover)) {
    if (isPar(_re, _h) or isPar(_recover, _help)) {
      printHelp();
      exit(1);
    }
    return true;
  }
  return false;
}
void
CLPRecover::printHelp() const {
  cout << "=== Recover Help =====================================\n";
  cout << " -re or --recover switch to recovering mode\n"
       << " -clcl <int>      recover where number of clusters is..\n"
       << " -clcn <int>      recover from cycle number..\n"
       << " -clcv <flaot>    recover from cycle with value..\n"
       << " -rn    [int]     recover only from these clusters..\n"
       << "                  DEFAULT 10\n"
       << " -clsz [int]      recover only if cluster size is..\n"
       << "                  DEFAULT 5\n"
       << "\n"
       << " e.g. ./this program -re -clcn 2 -n 15 -clsz 7 \n";
  cout << "======================================================\n";
}

//--- class CLPScore ------------------------------------------------
const string CLPScore::_score = "--score";
const string CLPScore::_sc = "-sc";
const string CLPScore::_rpin = "-rpin";

bool
CLPScore::isRun() const {
  if (isPar(_sc) or isPar(_score)) {
    if (isPar(_sc, _h) or isPar(_score, _help)) {
      printHelp();
      exit(0);
    }
    if (isPar(_rpin) and isVal(_rpin)) {
      return true; 
    }
    else {
      cout << "WARNING: no input file for residue propensities\n";
      return true;
    }
  }
  return false;
}

void
CLPScore::printHelp() const {
  cout << "=== Score Help =======================================\n";
  cout << " -sc or --score switch to clustering mode\n"
       << " -rpin <string> residue propensity file\n"
       << " -cdist [float] contact distance for RP calculation\n"
       << "                DEFAULT 5.0\n"
       << " -rpdef [int]   definition of rp calculation\n"
       << "                DEFAULT 5\n"
       << " -n [int]       number of structures to score\n"
       << "                DEFAULT 500\n"
       << "\n"
       << " e.g.: ./program -sc -f55 complexes -p1 p1.pdb -p2 p2.pdb "
       <<           "-rpin rp1.txt -rpin rp2.txt -cdist 6.0 -rpdef 2\n";
  cout << "======================================================\n";
}


