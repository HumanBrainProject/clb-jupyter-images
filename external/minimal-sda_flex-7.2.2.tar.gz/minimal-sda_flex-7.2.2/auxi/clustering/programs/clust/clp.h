//-------------------------------------------------------------------
// Classes:
// CLP, CLPCluster, CLPAnalyze
//
// What: 
// these are made to handle command line parameters, CLP is a
// base, derived class then should be addopted for particular
// parameter handle.
//
// by D.M. EML Research 2005.11
// v0.1 
//-------------------------------------------------------------------
#ifndef CLP_H
#define CLP_H

#include <vector>
#include <string>
using namespace std;


class CLP {
  public:
    typedef vector<string>::const_iterator CiterS;
    const static string none;
    const static string _n;
    const static string _h;
    const static string _help;
    CLP(int argc_, char* argv_[]);
    CLP(const CLP& clp_); 
    ~CLP() {}
    virtual bool isRun() const =0;
    // check if parameter is in the list
    virtual bool isPar(const string& par_) const;
    // check if pair of subsequent parameters is in the list
    virtual bool isPar(const string& par1_,
                       const string& par2_) const;
    // check if value follows the parameter
    virtual bool isVal(const string& par_) const;       
    // get value which follows parameter
    virtual const string* getVal(const string& par_) const;
    // get value which follows subsequent pair of parameters
    virtual const string* getVal(const string& par1_,
                                 const string& par2_) const;
    /*! get all values which follow same parameter */
    virtual vector<const string*> getAllVal(const string& par_) const;
    virtual void printHelp() const =0;
    // here all parameters are kept
  protected:
    vector<string> clpList;
  private:
    // some checking
    virtual bool checkPar(const string& par_) const;    
    virtual bool checkVal(CiterS item_) const;
};

class CLPFile: public CLP {
  public:
    CLPFile(int argc_, char* argv_[]): CLP(argc_, argv_) {}
    ~CLPFile() {}
    virtual bool isRun() const;
    virtual void printHelp() const;
    
    const static string _f55;
    const static string _p1;
    const static string _p2;
  private:
 
}; 

class CLPAnalyze: public CLP {
  public:
    CLPAnalyze(int argc_, char* argv_[]): CLP(argc_, argv_) {}
    ~CLPAnalyze() {}
    virtual void printHelp() const;
    virtual bool isRun() const;
    //
  private: 
    const static string _analyze;
    const static string _an;
};

class CLPCluster: public CLP {
  public:
    CLPCluster(int argc_, char* argv_[]): CLP(argc_, argv_) {}
    ~CLPCluster() {}
    virtual void printHelp() const;
    virtual bool isRun() const;
  private:
    const static string _cluster;
    const static string _cl;
};

class CLPRecover: public CLP {
  public:
    CLPRecover(int argc_, char* argv_[]): CLP(argc_, argv_) {}
    ~CLPRecover() {}
    virtual void printHelp() const;
    virtual bool isRun() const;
  private:
    const static string _recover;
    const static string _re;
};

class CLPScore: public CLP {
  public:
    CLPScore(int argc_, char* argv_[]): CLP(argc_, argv_) {}
    ~CLPScore() {}
    virtual void printHelp() const;
    virtual bool isRun() const;
  private:
    const static string _score;
    const static string _sc;
    const static string _rpin;
};

//-------------------------------------------------------------------

#endif 



