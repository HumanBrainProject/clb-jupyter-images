#!/sw/pub/bin/python
# 
# this one goes to folders with printed out results and 
# makes a plot with gnuplot,
#
import os, sys

def makeGnuPlotScript(title, fileIn, fileOut, lineNumb):
  return """
set term png
set output '"""+fileOut+"""'
set xrange [0:"""+str(lineNumb)+"""] reverse
set grid
set title '"""+title+"""'
set xlabel 'Number of Clusters'
set ylabel 'Min Distance Between Clusters'
set y2label 'Value increace from previous %'
set key top left box
set xtics 10
set ytics nomirror
set y2tics
plot '< tail -"""+str(lineNumb)+""" """+fileIn+"""' using 1:3 axes x1y1 \
with steps lw 2 lt 1 title 'distance', \
'< tail -"""+str(lineNumb)+""" """+fileIn+"""' using 1:4 axes x1y2 \
with points pt 6 ps 1 lt 3 title ' increace % '
"""

fileOut = 'none'
fileIn  = 'none'
title = 'none'
tmpFile = 'tmpGnuplotScript.scr'

try:
  title  = sys.argv[1]
  fileIn = sys.argv[2]
  fileOut= sys.argv[3]
except IndexError:
  print 
  print 'USAGE: '
  print './thisProgram title inputFile outputFile'
  print
  sys.exit(1)
  
fileOutObj = open(tmpFile, 'w')
_file = open(fileIn)
n = 0
for i in _file:
  n += 1
n -= 1
if n > 100:
  n = 100

fileOutObj.write(makeGnuPlotScript(title, fileIn, fileOut, n))
fileOutObj.close()
os.system('gnuplot '+tmpFile)

sys.exit(0)
os.system('rm '+tmpFile)  


print 'Done...'
    