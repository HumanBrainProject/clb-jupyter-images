#!/sw/pub/bin/python
# 
# this one goes to folders with printed out results and 
# makes a plot with gnuplot,
#
import os, sys

def makeGnuPlotScript(title, fileIn, fileOut):
  return """
set term png
set output '"""+fileOut+"""'
set grid
set title '"""+title+"""'
set xlabel 'Bins'
set ylabel 'Number of Clusters'
set key top right box
plot '"""+fileIn+"""' with lines
"""
#plot '< tail -100 """+fileIn+"""' with steps lw 2 lt 1 
#"""

fileOut = 'none'
fileIn  = 'none'
title = 'none'
tmpFile = 'tmpGnuplotScript.scr'

try:
  title  = sys.argv[1]
  fileIn = sys.argv[2]
  fileOut= sys.argv[3]
except IndexError:
  print 
  print 'USAGE: '
  print './thisProgram title inputFile outputFile'
  print
  sys.exit(1)
  
fileOutObj = open(tmpFile, 'w')
fileOutObj.write(makeGnuPlotScript(title, fileIn, fileOut))
fileOutObj.close()
os.system('gnuplot '+tmpFile)
os.system('rm '+tmpFile)  


print 'Done...'
    