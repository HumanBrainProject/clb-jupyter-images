#!/sw/pub/bin/python
# 
# this one goes to folders with printed out results and 
# makes a plot with gnuplot,
#
import os, sys

def makeGnuPlotScript(title, fileIn, fileOut):
  return """
set term png
set output '"""+fileOut+"""'
set grid
set title '"""+title+"""'
set xlabel "rmsd to X-ray structure"
set ylabel "Cluster size 1"
set y2label "Cluster size 2"
set key top right box
set ytics nomirror
set y2tics
set pointsize 1
plot '"""+fileIn+"""' using 8:2 title "clSize 1" with points 11, \
     '"""+fileIn+"""' using 8:3 title "clSize 2" axis x1y2 with points 9
"""

fileOut = 'none'
fileIn  = 'none'
title = 'none'
tmpFile = 'tmpGnuplotScript.scr'

try:
  title  = sys.argv[1]
  fileIn = sys.argv[2]
  fileOut= sys.argv[3]
except IndexError:
  print 
  print 'USAGE: '
  print './thisProgram title inputFile outputFile'
  print
  sys.exit(1)
  
fileOutObj = open(tmpFile, 'w')
fileOutObj.write(makeGnuPlotScript(title, fileIn, fileOut))
fileOutObj.close()
os.system('gnuplot '+tmpFile)
#os.system('rm '+tmpFile)  


print 'Done...'
    
