//---------------------------------------------------------
/*! \file mathstuff.h
    \brief Math stuff from 3d Math primer

*/    
//---------------------------------------------------------

#ifndef MATHSTUFF_H
#define MATHSTUFF_H

#include <cmath>

/*! pi */
const float cpi 	= 3.14159265f;
const float cpi2        = cpi * 2.0f;
const float c2Mpi	= cpi * 2.0f;
const float cpiD2 	= cpi / 2.0f;
const float c1Dpi	= 1.0f / cpi;
const float c1D2pi	= 1.0f / c2Mpi;
const float cpiD180	= cpi / 180.0f;
const float c180Dpi	= 180.0f / cpi;

//---various adjusting stuff--->
/*! make anlge in nice range, [-pi, pi] */
extern float makeNiceAngle(float);
/*! safe inverse trig function with "proper" angle */
extern float safeAcos(float);
/*! convert degrees to radians */
inline float deg2rad(float deg) { return deg * cpiD180; }
/*! convert radians to degrees */
inline float rad2deg(float rad) { return rad * c180Dpi; }
/* compute sin & cos of an angle at a time (may be fater they say:-) */
inline void sinCos(float* gosin, float* gocos, float alfa) {
  *gosin = sin(alfa);
  *gocos = cos(alfa);
}

#endif


