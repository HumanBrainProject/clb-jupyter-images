/*! \file vector3.h
    \brief Represent vector (or point) in 3d.
    
   class Vector3 
*/

#ifndef VECTOR3_H
#define VECTOR3_H

#include <vector>

using namespace std;
/*! \brief Represent vector (or point) in 3d.

  Stores 3d vector (or point) and has number of methods to do
  main operations with 3d vectors
*/
class Vector3 {
  public:
  //---constructors--->
    Vector3(){};
    Vector3(const Vector3&);
    Vector3(float, float, float);

  //---overloaded operators--->
  // assignment
    Vector3& operator =(const Vector3&);
  // arithmetics
    Vector3  operator +(const Vector3&) const;
    Vector3  operator -(const Vector3&) const;
    Vector3  operator *(float) const;
    Vector3  operator /(float) const;
  // arithmetics on current Vector3
    Vector3& operator +=(const Vector3&);
    Vector3& operator -=(const Vector3&);
    Vector3& operator *=(const Vector3&);
    Vector3& operator /=(const Vector3&);
  // negation
    Vector3  operator -() const;
  // comparison
    bool     operator ==(const Vector3&) const;
    bool     operator !=(const Vector3&) const;
  //---other operations--->
  // normalization
    void normalize();
  // dot product
    float operator* (const Vector3&) const;
  // zero vector
    void zero();
  // coordinates
    float x, y, z;
};
//---other vector/point stuff--->
inline float vectorMag(const Vector3&);
inline Vector3 crossProduct(const Vector3&, const Vector3&);
// two vector multiplication
inline Vector3 operator*(float, const Vector3&);
// distance between poiints
inline float dist(const Vector3&, const Vector3&);
inline float dist(const Vector3*, const Vector3*);
inline float dist2(const Vector3&, const Vector3&);
                        
float vector3Rmsd(const vector<Vector3>& v1_,
                  const vector<Vector3>& v2_);
Vector3 vector3Center(const vector<Vector3>& v_);                         
                         
#endif
