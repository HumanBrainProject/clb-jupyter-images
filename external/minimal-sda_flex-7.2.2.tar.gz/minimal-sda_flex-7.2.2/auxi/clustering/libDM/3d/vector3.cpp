/*! \file vector3.cpp
*/
#include <iostream>

#include <cmath>
#include <vector>
#include <cassert>
#include "vector3.h"

using namespace std;

//===Vector3===>
//---constructors--->
Vector3::Vector3(const Vector3& v)
{
	x=v.x; y=v.y; z=v.z;
}
Vector3::Vector3(float x_in, float y_in, float z_in)
{
	x=x_in; y=y_in; z=z_in;
}
//---overloaded operators--->
// assignment
Vector3& Vector3::operator=(const Vector3& v)
{
	x=v.x; y=v.y; z=v.z;
	return *this;
}
// arithmetics
Vector3 Vector3::operator+(const Vector3& v) const
{
	return Vector3(x+v.x, y+v.y, z+v.z);
}
Vector3 Vector3::operator-(const Vector3& v) const
{
	return Vector3(x-v.x, y-v.y, z-v.z);
}
Vector3 Vector3::operator*(float f) const
{
	return Vector3(x*f, y*f, z*f);
}
Vector3 Vector3::operator/(float f) const
{
	if (f < 0.00001f)
	{
		cout << "W: division by 0 in vector / operation!" << endl;
		return Vector3();
	}
	long double _f = (long double)1.0f/(long double)f;
	return Vector3(x*_f, y*_f, z*_f);
}
// arithmetics on this
Vector3& Vector3::operator+=(const Vector3& v)
{
	x+=v.x; y+=v.y; z+=v.z;
	return *this;
}
Vector3& Vector3::operator-=(const Vector3& v)
{
	x-=v.x; y-=v.y; z-=v.z;
	return *this;
}
Vector3& Vector3::operator*=(const Vector3& v)
{	
	x*=v.x; y*=v.y; z*=v.z;
	return *this;
}
Vector3& Vector3::operator/=(const Vector3& v)
{
	if (v.x < 0.00000000001f || v.y < 0.00000000001f || v.z < 0.00000000001f)
	{
		cout << "W: division by 0 in vector /= operation~" << endl;
		return *this;
	}
	x/=v.x; y/=v.y; z/=v.z;
	return *this;
}
// negation
Vector3 Vector3::operator-() const
{
	return Vector3(-x, -y, -z);
}
// comparison
bool Vector3::operator==(const Vector3& v) const
{
	return (x==v.x && y==v.y && z==v.z);
}
bool Vector3::operator!=(const Vector3& v) const
{
	return (x!=v.x || y!=v.y || z!=v.z);
}
//---other operations--->
// normalization
void Vector3::normalize()
{
	long double msqr = x*x + y*y + z*z;
	if (msqr > (long double)0.0f)
	{ 
		long double _f = (long double)1.0f / sqrt(msqr);
		x *= _f;
		y *= _f;
		z *= _f;
	}
	else
	{
		cout << "W: division by 0 in vector normalization!" << endl;
	}
}
// dot product
float Vector3::operator*(const Vector3& v) const
{
	return (x*v.x + y*v.y + z*v.z);
}
// make it zero
void Vector3::zero()
{
	x=0.0f; y=0.0f; z=0.0f;
}
//===Vector3===/

//---other vector/point stuff--->
inline float vectorMag(const Vector3& v){
	return sqrt((long double)
			((long double)v.x*(long double)v.x
			+ (long double)v.y*(long double)v.y
			+ (long double)v.z*(long double)v.z));
}
inline Vector3 crossProduct(const Vector3& v1, const Vector3& v2)
{
	return Vector3((long double)v1.y*(long double)v2.z - (long double)v1.z*(long double)v2.y,
			(long double)v1.z*(long double)v2.x - (long double)v1.x*(long double)v2.z,
			(long double)v1.x*(long double)v2.y - (long double)v1.y*(long double)v2.x);
}
// two vector multiplication
inline Vector3 operator*(float f, const Vector3& v)
{
	return Vector3(v.x*f, v.y*f, v.z*f);
}
// distance between points
inline float dist(const Vector3& v1, const Vector3& v2)
{
	long double dx = (long double)v1.x - (long double)v2.x;
	long double dy = (long double)v1.y - (long double)v2.y;
	long double dz = (long double)v1.z - (long double)v2.z;
	return sqrt(dx*dx + dy*dy + dz*dz);
}
inline float dist(const Vector3* v1, const Vector3* v2){
	long double dx = (long double)v1->x - (long double)v2->x;
	long double dy = (long double)v1->y - (long double)v2->y;
	long double dz = (long double)v1->z - (long double)v2->z;
	return sqrt(dx*dx + dy*dy + dz*dz);
}

inline float dist2(const Vector3& v1, const Vector3& v2){
        long double dx = (long double)v1.x - (long double)v2.x;
        long double dy = (long double)v1.y - (long double)v2.y;
        long double dz = (long double)v1.z - (long double)v2.z;
        return dx*dx + dy*dy + dz*dz;
}


float vector3Rmsd(const vector<Vector3>& v1_, 
                  const vector<Vector3>& v2_) {
  vector<Vector3>::const_iterator citV1, citV2;
  assert(v1_.size() == v2_.size());
  long double dx, dy, dz, _res;
  unsigned int n = 0;
  for (citV1 = v1_.begin(), citV2 = v2_.begin();
       citV1 !=v1_.end(), citV2 !=v2_.end();
       ++citV1, ++citV2) {
    dx = (long double)citV1->x - (long double)citV2->x;
    dy = (long double)citV1->y - (long double)citV2->y;
    dz = (long double)citV1->z - (long double)citV2-> z;
    _res += (dx * dx + dy * dy + dz * dz);
    ++n;
  }
  long double _1overN = (long double)1.0f / (long double)n;
  return sqrt(_res * _1overN);
}

Vector3 vector3Center(const vector<Vector3>& v_) {
  long double x = 0.0f, y = 0.0f, z = 0.0f;
  unsigned int n = 0;
  for (vector<Vector3>::const_iterator citV = v_.begin();
       citV != v_.end(); ++citV) {
    x += (long double)citV->x;
    y += (long double)citV->y;
    z += (long double)citV->z;
    ++n;
  }
  long double _1overN = (long double)1.0f /(long double) n;
  return Vector3(x * _1overN, y * _1overN, z * _1overN);
}

//---/


