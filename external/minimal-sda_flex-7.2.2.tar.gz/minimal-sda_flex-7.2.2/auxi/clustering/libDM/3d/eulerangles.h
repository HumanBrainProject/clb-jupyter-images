//---------------------------------------------------
// eulerangles - header
// This is to store an orientation in Euler angles
// in heading-pitch-bank manner
//  
//            /\      /\     
//            |      /
// <--|-->    +      |--o--|
//            |            /
//            \/         \/
//---------------------------------------------------

#ifndef EULERANGLES_H
#define EULERANGLES_H

class Quaternion;
class Matrix4x3;
class RotationMatrix;

class EulerAngles
{
	public:
		EulerAngles(){}
		EulerAngles(float h_in, float p_in, float b_in):
			h(h_in), p(p_in), b(b_in) {}
		
		// here are Euler Angles in radians
		float h;
		float p;
		float b;
		//---operations--->
		// all zeros
		void setIdentity() { h = p = b = 0.0f; }
		// make angles canonical
		void makeCanonic();
		//---conversions--->
		// convert quaterion to euler angles
		void fromObj2IneQua(const Quaternion&);
		void fromIne2ObjQua(const Quaternion&);
		// convert from transformation matrix to euler anlges, translation ignored
		void fromObj2WorMat(const Matrix4x3&);
		void fromWor2ObjMat(const Matrix4x3&);
		// convert from rotation matrix to euler angles
		void fromRotMat(const RotationMatrix&);
};

#endif

