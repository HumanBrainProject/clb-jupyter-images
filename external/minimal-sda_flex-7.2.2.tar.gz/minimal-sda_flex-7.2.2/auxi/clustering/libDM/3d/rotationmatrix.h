//-------
// rotationmatrix header
//-------

#ifndef ROTATIONMATRIX_H
#define ROTATIONMATRIX_H

class Vector3;
class EulerAngles;
class Quaternion;

//==========RotationMatrix class==========>
// 3x3 matrix, used for ROTATION ONLY. The direction of transformation
// is specified at the time of transformation.

class RotationMatrix
{
	public:
		float m11, m12, m13;
		float m21, m22, m23;
		float m31, m32, m33;
		// set to identity
		void identity();
		// Setup the matrix with a specified orientation
		void setup(const EulerAngles&);
		// Setup the matrix from a quaternion, assuming the
		// quaternion performs the rotation in the
		// specified direction of transformation
		void fromIne2ObjQua(const Quaternion&);
		void fromObj2IneQua(const Quaternion&);
		// Perform rotations
		Vector3	ine2Obj(const Vector3&) const;
		Vector3	obj2Ine(const Vector3&) const;
};

#endif

