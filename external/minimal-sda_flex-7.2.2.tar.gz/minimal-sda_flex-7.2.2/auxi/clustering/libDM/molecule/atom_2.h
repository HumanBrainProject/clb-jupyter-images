//-------------------------------------------------------------------
/*! \file atom.h
    \brief Classes for atom 
    
    
*/
//-------------------------------------------------------------------

#ifndef ATOM_H
#define ATOM_H

//tmp
#include <iostream>


#include <string>
#include <vector>
#include "vector3.h"

namespace libDM_molecule {

class PdbLine;

//*******************************************************************
// ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM 
//-------------------------------------------------------------------
/*! \brief Basic atom class

*/
class BasicAtom {
  public:
    BasicAtom(): coord(0.0f, 0.0f, 0.0f) {/*who();*/}
    BasicAtom(const Vector3& coord_): coord(coord_) {/*who();*/}
    BasicAtom(float x_, float y_, float z_): coord(x_, y_, z_) {/*who();*/}
    BasicAtom(const BasicAtom& other);
    
    void who() { cout << "BasicAtom\n"; } 
    BasicAtom& operator=(const BasicAtom& other);
    bool operator==(const BasicAtom& other) const;
    
    const Vector3& getCoord() const; 
    Vector3& accessCoord() {return coord;}
  protected:
    Vector3 coord;
  
};
/*! \brief Common protein atom.

.
*/
class Atom: public BasicAtom {
  public:
    Atom(): BasicAtom(), altLoc(' '), name(" ") {/*who();*/}
    Atom(const Vector3& coord_, const string& name_, const char altLoc_):
        BasicAtom(coord_), altLoc(altLoc_), name(name_) {/*who();*/}
    Atom(const PdbLine& pdbLine_);
    Atom(const Atom& other);
   
    void who() { cout << "Atom\n"; }   
    Atom& operator=(const Atom& other); 
    bool operator==(const Atom& other) const;
    
    char           getAltLoc() const;
    const string&  getName() const;
  protected:
    char    altLoc;
    string  name;
};


/*! \brief Atom with one more float value:-)


*/
class AtomF: public Atom {
  public:
    AtomF(): Atom(), f(0.0f) {}
    AtomF(const PdbLine& pdbLine_, float f_): 
      Atom(pdbLine_), f(f_) {}
    
    float getF() const {return f;}
    void setF(float f_) {f = f_;}
  protected:
    float f;
};
//-------------------------------------------------------------------
// ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM ATOM 
//*******************************************************************

/* moved to vector3.h
float vector3Rmsd(const vector<Vector3>& v1_,
                  const vector<Vector3>& v2_);
Vector3 vector3Center(const vector<Vector3>& v_);
*/
/*
class Atom
{
	public:
		Atom(PdbLine*);
		void who();
	//---methods--->
		// is?
		bool isBackbone() const;
	//---members--->
		//-------------------//
		string atom;         //
		const char* altLoc;  //
		Vector3 coor;        //
		//-------------------//

	private:
		//---methods--->
		void makeAtom(const string*);
		void makeAltLoc(const char*);
		//---members--->
		char  _altLoc;
		// iterators
		vector<string>::iterator vs_i;
};
*/

} // namespace libDM_molecule
#endif

