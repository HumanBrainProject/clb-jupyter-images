//-------------------------------------------------------------------
/*! \file pdbfile.cpp

*/
//-------------------------------------------------------------------
#include <vector>
#include <string>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cassert>

#include "pdbfile.h"
#include "pdbline.h"
#include "../3d/vector3.h"

using namespace std;



// class PdbFileS1 --------------------------------------------------
// static members
// int PdbFileS1::getCenterCallNo = 0;
// constructor
PdbFileS1::PdbFileS1(const vector<PdbLineS1>& pdbLines_) {
  pdbLines = pdbLines_;
}
PdbFileS1::PdbFileS1(const vector<string>& pdbLines_) {
  setPdbLines(pdbLines_);
}
PdbFileS1::PdbFileS1(const PdbFileS1& pdbFile_) {
  pdbLines = *pdbFile_.getPdbLines();
}
PdbFileS1::PdbFileS1(Reader& reader_) {
  unsigned int _vectorSize;
  reader_ >> _vectorSize;
  pdbLines.reserve(_vectorSize);
  for (unsigned int i = 0; i < _vectorSize; ++i) {
    PdbLineS1* _pL = new PdbLineS1(reader_);
    pdbLines.push_back(*_pL);
    delete _pL;
  }
}
// operator
PdbFileS1&
PdbFileS1::operator=(const PdbFileS1& pdbFile_) {
  pdbLines = *pdbFile_.getPdbLines();
  return *this;
}
bool
PdbFileS1::operator==(const PdbFileS1& pdbFile_) const {
  for (vector<PdbLineS1>::const_iterator citerPLThis = pdbLines.begin(),
                          citerPLThat = pdbFile_.getPdbLines()->begin();
       citerPLThis != pdbLines.end(),
       citerPLThat != pdbFile_.getPdbLines()->end();
       ++citerPLThis,
       ++citerPLThat) {
    if (!(*citerPLThis == *citerPLThat))
      return false;
  }
  return true;  
}
// set
void
PdbFileS1::setPdbLines(const vector<PdbLineS1>* pdbLines_) {
  pdbLines = *pdbLines_;
}
void
PdbFileS1::setPdbLines(const vector<string>& pdbLines_) {
  pdbLines.reserve(pdbLines_.size());
  for (vector<string>::const_iterator citerS = pdbLines_.begin();
       citerS != pdbLines_.end();
       ++citerS) {
    pdbLines.push_back(PdbLineS1(*citerS));
  }
}
void
PdbFileS1::addPdbLine(const PdbLineS1* pdbLine_) {
  pdbLines.push_back(*pdbLine_);
}
// get
const vector<PdbLineS1>*
PdbFileS1::getPdbLines() const {
  return &pdbLines;
}
vector<PdbLineS1>&
PdbFileS1::accessPdbLines() {
  return pdbLines;
}
Vector3
PdbFileS1::getCenter() const {
  float _x = 0.0f, _y = 0.0f, _z = 0.0f;
  int _n = 0;
  for (vector<PdbLineS1>::const_iterator citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    _x += (citerPL->getCoord()).x;
    _y += (citerPL->getCoord()).y;
    _z += (citerPL->getCoord()).z;
    ++_n;
  }
  float _1overN = (1.0f / _n);
  return Vector3((_x*_1overN), (_y*_1overN), (_z*_1overN));
}

// this assumes y have really the same structure, does just minor checks
float
PdbFileS1::backbRmsd(const PdbFileS1& pdbFile_) const {
  if (this->pdbLines.size() != pdbFile_.getPdbLines()->size()) {
    cerr << "The number of pdbLines in PdbFile objects are different. "
         << "Can't calculate RMSD." << endl;
    exit(1);
  }
  long double _res = 0.0f;
  int _n = 0;
  vector<PdbLineS1>::const_iterator end1=this->pdbLines.end();
  vector<PdbLineS1>::const_iterator end2=pdbFile_.getPdbLines()->end();
  for (vector<PdbLineS1>::const_iterator citerPL1 = this->pdbLines.begin(),
                                citerPL2 = pdbFile_.getPdbLines()->begin();
       citerPL1 !=end1,
       citerPL2 !=end2;
       ++citerPL1,
       ++citerPL2) {
    // maybe its too expensive to check so much (but secure:-))   
    if (//is fullfilled by the next condidtion citerPL1->isAtom("CA") && citerPL2->isAtom("CA") ||
        citerPL1->isBackbone and citerPL2->isBackbone) {
//    		citerPL1->isAtom("C")  && citerPL2->isAtom("C")  ||
//	citerPL1->isAtom("N")  && citerPL2->isAtom("N")  ||
//	citerPL1->isAtom("O")  && citerPL2->isAtom("O")   ) {
      long double _dx = (citerPL1->getCoord().x - citerPL2->getCoord().x);
      long double _dy = (citerPL1->getCoord().y - citerPL2->getCoord().y);
      long double _dz = (citerPL1->getCoord().z - citerPL2->getCoord().z);
      _res += (_dx*_dx + _dy*_dy + _dz*_dz);
      ++_n;
    }
  } //for end
  long double _1overN = (long double) 1.0f / (long double)_n;
  return sqrt(_res * _1overN);
}
void 
PdbFileS1::storageWrite(Writer& writer_) {
  unsigned int si = pdbLines.size();
  writer_ << si;
  //writer_ << ( pdbLines.size() ); why doesn't this work?
  for (vector<PdbLineS1>::iterator iterPL = pdbLines.begin();
       iterPL != pdbLines.end();
       ++iterPL) {
    iterPL->storageWrite(writer_);
  }
}
// ==================================================================

// class PdbFileS1 --------------------------------------------------
PdbFile::PdbFile(const PdbFile& other) {
  pdbLines = *other.getPdbLines();
}
PdbFile::PdbFile(const vector<PdbLine>& pdbLines_) {
  pdbLines = pdbLines_;
}
PdbFile::PdbFile(const vector<string>& pdbLines_) {
  for (vector<string>::const_iterator citerS = pdbLines_.begin();
       citerS != pdbLines_.end();
       ++citerS) {
    pdbLines.push_back(PdbLine(*citerS));
  }
}

PdbFile&
PdbFile::operator=(const PdbFile& other) {
  pdbLines = *other.getPdbLines();
  return *this;
}

const vector<PdbLine>*
PdbFile::getPdbLines() const {
  return &pdbLines;
}

void
PdbFile::removeHydrogens() {
  vector<PdbLine> _res;
  for (CiterPL citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    if (!citerPL->isHydrogen())
      _res.push_back(*citerPL);
  }
  pdbLines = _res;
}
void
PdbFile::changeResName(const string& from, const string& to) {
  for (IterPL iterPL = pdbLines.begin();
       iterPL != pdbLines.end();
       ++iterPL) {
    if (*iterPL->getResName() == from) {
      iterPL->setResName(to);
    }
  }
}
void 
PdbFile::filterAltLoc(const char altLoc_) {
  vector<PdbLine> _res;
  for (IterPL iterPL = pdbLines.begin();
       iterPL != pdbLines.end();
       ++iterPL) {
    // if no altLoc just take this PdbLine
    if (*iterPL->getAltLoc() == ' ') {
      _res.push_back(*iterPL);
    }
    // if altLoc that is required just clear and take it 
    else if (*iterPL->getAltLoc() == altLoc_) {
      iterPL->setAltLoc(' ');
      _res.push_back(*iterPL);
    }
    // remove this line, don't take in
    else {
      continue;
    }
  }
  pdbLines = _res;
}
void
PdbFile::fixResName(const string& name_) {
  bool is = false;
  for (ItPL itPL = pdbLines.begin();
            itPL !=pdbLines.end();
          ++itPL) {
    if (name_ == *itPL->getResName()) {
      ItPL _t = itPL;
      if (_t != pdbLines.begin()) { 
        --_t;
        if (*_t->getResSeq() != *itPL->getResSeq())
          ++_t;
      }
      while (*_t->getResSeq() == *itPL->getResSeq()) {
        if (*_t->getResName() != *itPL->getResName()) {
          is = true;
          itPL->setResName(*_t->getResName());  
          break;
        }
        ++_t;
      } // while loop
    } // if foun such residue
  } // for loop
  if (!is)
    changeResName(name_, "GLY");
}

void
PdbFile::getAtomCoord(vector<Vector3>& atoms_) const {
  atoms_.clear(); atoms_.reserve(pdbLines.size());
  for (CitPL citPL = pdbLines.begin();
             citPL !=pdbLines.end(); ++citPL) {
    atoms_.push_back(*citPL->getCoord());
  }
}

vector<Vector3>
PdbFile::getAtomCoord() const {
  vector<Vector3> _res;
  _res.reserve(pdbLines.size());
  for (CitPL citPL = pdbLines.begin();
       citPL != pdbLines.end(); ++citPL) {
    _res.push_back(*citPL->getCoord());
  }
  return _res;
}


Vector3
PdbFile::getCenter() const {
  float _x = 0.0f, _y = 0.0f, _z = 0.0f;
  int _n = 0;
  for (vector<PdbLine>::const_iterator citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    _x += (citerPL->getCoord())->x;
    _y += (citerPL->getCoord())->y;
    _z += (citerPL->getCoord())->z;
    ++_n;
  }
  float _1overN = (1.0f / _n);
  return Vector3((_x*_1overN), (_y*_1overN), (_z*_1overN));
}

void
PdbFile::setAtomCoord(const vector<Vector3>& atoms_) {
  assert(atoms_.size() == pdbLines.size());
  int _n = atoms_.size();
  for (int i = 0; i < _n; ++i) {
    pdbLines[i].setCoord(atoms_[i]); 
  }
}

void
PdbFile::setAtomCoord(const vector<float>& atoms_) {

  assert(atoms_.size() == pdbLines.size() *3 );
  int _n = pdbLines.size();
  
  vector<PdbLine>::iterator it = pdbLines.begin();
  vector<float>::const_iterator cit = atoms_.begin();
  float _x, _y, _z;
  for (int i = 0; i < _n; ++i) {
    _x = *cit; ++cit;
    _y = *cit; ++cit;
    _z = *cit; ++cit;
    it->setCoord(_x, _y, _z);
    ++it;
  }
}

float
PdbFile::backbRmsd(const PdbFile& pdbFile_) const {
  if (this->pdbLines.size() != pdbFile_.getPdbLines()->size()) {
    cerr << "The number of pdbLines in PdbFile objects are different. "
         << "Can't calculate RMSD." << endl;
    return 0.0f;
  }
  float _res = 0.0f;
  int _n = 0;
  
  CitPL citThis, citOther;
  for (citThis  = this->pdbLines.begin(),
       citOther = pdbFile_.getPdbLines()->begin();
       citThis  !=this->pdbLines.end(),
       citOther !=pdbFile_.getPdbLines()->end();
       ++citThis, ++citOther) {
    // maybe its too expensive to check so much (but secure:-))   
    if (*citThis->getAtom() == "CA" || *citThis->getAtom() == "C" ||
        *citThis->getAtom() == "N"  || *citThis->getAtom() == "O" ) {
      assert(*citThis->getAtom() == *citOther->getAtom());   
      float _dx = (citThis->getCoord()->x - citOther->getCoord()->x);
      float _dy = (citThis->getCoord()->y - citOther->getCoord()->y);
      float _dz = (citThis->getCoord()->z - citOther->getCoord()->z);
      _res += (_dx*_dx + _dy*_dy + _dz*_dz);
      ++_n;
    }
  } //for end
  float _1overN = 1.0f / _n;
  return sqrt(_res * _1overN);
}

int 
PdbFile::cutOffAfterRes(PdbFile& pdbFile_, int res_) {
  // first check if res_ is not too big
  if (res_ >= pdbLines.size()) 
    return -1;
  
  ++res_;
  IterPL it;
  // find iterator of first PdbLine with ++res_ resSeq
  for (IterPL _it = pdbLines.begin(); _it != pdbLines.end(); ++_it) {
    if (*_it->getResSeq() == res_) {
      it = _it;
      break;
    } 
  }
  // move the rest of the protein to pdbFile_ and cut that part
  // from this object
  vector<PdbLine>& _pdbLines = pdbFile_.accessPdbLines();
  // clear just in case the vector in 'pdbFile_' and reserve 
  // appropriate piece of space
  _pdbLines.clear();
  _pdbLines.reserve(pdbLines.end() - it);
  for (IterPL _it = it; _it != pdbLines.end(); ++_it) {
    _pdbLines.push_back(*_it);
  }
  pdbLines.erase(it, pdbLines.end());
  return 1;

}

// ==================================================================
// class PdbFileCoord -----------------------------------------------
/*
PdbFileCoord::PdbFileCoord(const vector<string>& pdbLines_) {
  for (vector<string>::const_iterator citerS = pdbLines_.begin();
       citerS != pdbLines_.end(); 
       ++citerS) {
    coord.push_back(Vector3(atof(pdbLine_.substr(31, 38).c_str()),
                            atof(pdbLine_.substr(39, 46).c_str()),
                            atof(pdbLine_.substr(47, 54).c_str()));
}
PdbFileCoord::PdbFileCoord(const PdbFileCoord& other) {
  coord = *other.getCoord();
}
PdbFileCoord&
PdbFileCoord::operator=(const PdbFileCoord& other) {
  coord = *other.getCoord();
  return *this;
}

float
PdbFileCoord::getMaxX() const {
  float _res = -9999.0f;
  

const vector<Vector3>*
PdbFileCoord::getCoord() const{
  return &coord;
}
*/

