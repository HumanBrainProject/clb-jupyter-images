//-------------------------------------------------------------------
/*! \file residue.h
    \brief Implementation of residue classes
    
    by D.M. EML Research
    V 0.3
*/
//-------------------------------------------------------------------
#ifndef RESIDUE_H
#define RESIDUE_H

#include <vector>
#include <string>
#include "vector3.h"
#include "atom_2.h"

namespace libDM_molecule {

class PdbLine;

//*******************************************************************
// RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE 
//-------------------------------------------------------------------
/*! \brief Encapsulate protein residue.

    This class stores protein residues.
*/
class Residue {
  public:
    Residue(): name(" "), resSeq(0), iCode(' '),
               _gCenter(0.0f, 0.0f, 0.0f), gCenter(0) {}
    Residue(const Residue& other);
    Residue(const vector<PdbLine>& pdbLines_);
    
    Residue& operator=(const Residue& other);
    bool operator==(const Residue& other) const;
    bool hasAtom(const Atom& atom_) const;
    bool hasAtom(const string& name_) const;
    bool isProtResidue() const;
    
    // get
    const Atom&          getAtom(const string& name_) const;
    const string&        getName() const;
          int            getResSeq() const;
          char           getICode() const;
    const vector<Atom>&  getAtoms() const;
    vector<Atom>&  accessAtoms() {return atoms;}
    const Vector3&       getCenter();

    
    void setAtoms(const vector<Atom>& atoms_);
  protected:

    Vector3       _gCenter;
    Vector3      *gCenter;
    string        name;
    int           resSeq;
    char          iCode;
    vector<Atom>  atoms;
};


//-------------------------------------------------------------------
// RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE 
//*******************************************************************

void trim2CB(Residue& res_);
void writeResidues2PDB(const string& fileName_, 
                       const vector<const Residue*>& res_);



} // namespace libDM_molecule


#endif

