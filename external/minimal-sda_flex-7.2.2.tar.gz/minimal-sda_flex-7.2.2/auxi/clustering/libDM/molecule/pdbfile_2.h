//-------------------------------------------------------------------
/*! \file pdbfile_2.h
    \brief Classes to encapsulate a pdb file.
    
    Here we have classes to encapsulate pdb files at different level
    of precision. Classes should be used depending on purpose. E. g.
    when only the coordinates of pdb file are important, ther is no 
    sense to use classes considering anything else, like e.g. 
    residues names. See class description.
*/
#ifndef PDBFILE_2_H
#define PDBFILE_2_H

#include <vector>
#include <string>
#include "vector3.h"
#include "storage.h"



namespace libDM_molecule {
  
  using std::vector;
  using std::string;
  
//*******************************************************************
// PdbLine -> classes to encapsulate pdb lines
//-------------------------------------------------------------------
/*! \brief Simple encapsulation of pdbline

  A simple class to store pdbline
  it takes everything up to coordinates like a string
  the x, y, z are float, rest is not kept here
*/
class PdbLineS1: public Storage {
  public:
    PdbLineS1(): lineTo30(""), coord(0.0f, 0.0f, 0.0f) {}
    PdbLineS1(const string& pdbLine_);
    PdbLineS1(const PdbLineS1& pdbLine_);
    PdbLineS1(Reader& reader_);
    ~PdbLineS1() {}
    
    PdbLineS1& operator=(const PdbLineS1& pdbLine_);
    bool operator==(const PdbLineS1& pdbLine_) const;
    void setCoord(const Vector3& coord_);
    const string&  getLineTo30() const;
    const Vector3& getCoord() const;
    Vector3& accessCoord();
    bool isAtom(const string& atomName_) const;
    void storageWrite(Writer& writer_);
  private:
    string lineTo30; //meens that line from pdbfile up to 30 column
    Vector3 coord;
};

//-------------------------------------------------------------------
/*! \brief Fuller encapsulation of pdbline.

  This class encapsulates the pdb line up to coordinate entry.
*/
class PdbLine {
  public:
    PdbLine(): atom(" "), altLoc(' '), resName(" "), chainID(' '),
               resSeq(0), iCode(' '), coord(0.0f, 0.0f, 0.0f) {}
    PdbLine(const string& pdbLine_);
    PdbLine(const PdbLine& other);
    PdbLine& operator=(const PdbLine& other);
    bool operator==(const PdbLine& other) const;
    
    // get
    const string*  getAtom() const;
    const char*    getAltLoc() const;
    const string*  getResName() const;
    const char*    getChainID() const;
    const int*     getResSeq() const;
    const char*    getICode() const;
    const Vector3* getCoord() const;
    // set
    void setAtom(const string& atom_);
    void setAltLoc(const char& altLoc_);
    void setResName(const string& resName_);
    void setChainID(const char& chainID_);
    void setResSeq(const int& resSeq_);
    void setICode(const char& iCode_);
    void setCoord(const Vector3& coord_);
    void setCoord(float x_, float y_, float z_);
    
    void translateMe(const Vector3& vector3_);
    bool isHydrogen() const;
    bool isBackbone() const;
    bool isSameAtom(const PdbLine& other) const;
    
  private:
    string   atom;             // 1
    char     altLoc;           // 2
    string   resName;          // 3
    char     chainID;          // 4
    int      resSeq;           // 5
    char     iCode;            // 6
    Vector3  coord;            // 7
};
//-------------------------------------------------------------------

//*******************************************************************
// PdbFile -> classes to encapsulate pdbFiles
typedef vector<PdbLine>::const_iterator CitPL;
typedef vector<PdbLine>::iterator ItPL;


/*! \brief Container for simple pdblineS1 objects.

   this container class to store pdb file in a very simple way
   it uses PdbLinesS1 which have all up to x y z in string,
   x, y, z in float and nothing else
*/
class PdbFileS1 {
  public:
    PdbFileS1() {}
    PdbFileS1(const PdbFileS1& pdbFile_);
    // takes ready vector of PdbLineS1 objects
    PdbFileS1(const vector<PdbLineS1>& pdbLines_);
    // takes vector of strings and makes PdbLineS1 from each
    PdbFileS1(const vector<string>& pdbLines_);
    PdbFileS1(Reader& reader_);
    ~PdbFileS1() {}
    
    PdbFileS1& operator=(const PdbFileS1& pdbFile_);
    bool operator==(const PdbFileS1& pdbFile_) const;
    
    void setCoord(const vector<Vector3>& coord_);
    void setPdbLines(const vector<PdbLineS1>* pdbLines_);
    void setPdbLines(const vector<string>& pdbLines_);
    void addPdbLine(const PdbLineS1* pdbLine_);
    
    const vector<PdbLineS1>* getPdbLines() const;
    vector<PdbLineS1>&       accessPdbLines();
    Vector3                  getCenter() const;
    void                     getCoord(vector<Vector3>& coord_) const;
    vector<Vector3>          getCoord() const;
    
    
    float backbRmsd(const PdbFileS1& pdbFile_) const;
    void storageWrite(Writer& writer_);
  private:
    vector<PdbLineS1> pdbLines;
};
//-------------------------------------------------------------------
/*! \brief Container for fuller pdb file.

    This container class is to store PdbLine objects, that is fully
    described pdblines up to coordinate entry.
*/
class PdbFile {
  public:
    typedef vector<PdbLine>::const_iterator CiterPL;
    typedef vector<PdbLine>::iterator IterPL;
    PdbFile() {}
    PdbFile(const PdbFile& other);
    PdbFile(const vector<string>& pdbLines_);
    PdbFile(const vector<PdbLine>& pdbLines_);
    
    PdbFile& operator=(const PdbFile& other);
    void operator+=(const PdbFile& other);
    PdbFile operator+(const PdbFile& other) const;
    // get
    const vector<PdbLine>* getPdbLines() const;
    
    void leaveAtom(const string&);
    /*! leaves only selected atom
    */
    
    /*! Removes not backbone atoms */
    void removeNonBackbone();
    /*! Removes hydrogens, that is lines where atom name starts with H, or
        where first charachter is number from 1-5 and secont is H, or
        where first and second character is number from 1-5 and third is H.
    */
    void removeHydrogens();
    /*! Selects specific altLoc and deletes the other. Also altLocation
        identifier itself is removed. It is very simple just leaves altLoc
        with specified letter 'altLoc_' every other altLoc is removed.
        Lines without any altLoc are kept of course.
    */
    void filterAltLoc(const char altLoc_ = 'A');
    /*! Changes residue name from 'from' to 'to' 
    */
    void changeResName(const string& from, const string& to);
    /*! Fixes residue name. This can be used then some atoms in residue
        for whatever reason are named differently from the others. 
        e.g. after UHBD some atoms in N terminal residue are named NTRM
        in C terminal residue CTRM. Such residues can be fixed with this 
        function.
    */
    void fixResName(const string& name_);
    
    /*! Returns all atoms as vector<Vector3> */
    vector<Vector3> getAtomCoord() const;
    void getAtomCoord(vector<Vector3>& atoms_) const;
    vector<PdbLine>& accessPdbLines() {return pdbLines;}
    Vector3 getCenter() const;
    
    void setAtomCoord(const vector<Vector3>& atoms_);
    void setAtomCoord(const vector<float>& atoms_);
    void setChainID(char chId_);
    float backbRmsd(const PdbFile& pdbFile_) const;
    
    /*! cuts PdbFile object into two pieces. from begining to 
        'res_' part stays in this object and from 'res_+1' to 
        the end is loaded into 'pdbFile_' object which comes 
        as an argument of this foo
    */
    int cutOffAfterRes(PdbFile& pdbFile_, int res_);
  private:
    vector<PdbLine> pdbLines;
};
//-------------------------------------------------------------------
//-------------------------------------------------------------------
/*! \brief Container for residue identity

    This container class is to store info from pdb line which is 
    necessary to identify the residue, namely residue name, 
    residue number, and chain id
    
*/
class PdbResidueId {
  public:
    PdbResidueId(): name(" "), numb(0), chain(' '), iCode(' ') {}
    PdbResidueId(const string& name_, int numb_, char chain_):
    name(name_), numb(numb_), chain(chain_), iCode(' ') {}
    void clear();
    bool operator==(const PdbResidueId& r_) const;
    bool operator==(const PdbLine& pdbLine_) const;
  
    string name;
    int    numb;
    char   chain;
    char   iCode;
};


//-------------------------------------------------------------------


// Fooos
void getAllLines(const char* fileName_, vector<string>& lines_);
void getAtomLines(const char* fileName_, vector<string>& lines_);
void getAtomLinesBackbone(const char* fileName_, vector<string>& lines_);
void getAtomHetLines(const char* fileName_, vector<string>& lines_);
void getAtomCoord(const char* fileName_, vector<Vector3>& coord_);
void getAtomCoordBackbone(const char* fileName_, vector<Vector3>& coord_);
void getAtomHetCoord(const char* fileName_, vector<Vector3>& coord_);
/*! Calculates the center of mass of PdbFileS1 object
    C, N, O, S, H, P elements are considered with masses from Amber:
      H = 1.008    C = 12.01
      N = 14.01    O = 16.00
      P = 30.97    S = 32.00
    returns coordinates as Vector3 object
*/
Vector3 getCenterOfMass(const PdbFileS1& pdbFile_);
/*! Calculates the center of mass of PdbFile object
    C, N, O, S, H, P elements are considered with masses from Amber:
      H = 1.008    C = 12.01
      N = 14.01    O = 16.00
      P = 30.97    S = 32.00
    returns coordinates as Vector3 object
*/
Vector3 getCenterOfMass(const PdbFile& pdbFile_);


/*! Translates the PdbFileS1 object by adding vector to each coordinate.
      tr_ -> translation vector
      pdbFile_ -> PdbFileS1 object to translate
*/
void translateMolecule(const Vector3& tr_, PdbFileS1& pdbFile_);
/*! Writes PdbFileS1 object to pdb file */
void writePdbFileS1(const char* fileName_, const PdbFileS1& pdbFile_);
/*! Writes PdbFile object to pdb file */
void writePdbFile(const char* fileName_, const PdbFile& pdbFile_);
/*! makes a pdb string form pdbLineS1 */
string pdbLineS1ToString(const PdbLineS1& pdbLineS1_);
/*! */
float advancedBackboneRmsd(const PdbFile& pf1_, const PdbFile& pf2_);
/*! */
void changeResidueName(PdbFile& pf_, const string& from_, const string& to_);

} // namespace libDM_molecule



#endif
