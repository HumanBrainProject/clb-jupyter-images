//-----------------------------------------------------------//
// protein.cpp                                               //
//                                                           //
// Builds a protein from FullPdb object. Protein, Residues,  //
// and Atoms are implemented via aggregation of respective   //
// objects:                                                  //
//  Protein <>--- Residue <>--- Atom                         //
//                                                           //
// Version: 2nd Generation 2005.04.23                        //
//-----------------------------------------------------------//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <cassert>
#include <cmath>

#include "protein.h"
#include "residue.h"
#include "atom.h"
#include "fullpdb.h"
#include "pdbline.h"
#include "../constdata/constdata.h"
#include "../constdata/commonfoo.h"
#include "../3d/vector3.h"

using namespace std;

//---inlines--->
inline void stripString(string& s_){
	const string from = " ";
	const string to = "";
	size_t search_here = 0;
	size_t found_here;
	while ((found_here = s_.find(from, search_here)) != string::npos){
		s_.replace(found_here, 1, to);
		search_here = found_here;
	}
}
//===class===>
// constructor
Protein::Protein(){
	clear();
}
Protein::Protein(FullPdb& fp){
	makeResidues(fp);
}
//Protein::Protein(vector<string>& pdb_lines){
//	makeResidues(pdb_lines);
//}
void Protein::who(){
	cout << "INFO: class Protein" << endl;
}
void Protein::clear(){
// clear data mambers and state
	name = "";
	residues.clear();
	chains.clear();
	sAResidues.clear();
	clearState();
}
//---methods--->
void Protein::translateMe(Vector3& v3_){
	for (iterR = residues.begin();
	     iterR !=residues.end();
	     ++iterR){
	     	iterR->translateMe(v3_);
	}
}
void Protein::makeResidues(FullPdb& fp_){
// makes residues and filles vector<Residue>
	vector<PdbLine*> _res;
	// doesn't work with old compiler!!!
	//size_t _st;
	//_res.reserve( (_st * 25));
	_i = 0;

	iterVP = fp_.pdbLines.begin();
	Chain _x;
	_x.chainID = *iterVP->getChainID();
	_x.from = 0;
	assert(_res.empty());
	for (iterVP = fp_.pdbLines.begin();
	     iterVP !=fp_.pdbLines.end();
	     ++iterVP){
		if (_res.empty() ||
		    iterVP->isSameRes(*_res.back())){
			_res.push_back(&(*iterVP));
		}
		else{
			residues.push_back(Residue(_res));
			++_i;
			if (*iterVP->getChainID() != _x.chainID){
				_x.to = _i;
				chains.push_back(_x);
				_x.chainID = *iterVP->getChainID();
				_x.from = _i;
				}
			_res.clear();
			_res.push_back(&(*iterVP));
	     	}
	}
	residues.push_back(Residue(_res));
	_res.clear();
	state.empty = false;
	++_i;
	assert(_i == residues.size());
	_x.to = _i;
	chains.push_back(_x);
}
	

bool Protein::isResidue(string& nam_, int num_, char cH_){
// checks if the residue with nam_in and num_in is in this protein
	for (citerVC = chains.begin();
	     citerVC !=chains.end();
	     ++citerVC){
	     	if (citerVC->chainID != cH_){
			continue;
		}
		for (int i = citerVC->from;
		     i < citerVC->to;
		     ++i){
			if (residues[i].resName == nam_ &&
			    residues[i].resSeq  == num_){
				return true;
			}
		}
	}
	return false;
}

const Residue* Protein::getResidue(string& nam_, int num_, char cH_){
// returns a pointer to residue instance
	for (citerVC = chains.begin();
	     citerVC !=chains.end();
	     ++citerVC){
	     	if (citerVC->chainID != cH_){
			continue;
		}
		for (size_t i = citerVC->from;
		     i < citerVC->to;
		     ++i){
			if (residues[i].resName == nam_ &&
			    residues[i].resSeq  == num_){
				return &residues[i];
			}
		}
	}
	const Residue* _x = NULL;
	return _x;
}

void Protein::setName(const string& name_){
// sets the name of protein object instance if you want:-)
	name = name_;
}

void Protein::makeResAccRel(const vector<string>& rsaLines_){
// finds residues with SA > ACCESS_THR in vector of rsa file RES lines
// and makes sAResidues vector with pointers to SA residues.
	_f = 0.0f;
	vector<const Residue*> _tmp;
	_tmp.reserve(residues.size());
	assert(rsaLines_.size() == residues.size());
	vector<string>::const_iterator citerVS;
	citerVS = rsaLines_.begin();
	for (citerVR = residues.begin();
	     citerVR !=residues.end();
	     ++citerVR){
		_f = atof((citerVS->substr(23, 5).c_str()));
		if (_f > ACCESS_THR){
			_tmp.push_back(&(*citerVR));
		}
		++citerVS;
	}
	sAResidues = _tmp;
}

const Protein::Chain* Protein::getChain(char chainID_){
// returns pointer to appropriate Chain structure
	for (citerVC = chains.begin();
	     citerVC !=chains.end();
	     ++citerVC){
		if (citerVC->chainID == chainID_){
			return &(*citerVC);
		}
	}
	Chain* x = NULL;
	return x;
}

void Protein::clearState(){
// use this to clear all needed stuff in state
	state.empty = true;
}

float Protein::backbRmsd(const Protein* prot_){
// calculates backbone rmsd between to Protein objects
// ! more checks may be needed
	if (this->residues.size() != prot_->residues.size()){
		cout << "Proteins have different number of residues!!!" << endl;
		exit(1);
	}
	float _res = 0.0f;
	int   _n   = 0;
	vector<Residue>::const_iterator citerR1, citerR2;
	vector<Atom>::const_iterator    citerA1, citerA2;
	// for each residue in Protein 1 and Protein 2
	for (citerR1 = this->residues.begin(),
	     citerR2 = prot_->residues.begin();
	     citerR1 !=this->residues.end(),
	     citerR2 !=prot_->residues.end();
	     ++citerR1, ++citerR2){
		assert(citerR1->isSameResidue(&(*citerR2)));
		// for each atom in Residue 1 and Residue 2
		for (citerA1 = citerR1->atoms.begin(),
		     citerA2 = citerR2->atoms.begin();
		     citerA1 !=citerR1->atoms.end(),
		     citerA2 !=citerR2->atoms.end();
		     ++citerA1, ++citerA2){
		     // is atom a backbone atom?
			if (citerA1->isBackbone() &&
			    citerA2->isBackbone()){
		// calculate (x1-x2)^2+(y1-y2)^2+(z1-z2)^2
		++_n;
		float dx = (citerA1->coor.x - citerA2->coor.x);
		float dy = (citerA1->coor.y - citerA2->coor.y);
		float dz = (citerA1->coor.z - citerA2->coor.z);
		_res += (dx*dx + dy*dy + dz*dz);
			}
		}

	}
	// calculate rmsd
	float _1n = 1.0f / _n;
	return sqrt(_res * _1n);
}

Vector3 Protein::getCenter() const {
	float _x = 0.0f, _y = 0.0f, _z = 0.0f;
	int _n = 0;
	vector<Residue>::const_iterator citerVR;
	vector<Atom>::const_iterator citerVA;
	for (citerVR = residues.begin();
	     citerVR !=residues.end();
	     ++citerVR){
		for (citerVA = citerVR->atoms.begin();
		     citerVA !=citerVR->atoms.end();
		     ++citerVA){
			_x += citerVA->coor.x;
			_y += citerVA->coor.y;
			_z += citerVA->coor.z;
			++_n;
		}
	}
	float _1n = ( 1.0f / _n);
	Vector3 _res((_x*_1n), (_y*_1n), (_z*_1n));
	//cout << "Protein" << endl;
	//cout << "x " << _res.x << endl;
	//cout << "y " << _res.y << endl;
	//cout << "z " << _res.z << endl;
	//cout << "========" << endl;
  	return _res;
}

float Protein::getMax(char xyz_) const{
// returns particular max coordinate of protein
	float _max = -9999.0f;
	float _tmp = 0.0f;
	vector<Residue>::const_iterator citerVR;
	for (citerVR = residues.begin();
	     citerVR !=residues.end();
	     ++citerVR){
		_tmp = citerVR->getMax(xyz_);
		if (_tmp > _max)
			_max = _tmp;
	}
	return _max;
}

float Protein::getMin(char xyz_) const{
// returns particular min coordinate of protein
	float _min = 9999.0f;
	float _tmp = 0.0f;
	vector<Residue>::const_iterator citerVR;
	for (citerVR = residues.begin();
	     citerVR !=residues.end();
	     ++citerVR){
		_tmp = citerVR->getMin(xyz_);
		if (_tmp < _min)
			_min = _tmp;
	}
	return _min;
}


