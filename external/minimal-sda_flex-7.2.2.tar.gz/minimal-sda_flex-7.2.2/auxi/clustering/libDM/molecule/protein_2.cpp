//-------------------------------------------------------------------
/*! \file protein.cpp


    by D.M. EML Research
    V0.3 2006.01.19
*/
//-------------------------------------------------------------------

#include <string>
#include <vector>
#include <iomanip>
#include <iostream>

#include "protein_2.h"
#include "residue_2.h"
#include "atom_2.h"
#include "pdbfile_2.h"
#include "vector3.h"


namespace libDM_molecule {



// Chain------------------------------------------------------------
/*! \brief Constructs Chain from vector of PdbLine objects. 
    
    First '_checkRes' takes a pointer to first PdbLine in 'pdbLines_', 
    also an empty vector<PdbLine> '_res' is created. Then it iterates over 
    all 'pdbLines_' and at every step adds PdbLine object to temporary
    '_res' and checks if it is still the same residue as in first 
    element of 'pdbLines_', namely '_checkRes'. Once different residue 
    is found, Residue object is created from current content of '_res' 
    and added to Chain member 'residues'. Then '_res' is cleared and 
    '_checkRes' is now pointed to new current PdbLine and used further 
    for checking of residue. At the end of cycle the last Residue object 
    is created from '_res' and added to 'residues' member.
*/
Chain::Chain(const vector<PdbLine>& pdbLines_) {
  name = *pdbLines_.begin()->getChainID();
  const PdbLine* _checkRes = &(*pdbLines_.begin());
  vector<PdbLine> _res;
  for (PdbFile::CiterPL citerPL = pdbLines_.begin();
                        citerPL !=pdbLines_.end();
                      ++citerPL) {
    if (*_checkRes->getResSeq()  == *citerPL->getResSeq() &&
        *_checkRes->getResName() == *citerPL->getResName()) {
      _res.push_back(*citerPL);
    }
    else {
      residues.push_back(Residue(_res));
      _res.clear();
      _res.push_back(*citerPL);
      _checkRes = &(*citerPL);
    }
  }
  residues.push_back(Residue(_res));
}
Chain::Chain(const Chain& other) {
  name     = other.getName();
  residues = other.getResidues();
}
Chain&
Chain::operator=(const Chain& other) {
  name     = other.getName();
  residues = other.getResidues();
  *this;
}  
bool
Chain::operator==(const Chain& other) const {
  if (residues.size() != other.getResidues().size())
    return false;
  for (CiterR citerR = other.getResidues().begin();
              citerR !=other.getResidues().end();
            ++citerR) {
    if (!hasResidue(*citerR))
      return false;
  }
  return true;
}
bool
Chain::hasResidue(const Residue& residue_) const {
  for (CiterR citerR = residues.begin();
              citerR !=residues.end();
            ++citerR) {
    if (*citerR == residue_)
      return true;
  }
  return false;
}
const char&
Chain::getName() const {
  return name;
}
const vector<Residue>&
Chain::getResidues() const {
  return residues;
}
vector<Residue>&
Chain::accessResidues() {
  return residues;
}
// Protein------------------------------------------------------------
/*! Iterates over 'pdbLines_' and pushes all lines to a new temporary
    vector of PdbLine objects, at the end creates a Chain and adds to
    chains vector data member. If during the iteration chain change 
    is detected then current Chain object is added to 'chains' and 
    new vector of PdbLine for new chain is being built.
*/
Protein::Protein(const vector<PdbLine>& pdbLines_, const string& name_) {
  name = name_;
  vector<PdbLine> _res;
  char _chain = *pdbLines_.begin()->getChainID();
  for (PdbFile::CiterPL citerPL = pdbLines_.begin();
       citerPL != pdbLines_.end();
       ++citerPL) {
    if (*citerPL->getChainID() == _chain) {
      _res.push_back(*citerPL);
    }
    else {
      chains.push_back(_res);
      _res.clear();
      _chain = *citerPL->getChainID();
      _res.push_back(*citerPL);
    }
  }
  chains.push_back(_res);
}
Protein::Protein(const PdbFile& pdbFile_, const string& name_) {
  *this = Protein(*pdbFile_.getPdbLines());
}
Protein::Protein(const Protein& other) {
  name   = other.getName();
  chains = other.getChains();
}
Protein&
Protein::operator=(const Protein& other) {
  name   = other.getName();
  chains = other.getChains();
  return *this;
}
bool
Protein::operator==(const Protein& other) const {
  if (chains.size() != other.getChains().size())
    return false;
  for (CiterC citerC = other.getChains().begin();
              citerC !=other.getChains().end();
            ++citerC) {
    if (!hasChain(*citerC))
      return false;
  }
  return true;
}  
bool
Protein::hasChain(const Chain& chain_) const {
  for (CiterC citerC = chains.begin();
              citerC !=chains.end();
            ++citerC) {
    if (*citerC == chain_)
     return true;
  }
  return false;
}

int
Protein::getResNumb() const {
  int n = 0;
  for (vector<Chain>::const_iterator cit = chains.begin();
       cit != chains.end(); ++cit) {
    n += cit->getResidues().size();
  }
  return n;
}

const string&
Protein::getName() const {
  return name;
}
const vector<Chain>&
Protein::getChains() const {
  return chains;
}
vector<Chain>&
Protein::accessChains() {
  return chains;
}
void
Protein::accessCoord(vector<Vector3*>& coord_) {
  for (IterC itC = accessChains().begin(); itC != accessChains().end();
       ++itC) {
    for (IterR itR = itC->accessResidues().begin();
         itR != itC->accessResidues().end();
         ++itR) {
      for (IterA itA = itR->accessAtoms().begin();
           itA != itR->accessAtoms().end();
           ++itA) {
        coord_.push_back(&itA->accessCoord());  
      }
    }
  }
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//- Foos ------------------------------------------------------------

/*! makes vector of Residue objects from vector of PdbLine objects */
void pdbLines2Residues(const vector<PdbLine>& pdbLines, 
                             vector<Residue>& residues) {
  vector<PdbLine> _pl;
  string _resName = *pdbLines.begin()->getResName();
  int    _resSeq  = *pdbLines.begin()->getResSeq();
  char   _chainID = *pdbLines.begin()->getChainID();
  char   _iCode   = *pdbLines.begin()->getICode();
  for (vector<PdbLine>::const_iterator cit = pdbLines.begin();
       cit != pdbLines.end(); ++cit) {
    if (*cit->getResName() == _resName and
        *cit->getResSeq()  == _resSeq  and
        *cit->getChainID() == _chainID and
        *cit->getICode()   == _iCode) {
      _pl.push_back(*cit);
    }
    else {
      residues.push_back(Residue(_pl));
      _pl.clear();
      _resName = *cit->getResName();
      _resSeq  = *cit->getResSeq();
      _chainID = *cit->getChainID();
      _iCode   = *cit->getICode();
      _pl.push_back(*cit);
    }
  }
  residues.push_back(Residue(_pl));
}
  
/*! makes vector of Residue objects from PdbFile object */
void pdbFile2Residues(const PdbFile& pdbFile, 
                            vector<Residue>& residues) {
  libDM_molecule::pdbLines2Residues(*pdbFile.getPdbLines(), residues);
}                            
 

void
writeProtein2PDB(const string& fileName_, const Protein& p_) {
  
  ofstream fou;
  fou.open(fileName_.c_str());
  if (!fou.is_open()) {
    cout << "WARNING: can't open file " << fileName_ 
         << " for writing." << endl;
    return;
  }
  int n = 1;
  for (vector<Chain>::const_iterator citC = p_.getChains().begin();
       citC != p_.getChains().end(); ++citC) {
    for (vector<Residue>::const_iterator citR = citC->getResidues().begin();
         citR != citC->getResidues().end(); ++citR) {
      for (vector<Atom>::const_iterator citA = citR->getAtoms().begin();
           citA != citR->getAtoms().end(); ++citA) {
        fou << "ATOM  ";
        fou << setw(5) << setiosflags(ios::right) << n << " "
            << (citA->getName().size() < 3 ?
               (citA->getName().size() > 1 ?
                " "+citA->getName()+" "    :
                " "+citA->getName()+"  ")  :
               (citA->getName().size() == 4?
                citA->getName() : " "+citA->getName()))
            << " "
            << citR->getName()
            << " "
            << citC->getName()
            << setw(4)
            << citR->getResSeq()
            << "    ";
        fou.setf(ios::fixed, ios::floatfield);
        fou << setprecision(3)
            << setw(8) << citA->getCoord().x
            << setw(8) << citA->getCoord().y
            << setw(8) << citA->getCoord().z
            << endl;  
            ++n;                  
      } // atom
    } // residue
    fou << "TER" << endl;
  } // chain
  fou << "END" << endl;
  fou.close();

}

  


} // namespace libDM_molecule

