//-----------
// fullpdb.h
//-----------
#ifndef FULLPDB_H
#define FULLPDB_H

#include <vector>
#include "pdbline.h"
using namespace std;
class Vector3;

class FullPdb{
		struct State{
			bool hydrogens;
			bool altLoc;
			bool empty;
			bool emptyLines;
		};
	public:
		FullPdb();
		FullPdb(vector<string>&);
	// maintain
		void who() const;
		void init();
		void clear();
	//---methods--->
		void translateMe(const Vector3&);
		void makePdbLines(const vector<string>&);
		void removeAltLoc(char aloc_ = 'B');
		void shiftICode();
		bool removeHydrogens();
		void fixTerminalRes(const string&);
		void fixResidueNames(const string&, const string&);
	// get
		Vector3 getCenter() const;
	// is?
		bool areHydrogens();
		bool isAltLoc();
		bool isICode();
	//---members--->
		vector<PdbLine> pdbLines;
		State state;
	// operators
		FullPdb& operator=(FullPdb&);
		bool operator==(FullPdb&);
	private:
	//---methods--->
		void removeEmptyPdbLines();
		void findChains();
		const PdbLine* findSameResUnnamed(PdbLine*) const;
	//---members--->
		// !!! update these before you use
		vector<char> chains;
		vector<int> chainBegin;
		vector<int> chainEnd;
	// iterators
		vector<string>::iterator  iterVS;
		vector<PdbLine>::iterator iterVP;
	// tmp
		string _str;
		int _i;
		char _ch;
};


// HOW TO ------------------------------------------------------------
// example of loading pdb to FullPdb object
//
// fp = new FullPdb;
// fp->makePdbLines(pdblines());	fead "ATOM" lines to object
// fp->removeAltLoc();			remove alt locations
// fp->fixTerminalRes("CTR");		fixing res after e.g. SDA
// fp->removeHydrogens();
// fp->fixResidueNames("CYX", "CYS");	fix funny residue names
//--------------------------------------------------------------------

#endif


