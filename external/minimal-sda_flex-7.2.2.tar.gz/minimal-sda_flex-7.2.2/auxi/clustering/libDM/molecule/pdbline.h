//-------------------------------------------------------------------
/*! \file pdbline.h
    \brief Classes to encapsulate a pdb line.
    
    Here we have classes to encapsulate pdb line at different level
    of precision. Classes should be used depending on purpose. E. g.
    when only the coordinates of pdb file are important, ther is no 
    sense to use classes considering anything else, like e.g. 
    residues names. See class description.
*/
#ifndef PDBLINE_H
#define PDBLINE_H

#include <vector>
#include <string>

#include "../3d/vector3.h"
#include "../common/storage.h"
using namespace std;

//-------------------------------------------------------------------
/*! \brief Simple encapsulation of pdbline

  A simple class to store pdbline
  it takes everything up to coordinates like a string
  the x, y, z are float, rest is not kept here
*/
class PdbLineS1: public Storage {
  public:
    PdbLineS1(): lineTo30(""), coord(0.0f, 0.0f, 0.0f) {}
    PdbLineS1(const string& pdbLine_);
    PdbLineS1(const PdbLineS1& pdbLine_);
    PdbLineS1(Reader& reader_);
    ~PdbLineS1() {}
    
    PdbLineS1& operator=(const PdbLineS1& pdbLine_);
    bool operator==(const PdbLineS1& pdbLine_) const;
    void setCoord(const Vector3& coord_);
    const string&  getLineTo30() const;
    const Vector3& getCoord() const;
    Vector3& accessCoord();
    bool  checkAtom(const PdbLineS1& line) const;
    bool isAtom(const string& atomName_) const;
    void storageWrite(Writer& writer_);
    bool isBackbone;
  private:
    string lineTo30; //meens that line from pdbfile up to 30 column
    Vector3 coord;
};

//-------------------------------------------------------------------
/*! \brief Fuller encapsulation of pdbline.

  This class encapsulates the pdb line up to coordinate entry.
*/
class PdbLine {
  public:
    PdbLine(): atom(" "), altLoc(' '), resName(" "), chainID(' '),
               resSeq(0), iCode(' '), coord(0.0f, 0.0f, 0.0f) {}
    PdbLine(const string& pdbLine_);
    PdbLine(const PdbLine& other);
    PdbLine& operator=(const PdbLine& other);
    bool operator==(const PdbLine& other) const;
    
    // get
    const string*  getAtom() const;
    const char*    getAltLoc() const;
    const string*  getResName() const;
    const char*    getChainID() const;
    const int*     getResSeq() const;
    const char*    getICode() const;
    const Vector3* getCoord() const;
    // set
    void setAtom(const string& atom_);
    void setAltLoc(const char& altLoc_);
    void setResName(const string& resName_);
    void setChainID(const char& chainID_);
    void setResSeq(const int& resSeq_);
    void setICode(const char& iCode_);
    void setCoord(const Vector3& coord_);
    void setCoord(float x_, float y_, float z_);
    
    void translateMe(const Vector3& vector3_);
    bool isHydrogen() const;
  private:
    string   atom;             // 1
    char     altLoc;           // 2
    string   resName;          // 3
    char     chainID;          // 4
    int      resSeq;           // 5
    char     iCode;            // 6
    Vector3  coord;            // 7
};
//-------------------------------------------------------------------
#endif


