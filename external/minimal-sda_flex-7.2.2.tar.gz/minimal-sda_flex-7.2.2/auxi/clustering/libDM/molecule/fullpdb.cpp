//-----------------------------------------------------------//
// fullpdb.cpp                                               //
//                                                           //
// This is to load store manipulate pdb file.                //
// It loads pdb by encapsulating each line into PdbLine      //
// objects and stores these objects in vector<PdbLine>.      //
// So generaly the idea is to load pdb into this object,     //
// manipulate appropriately and then pass this object to     //
// some other like Protein class                             //
//                                                           //
// Version: 2n Generation 2005.04.22                         //
// D.M.                                                      //
//-----------------------------------------------------------//
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cassert>

#include "fullpdb.h"
#include "pdbline.h"
#include "../constdata/constdata.h"

using namespace std;


//===class===>
FullPdb::FullPdb(){
	init();
}
FullPdb::FullPdb(vector<string>& pdbLines_){
	init();
	makePdbLines(pdbLines_);
}
// maintain
void FullPdb::who() const{
	cout << "INFO: class FullPdb" << endl;
}

void FullPdb::init(){
	state.empty 	= true;
}

void FullPdb::clear(){
	pdbLines.clear();
	init();
}
//---methods--->
void FullPdb::translateMe(const Vector3& v3_){
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		iterVP->translateMe(v3_);
	}
}
void FullPdb::makePdbLines(const vector<string>& pdbLines_){
// main foo to fill this object with PdbLine objects
// from vector of pdb line strings
	vector<string>::const_iterator citerVS;
	pdbLines.reserve(pdbLines_.size());
	for (citerVS = pdbLines_.begin();
	     citerVS !=pdbLines_.end();
	     ++citerVS){
	     pdbLines.push_back(PdbLine (*citerVS));
	}
	state.empty = false;
}

void FullPdb::removeAltLoc(char altLoc_){
// removes alternative locations, ('B' by default)
// first it clears pdbline objects with B alt location
// then makes new vector<PdbLine>
	// for each chain
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		if (*iterVP->getAltLoc() != CHOLD1){
			if (*iterVP->getAltLoc() == altLoc_){
				iterVP->clear();
				state.emptyLines = true;
			}
			iterVP->setAltLoc();
		}
	}
	removeEmptyPdbLines();
	state.altLoc = false;

}

void FullPdb::shiftICode(){
// this removes insertions and shifts the residue
// numbers accordingly
	// call this befor to gather data about chains, !!! always call it befor
	// doing something since chains info may have been changed due to smth.
	findChains();
	_i = 0;
	vector<int> _labels;
	// for each chain
	for (int i = 0; i < chains.size(); ++i){
		// for each line in chain
		for (int j = chainBegin[i]; j < chainEnd[i]; ++j){
			// if there is an iCode
			if (*pdbLines[j].getICode() != HOLD1){
				pdbLines[j].setICode(); // rmv it
				if (_labels.empty()){
					_labels.push_back(j);
					_i = j;
				}
				else if (pdbLines[j].isSameICode(pdbLines[_i])){
					_labels.pop_back();
					_labels.push_back(j);
				}
				else if (!pdbLines[j].isSameICode(pdbLines[_i])){
					_labels.push_back(j);
					_i = j;
				}
				else{
					cerr << "WARNING: You should not be here!" << endl;
				}
			}
		}
	if (!_labels.empty()){
	// shifts up residue numbers where needed
		for (int k = 0; k < _labels.size(); ++k){
			for (int l = _labels[k]+1; l < pdbLines.size(); ++l){
				pdbLines[l].setResSeq(*pdbLines[l].getResSeq()+1);
			}
		}
	}
	_labels.clear();
	}
}

bool FullPdb::removeHydrogens(){
//
	if (!areHydrogens())
		return false;
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		if (iterVP->isHydrogen())
			iterVP->clear();
	}
	removeEmptyPdbLines();
	state.hydrogens = false;
	return true;
}

void FullPdb::fixTerminalRes(const string& resName_) {
// fix terminal residues like NTRM, CTRM
	if (state.empty){
		cerr << "WARNING: this object is empty." << endl;
		return;
	}
	const PdbLine* _pl;
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		if (*iterVP->getResName() == resName_){
			 _pl = findSameResUnnamed(&(*iterVP));
			if (_pl != NULL){
				cout << *_pl->getResName() << endl;
				iterVP->setResName(_pl->getResName());
				iterVP->setICode(_pl->getICode());
			}else{
				iterVP->setResName(&AAA[12]);
			}
		}

	}

}
void FullPdb::fixResidueNames(const string& from_, const string& to_){
// fix some residue names like HID, HIE to HIS
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		if (*iterVP->getResName() == from_){
		iterVP->setResName(&to_);
		}
	}
}
// get
Vector3 FullPdb::getCenter() const {
	float _x = 0.0f, _y = 0.0f, _z = 0.0f;
	float _n = 1.0f / pdbLines.size();
	vector<PdbLine>::const_iterator citerVPL;
	for (citerVPL = pdbLines.begin();
	     citerVPL !=pdbLines.end();
	     ++citerVPL){
		_x += citerVPL->coor.x;
		_y += citerVPL->coor.y;
		_z += citerVPL->coor.z;
	}
	Vector3 _res((_x*_n), (_y*_n), (_z*_n));
	return _res;
}
// is?
bool FullPdb::areHydrogens() {
// are there hydrogens?
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
        	if (iterVP->isHydrogen()){
			state.hydrogens = true;
			return true;
		}
	}
	state.hydrogens = false;
	return false;
}

bool FullPdb::isAltLoc(){
// is there some alternative location in pdb
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
        	if (*iterVP->getAltLoc() != CHOLD1)
				return true;
	}
	return false;
}

bool FullPdb::isICode(){
// is there insertion codes in pdb
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		if (*iterVP->getICode() != CHOLD1)
				return true;
	}
	return false;
}

//---private methods--->
void FullPdb::removeEmptyPdbLines(){
// creates new vector<PdbLine> without empty line and
// replaces old vector<PdbLine>
	vector<PdbLine> _result;
	_result.reserve(pdbLines.size());
	for (iterVP = pdbLines.begin();
	     iterVP !=pdbLines.end();
	     ++iterVP){
		if (!iterVP->empty())
			_result.push_back(*iterVP);
	}
	pdbLines.clear();
	pdbLines = _result;
}

void FullPdb::findChains(){
// finds chains and filles vector chains with chainID's
// chainBegin with start indixes chianEnd end indexes of chains in pdbLines
	chains.clear();
	chainBegin.clear();
	chainEnd.clear();
	_i = 0;
	_ch = *pdbLines.begin()->getChainID();
	chains.push_back(_ch);
	chainBegin.push_back(_i);
	for (int i = 0; i < pdbLines.size(); ++i){
		++_i;
		if (*pdbLines[i].getChainID() != _ch){
			chains.push_back(*pdbLines[i].getChainID());
			chainEnd.push_back(i);
			chainBegin.push_back(i);
			_ch = *pdbLines[i].getChainID();
		}
	}
	chainEnd.push_back(pdbLines.size());
}

const PdbLine* FullPdb::findSameResUnnamed(PdbLine* pdbLine_) const{
// finds PdbLine fo residue with same number in same chain but different name
// if not found returns NULL pointer
	vector<PdbLine>::const_iterator citerVP;
	for (citerVP = pdbLines.begin();
	     citerVP !=pdbLines.end();
	     ++citerVP){
		if ( (pdbLine_->getResSeq()  == citerVP->getResSeq()) &&
		     (pdbLine_->getChainID() == citerVP->getChainID())&&
		     (pdbLine_->getResName() != citerVP->getResName()) )
			return &(*citerVP);
	}
	return NULL;
}

//===class===/



