//-------------------------------------------------------------------
/*! \file atom.cpp
    \brief Implementation of atom classes
    
    by D.M. EML Research
    V 0.3
*/
//-------------------------------------------------------------------

#include <iostream>
#include <vector>
#include <algorithm>
#include <cassert>

#include "atom.h"
#include "pdbline.h"

// BasicAtom--------------------------------------------------------
BasicAtom::BasicAtom(const BasicAtom& other) {
  coord = other.getCoord();
}
const Vector3&
BasicAtom::getCoord() const {
  return coord;
}
BasicAtom&
BasicAtom::operator=(const BasicAtom& other) {
  coord = other.getCoord();
  return *this;
}
bool
BasicAtom::operator==(const BasicAtom& other) const {
  if (coord == other.coord)
    return true;
  return false;
}
// Atom-------------------------------------------------------------
// constructor
Atom::Atom(const PdbLine& pdbLine_): BasicAtom(*pdbLine_.getCoord()) {
  /*who();*/
  altLoc = *pdbLine_.getAltLoc();
  name   = *pdbLine_.getAtom();
}

Atom::Atom(const Atom& other): BasicAtom(other.getCoord()) { 
  /*who();*/
  altLoc = other.getAltLoc();
  name   = other.getName();
}

// operator
Atom&
Atom::operator=(const Atom& other) { 
  BasicAtom(other.getCoord());
  altLoc = other.getAltLoc();
  name   = other.getName();
  return *this;
}

bool
Atom::operator==(const Atom& other) const {
  if (altLoc == other.getAltLoc() &&
      name   == other.getName() &&
      coord  == other.getCoord()) 
    return true;
  return false;
}

// get
char 
Atom::getAltLoc() const {
  return altLoc;
}
const string&
Atom::getName() const {
  return name;
}

// AtomAcc-----------------------------------------------------------



/* moved to vector3.h

// ---
float vector3Rmsd(const vector<Vector3>& v1_, 
                  const vector<Vector3>& v2_) {
  vector<Vector3>::const_iterator citV1, citV2;
  assert(v1_.size() == v2_.size());
  float dx, dy, dz, _res;
  unsigned int n = 0;
  for (citV1 = v1_.begin(), citV2 = v2_.begin();
       citV1 !=v1_.end(), citV2 !=v2_.end();
       ++citV1, ++citV2) {
    dx = citV1->x - citV2->x;
    dy = citV1->y - citV2->y;
    dz = citV1->z - citV2-> z;
    _res += (dx * dx + dy * dy + dz * dz);
    ++n;
  }
  float _1overN = 1.0f / n;
  return sqrt(_res * _1overN);
}

Vector3 vector3Center(const vector<Vector3>& v_) {
  float x = 0.0f, y = 0.0f, z = 0.0f;
  unsigned int n = 0;
  for (vector<Vector3>::const_iterator citV = v_.begin();
       citV != v_.end(); ++citV) {
    x += citV->x;
    y += citV->y;
    z += citV->z;
    ++n;
  }
  float _1overN = 1.0f / n;
  return Vector3(x * _1overN, y * _1overN, z * _1overN);
}
*/
/* old atom
//---functions--->
//---statics--->
//===class===>
Atom::Atom(PdbLine* pl_){
	atom = *pl_->getAtom();
	makeAltLoc(pl_->getAltLoc());
	coor = *pl_->getCoor();
 }
 
void Atom::who(){
	cout << "INFO: class Atom" << endl;
}

bool Atom::isBackbone() const{
	if (atom == "C" ||
	    atom == "N" ||
	    atom == "O" ||
	    atom == "CA")
		return true;
	return false;
}

void Atom::makeAltLoc(const char* altLoc_in){
// if no AltLoc then just point to CHOLD1 	in constdata.h
	if (*altLoc_in == CHOLD1){
		altLoc = &CHOLD1;
	}else{
		_altLoc = *altLoc_in;
		altLoc = &_altLoc;
	}
}

*/

