//-------------------------------------------------------------------
/*! \file molgrid.cpp
    \brief Stuff to put molecules in grids
    
    by D.M. 2006.03 EML Research
    V 0.01
*/
#include <iostream>
#include <vector>
#include <cassert>
#include <string>

#include "vector3.h"
#include "mymath.h"
#include "molgrid.h"
#include "qtable_2.h"
#include "pdbfile_2.h"

using  libDM_molecule::PdbFile;
using  libDM_molecule::PdbLine;
using namespace std;

inline void stripString(string& s_in) {
  const string from = " ";
  const string to = "";
  unsigned int search_here = 0;
  unsigned int found_here;
  while ((found_here = s_in.find(from, search_here)) != string::npos){
    s_in.replace(found_here, 1, to);
    search_here = found_here;
  }
}
//*******************************************************************
//_________________MolGrid___________________________________________
MolGrid::MolGrid(Uint size_) {

  x = new float[size_];
  y = new float[size_];
  z = new float[size_];
  i = new Uint[size_];
  atomNumb = size_;
  maxX=maxY=maxZ=minX=minY=minZ=0.0f;
  iSize=jSize=kSize=ijSize=ijkSize=0;
  //cout << "MolGrid constructor" << endl;
}

MolGrid::~MolGrid() {
  delete[] x;
  delete[] y;
  delete[] z;
  delete[] i;
  //cout << "MolGrid destructor" << endl;
}

void
MolGrid::loadCoord(const PdbFile& pdbFile_) {
  const vector<PdbLine>* _pdbLines = pdbFile_.getPdbLines();
  assert(_pdbLines->size() == atomNumb);
  vector<PdbLine>::const_iterator cit = _pdbLines->begin();
  for (Uint i = 0; i < atomNumb; ++i) {
    x[i] = cit->getCoord()->x;
    y[i] = cit->getCoord()->y;
    z[i] = cit->getCoord()->z;
    ++cit;
  }
  // also calculate min max x y z
  maxX = libDM_math::getMax(x, atomNumb);
  maxY = libDM_math::getMax(y, atomNumb);
  maxZ = libDM_math::getMax(z, atomNumb);
  minX = libDM_math::getMin(x, atomNumb);
  minY = libDM_math::getMin(y, atomNumb);
  minZ = libDM_math::getMin(z, atomNumb);
}

void
MolGrid::loadCoord(const vector<Vector3>& coord) {
  assert(coord.size() == atomNumb);
  
  for (Uint i = 0; i < atomNumb; ++i) {
    x[i] = coord[i].x;
    y[i] = coord[i].y;
    z[i] = coord[i].z;
  }
  // also calculate min max x y z
  maxX = libDM_math::getMax(x, atomNumb);
  maxY = libDM_math::getMax(y, atomNumb);
  maxZ = libDM_math::getMax(z, atomNumb);
  minX = libDM_math::getMin(x, atomNumb);
  minY = libDM_math::getMin(y, atomNumb);
  minZ = libDM_math::getMin(z, atomNumb);
}

void
MolGrid::loadCoord(const vector<float>& coord) {
  assert(coord.size() == atomNumb*3);
  vector<float>::const_iterator cit = coord.begin();
  
  for (Uint i = 0; i < atomNumb; ++i) {
    x[i] = *cit;
    ++cit;
    y[i] = *cit;
    ++cit;
    z[i] = *cit;
    ++cit;
  }
  // also calculate min max x y z
  maxX = libDM_math::getMax(x, atomNumb);
  maxY = libDM_math::getMax(y, atomNumb);
  maxZ = libDM_math::getMax(z, atomNumb);
  minX = libDM_math::getMin(x, atomNumb);
  minY = libDM_math::getMin(y, atomNumb);
  minZ = libDM_math::getMin(z, atomNumb);  
}


int
MolGrid::findNeighborCells(Uint cellID_, int* neighbors_) const {
  assert(cellID_ <= ijkSize); // check if such cell index exists:-)
  // grid must be to each side at least more then 1
  assert(iSize > 1 and jSize > 1 and kSize > 1);
  // save cellID_ original value
  Uint _cellID = cellID_; 
  // first define +1 0 -1 for x, y, z  
  int ips=3, jps=3, kps=3;
  int* ip = new int[ips];
  int* jp = new int[jps];
  int* kp = new int[kps];
  for (int i = 0; i < 3; ++i) 
    ip[i] = jp[i] = kp[i] = i-1;

  // now find were is this cell, because if its at the edge of grid
  // then it will have less neighbors and some +1 0 -1 shits are 
  // not relevent and will be removed
  
  // 1. First, check if it is on first or last in z 
  if (cellID_ <= iSize*jSize) {
    // index_ is in the first xy plane, no z-1
    delete[] kp; --kps;
    kp = new int[kps];
    kp[0] = 0; kp[1] = 1;
  }
  else if (cellID_ > (ijkSize - ijSize)) {
    // index_ is in the last xy plane, no z+1
    delete[] kp; --kps;
    kp = new int[kps];
    kp[0] = -1; kp[1] = 0;
  }
  
  // 2. 3d->2d, make index_ as if it is in first xy plane
  if (cellID_ > ijSize) { 
    cellID_ = cellID_ - (cellID_ / ijSize) * ijSize;
    if (cellID_ == 0)
      cellID_ = ijSize;
  }
  
  // 3. Second, check if it is on first or last in y 
  if (cellID_ <= iSize) {
    // index_ is in the first y row, no y-1
    delete[] jp; --jps;
    jp = new int[jps];
    jp[0] = 0; jp[1] = 1;
  }
  else if (cellID_ > ijSize - iSize) {
    // index_ is in the last y row, no y+1
    delete[] jp; --jps;
    jp = new int[jps];
    jp[0] = -1; jp[1] = 0;
  }
       
  // 4. 2d->1d, make index_ as if it in 1st x row
  if (cellID_ >= iSize)         
    cellID_ = cellID_ - ( cellID_ / iSize) * iSize;
    
  // 5. Third, check if it is on first or last in x
  if (cellID_ == 0) {
    // index_ is in the last x column, no x+1
    delete[] ip; --ips;
    ip = new int[ips];
    ip[0] = -1; ip[1] = 0;
  }
  else if (cellID_ == 1) {
    // index_ is in the first x column, no x-1
    delete[] ip; --ips;
    ip = new int[ips];
    ip[0] = 0; ip[1] = 1;
  }
   
    
  // 6. now find the number of neigbors and their indices
  int nn = 0; // number of neighbors
  for (int i = 0; i < ips; ++i) {
    for (int j = 0; j < jps; ++j) {
      for (int k = 0; k < kps; ++k) { 
        neighbors_[nn] = _cellID + (ip[i] + jp[j]*iSize + kp[k]*ijSize);
        ++nn;
      } // k
    } // j
  } // i
  delete[] ip;
  delete[] jp;
  delete[] kp;
  return nn; // return number of neighbors
}

int 
MolGrid::findAtomsInCells(const int* cells_, 
                          const int cellNumb_, Uint* atom_) const {
  int _n = 0;
  for (int n1 = 0; n1 < cellNumb_; ++n1) {
    //DM Issue this is expensive to run through all atom every time
    // do something about it?
    for (int n2 = 0; n2 < atomNumb; ++n2) {
      if (cells_[n1] == i[n2]) {
        atom_[_n] = n2;
        ++_n;
      } 
    } // n1 -> neighbor cells
  } // n2 -> all atoms
  return _n; // number of atoms in 'cells_'   
}

int 
MolGrid::findAtomsInCellsNotThis(const int* cells_, const  int cellNumb_, 
                                 Uint* atom_, const int thisAtom_) const {
  int _n = 0;
  for (int n1 = 0; n1 < cellNumb_; ++n1) {
    //DM Issue this is expensive to run through all atom every time
    // do something about it? 
    for (int n2 = 0; n2 < atomNumb; ++n2) {
      // make sure to exclude this atom 'n2 != thisAtom_'
      if (cells_[n1] == i[n2] and n2 != thisAtom_) {
        atom_[_n] = n2;
        ++_n;
      } 
    } // n1 -> neighbor cells
  } // n2 -> all atoms
  return _n; // number of atoms in 'cells_'   
}


//*******************************************************************
//_________________MolGridR__________________________________________
MolGridR::MolGridR(Uint size_): MolGrid(size_) {
  r = new float[size_];
  r2= new float[size_];
  rr= new float[size_];
  maxR=minR=maxR2=minR2=maxRR=minRR=0.0f;
  //cout << "MolGridR constructor" << endl;
}

MolGridR::~MolGridR() {
  delete[] r;
  delete[] r2;
  delete[] rr;
  //cout << "MolGridR destructor" << endl;
}

void
MolGridR::loadRadii(const vector<float>& radii_) {
  assert(radii_.size() == atomNumb);
  vector<float>::const_iterator cit = radii_.begin();
  for (int i = 0; i < atomNumb; ++i) {     
    r[i] = *cit; ++cit;
    r2[i] = 2*r[i];
    rr[i] = r[i]*r[i];
  }
  // also calculate min max radii
  maxR = libDM_math::getMax(r, atomNumb);
  minR = libDM_math::getMin(r, atomNumb);
  maxR2= libDM_math::getMax(r2, atomNumb);
  minR2= libDM_math::getMin(r2, atomNumb);
  maxRR= libDM_math::getMax(rr, atomNumb);
  minRR= libDM_math::getMin(rr, atomNumb);
}

void
MolGridR::makeGrid() {
  // find grid sizes
  iSize = static_cast<Uint>(floor((maxX-minX)/maxR2)) + 1;
  if (iSize < 3) iSize = 3; // at least 3 cells
  jSize = static_cast<Uint>(floor((maxY-minY)/maxR2)) + 1;
  if (jSize < 3) jSize = 3; // at least 3 cells
  kSize = static_cast<Uint>(floor((maxZ-minZ)/maxR2)) + 1;
  if (kSize < 3) kSize = 3; // at least 3 cells
  ijSize = iSize*jSize;
  ijkSize = ijSize*kSize;
  // assign atoms to grid indices
  // as if grid cell are indexed from 1:-)
  Uint _i, _j, _k, _kji;
  for (int n = 0; n < atomNumb; ++n) {
    _i = static_cast<Uint>(floor((x[n]-minX)/maxR2) + 1);
    _j = static_cast<Uint>(floor((y[n]-minY)/maxR2));
    _k = static_cast<Uint>(floor((z[n]-minZ)/maxR2));
    _kji = _k*ijSize + _j*iSize + _i;
    i[n] = _kji;
  }
}


//_______________Helper Foos_________________________________________
void extractRadii(const PdbFile& pdbFile_, 
                  const vector<string>& data_, vector<float>& radii_) {
  const vector<PdbLine>* _pdbLines = pdbFile_.getPdbLines();
  radii_.reserve(_pdbLines->size());
  for (vector<PdbLine>::const_iterator cit = _pdbLines->begin();
       cit != _pdbLines->end(); ++cit) {
    radii_.push_back(getThatRadii(data_, 
                     *cit->getResName(), *cit->getAtom()));
  }
}

float getThatRadii(const vector<string>& data_, 
                   const string& res_, const string& atom_) {                 
  bool _isResidue = false;
  string _s;
  // iterate over all lines in data file
  for (vector<string>::const_iterator cit = data_.begin();
       cit != data_.end(); ++cit) {
    if (_isResidue) {
      // if new residue record, means that correct atom was not found
      if (cit->find("RESIDUE") == 0) {
        cout << "ERROR: no atom " << atom_ << " found in residue "
             << res_ << endl;
        exit(1);
      }
      _s = cit->substr(5,4);
      stripString(_s);
      // correct atom located, just get radii value
      if (_s == atom_) 
        return atof((cit->substr(10, 4)).c_str());
    } // 1st if
    else {
      // if correct residue is found later we'll look for an Atom
      if (cit->find("RESIDUE") == 0 && cit->find(res_) == 13) 
        _isResidue = true;
    } // else
  } // for end
  // DM Issue this has to be fixed, I mean what if there is some 
  // funny atom it should be assigned some radii anyway.!!! c'mon!!
  cout << "ERROR: no atom '" << atom_ << "' in residue '"
       << res_ << "' was found." << endl;
  exit(1);             
}
  







