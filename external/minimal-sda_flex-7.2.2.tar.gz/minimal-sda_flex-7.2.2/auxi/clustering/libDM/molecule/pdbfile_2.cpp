//-------------------------------------------------------------------
/*! \file pdbfile.cpp

*/
//-------------------------------------------------------------------
#include <vector>
#include <string>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <fstream>
#include <iomanip>
#include <sstream>

#include "pdbfile_2.h"
#include "vector3.h"
#include "commonfoo.h"


inline void stripString(string& s_in){
  const string from = " ";
  const string to = "";
  unsigned int search_here = 0;
  unsigned int found_here;
  while ((found_here = s_in.find(from, search_here)) != string::npos){
    s_in.replace(found_here, 1, to);
    search_here = found_here;
  }
}


namespace libDM_molecule {


// PdbLineS1 --------------------------------------------------------
// constructor
PdbLineS1::PdbLineS1(const string& pdbLine_) {
  lineTo30 = pdbLine_.substr(0, 30);
  coord.x  = atof(pdbLine_.substr(30, 8).c_str());
  coord.y  = atof(pdbLine_.substr(38, 8).c_str());
  coord.z  = atof(pdbLine_.substr(46, 8).c_str());
}
PdbLineS1::PdbLineS1(const PdbLineS1& pdbLine_) {
  lineTo30 = pdbLine_.getLineTo30();
  coord    = pdbLine_.getCoord();
}
PdbLineS1::PdbLineS1(Reader& reader_) {
  char* _cStr;
  reader_ >> _cStr;
  lineTo30 = _cStr;
  delete _cStr; // don't forget its in the heap
  reader_ >> coord.x;
  reader_ >> coord.y;
  reader_ >> coord.z;
}
// operator
PdbLineS1&
PdbLineS1::operator=(const PdbLineS1& pdbLine_) {
  lineTo30 = pdbLine_.getLineTo30();
  coord    = pdbLine_.getCoord();
  return *this;
}
bool
PdbLineS1::operator==(const PdbLineS1& pdbLine_) const {
  if (lineTo30 == pdbLine_.getLineTo30() &&
      coord    == pdbLine_.getCoord())
    return true;
  return false;
}
// set
void
PdbLineS1::setCoord(const Vector3& coord_) {
  coord = coord_;
}
// get
const string&
PdbLineS1::getLineTo30() const {
  return lineTo30;
}
const Vector3&
PdbLineS1::getCoord() const {
  return coord;
}
Vector3&
PdbLineS1::accessCoord() {
  return coord;
}
bool
PdbLineS1::isAtom(const string& atomName_) const {
  // searches for atomName_ string in lineTo30 string, if 
  // found returns the index in lineTo30 if not returns
  // string::npos
  unsigned int _pos = lineTo30.find(atomName_, 12);
  // if found and if between [12, 15], (not it is -1 since starts from 0)
  // than this line represents atomName_, therefore true
  if (_pos != string::npos && _pos > 11 && _pos < 16) {
    return true;
  }  
  return false;
}
void
PdbLineS1::storageWrite(Writer& writer_) {
  writer_ << const_cast<char*>(lineTo30.c_str());
  writer_ << coord.x;
  writer_ << coord.y;
  writer_ << coord.z;
}
// ==================================================================

// PdbLine ----------------------------------------------------------
PdbLine::PdbLine(const string& pdbLine_) {
  atom    = pdbLine_.substr(12, 4); stripString(atom);
  altLoc  = *const_cast<char*>(pdbLine_.substr(16, 1).c_str());
  resName = pdbLine_.substr(17, 3); stripString(resName);
  chainID = *const_cast<char*>(pdbLine_.substr(21, 1).c_str());
  resSeq  = atoi((pdbLine_.substr(22, 4)).c_str());
  iCode   = *const_cast<char*>(pdbLine_.substr(26, 1).c_str());
  coord.x = atof((pdbLine_.substr(30, 8)).c_str());
  coord.y = atof((pdbLine_.substr(38, 8)).c_str());
  coord.z = atof((pdbLine_.substr(46, 8)).c_str());
}
PdbLine::PdbLine(const PdbLine& other) {
  atom =    *other.getAtom();
  altLoc =  *other.getAltLoc();
  resName = *other.getResName();
  chainID = *other.getChainID();
  resSeq =  *other.getResSeq();
  iCode =   *other.getICode();
  coord =   *other.getCoord();
}

PdbLine&
PdbLine::operator=(const PdbLine& other) {
  atom =    *other.getAtom();
  altLoc =  *other.getAltLoc();
  resName = *other.getResName();
  chainID = *other.getChainID();
  resSeq =  *other.getResSeq();
  iCode =   *other.getICode();
  coord =   *other.getCoord();
  return *this;
}
bool
PdbLine::operator==(const PdbLine& other) const {
  if (atom    == *other.getAtom() && 
      altLoc  == *other.getAltLoc() &&
      resName == *other.getResName() &&
      chainID == *other.getChainID() &&
      resSeq  == *other.getResSeq() &&
      iCode   == *other.getICode() &&
      coord   == *other.getCoord())
    return true;
  return false;
}
// get stuff
const string*  
PdbLine::getAtom() const{
  return &atom;
}
const char*    
PdbLine::getAltLoc() const{
  return &altLoc;
}
const string*  
PdbLine::getResName() const{
  return &resName;
}
const char*    
PdbLine::getChainID() const{
  return &chainID;
}
const int*     
PdbLine::getResSeq() const{
  return &resSeq;
}
const char*    
PdbLine::getICode() const{
  return &iCode;
}
const Vector3* 
PdbLine::getCoord() const{
  return &coord;
}
// set stuff
void
PdbLine::setAtom(const string& atom_) {
  atom = atom_;
}
void 
PdbLine::setAltLoc(const char& altLoc_) {
  altLoc = altLoc_;
}
void 
PdbLine::setResName(const string& resName_) {
  resName = resName_;
}
void
PdbLine::setChainID(const char& chainID_) {
  chainID = chainID_;
}
void 
PdbLine::setResSeq(const int& ResSeq_) {
  resSeq = ResSeq_;
}
void 
PdbLine::setICode(const char& iCode_) {
  iCode = iCode_;
}
void
PdbLine::setCoord(const Vector3& coord_) {
  coord = coord_;
}
void
PdbLine::setCoord(float x_, float y_, float z_) {
   coord.x = x_;
   coord.y = y_;
   coord.z = z_;
}

void 
PdbLine::translateMe(const Vector3& vector3_){
  coord += vector3_;
}
/*! Checks if this line is for hydrogen atom. Namely checks if the
    first letter is H, or first letter is number from 1 to 5 and
    second letter is H or first and second letters are numbers 
    from 1 to 5 and third is H. (not sure if covers all hydrogens).
*/
bool
PdbLine::isHydrogen() const {
  // if first letter is H
  if (atom[0] == 'H'){ 
    return true;
  // if first letter is 1-5 number and second is H
  } else if (atom[0] == '1' || atom[0] == '2' || atom[0] == '3' ||
             atom[0] == '4' || atom[0] == '5' && atom[1] == 'H') {
    return true;
  // if first and second letter are 1-5 number and third H
  } else if ((atom[0] == '1' || atom[0] == '2' || atom[0] == '3' ||
              atom[0] == '4' || atom[0] == '5') && 
             (atom[1] == '1' || atom[1] == '2' || atom[1] == '3' ||
              atom[1] == '4' || atom[1] == '5') &&   
             (atom[2] == 'H')) {
    return true;
  }
  return false;
}
/*! Checks if the atom is backbone atom */
bool
PdbLine::isBackbone() const {
  if (atom == "C" or atom == "CA" or atom == "N" or atom == "O")
    return true;
  return false;
}
/*! Checks if it is the same atom, checks all fields
    except coordinates thats the difference from == */
bool
PdbLine::isSameAtom(const PdbLine& other) const {
  if (atom    == *other.getAtom() && 
      altLoc  == *other.getAltLoc() &&
      resName == *other.getResName() &&
      chainID == *other.getChainID() &&
      resSeq  == *other.getResSeq() &&
      iCode   == *other.getICode())
    return true;
  return false;
}




// ==================================================================

// class PdbFileS1 --------------------------------------------------
// static members
// int PdbFileS1::getCenterCallNo = 0;
// constructor
PdbFileS1::PdbFileS1(const vector<PdbLineS1>& pdbLines_) {
  pdbLines = pdbLines_;
}
PdbFileS1::PdbFileS1(const vector<string>& pdbLines_) {
  setPdbLines(pdbLines_);
}
PdbFileS1::PdbFileS1(const PdbFileS1& pdbFile_) {
  pdbLines = *pdbFile_.getPdbLines();
}
PdbFileS1::PdbFileS1(Reader& reader_) {
  unsigned int _vectorSize;
  reader_ >> _vectorSize;
  pdbLines.reserve(_vectorSize);
  for (unsigned int i = 0; i < _vectorSize; ++i) {
    PdbLineS1* _pL = new PdbLineS1(reader_);
    pdbLines.push_back(*_pL);
    delete _pL;
  }
}
// operator
PdbFileS1&
PdbFileS1::operator=(const PdbFileS1& pdbFile_) {
  pdbLines = *pdbFile_.getPdbLines();
  return *this;
}

bool
PdbFileS1::operator==(const PdbFileS1& pdbFile_) const {
  for (vector<PdbLineS1>::const_iterator citerPLThis = pdbLines.begin(),
                          citerPLThat = pdbFile_.getPdbLines()->begin();
       citerPLThis != pdbLines.end(),
       citerPLThat != pdbFile_.getPdbLines()->end();
       ++citerPLThis,
       ++citerPLThat) {
    if (!(*citerPLThis == *citerPLThat))
      return false;
  }
  return true;  
}


// set
void
PdbFileS1::setCoord(const vector<Vector3>& coord_) {
  assert(coord_.size() == pdbLines.size());
  vector<PdbLineS1>::iterator it;
  vector<Vector3>::const_iterator cit;
  for (it = pdbLines.begin(), cit = coord_.begin();
       it !=pdbLines.end(),   cit !=coord_.end();
       ++it, ++cit) {
    it->setCoord(*cit);
  }
}

void
PdbFileS1::setPdbLines(const vector<PdbLineS1>* pdbLines_) {
  pdbLines = *pdbLines_;
}
void
PdbFileS1::setPdbLines(const vector<string>& pdbLines_) {
  pdbLines.reserve(pdbLines_.size());
  for (vector<string>::const_iterator citerS = pdbLines_.begin();
       citerS != pdbLines_.end();
       ++citerS) {
    pdbLines.push_back(PdbLineS1(*citerS));
  }
}
void
PdbFileS1::addPdbLine(const PdbLineS1* pdbLine_) {
  pdbLines.push_back(*pdbLine_);
}
// get
const vector<PdbLineS1>*
PdbFileS1::getPdbLines() const {
  return &pdbLines;
}
vector<PdbLineS1>&
PdbFileS1::accessPdbLines() {
  return pdbLines;
}

void
PdbFileS1::getCoord(vector<Vector3>& coord_) const {
  coord_.clear(); coord_.reserve(pdbLines.size());
  for (vector<PdbLineS1>::const_iterator cit = pdbLines.begin();
       cit != pdbLines.end(); ++cit) {
    coord_.push_back(cit->getCoord());
  }
}

vector<Vector3>
PdbFileS1::getCoord() const {
  vector<Vector3> _res;
  for (vector<PdbLineS1>::const_iterator cit = pdbLines.begin();
       cit != pdbLines.end(); ++cit) {
    _res.push_back(cit->getCoord());
  }
  return _res;
}

Vector3
PdbFileS1::getCenter() const {
  float _x = 0.0f, _y = 0.0f, _z = 0.0f;
  int _n = 0;
  for (vector<PdbLineS1>::const_iterator citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    _x += (citerPL->getCoord()).x;
    _y += (citerPL->getCoord()).y;
    _z += (citerPL->getCoord()).z;
    ++_n;
  }
  float _1overN = (1.0f / _n);
  return Vector3((_x*_1overN), (_y*_1overN), (_z*_1overN));
}

// this assumes y have really the same structure, does just minor checks
float
PdbFileS1::backbRmsd(const PdbFileS1& pdbFile_) const {
  if (this->pdbLines.size() != pdbFile_.getPdbLines()->size()) {
    cerr << "The number of pdbLines in PdbFile objects are different. "
         << "Can't calculate RMSD." << endl;
    exit(1);
  }
  long double _res = 0.0f;
  int _n = 0;
  for (vector<PdbLineS1>::const_iterator citerPL1 = this->pdbLines.begin(),
                                citerPL2 = pdbFile_.getPdbLines()->begin();
       citerPL1 !=this->pdbLines.end(),
       citerPL2 !=pdbFile_.getPdbLines()->end();
       ++citerPL1,
       ++citerPL2) {
    // maybe its too expensive to check so much (but secure:-))   
    if (citerPL1->isAtom("CA") && citerPL2->isAtom("CA") ||
        citerPL1->isAtom("C")  && citerPL2->isAtom("C")  ||
        citerPL1->isAtom("N")  && citerPL2->isAtom("N")  ||
        citerPL1->isAtom("O")  && citerPL2->isAtom("O")   ) {
      long double _dx = (citerPL1->getCoord().x - citerPL2->getCoord().x);
      long double _dy = (citerPL1->getCoord().y - citerPL2->getCoord().y);
      long double _dz = (citerPL1->getCoord().z - citerPL2->getCoord().z);
      _res += (_dx*_dx + _dy*_dy + _dz*_dz);
      ++_n;
    }
  } //for end
  long double _1overN =(long double) 1.0f / (long double)_n;
  
  return sqrt(_res * _1overN);
}
void 
PdbFileS1::storageWrite(Writer& writer_) {
  unsigned int si = pdbLines.size();
  writer_ << si;
  //writer_ << ( pdbLines.size() ); why doesn't this work?
  for (vector<PdbLineS1>::iterator iterPL = pdbLines.begin();
       iterPL != pdbLines.end();
       ++iterPL) {
    iterPL->storageWrite(writer_);
  }
}
// ==================================================================

// class PdbFileS1 --------------------------------------------------
PdbFile::PdbFile(const PdbFile& other) {
  pdbLines = *other.getPdbLines();
}
PdbFile::PdbFile(const vector<PdbLine>& pdbLines_) {
  pdbLines = pdbLines_;
}
PdbFile::PdbFile(const vector<string>& pdbLines_) {
  for (vector<string>::const_iterator citerS = pdbLines_.begin();
       citerS != pdbLines_.end();
       ++citerS) {
    pdbLines.push_back(PdbLine(*citerS));
  }
}

PdbFile&
PdbFile::operator=(const PdbFile& other) {
  pdbLines = *other.getPdbLines();
  return *this;
}

void
PdbFile::operator+=(const PdbFile& other) {
  for (vector<PdbLine>::const_iterator cit = other.getPdbLines()->begin();
       cit != other.getPdbLines()->end(); ++cit) {
    pdbLines.push_back(*cit);    
  }
}

PdbFile
PdbFile::operator+(const PdbFile& other) const {
  PdbFile res(*this);
  res+=other;
  return res;
}

const vector<PdbLine>*
PdbFile::getPdbLines() const {
  return &pdbLines;
}

void
PdbFile::leaveAtom(const string& atom_) {
  vector<PdbLine> _res;
  for (CiterPL citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    if (*citerPL->getAtom() == atom_) {
      _res.push_back(*citerPL);    
    }
  }
  pdbLines = _res;
}

void
PdbFile::removeNonBackbone() {
  vector<PdbLine> _res;
  for (CiterPL citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    if (citerPL->isBackbone())
      _res.push_back(*citerPL);
  }
  pdbLines = _res;
}

void
PdbFile::removeHydrogens() {
  vector<PdbLine> _res;
  for (CiterPL citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    if (!citerPL->isHydrogen())
      _res.push_back(*citerPL);
  }
  pdbLines = _res;
}

void
PdbFile::changeResName(const string& from, const string& to) {
  for (IterPL iterPL = pdbLines.begin();
       iterPL != pdbLines.end();
       ++iterPL) {
    if (*iterPL->getResName() == from) {
      iterPL->setResName(to);
    }
  }
}
void 
PdbFile::filterAltLoc(const char altLoc_) {
  vector<PdbLine> _res;
  for (IterPL iterPL = pdbLines.begin();
       iterPL != pdbLines.end();
       ++iterPL) {
    // if no altLoc just take this PdbLine
    if (*iterPL->getAltLoc() == ' ') {
      _res.push_back(*iterPL);
    }
    // if altLoc that is required just clear and take it 
    else if (*iterPL->getAltLoc() == altLoc_) {
      iterPL->setAltLoc(' ');
      _res.push_back(*iterPL);
    }
    // remove this line, don't take in
    else {
      continue;
    }
  }
  pdbLines = _res;
}
void
PdbFile::fixResName(const string& name_) {
  bool is = false;
  for (ItPL itPL = pdbLines.begin();
            itPL !=pdbLines.end();
          ++itPL) {
    if (name_ == *itPL->getResName()) {
      ItPL _t = itPL;
      if (_t != pdbLines.begin()) { 
        --_t;
        if (*_t->getResSeq() != *itPL->getResSeq())
          ++_t;
      }
      while (*_t->getResSeq() == *itPL->getResSeq()) {
        if (*_t->getResName() != *itPL->getResName()) {
          is = true;
          itPL->setResName(*_t->getResName());  
          break;
        }
        ++_t;
      } // while loop
    } // if foun such residue
  } // for loop
  if (!is)
    changeResName(name_, "GLY");
}

void
PdbFile::getAtomCoord(vector<Vector3>& atoms_) const {
  atoms_.clear(); atoms_.reserve(pdbLines.size());
  for (CitPL citPL = pdbLines.begin();
             citPL !=pdbLines.end(); ++citPL) {
    atoms_.push_back(*citPL->getCoord());
  }
}

vector<Vector3>
PdbFile::getAtomCoord() const {
  vector<Vector3> _res;
  _res.reserve(pdbLines.size());
  for (CitPL citPL = pdbLines.begin();
       citPL != pdbLines.end(); ++citPL) {
    _res.push_back(*citPL->getCoord());
  }
  return _res;
}


Vector3
PdbFile::getCenter() const {
  float _x = 0.0f, _y = 0.0f, _z = 0.0f;
  int _n = 0;
  for (vector<PdbLine>::const_iterator citerPL = pdbLines.begin();
       citerPL != pdbLines.end();
       ++citerPL) {
    _x += (citerPL->getCoord())->x;
    _y += (citerPL->getCoord())->y;
    _z += (citerPL->getCoord())->z;
    ++_n;
  }
  float _1overN = (1.0f / _n);
  return Vector3((_x*_1overN), (_y*_1overN), (_z*_1overN));
}

void
PdbFile::setAtomCoord(const vector<Vector3>& atoms_) {
  assert(atoms_.size() == pdbLines.size());
  int _n = atoms_.size();
  for (int i = 0; i < _n; ++i) {
    pdbLines[i].setCoord(atoms_[i]); 
  }
}

void
PdbFile::setAtomCoord(const vector<float>& atoms_) {

  assert(atoms_.size() == pdbLines.size() *3 );
  int _n = pdbLines.size();
  
  vector<PdbLine>::iterator it = pdbLines.begin();
  vector<float>::const_iterator cit = atoms_.begin();
  float _x, _y, _z;
  for (int i = 0; i < _n; ++i) {
    _x = *cit; ++cit;
    _y = *cit; ++cit;
    _z = *cit; ++cit;
    it->setCoord(_x, _y, _z);
    ++it;
  }
}

void
PdbFile::setChainID(char chId_) {
  
  for (vector<PdbLine>::iterator it = pdbLines.begin();
       it != pdbLines.end(); ++it) {
    it->setChainID(chId_);    
  }
}

float
PdbFile::backbRmsd(const PdbFile& pdbFile_) const {
  if (this->pdbLines.size() != pdbFile_.getPdbLines()->size()) {
    cerr << "The number of pdbLines in PdbFile objects are different. "
         << "Can't calculate RMSD." << endl;
    return 0.0f;
  }
  long double _res = (long double) 0.0f;
  int _n = 0;
  
  CitPL citThis, citOther;
  for (citThis  = this->pdbLines.begin(),
       citOther = pdbFile_.getPdbLines()->begin();
       citThis  !=this->pdbLines.end(),
       citOther !=pdbFile_.getPdbLines()->end();
       ++citThis, ++citOther) {
    // maybe its too expensive to check so much (but secure:-))   
    if (*citThis->getAtom() == "CA" || *citThis->getAtom() == "C" ||
        *citThis->getAtom() == "N"  || *citThis->getAtom() == "O" ) {
      assert(*citThis->getAtom() == *citOther->getAtom());   
      long double _dx = (citThis->getCoord()->x - citOther->getCoord()->x);
      long double _dy = (citThis->getCoord()->y - citOther->getCoord()->y);
      long double _dz = (citThis->getCoord()->z - citOther->getCoord()->z);
      _res += (_dx*_dx + _dy*_dy + _dz*_dz);
      ++_n;
    }
  } //for end
  long double _1overN = (long double)1.0f / (long double) _n;
  return sqrt(_res * _1overN);
}

int 
PdbFile::cutOffAfterRes(PdbFile& pdbFile_, int res_) {
  // first check if res_ is not too big
  if (res_ >= pdbLines.size()) 
    return -1;
  
  ++res_;
  IterPL it;
  // find iterator of first PdbLine with ++res_ resSeq
  for (IterPL _it = pdbLines.begin(); _it != pdbLines.end(); ++_it) {
    if (*_it->getResSeq() == res_) {
      it = _it;
      break;
    } 
  }
  // move the rest of the protein to pdbFile_ and cut that part
  // from this object
  vector<PdbLine>& _pdbLines = pdbFile_.accessPdbLines();
  // clear just in case the vector in 'pdbFile_' and reserve 
  // appropriate piece of space
  _pdbLines.clear();
  _pdbLines.reserve(pdbLines.end() - it);
  for (IterPL _it = it; _it != pdbLines.end(); ++_it) {
    _pdbLines.push_back(*_it);
  }
  pdbLines.erase(it, pdbLines.end());
  return 1;

}
//===================================================================

// PdbResidueID -----------------------------------------------------
bool
PdbResidueId::operator==(const PdbResidueId& r_) const {
  if (this->name == r_.name  and 
      this->numb == r_.numb  and
      this->chain== r_.chain and
      this->iCode== r_.iCode)
    return true;
  return false;
}

bool
PdbResidueId::operator==(const PdbLine& pdbLine_) const {
  if (this->name == *pdbLine_.getResName() and
      this->numb == *pdbLine_.getResSeq() and
      this->chain== *pdbLine_.getChainID() and
      this->iCode== *pdbLine_.getICode())
    return true;
  return false;
}

void
PdbResidueId::clear() {
  name  = " ";
  numb  = 0;
  chain = ' ';
  iCode = ' ';
}

//===================================================================
//*******************************************************************
// FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO  
void 
getAllLines(const char* fileName_, vector<string>& lines_) {
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return;
  }  
  string _str;
  while(!fin.eof()) {
    getline(fin, _str);
    lines_.push_back(_str);
  }
  fin.close();
}

void
getAtomLines(const char* fileName_, vector<string>& lines_) {
  const string ATOM = "ATOM";
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " <<  fileName_ << endl;
    return;
  }
  string _str;
  while(!fin.eof()) {
    getline(fin, _str);
    if (_str.substr(0, 4) != ATOM)
      continue;
    lines_.push_back(_str);
  }
  fin.close();
}

void
getAtomLinesBackbone(const char* fileName_, vector<string>& lines_) {
  const string ATOM = "ATOM";
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " <<  fileName_ << endl;
    return;
  }
  string _str;
  string _atom;
  while(!fin.eof()) {
    getline(fin, _str);
    if (_str.substr(0, 4) != ATOM)
      continue;
    _atom = _str.substr(12, 4);
    stripString(_atom);  
    if (_atom == "CA" or _atom == "N" or 
        _atom == "C" or _atom == "O")  
      lines_.push_back(_str);
  }
  fin.close();  
}


void
getAtomHetLines(const char* fileName_, vector<string>& lines_) {
  const string ATOM = "ATOM";
  const string HETATM = "HETATM";
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " <<  fileName_ << endl;
    return;
  }
  string _str;
  while(!fin.eof()) {
    getline(fin, _str);
    if (_str.substr(0, 4) != ATOM and _str.substr(0, 6) != HETATM)
      continue;
    lines_.push_back(_str);
  }
  fin.close();
}

void
getAtomCoord(const char* fileName_, vector<Vector3>& coord_) {
  vector<string> _lines;
  getAtomLines(fileName_, _lines);
  coord_.reserve(_lines.size());
  for (vector<string>::const_iterator cit = _lines.begin();
       cit != _lines.end(); ++cit) {
    coord_.push_back(Vector3(atof(cit->substr(30, 8).c_str()), 
                             atof(cit->substr(38, 8).c_str()),
                             atof(cit->substr(46, 8).c_str())) );     
  }
}

void
getAtomCoordBackbone(const char* fileName_, vector<Vector3>& coord_) {
  vector<string> _lines;
  getAtomLinesBackbone(fileName_, _lines);
  coord_.reserve(_lines.size());
  for (vector<string>::const_iterator cit = _lines.begin();
       cit != _lines.end(); ++cit) {
       coord_.push_back(Vector3(atof(cit->substr(30, 8).c_str()), 
                               atof(cit->substr(38, 8).c_str()),
                               atof(cit->substr(46, 8).c_str())) );     
  }
}


void
getAtomHetCoord(const char* fileName_, vector<Vector3>& coord_) {
  vector<string> _lines;
  getAtomHetLines(fileName_, _lines);
  coord_.reserve(_lines.size());
  for (vector<string>::const_iterator cit = _lines.begin();
       cit != _lines.end(); ++cit) {
    coord_.push_back(Vector3(atof(cit->substr(30, 8).c_str()), 
                             atof(cit->substr(38, 8).c_str()),
                             atof(cit->substr(46, 8).c_str())) );     
  }
}

Vector3
getCenterOfMass(const PdbFileS1& pdbFile_) {

  const vector<PdbLineS1>* pdbLines = pdbFile_.getPdbLines();
  float mass, totalMass = 0.0f, xm = 0.0f, ym = 0.0f, zm = 0.0f;
  for (vector<PdbLineS1>::const_iterator cit = pdbLines->begin();
       cit != pdbLines->end(); ++cit) {
    string _str = cit->getLineTo30().substr(12,4);
    stripString(_str);
    if        (_str[0] == 'C') {
      mass = 12.01f;
    } else if (_str[0] == 'O') {
      mass = 16.00f;
    } else if (_str[0] == 'N') {
      mass = 14.01f;
    } else if (_str[0] == 'H') {
      mass = 1.008f;
    } else if (_str[0] == 'P') {
      mass = 30.97f;
    } else if (_str[0] == 'S') {
      mass = 32.06;
    } else if (_str[0] == '1' or 
               _str[0] == '2' or
               _str[0] == '3' or
               _str[0] == '4' or
               _str[0] == '5' or
               _str[0] == '6' or
               _str[0] == '7' or
               _str[0] == '8' or
               _str[0] == '9' or
               _str[0] == '0') {
      if (_str[1] == 'H') {
        mass = 1.008f;
      } else if (_str[1] == '1' or 
                 _str[1] == '2' or
                 _str[1] == '3' or
                 _str[1] == '4' or
                 _str[1] == '5' or
                 _str[1] == '6' or
                 _str[1] == '7' or
                 _str[1] == '8' or
                 _str[1] == '9' or
                 _str[1] == '0' and 
                 _str[2] == 'H') {
         mass = 1.008f;
       }
     } else {
       mass = 0.0f;
     }
  xm += cit->getCoord().x * mass;
  ym += cit->getCoord().y * mass;
  zm += cit->getCoord().z * mass;
  totalMass += mass;
  } // for each PdbLineS1
  return Vector3(xm/totalMass, ym/totalMass, zm/totalMass);
}


Vector3
getCenterOfMass(const PdbFile& pdbFile_) {

  const vector<PdbLine>* pdbLines = pdbFile_.getPdbLines();
  float mass, totalMass = 0.0f, xm = 0.0f, ym = 0.0f, zm = 0.0f;
  for (vector<PdbLine>::const_iterator cit = pdbLines->begin();
       cit != pdbLines->end(); ++cit) {
    string _str = *cit->getAtom();
    stripString(_str);
    if        (_str[0] == 'C') {
      mass = 12.01f;
    } else if (_str[0] == 'O') {
      mass = 16.00f;
    } else if (_str[0] == 'N') {
      mass = 14.01f;
    } else if (_str[0] == 'H') {
      mass = 1.008f;
    } else if (_str[0] == 'P') {
      mass = 30.97f;
    } else if (_str[0] == 'S') {
      mass = 32.06;
    } else if (_str[0] == '1' or 
               _str[0] == '2' or
               _str[0] == '3' or
               _str[0] == '4' or
               _str[0] == '5' or
               _str[0] == '6' or
               _str[0] == '7' or
               _str[0] == '8' or
               _str[0] == '9' or
               _str[0] == '0') {
      if (_str[1] == 'H') {
        mass = 1.008f;
      } else if (_str[1] == '1' or 
                 _str[1] == '2' or
                 _str[1] == '3' or
                 _str[1] == '4' or
                 _str[1] == '5' or
                 _str[1] == '6' or
                 _str[1] == '7' or
                 _str[1] == '8' or
                 _str[1] == '9' or
                 _str[1] == '0' and 
                 _str[2] == 'H') {
         mass = 1.008f;
       }
     } else {
       mass = 0.0f;
     }
  xm += cit->getCoord()->x * mass;
  ym += cit->getCoord()->y * mass;
  zm += cit->getCoord()->z * mass;
  totalMass += mass;
  } // for each PdbLineS1
  return Vector3(xm/totalMass, ym/totalMass, zm/totalMass);
}



void
translateMolecule(const Vector3& tr_, PdbFileS1& pdbFile_) {
  vector<PdbLineS1>& pdbLines = pdbFile_.accessPdbLines();
  for (vector<PdbLineS1>::iterator it = pdbLines.begin();
       it != pdbLines.end(); ++it) {
    it->accessCoord() += tr_;    
  }
}

void writePdbFileS1(const char* fileName_, const PdbFileS1& pdbFile_) {
  ofstream fou;
  fou.open(fileName_);
  if (!fou.is_open()) {
    cout << "ERROR: Failed to open file: " << fileName_ << endl;
    return;
  }
  for (vector<PdbLineS1>::const_iterator 
       cit = pdbFile_.getPdbLines()->begin();
       cit != pdbFile_.getPdbLines()->end();
       ++cit) {
    fou << cit->getLineTo30();
    fou.setf(ios::right, ios::adjustfield);
    fou.setf(ios::fixed, ios::floatfield);
    fou << setprecision(3)
        << setw(8) << cit->getCoord().x
        << setw(8) << cit->getCoord().y
        << setw(8) << cit->getCoord().z << endl;    
  }
  fou.close();
}


void
writePdbFile(const char* fileName_, const PdbFile& pdbFile_) {
  ofstream fou;
  fou.open(fileName_);
  if (!fou.is_open()) {
    cout << "ERROR: Failed to open file: " << fileName_ << endl;
    return;
  }
  
  int _n = 1;
  for (vector<PdbLine>::const_iterator
       cit = pdbFile_.getPdbLines()->begin();
       cit !=pdbFile_.getPdbLines()->end();
       ++cit) {
    string atom = *cit->getAtom();
    fou << "ATOM  "
        << setw(5) << setiosflags(ios::right) << _n << " "
        << (atom.size() < 3 ?
            atom.size() > 1 ? " "+atom+" " : " "+atom+"  " :
            atom.size() ==4 ? atom : " "+atom)
        << *cit->getAltLoc()
        << *cit->getResName() << " "
        << *cit->getChainID()
        << setw(4) << setiosflags(ios::right) 
        << *cit->getResSeq()
        << *cit->getICode() << "   ";
    fou.setf(ios::right, ios::adjustfield);
    fou.setf(ios::fixed, ios::floatfield);
    fou << setprecision(3)
        << setw(8) << cit->getCoord()->x
        << setw(8) << cit->getCoord()->y
        << setw(8) << cit->getCoord()->z
        << '\n';
    ++_n;
  }
}



string 
pdbLineS1ToString(const PdbLineS1& pdbLineS1_) {
  stringstream ss;
  ss <<  pdbLineS1_.getLineTo30();
  ss.setf(ios::right, ios::adjustfield);
  ss.setf(ios::fixed, ios::floatfield);
  ss << setprecision(3)
     << setw(8) << pdbLineS1_.getCoord().x
     << setw(8) << pdbLineS1_.getCoord().y
     << setw(8) << pdbLineS1_.getCoord().z << endl;
  return ss.str();
  
}

/*! This is slow but more rubust. I should be able to calculate the
    backbone rmsd even if the sequences are of different length, because
    it first extracts the same atoms and then calculates the rmsd
    Note this will not include atoms of missmached residues as it sometimes
    occure in say bound vs unbound protein...
*/

float
advancedBackboneRmsd(const PdbFile& pf1_, const PdbFile& pf2_) {
  PdbFile pf1 = pf1_;
  PdbFile pf2 = pf2_;
  pf1.removeNonBackbone();
  pf2.removeNonBackbone();
  vector<Vector3> pfClean1;
  vector<Vector3> pfClean2;
  for (CitPL citPL1 = pf1.getPdbLines()->begin();
       citPL1 != pf1.getPdbLines()->end(); ++citPL1) {
    for (ItPL itPL2 = pf2.accessPdbLines().begin();
         itPL2 != pf2.accessPdbLines().end(); ++itPL2) {
      if (citPL1->isSameAtom(*itPL2)) {
        pfClean1.push_back(*citPL1->getCoord());
        pfClean2.push_back(*itPL2->getCoord());
        break;
      } // if
    } // for 2
  } // for 1
  return vector3Rmsd(pfClean1, pfClean2);
}

void
changeResidueName(PdbFile& pf_, const string& from_, const string& to_) {
  vector<PdbLine>& pl_ = pf_.accessPdbLines();
  for (vector<PdbLine>::iterator it = pl_.begin();
       it != pl_.end(); ++it) {
    if (*it->getResName() == from_) {
      it->setResName(to_);
    }    
  }
}

// FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO  
//******************************************************************


} // namespace libDM_molecule






