//-------------------------------------------------------------------
/*! \file residue.h
    \brief Implementation of residue classes
    
    by D.M. EML Research
    V 0.3
*/
//-------------------------------------------------------------------
#ifndef RESIDUE_H
#define RESIDUE_H

#include <vector>
#include <string>
#include "vector3.h"
#include "atom.h"

using namespace std;
class Vector3;
class PdbLine;
class Atom;

//*******************************************************************
// RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE 
//-------------------------------------------------------------------
/*! \brief Encapsulate protein residue.

    This class stores protein residues.
*/
class Residue {
  public:
    Residue(): name(" "), resSeq(0), iCode(' '),
               _gCenter(0.0f, 0.0f, 0.0f), gCenter(0) {}
    Residue(const Residue& other);
    Residue(const vector<PdbLine>& pdbLines_);
    
    Residue& operator=(const Residue& other);
    bool operator==(const Residue& other) const;
    bool hasAtom(const Atom& atom_) const;
    bool hasAtom(const string& name_) const;
    bool isProtResidue() const;
    
    // get
    const Atom&          getAtom(const string& name_) const;
    const string&        getName() const;
          int            getResSeq() const;
          char           getICode() const;
    const vector<Atom>&  getAtoms() const;
    vector<Atom>&  accessAtoms() {return atoms;}
    const Vector3&       getCenter();

    
    void setAtoms(const vector<Atom>& atoms_);
  protected:

    Vector3       _gCenter;
    Vector3      *gCenter;
    string        name;
    int           resSeq;
    char          iCode;
    vector<Atom>  atoms;
};
//-------------------------------------------------------------------
// RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE RESIDUE 
//*******************************************************************
void trim2CB(Residue& res_);


/*
class ResidueF: public Residue {
  public:
    ResidueF(): Residue() {}
  
  protected:
    vector<AtomR> atoms;

};
*/


/*
class Residue{
		friend class Protein;
		struct State{
			bool empty;
		};
	public:
		Residue(vector<PdbLine*>&);
	// maintain
		void who();
		void init();
	//---methods--->
		void makeAtoms(vector<PdbLine*>&);
		void translateMe(Vector3&);
	// get
		const Atom* getAtom(const string&);
		//void getStdRData1();
		Vector3* getCenter();
	// checks?
		bool isCommonResidue() const;
		bool isSameResidue(const Residue*) const;
	//---members--->
		// main data------------//
		string resName;		//
		int    resSeq;		//
		char   iCode;           //
		vector<Atom> atoms;     //
		//----------------------//
		State state;
	private:
	//---methods--->
	// get
		float getMax(char) const;
		float getMin(char) const;
		void clearState();
	//---members--->
		Vector3* center;
		Vector3 _center;
		
	// iterators
		vector<PdbLine*>::iterator iterVP;
		vector<Atom>::const_iterator citerVA;
		vector<Atom>::iterator iterA;
};
*/
#endif

