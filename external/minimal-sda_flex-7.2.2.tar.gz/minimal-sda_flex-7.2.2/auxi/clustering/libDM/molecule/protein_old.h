//-----------//
// protein.h //
//-----------//
#ifndef PROTEIN_H
#define PROTEIN_H

#include <vector>
#include "residue.h"
using namespace std;
class FullPdb;
class PdbLine;
class Vector3;
class AccessIn;

class Protein{
		struct State{
			bool empty;
		};
		struct Chain{
			char chainID;
			int from, to;
		};
	public:
		Protein();
		Protein(FullPdb&);
		//Protein(vector<string>&);
	// maintain
		void who();
		void clear();
	//---methods--->
	// make
		void makeResidues(FullPdb&);
		//void makeResidues(vector<string>&);
		void defineSAResidues(AccessIn&);
		void makeResAccRel(const vector<string>&);
		void translateMe(Vector3&);
	// is?
		bool isResidue(string&, int, char);

	// get
  		const Residue* getResidue(string&, int, char);
		const Chain* getChain(char);
		float backbRmsd(const Protein*);
		Vector3 getCenter() const;
	// set
		void setName(const string&);
	//---members--->
		// main data -----------------------------------//
		string name;                                    //
		vector<Residue> residues;                       //
		vector<Chain> chains;                           //
		//----------------------------------------------//
		vector<const Residue*> sAResidues;
		State state;
	private:
	//---methods--->
		void clearState();
		float getMax(char) const;
		float getMin(char) const;
	//---members--->
		// iterators
		vector<PdbLine>::iterator iterVP;
		vector<Chain>::const_iterator citerVC;
		vector<string>::iterator iterVS;
		vector<Residue>::const_iterator citerVR;
		vector<Residue>::iterator iterR;
	// tmp 
		float _f;
		int _i;
		char _ch;

};


// HOW TO ------------------------------------------------------------
// Create Protein object from FullPdb object
//
// fp = new FullPdb;
// ...
// pr = new Protein;
// pr->makeResidues(*fp);	fead ready FullPdb object
// pr->makeResAccRel(accLines)  load "RES" lines from rsa file
//--------------------------------------------------------------------

#endif



