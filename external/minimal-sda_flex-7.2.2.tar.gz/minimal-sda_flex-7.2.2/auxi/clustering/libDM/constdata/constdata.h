//----------------//
// constdata.h    //
//----------------//
#ifndef CONSTDATA_H
#define CONSTDATA_H

#include <string>
#include <vector>
using namespace std;
//===CALCULATION PARAMETERS====================================>
// residue suface accessibility
const float ACCESS_THR = 10.0f;
// distance for residue residue contact definition
const float R2RCONT = 4.0f;
const float R2RCONTDOCK = 6.0f;

//=============================================================/
//===VARIOUS===================================================>
// place holders
const char HOLD1	= ' ';
const char CHOLD1	= ' ';
const char CHOLD2	= '#';
const string SHOLD1	= " ";
const string SHOLD2	= "#";
//==============================================================/

//===FILES======================================================>
// PDB file
const string ATOM = "ATOM";
const string TER  = "TER";
const string END  = "END";

// NACCESS file
const string ACCESS_RES = "RES";
//==============================================================/

//===AA=========================================================>
// residue names
const int AAARRAY = 20;
//---this is just to map 3letter code onto 1letter code-----|
// DON'T change order stuff depends on this               //|
const string AAA[] = {"ARG", "LYS", "ASN", "ASP", "GLN",  //|
		      "GLU", "HIS", "PRO", "TYR", "TRP",  //|
		      "SER", "THR", "GLY", "ALA", "MET",  //|
		      "CYS", "PHE", "LEU", "VAL", "ILE"}; //|
const char     A[] = {  'R',   'K',   'N',   'D',   'Q',  //|
			'E',   'H',   'P',   'Y',   'W',  //|
			'S',   'T',   'G',   'A',   'M',  //|
			'C',   'F',   'L',   'V',   'I'}; //|
//--------------------------------------------------------//|
//---and translator functions:				  //|
inline char from321(const string&);			  //|
inline string from123(const char);			  //|
//-----------------------------------------------------------
// map 3 letter names to stings                           //
const string ARG = "ARG"; const string LYS = "LYS";	  //
const string ASN = "ASN"; const string ASP = "ASP";	  //
const string GLN = "GLN"; const string GLU = "GLU";	  //
const string HIS = "HIS"; const string PRO = "PRO";	  //
const string TYR = "TYR"; const string TRP = "TRP";	  //
const string SER = "SER"; const string THR = "THR";	  //
const string GLY = "GLY"; const string ALA = "ALA";	  //
const string MET = "MET"; const string CYS = "CYS";	  //
const string PHE = "PHE"; const string LEU = "LEU";	  //
const string VAL = "VAL"; const string ILE = "ILE";	  //
const string HIE = "HIE"; const string HID = "HID";	  //
const string CYX = "CYX";			  	  //
//--------------------------------------------------------//

// Residue names ordered by hydrophobicity----------------//
// Kyte & Doolittle. 1982. JMB. 157. 105-132              //
const string AAA1[] = {"ARG", "LYS", "ASN", "ASP", "GLN", //
		       "GLU", "HIS", "PRO", "TYR", "TRP", //
		       "SER", "THR", "GLY", "ALA", "MET", //
		       "CYS", "PHE", "LEU", "VAL", "ILE"};//
//--------------------------------------------------------//


//---Residue Data-----------------------------------------//
// residue Volume                                         //
// A.A.Zamyatin et al, 1972, Mol.Biol. 24:107-123         //
const float VOLUME1[] = {                                 //
	173.4, 168.6, 114.1, 111.1, 143.8,                //
	138.4, 153.2, 112.7, 193.6, 227.8,                //
	 89.0, 116.1,  60.1,  88.6, 162.9,                //
	108.5, 189.9, 166.7, 140.0, 166.7 };              //
//--------------------------------------------------------//
       		       
// distances from residue center to furthers atom, -------//
// for ideal a.a. structures mapped to AAA                //
const float RESCEN2EDGE[] = {                             //
	 5.0710691673452848, 4.2631099563581518,          //
	 2.7683734394044457, 2.7420800954749662,          //
	 3.7457192233268102, 3.7236197778505797,          //
	 3.3769250435862501, 2.4950888761725505,          //
	 4.5155963891827176, 4.6064153362457452,          //
	 2.3443752899226697, 2.6679061546463738,          //
	 1.2482551822443999, 1.8693047504353058,          //
	 3.7398271684664786, 2.4929654028886965,          //
	 3.8567993530905911, 3.1506940901966347,          //
	 2.6093126489556595, 3.0445000821152890};         //
//--------------------------------------------------------//
//=========================================================/

//===ATOMS=================================================>
// Atom names in pdbs
const int ATOMARRAY = 73;
const string PROTATOMS[] =
{"C", 	"CA", 	"CB", 	"CD", 	"CG",
 "CE", 	"CZ",	"CG1", 	"CG2", 	"CD1",
 "CD2", "CE1", 	"CE2", 	"CE3", 	"CZ2",
 "CZ3",	"CH2",	"O",	"OG", 	"OH",
 "OG1",	"OD1", 	"OD2",	"OE1",	"OE2",
 "N",	"NE", 	"NZ",	"ND1",	"ND2",
 "NE1",	"NE2",	"NH1",	"NH2",	"S",
 "SD",	"SG",	"OXT",  "O2",
 "H",	"HG",	"1HZ",	"2HZ",	"3HZ",
 "HH",	"1HH1",	"2HH1",	"1HH2",	"2HH2",
 "1HD2","2HD2",	"HG1",	"HE",	"HE1",
 "HD1",	"HE2",	"1HE2",	"2HE2", "1H",
 "2H",	"3H",	"HD2",
 "HH11","HH12", "HH21", "HH22",
 "HZ1", "HZ2",  "HZ3",
 "HD21","HD22",
 "HE21","HE22"
 };
 
 // Backbone atom names
 const int BACKBONEATOMARRAY = 4;
 const string BACKBONEATOMS[] =
 {"C", "N", "O", "CA"};

//=========================================================/

#endif


