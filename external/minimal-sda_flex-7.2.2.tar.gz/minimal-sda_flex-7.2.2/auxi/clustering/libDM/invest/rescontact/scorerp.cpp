//-------------------------------------------------------------------
/*! \file .cpp

*/
//-------------------------------------------------------------------



#include <iostream>
#include <map>
#include <vector>
#include <cassert>

#include "residue.h"
#include "scorerp.h"


using namespace std;

void
ScoreRP::loadStdRP(const map<string, float>& stdRP_) {
  stdRP = stdRP_; 
}

void
ScoreRP::loadStdRP(const vector<string>& resMap_,
                   const vector<float>& rp_) {
  assert(resMap_.size() == rp_.size());
  for (int i = 0; i < resMap_.size(); ++i) {
    stdRP.clear();
    stdRP[resMap_[i]] = rp_[i];
  }  
}

float
ScoreRP::scoreRP(const vector<const Residue*>& r1_,
                 const vector<const Residue*>& r2_) {
  float _res = 0.0f;  
  for (vector< const Residue*>::const_iterator citR = r1_.begin();
       citR != r1_.end(); ++citR) {
    if (stdRP.find((*citR)->getName()) == stdRP.end()) {
      cerr << "WARNING: " << (*citR)->getName() << " residue "
      "does not have propensity value\n";
      continue;
    }
    _res += stdRP[(*citR)->getName()];
  } 

  for (vector< const Residue*>::const_iterator citR = r2_.begin();
       citR != r2_.end(); ++citR) {
    if (stdRP.find((*citR)->getName()) == stdRP.end()) {
      cerr << "WARNING: " << (*citR)->getName() << " residue "
      "does not have propensity value\n";
      continue;
    }
    _res += stdRP[(*citR)->getName()];
  } 
  return _res;                   
}

const map<string, float>& 
ScoreRP::getStdRP() const {
  return stdRP;
}


