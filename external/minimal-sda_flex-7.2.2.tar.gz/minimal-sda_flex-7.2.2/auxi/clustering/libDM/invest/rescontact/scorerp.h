//-------------------------------------------------------------------
/*! \file .h

*/
//-------------------------------------------------------------------

#ifndef SCORERP_H
#define SCORERP_H

#include <map>
#include <string>
using namespace std;
class Residue;

class ScoreRP {
  public:
    ScoreRP() {}
    
    void loadStdRP(const map<string, float>& stdRP_);
    void loadStdRP(const vector<string>& resMap_,
                   const vector<float>& rp_);
    float scoreRP(const vector<const Residue*>& r1_,
                  const vector<const Residue*>& r2_) ;
    const map<string, float>& getStdRP() const ;
  private:
    map<string, float> stdRP;
};

#endif

