//-------------------------------------------------------------------
/*! \file access.cpp
    \brief Classes for surface accessibility calculations

    by D.M. EML Research
*/
#include <iostream>
#include <cassert>

#include "molgrid.h"
#include "commonfoo.h"
#include "access.h"
#include "mathstuff.h"

using namespace std;

inline void stripString(string& s_in) {
  const string from = " ";
  const string to = "";
  size_t search_here = 0;
  size_t found_here;
  while ((found_here = s_in.find(from, search_here)) != string::npos){
    s_in.replace(found_here, 1, to);
    search_here = found_here;
  }
}

//_____________________AccessAtom____________________________________
AccessAtom::AccessAtom(const MolGridR& mgr_, float probe_, float zsl_) {
  mgr = &mgr_;
  acc = new float[mgr->getAtomNumb()];
  atomNumb = mgr->getAtomNumb();
  
  probe = probe_;
  zSlice= zsl_;
  //cout << "AccessAtom constructor" << endl;
}

AccessAtom::~AccessAtom() {
  delete[] acc;
  //delete   mgr;
  //cout << "AccessAtom destructor" << endl;
}

void
AccessAtom::makeAcc() {
  // get pointers to frequently used stuff
  const Uint*  i = mgr->getI(); // array of grid cell indices for each atom
  const float* x = mgr->getX();
  const float* y = mgr->getY();
  const float* z = mgr->getZ();
  const float* r = mgr->getR();  // radii with probe if necessery
  const float* r2= mgr->getR2(); //
  const float* rr= mgr->getRR(); //
  const int _atomNumb = mgr->getAtomNumb(); // 
    
  float res = static_cast<Uint>(1.0 / zSlice + 0.5);
  //11111111111111111111111111111111111111111111111111111111111111111
  //   each atom 
  //11111111111111111111111111111111111111111111111111111111111111111
  for (int a = 0; a < _atomNumb; ++a) {
    float area = 0.0f;
   
    // resolution steps for this atom
    float zStep = r2[a] / res; // z section step size
    float zPoint= z[a] - r[a] - zStep / 2; // this step coord
      
    // get neighbors
    int neighbors[27], nn; // nn->number of neighbor cells
    nn = mgr->findNeighborCells(i[a], neighbors);
    sortArrayA(neighbors, nn); // DM Issue inline this maybe?
    
    // get atoms in neighbor cells, excluding this atom ('a')
    Uint nAtoms[NNATOM], nnAtoms; // nnAtoms-> number of atoms around
    nnAtoms = mgr->findAtomsInCellsNotThis(neighbors, nn, nAtoms, a); 
   
    // if no atoms in neighborhood calculate area for this atom already
    if (nnAtoms == 0) {
      acc[a] = cpi2*r2[a]*r[a];
      continue; // go for another atom
    }  
    
    // get squered distances and distances between 
    // this and neighbor atoms in 2d xy plane, by Pitagor
    float ddXY[nnAtoms], dXY[nnAtoms];
    makeDistToNeighbors(nAtoms, nnAtoms, a, ddXY, dXY);

    // this switch to go out for another atom needed later...
    bool goOut = false;
    
    //222222222222222222222222222222222222222222222222222222222222222
    //   each Z section
    //222222222222222222222222222222222222222222222222222222222222222
    for (int s = 0; s < res; ++s) {
      zPoint += zStep;

      // squered radii of circle of this atom at this section 
      float rrZA = rr[a]-(zPoint- z[a])*(zPoint-z[a]);
      // radii of circle of this atom at this section
      float rZA = sqrt(rrZA);    
      
      // arrays for intersection anglFrom anglTo
      float arcPoint1[ARCPN], arcPoint2[ARCPN];
      int arcPointN = 0;
      
      //3333333333333333333333333333333333333333333333333333333333333
      //    each neighbor atom
      //3333333333333333333333333333333333333333333333333333333333333   
      for (int n = 0; n < nnAtoms; ++n) {     
        
        // squered radii of circle of neighbor atom at this section
        float rrZN = rr[nAtoms[n]] -   
                     (zPoint-z[nAtoms[n]])*(zPoint-z[nAtoms[n]]);
        
        // is neigbor not at this plane anyway?
        if (rrZN <= 0.0f) {       
          continue; // go for another neighbor atom
        }
        // radii of circle of neighbor atom at this section  
        float rZN = sqrt(rrZN);
        
        // if this and neighbor atoms do not intersect
        if (dXY[n] >= rZA + rZN) {
          continue; // go for another neighbor atom
        }
        // if one atom is inside the other
        if (dXY[n] <= abs(rZA-rZN)) {  
          // if at this intersection atom is completely covered anyway
          // then accessibility from here is 0.0, go for another atom
          if (rZA - rZN <= 0.0f) {
            goOut = true; // imidietly continue in #2 loop 
            break;
          } else {
            continue; // go for another neighbor atom
          }
        }
       
        // apply low of cos to find angle between line connecting
        // two centers of cycles and radii to starting intersection point 
        float cosA = (ddXY[n]+rrZA-rrZN)/(2.0f*dXY[n]*rZA);
        
        // angle between center of circles and line from center to intersect
        float anglA = safeAcos(cosA); // stay in cos domain(-1:1)
        
        // angle between centers of circles and x axis
        // it is in the range [0:2pi]
        float anglB = atan2(y[a]-y[nAtoms[n]], x[a]-x[nAtoms[n]]) + cpi;
       
        // now make angles to start and end points of intersection
        float anglFrom = anglB - anglA;
        float anglTo   = anglB + anglA;
         
        if (anglFrom < 0.0f) anglFrom += cpi2;
        if (anglTo > cpi2) anglTo -= cpi2;
        
        // if intersection arc crosses 0 so it will be devided into 2 parts
        if (anglTo < anglFrom) {
          // From to cpi2;
          arcPoint1[arcPointN] = anglFrom; 
          arcPoint2[arcPointN] = cpi2;     
          ++arcPointN;
          // 0 to To
          arcPoint1[arcPointN] = 0.0f;  
          arcPoint2[arcPointN] = anglTo;         
          ++arcPointN;
        } else {
          arcPoint1[arcPointN] = anglFrom;        
          arcPoint2[arcPointN] = anglTo;        
          ++arcPointN;
        }
      } // n neighbor atoms
      //3333333333333333333333333333333333333333333333333333333333333   
      // means the atom is completely covered in this section anyeay
      if (goOut) { 
        goOut = false;
        continue; // go for another z section
      }
      
      // DM Issue inline this maybe?
      sortTwoPairedArraysA(arcPoint1, arcPoint2, arcPointN);
      
      // arcSum of all neighbor atoms at this z section
      float arcSum = 0.0f;

      // only one atom intersects at this Z section
      if (arcPointN == 1) {
        arcSum = arcPoint1[0] + cpi2 - arcPoint2[0];
      }
      // more then one atom intersects at this z section
      else if (arcPointN > 0) {
        arcSum = arcPoint1[0];
        float _tmp = arcPoint2[0];
        for (int _i = 1; _i < arcPointN; ++_i) {
          if (_tmp < arcPoint1[_i])
            arcSum+= arcPoint1[_i] - _tmp;
          if (arcPoint2[_i] > _tmp)
            _tmp = arcPoint2[_i];
        }
        arcSum += cpi2 - _tmp;    
      } 
      else { // no atoms intersect at this section
        arcSum = cpi2;
      } 
          
      // total acc area at this section
      area += arcSum * zStep;     
    } // z section
    //222222222222222222222222222222222222222222222222222222222222222
    
    // add final surface accessible area of this atom
    acc[a] = area * r[a];
  } // a atom
  //11111111111111111111111111111111111111111111111111111111111111111
}

void
AccessAtom::makeDistToNeighbors(const Uint* nAtoms_, 
      const Uint nnAtoms_, const int a_, float* ddXY_, float* dXY_) const {
  float _dx, _dy, _t;
  const float* x = mgr->getX();
  const float* y = mgr->getY();
  for (int q = 0; q < nnAtoms_; ++q) {
    _dx =  x[a_]-x[nAtoms_[q]];
    _dy =  y[a_]-y[nAtoms_[q]];
    _t = _dx*_dx + _dy*_dy;
    ddXY_[q] = _t;
    dXY_[q]  = sqrt(_t);
  }
}    

