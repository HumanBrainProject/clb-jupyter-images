/*! \file access.h
    \brief Classes for surface accessibility calculation
    
    by D.M. EML Research
*/
#ifndef ACCESS_H
#define ACCESS_H

class MolGridR;
/*! \brief Surface accessibility calculation for each atom.

    This class is to callculate suface accessibility for each atom 
    in a molecule. It works like NACCESS.
    
    HOWTO:
    First you need to prepare MolGridR object (see MolGrid and MolGridR
    documentation). Construct this class by supplying ready MolGridR 
    object, probe (1.4 default) and zSlice (the resolution of calculation).
    Then run 'makeAcc()' method. Atom accessibilies will be stored in data
    member 'acc'.
    !!!NOTE!!! don't forget to add the probe if you need any in MolGridR
               object already.
    
    The precission of calculation depends on 'ZSLICE' 0.05 by default
    gives 1.0 / zSlice + 0.5 == 20 sections along Z axis for each atom.
    Default probe is 1.4. Both these can be specified upon construction or
    changed with 'setProbe', 'setZSlice' methods.
    
    DM TODO & Issues:
      ->see in MolGridR
    
    by D.M. EML Research 2006.03.03
    V 0.2
    -> moved from std containers to pure array:-) much faster now
*/
class AccessAtom {
  public:
    typedef unsigned int Uint;
    /*! Construc by providing MolGridR object instance, probe and zSlice 
        'mgr_'   -> MolGridR object
        'probe_' -> probe
        'zsl_'   -> Z slice */
    AccessAtom(const MolGridR& mgr_, float probe_ = 1.4f, 
                                     float zsl_ = 0.05f);    
    ~AccessAtom();
    
    /*! This calculates the accessibility for each atom. It's kindda long
        and complicated, have a look at implementation and comments there.
        Briefly:
          1st iterates over all atom
          2nd iterates over each Z section for this atom
          3nd iterates over each neighboring atom at this section
        In all these iteration surface accessible area for the particular 
        atom is callculated and stored in data member acc. */
    void makeAcc();
    /*! This calculates the squered distance and distance in 2d XY plane
        from atom 'a_' to every atom in 'nAtoms_' array and stores these 
        distances in 'ddXY_' and 'dXY_' respectively.
          nAtoms_  -> array of atoms to calculate distance to 
          nnAtoms_ -> size of array 'nAtoms_', 'dXY_' and 'ddXY_'
          a_       -> atom to calculate distance from to:-)
          ddXY_    -> array to store squered distances from 'a_' to all 
                      'nAtoms_'
          dXY_     -> array to store distances from 'a_' to all 'nAtoms_'
    */
    void makeDistToNeighbors(const Uint* nAtoms_, const Uint nnAtoms_,
                       const int a_, float* ddXY_, float* dXY_) const;
    void setProbe(float probe_ = 1.4f) {probe = probe_;}
    void setZSlice(float zsl_ = 0.05f) {zSlice = zsl_;}
    
    const float* getAcc() const {return acc;}
    int getAtomNumb() const {return atomNumb;}
    const MolGridR* getMolGridR() const {return mgr;} 
  private:
    AccessAtom(const AccessAtom& other);
    AccessAtom& operator=(const AccessAtom& other);
    
    
    /* dynamically allocated array to store atom accessibilities */
    float *acc;
    int atomNumb;
    
    const MolGridR *mgr;
    
    float probe, zSlice;
    
    //!!!!!!!! these if too small will cause seffals, the problem is in
    // MolGrid methods findAtomsInCells and findAtomsInCellsNotThis
    // might be usefull to pus some exceptions there for this?...
    /*! this const is for array size for neighboring atoms */
    static const int NNATOM = 500;
    /*! this const is for array size for number of crossing arcpoints */
    static const int ARCPN = 500;
};


#endif


