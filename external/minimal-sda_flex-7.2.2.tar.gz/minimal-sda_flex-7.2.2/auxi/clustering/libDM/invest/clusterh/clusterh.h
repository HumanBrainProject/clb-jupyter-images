//____________________________________________________________________
//
// clusterh.h
//
// This is for implementation of hierarchical clustering procedure.
// Bsically you provide a vector containing (half) of initial distance
// matrix, it should look like this: if N = 4 ([1,2], [1,3], [1,4],
// [2,3], [2,4], [3,4]). Then run clustering cycles until y'end up
// with one.
//
// Inplementations:
//  Distance calculation -> unweighted average linkage
//  Spread penalty calc to find cycle with most compact clusters
//
//
// Version 0.1 2005.06.30
// by D.M.
//____________________________________________________________________

#ifndef CLUSTERH_H
#define CLUSTERH_H

#include <vector>
using namespace std;

class Cluster{
// store your clusters int this class, it basically have a list of
// numbered members (vector<int>members) which belong to this cluster
	public:
	// DB DB
		void who() const;
		void printValues() const;
		void visualizeMe() const;
	// CNSTRUCT
		Cluster(int _i);
		Cluster(vector<int>);
	// GET
		int getMemberNum() const;
		const vector<int>* getMembers() const;

	// IS
		bool isEmpty() const;
	// OPERATOR
		Cluster operator+(const Cluster&) const;
	private:
		vector<int> members;

};

class Group{
// a group is an object which has a distance (val) between two
// particular clusters (cl1, cl2), so these objects make up
// a distance matrix during the clustering
	public:
		Group(const Cluster* cl1_, const Cluster* cl2_, float val_):
			cl1(cl1_), cl2(cl2_), val(val_) {}
		Group(Cluster* cl1_, Cluster* cl2_, const float val_):
			cl1(cl1_), cl2(cl2_), val(val_) {}
	// GET
		const Cluster* getCl1() const;
		const Cluster* getCl2() const;
		float getVal() const;
	private:
		const Cluster* cl1;
		const Cluster* cl2;
		float val;
};

class ClusterEngine{
// this one manages clusters and groups and does all the management
// and clustering
		struct Cycle{
		// this stores info about each cycle of clustering
		// so y'can recover the situation:-) at each cycle
			int id;		// cycle number
			int clNum;	// number of clusters
			float avgSp;	// average spread
			float avgSpNorm;// normalized
			float penalty;  // penalty
			float thresh;	// closest distance between groups here
			vector<Cluster> clusters; // clusters at this cycle
		};
	public:
	// DB DB
		void who() const;
		void printCurrentGroups() const;
		void printCurrentClustersAddVal() const;
		void printInitMatrix() const;
		void printInitMatrixAddress() const;
		void printCurrentMatrix() const;
		void printCurrentMatrixAddress() const;
		void printCurrentMatrixClustersAddresses() const;
		void printCycleInfo() const;
		void printCycleInfo(const Cycle*) const;
		void printCycleLook(const Cycle*) const;
	// INIT
		void initClusters(int);
		void initGroups(const vector<float>&);

	// GET
		float getInitGroupVal(const int*, const int*) const;
		// extract distance value from initial distance matrix
		int   groupNum() const;
		int   clusterNum() const;
		const Cycle* getBestCycle() const;
		const Cycle* getThatCycle(float) const;
		vector<int> getRepresentatives( const vector<Cluster>*) const;
		// best cycle is with smallest penalty
	// DO
		const Group* findClosest();
		void mergeClusters(const Group*);
		void recalculateGroups(unsigned int distType = 1);
		// reclaculates distance matrix for new clusters
		float getDist(const Cluster*, const Cluster*, unsigned int);
		// calculated cluster cluster distance with requested algorithm
		void makeSpread();
		void normalizeAvgSp();
		void calcPenalties();
	private:
		void addCycle(float);
		// calc. average spread at eac cycle
		float distAverageLinkage(const Cluster*, const Cluster*) const;
		float distSingleLinkage(const Cluster*, const Cluster*) const;
		float distCompleteLinkage(const Cluster*, const Cluster*) const;

		// unweighted average linkage distance calculation
	// members:
		vector<Cycle>		cycles;
		vector<Cluster>		clusters;
		vector<Group>		groups;
		vector<Group> 		iniGroups;
		int n;
		//float currentThresh; //this holds current closest distance
};

#endif


//____________________________________________________________________
// e.g. of usage
//
// cluE = new ClusterEngine;
// cluE->initClusters(N);
// cluE->initGroups(distance_matrix);
// while(cluE->clusterNum() > 1){
// 	cluE->mergeClusters(cluE->findClosest());
//	cluE->recalculateGroups();
// }
// cluE->normalizeAvgSp();
// cluE->calcPenalties();
//
//

