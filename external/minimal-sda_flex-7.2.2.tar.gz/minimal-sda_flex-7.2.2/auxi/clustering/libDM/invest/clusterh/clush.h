//-------------------------------------------------------------------
/*! \file clush.h
    \brief Hierarchical clustering.
//
// What:
// This set of classes is to do clustering, store clustering data
// and do some analysis on clustering process and results.
// 
// HowTo:
    construct:
      ClusterEngine clusterEngine;
      clusterEngine.setClusters(numberOfDataPoints);
      clusterEngine.setGroups(halfMatrixOfDistancesBewteenDataPoints);
    cluster:
      while(clusterEngine.getClusterNumb() > 1) {
        clusterEngine.runClusteringCycle();
      }
//
// by D.M. EML Research
// V0.1
*/
//-------------------------------------------------------------------

#ifndef CLUS_H
#define CLUS_H

#include <vector>
#include "storage.h"


typedef unsigned int Uint;
class ClusterInvest;
class Cycle;
//-------------------------------------------------------------------
/*! \brief Holds the Cluster.

  Cluster class holds vector<int> which contains members of this 
  cluster. Also some methods to do operation or get info about these
  members. This class can be stored.
*/
class Cluster: public Storage {
  public:
    Cluster() {}
    explicit Cluster(int num_);
    Cluster(vector<int> nums_);
    Cluster(const Cluster& clust_);
    Cluster(Reader& reader_);
    ~Cluster() {}
    
    Cluster& operator= (const Cluster& clust_); // this = other
    Cluster  operator+ (const Cluster& clust_) const;
    bool     operator==(const Cluster& clust_) const;
    bool     operator<(const Cluster& clust_) const;
    
    /*! returns the average of some properties of members in this
        cluster prop_ is a vector of properties for all members, this 
       methods finds only members that belong to this cluster
    */
    float getPropAvg(const vector<float>& prop_) const;
    /*! returns the standard deviation of some properties of members in 
        this cluster
    */
    float getPropStdDeviation(const vector<float>& prop_) const;
    /*! returns the average of some property like 'getPropAvg', 
        plus in addition freq_ vector is provided which
        holds number of occurancies of some property for some member,
        so each property for a particular member is multiplied by its
        occurancy, and total number of members are scaled up accordingly
    */
    float getFPropAvg(const vector<float>& prop_,
                      const vector<int>& freq_) const;
    float getFPropStdDeviation(const vector<float>& prop_,
                      const vector<int>& freq_) const;
    // returns the sum of some properties in this cluster
    Uint  getPropSum(const vector<int>& prop_) const;
    float getAvgDistance(const ClusterInvest* clInv, int num_,const vector<int>& occ_) const;
    float getStdOfCluster(const ClusterInvest* clInv, int num_,const vector<int>& occ_) const;
    float getMaxDist(const ClusterInvest* clInv, int num_,const vector<int>& occ_) const;
    std::string getDetails(
    		const vector<float>& ele_, //change input TotE
    		const vector<int>& occ_,
    		const vector<float>& eleAv, //name wring getElecC was ent, now realy EleE
     		const vector<float>& eLj,
    		const vector<float>& rmsd,
    		const ClusterInvest* clInv, int num_) const;
    const vector<int>* getMembers() const;
    unsigned int getSize() const;
    // describes how this class has to be stored
    void storageWrite(Writer& write);
  private:
    // here members are stored 
    vector<int> members;
};
//-------------------------------------------------------------------
/*! \brief Holds distance between two clusters.

  Groups class holds pointers to two clusters with distance value
  between them. It is used to store distances between cluseters during
  hierarchical clustering procedure. 
*/
class Group {
  public:
    Group() {};
    Group(const Cluster* cl1_, const Cluster* cl2_, float val_):
          cl1(cl1_), cl2(cl2_), val(val_) {}
    Group(const Group& group_);
   
    Group& operator=(const Group& group_);
    
    float getVal() const;
    const Cluster* getCluster1() const;
    const Cluster* getCluster2() const;
  private:
    const Cluster* cl1;
    const Cluster* cl2;
    float val; //distance between clusters
};
//-------------------------------------------------------------------
/*! \brief Holds all info about particular clustering cycle.

  Cycle class stores clustering pattern at particular cycle of clustering.
    id        - is number of cycle during the clustering, 
    thresh    - is closest distance between two clusters at this cycle 
    clusters  - vector of Cluster objects
  The class is storable
*/
class Cycle: public Storage {
  public:
    Cycle() {}
    Cycle(const Cycle& cycle_);
    Cycle(Reader& reader_);
    ~Cycle() {}
    
    Cycle& operator=(const Cycle& cycle_);
    bool   operator==(const Cycle& cycle_) const;
    
    // set methods used to create this object
    void setId(unsigned int cycleNumb_);
    void setThresh(float val_);
    void setClusters(const vector<Cluster>& clusters_);
    // get methods
    int getId() const;
    unsigned int getClusterNumb() const;
    std::string distanceBetweenClusters(const ClusterInvest* clInv) const;
    float getThresh() const;
    const vector<Cluster>* getClusters() const;
    // sorts clusters from largest to smallest in this cycle
    void sortClusters();    
    // describes how Cycle has to be stored
    void storageWrite(Writer& writer_);                               
  private:
    int id;                    // cycle number
    float thresh;              // closest distance between groups here
    vector<Cluster> clusters;  // clusters at this cycle
};
//-------------------------------------------------------------------
/*! \brief Main engine which does clustering.

  ClusterEngine class is used to do actual clustering. Methods of this
  class shoul be used to load prepare data necessary for clustering and
  do the actual clustering. 
  Initially it stores initial groups, that is actually half matrix of 
  distances between each member in data which is being clustered.
  During the clustering it stores vector of current clusters and groups.
  At the end of the clustering all cycles of clustering that were carried
  out, are stored.
  HOWTO
    construct:
      ClusterEngine clusterEngine;
      clusterEngine.setClusters(numberOfDataPoints);
      clusterEngine.setGroups(halfMatrixOfDistancesBewteenDataPoints);
    cluster:
      while(clusterEngine.getClusterNumb() > 1) {
        clusterEngine.runClusteringCycle();
      }
*/
class ClusterEngine {
  public:
    ClusterEngine(){}
    ClusterEngine(const ClusterEngine& clustEng_);
    ~ClusterEngine() {}
    ClusterEngine& operator=(const ClusterEngine& clustEng_);
    // set methods, you need number of items and halfMatrix of distances
    // between them
    void setClusters(int num_);
    void setGroups(const vector<float>& halfMatrix_);
    // get methods
    const vector<Cluster>* getClusters() const;
    const vector<Group>*   getGroups() const;
    const vector<Group>*   getInitGroups() const;
    const vector<Cycle>*   getCycles() const;
    unsigned int           getProteinNumb() const;
    unsigned int                 getClusterNumb() const;
    // use this method to do one clustering cycle
    // distType_ switch is used for different type of distance
    // calculation between clusters
    void runClusteringCycle(unsigned int distType_ = 1);
    // this method describes how ClusterEngine has to be stored on disk
    void storeClusteringData(Writer& writer_);
    float getInitGroupVal(const int* i1_, const int* i2_) const;
    unsigned int    proteinNumb;  // stored 1st
  private:
    // finds closest clusters and returns pointer to the Groups containing
    // these clusters
    const Group* findClosest();
    // merges clusters in the group_ and updates cluster member of this
    // !! leaves empty groups members so those has to be recalculated 
    // before next clustering cycle
    void mergeClusters(const Group* group_);
    // use this to recalculate groups member after two clusters were merged
    void recalculateGroups(unsigned int distType_ = 1);
    // this adds a new cycle at the end of cycle vector
    void addCycle(float distVal_);
    // gets distance between two clusters with specified method
    float getDist(const Cluster& clu1_, const Cluster& clu2_,
                  unsigned int distType_ = 1) const;
    // this gets distance between data point in initial set
    float distAverageLinkage(const Cluster& clu1_, const Cluster& clu2_) const;
    float distQuadraticLinkage(const Cluster& clu1_, const Cluster& clu2_) const;
    float distMaxLinkage(const Cluster& clu1_, const Cluster& clu2_) const;
    float distMinLinkage(const Cluster& clu1_, const Cluster& clu2_) const;
    // members
    vector<Cycle>   cycles;       // stored 2nd
    vector<Cluster> clusters;
    vector<Group>   groups;
    vector<Group>   initGroups;   // stored 3rd !!! as vector<float>
};
//-------------------------------------------------------------------
/*! \brief Analyzis of the clustering process and results.

  Construct this class from ClusterEngine directly or load from stored 
  objects. Use it to do various analyzis of clustering process and results.
  
*/
class ClusterInvest: public Storage {
  public:
    ClusterInvest(): proteinNumb(0) {}
    ClusterInvest(const ClusterInvest& clusterInvest_);
    ClusterInvest(const ClusterEngine& clusterEngine_);
    ClusterInvest(unsigned int proteinNumb_, const vector<Cycle>& cycles_);
    ClusterInvest(Reader& reader_); 
    ClusterInvest& operator=(const ClusterInvest& clusterInvest_); 
  

    
    //! get data set spread
    // Finds the representative in whole data set, and then 
    // finds the average distance of other data points from this
    /// 'representative' data point.
    float getDataSpread() const;
      
    unsigned int         getProteinNumb() const;
    unsigned int         getCycleNumb() const;
    const vector<Cycle>* getCycles() const;
    const vector<float>* getHalfMatrix() const;
    const Cycle* getCycleWithNumbOfClusters(unsigned int clustNumb_) const;
    //! get cycle number during clustering
    const Cycle*         getCycle(unsigned int cycleNumb_) const;
    const Cycle*         getCycle(int cycleNumb_) const;
    //! cycle closest to provided (distance) value
    const Cycle*         getCycle(float val_) const;
    const Cycle*         getCycle(double val_) const;
    /*!
    // recover numb_ of representatives from cycle cycle_, where 
    // size of cluster is not less then size_
    */
    Uint                 getRepr(const Cluster* clust_) const;
    // DMIssue maybe deprecated?
    vector<int>          getClustReprList(const Cycle* cycle_, 
                                          unsigned int numb_ = 999,
                                          unsigned int size_ = 5) const; 
    vector<float>        getClustSpreadList(const Cycle* cycle_,
                                          unsigned int numb_ = 999,
                                          unsigned int size_ = 5) const;
    // PRINT
    void printCycleDataFrom(unsigned int cycles_ = 0) const;
    void printClustDataAtCycle(
         const Cycle*         cycle_,
         const vector<int>*   occur_,
         const vector<float>* elE_,
         const vector<float>* avgElE_,
         const vector<float>* rmsds_,
                        Uint  num_ = 0,
                        Uint  size_ = 5) const; 
    void printBinLog(int printFrom_ = 0, int binNumb = 1000) const;
    /*!
    // approx visualization of clusters max cluster is shown as 60 '='
    // characters the res are adjusted relatively
    */
    void visualizeClustAt(const Cycle* _cycle) const;
    void storageWrite(Writer& writer_);
    
    float getDistBetweenComplexes(unsigned int member1_,
                                   unsigned int member2_) const;
   private:
    void printCycleData(vector<Cycle>::const_iterator citerFrom_,
                        vector<Cycle>::const_iterator citerTo_) const;
    float getPercentiveDiff(vector<Cycle>::const_iterator& _item) const;
    unsigned int getMinCluster(vector<Cycle>::const_iterator& _item) const;
    unsigned int getMaxCluster(vector<Cycle>::const_iterator& _item) const;
    float getAvgCluster(vector<Cycle>::const_iterator& _item) const;
    
    unsigned int  proteinNumb;
    vector<Cycle> cycles;
    vector<float> halfMatrix;
  
};
//-------------------------------------------------------------------

#endif

