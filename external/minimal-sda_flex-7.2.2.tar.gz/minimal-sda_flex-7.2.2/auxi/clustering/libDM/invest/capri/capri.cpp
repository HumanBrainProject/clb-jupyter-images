//*******************************************************************
//-------------------------------------------------------------------
/*! \file capri.cpp

*/
#include <iostream>
#include <vector>
#include <string>

#include "amberfiles.h"
#include "pdbfile_2.h"
#include "capri.h"
#include "vector3.h"


inline float dist2(const Vector3& v1, const Vector3& v2){
        float dx = v1.x - v2.x;
        float dy = v1.y - v2.y;
        float dz = v1.z - v2.z;
        return dx*dx + dy*dy + dz*dz;
}


namespace libDM_capri {
using libDM_molecule::PdbFile;
using libDM_molecule::PdbLine;
using libDM_molecule::PdbResidueId;
using std::vector;
using std::string;
using std::pair;
using std::cout;



// 1 --------------------------------------------------------------->
void 
getResiduesInContact(const PdbFile& pdbFile1_,
                     const PdbFile& pdbFile2_,
        vector<pair<PdbResidueId, PdbResidueId> >& resInCont_, float dist_) {
  
  float DIST2 = dist_ * dist_;
  PdbResidueId _last1, _last2;
  for (vector<PdbLine>::const_iterator 
       cit1  = pdbFile1_.getPdbLines()->begin();
       cit1 != pdbFile1_.getPdbLines()->end(); ++cit1) {
    for (vector<PdbLine>::const_iterator
         cit2  = pdbFile2_.getPdbLines()->begin();
         cit2 != pdbFile2_.getPdbLines()->end(); ++cit2) {
      if (dist2(*cit1->getCoord(), *cit2->getCoord()) <= DIST2) {
        _last1.name  = *cit1->getResName();
        _last1.numb  = *cit1->getResSeq();
        _last1.chain = *cit1->getChainID();
        _last1.iCode = *cit1->getICode();
        
        _last2.name  = *cit2->getResName();
        _last2.numb  = *cit2->getResSeq();
        _last2.chain = *cit2->getChainID();
        _last2.iCode = *cit2->getICode(); 
        
        pair<PdbResidueId, PdbResidueId> _pair;
        _pair.first = _last1;
        _pair.second= _last2;
        
        if (find(resInCont_.begin(), resInCont_.end(), _pair) ==
            resInCont_.end() ) {
          resInCont_.push_back(_pair);
        }  
      } // end of whole distance check if
    } // for 2
  } // for 1
}
     

// 2 --------------------------------------------------------------->
void 
makeInterfacePdbLines(
  const vector<pair<PdbResidueId, PdbResidueId> >& res_,
  const PdbFile& pf1_, const PdbFile& pf2_,
  vector<PdbLine>& pdbLinesP1_,
  vector<PdbLine>& pdbLinesP2_) {
  
  vector<PdbResidueId> _p1;
  vector<PdbResidueId> _p2;
  
                           
  vector<pair<PdbResidueId, PdbResidueId> >::const_iterator cit;
  
  for (cit = res_.begin(); cit != res_.end(); ++cit) {
    
    if (find(_p1.begin(), _p1.end(), cit->first) == _p1.end()) {
      _p1.push_back(cit->first);
    }   
    if (find(_p2.begin(), _p2.end(), cit->second) == _p2.end()) {
      _p2.push_back(cit->second);
    }  
  }

  // 1st protein
  for (vector<PdbResidueId>::const_iterator citRI = _p1.begin();
       citRI != _p1.end(); ++citRI) {  
    for (vector<PdbLine>::const_iterator citPL = pf1_.getPdbLines()->begin();
         citPL != pf1_.getPdbLines()->end(); ++citPL) {
      if (citRI->name == *citPL->getResName() and
          citRI->numb == *citPL->getResSeq() and
          citRI->chain== *citPL->getChainID() and
          citRI->iCode== *citPL->getICode() )
        pdbLinesP1_.push_back(*citPL);
    }      
  }
  
  // 2nd protein
  for (vector<PdbResidueId>::const_iterator citRI = _p2.begin();
       citRI != _p2.end(); ++citRI) {
    for (vector<PdbLine>::const_iterator citPL = pf2_.getPdbLines()->begin();
         citPL != pf2_.getPdbLines()->end(); ++citPL) {
      if (citRI->name == *citPL->getResName() and
          citRI->numb == *citPL->getResSeq()  and
          citRI->chain== *citPL->getChainID() and
          citRI->iCode== *citPL->getICode() )
        pdbLinesP2_.push_back(*citPL);
    }
  }

}                        

float 
getNatCont(const vector<pair<PdbResidueId, PdbResidueId> >& crB_,
           const vector<pair<PdbResidueId, PdbResidueId> >& crU_) {
  
  int correctContacts = 0;
  for (vector<pair<PdbResidueId, PdbResidueId> >::const_iterator citU =
       crU_.begin(); citU != crU_.end(); ++citU) {
    if (find(crB_.begin(), crB_.end(), *citU) != crB_.end()) {
      correctContacts += 1;
    }
  }
  //cout << correctContacts << " " << crB_.size() << " " << endl;
  return static_cast<float>(correctContacts) / 
         static_cast<float>(crB_.size());
                                              
}                         


                
char 
getCapriEval(float nc_, float rmsdFull_, float rmsdInter_) {
  
  if        (nc_ >= 0.5 and (rmsdFull_ <= 1.0 or rmsdInter_ <= 1.0)) {
    return 'H';
  
  } else if (((nc_ >= 0.3 and nc_ < 0.5) and
              (rmsdFull_ <= 5.0 or rmsdInter_ <= 2.0)) or 
             (nc_ >= 0.5 and rmsdFull_ > 1.0 and rmsdInter_ > 1.0))    {
    return 'M';
  
  } else if (((nc_ >= 0.1 and nc_ < 0.3) and
              (rmsdFull_ <= 10.0 or rmsdInter_ <= 4.0)) or
             (nc_ >= 0.3 and rmsdFull_ > 5.0 and rmsdInter_ > 2.0))  {
    return 'A';
  
  } else if (nc_ < 0.1 or (rmsdFull_ > 10.0 and rmsdInter_ > 4.0))   {
    return 'I';
  
  } else {
    return 'E';
  }
  
}                          
  
vector<pair<PdbResidueId, PdbResidueId> >                        
checkResidueMissmatch(const vector<pair<PdbResidueId, PdbResidueId> >&
                                                resInCont_,
                      const PdbFile& p1_, const PdbFile& p2_) {
  
  vector<pair<PdbResidueId, PdbResidueId> > res;  
                  
  for (vector<pair<PdbResidueId, PdbResidueId> >::const_iterator cit = 
       resInCont_.begin(); cit != resInCont_.end(); ++cit) {
    bool _first = false;
    for (vector<PdbLine>::const_iterator cit1 = p1_.getPdbLines()->begin();
         cit1 != p1_.getPdbLines()->end(); ++cit1) {
      if (cit->first == *cit1) {
        _first = true;
        break;
      }
    }
    
    bool _second = false;
    for (vector<PdbLine>::const_iterator cit2 = p2_.getPdbLines()->begin();
         cit2 != p2_.getPdbLines()->end(); ++cit2) {
      if (cit->second == *cit2) {
        _second = true;
        break;
      }
    }    
       
    if (_first and _second) {
      res.push_back(*cit);
    } 
    
    if (!_first) {
      cout << "Warning residue in protein 1 not found: "
           << cit->first.name << " " 
           << cit->first.numb << " "
           << cit->first.chain<< " "
           << cit->first.iCode<< endl; 
    }
    if (!_second) {
      cout << "Warning residue in protein 2 not found: "
           << cit->second.name << " "
           << cit->second.numb << " "
           << cit->second.chain<< " "
           << cit->second.iCode<< endl; 
    }
      
  }
  return res;          
}
                          
 
void 
makePdbFile(AmberTopFile& top_, AmberCrdFile& crd_, PdbFile& pdbFile_) {

  int atomNumb = top_.getFlag(AmberTopFile::NATOM);
  
  // get ref to vector<PdbLines>  
  vector<PdbLine>& plRef = pdbFile_.accessPdbLines();
  plRef.reserve(atomNumb);

  // get residue names
  vector<string> resNames; resNames.reserve(top_.getFlag(AmberTopFile::NRES)); 
  top_.getData(resNames, AmberTopFile::RESIDUE_LABEL);
  
  // get residue pointers
  vector<int> resPointers; resPointers.reserve(top_.getFlag(AmberTopFile::NRES));
  top_.getData(resPointers, AmberTopFile::RESIDUE_POINTER);
  
  // get atom names
  vector<string> atomNames; atomNames.reserve(atomNumb);
  top_.getData(atomNames, AmberTopFile::ATOM_NAME);
  
  // get coordinates
  vector<Vector3> atomCoords; atomCoords.reserve(atomNumb);
  crd_.getCoord(atomCoords);
   
  // construct PdbLines and push'em to teir vector  
  int resNumb = 0;
  // foreach atom
  for (int i = 0; i < atomNumb; ++i) {
    
    PdbLine _pl;
    
    _pl.setAtom(atomNames[i]);
    _pl.setCoord(atomCoords[i]);
    // if its not the last residue
    if (resNumb != resNames.size() -1) {
      // if this atom is in new residue
      if (i+1 >= resPointers[resNumb+1]) {
        ++resNumb;
      }
    }
    
    _pl.setResName(resNames[resNumb]);
    _pl.setResSeq(resNumb+1);
    
    // this is dummyly empty char ' ' ;)
    _pl.setChainID(' ');
    _pl.setICode(' ');
    plRef.push_back(_pl);
  }
}       




} // namespace libDM_capri


//-------------------------------------------------------------------
//*******************************************************************



