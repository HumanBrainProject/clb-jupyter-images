//--------------------------------------------------------------------//
// sdadata.cpp
//
//
//
//
//--------------------------------------------------------------------//
#include <iostream>
#include <vector>
#include <string>
#include <cassert>

#include "sdadata.h"
#include "../molecule/protein.h"
#include "../molecule/residue.h"
#include "../molecule/atom.h"
#include "../3d/vector3.h"

//---inlines--->
inline Vector3 crossProduct(const Vector3& v1, const Vector3& v2){
	return Vector3(v1.y*v2.z - v1.z*v2.y,
		       v1.z*v2.x - v1.x*v2.z,
		       v1.x*v2.y - v1.y*v2.x);
}

//===class===>
SdaData::SdaData(){init();}

void SdaData::init(){
	o100.x = 1.0f; o100.y = 0.0f; o100.z = 0.0f;
	o010.x = 0.0f; o010.y = 1.0f; o010.z = 0.0f;
	o001.x = 0.0f; o001.y = 0.0f; o001.z = 1.0f;
	state.centerP1 = 	false;
	state.centerP2 = 	false;
	state.p1 = 	 	false;
	state.p2 = 		false;
	state.fort55All = 	false;
	state.fort55One = 	false;
}
// building this object...
void SdaData::setCenterP1(Vector3 cen_){
	p1Cen = cen_;
	state.centerP1 = true;
}
Vector3 SdaData::getCenterP1(){
	return p1Cen;
}
void SdaData::setCenterP2(Vector3 cen_){
	p2Cen = cen_;
	state.centerP2 = true;
}
Vector3 SdaData::getCenterP2(){
	return p2Cen;
}
void SdaData::setP1(const Protein* p1_){
	p1 = p1_;
	state.p1 = true;
}
void SdaData::setP2(const Protein* p2_){
	p2 = p2_;
	state.p2 = true;
}
void SdaData::getFort55DataAll(vector<vector<float> > fort55_){
	fort55All = fort55_;
	state.fort55All = true;
}
void SdaData::getFort55DataOne(vector<float> fort55_){
	fort55One = fort55_;
	state.fort55One = true;
}
int  SdaData::getFort55LineNumber(){
	if (!state.fort55All){
		cout << "WARNING: no fort55 lines loaded" << endl;
		return 0;
	}
	return fort55All.size();
}
float   SdaData::getEnergyNum(int num_){
	--num_;
	return fort55All[num_][9];
}
Protein SdaData::getDockedNum(int num_){
	--num_;
	return	recover(fort55All[num_]);
}
Protein SdaData::getDockedAvg(){
	return	recover(fort55Avg);
}

void SdaData::makeFort55Avg(){
// gets average structure from whole fort55 file
	vector<float> _res;
	float _sum[] = { 0.0f, 0.0f, 0.0f,
	     		 0.0f, 0.0f, 0.0f,
			 0.0f, 0.0f, 0.0f,
			 0.0f};
	vector<vector<float> >::const_iterator citerVF;
	vector<float>::const_iterator citerF;
	int _tmp = 0;
	for (citerVF = fort55All.begin();
	     citerVF !=fort55All.end();
	     ++citerVF){
	     	_tmp = 0;
	     	for (citerF = citerVF->begin();
		     citerF !=citerVF->end();
		     ++citerF){
	     		_sum[_tmp] += *citerF;
			++_tmp;
		}
	}
	float _1overN = 1.0f / fort55All.size();
	for (int i = 0; i < 10; ++i){
		_res.push_back(_sum[i] * _1overN);
	}
	state.fort55Avg = true;
	fort55Avg = _res;
}

/*
vector<float> SdaData::makePairMatrix(){
	vector<float> _res;
	Protein *_p1, *_p2;
	int _ln = getFort55LineNumber();
	//int _ln = 10;
	_res.reserve((_ln * _ln - _ln) / 2);
	for (int i = 0; i < _ln; ++i){
		_p1 = new Protein(recover(fort55All[i]));
		for (int j = i + 1; j < _ln; ++j){
// DB			cout << "[" << i <<"," << j << "]" << " ";
			_p2 = new Protein(recover(fort55All[j]));
			_res.push_back(_p1->backbRmsd(_p2));
			delete _p2;
		}
		delete _p1;
	}
	return _res;
}
*/


vector<float> SdaData::makePairMatrix(int linNum_){
// optimized version of previous 
	vector<float> _res;
	Protein *_p1, *_p1Next, *_p2;
	int _ln = getFort55LineNumber();
	// consider only specified number of lines linNum_
	if (_ln > linNum_)
		_ln = linNum_;
	//int _ln = 10;
	_res.reserve((_ln * _ln - _ln) / 2);
	_p1 = new Protein(recover(fort55All[0]));
	for (int i = 1; i < _ln; ++i){
		//_p1 = new Protein(recover(fort55All[i]));
		_p1Next = new Protein(recover(fort55All[i]));
		_res.push_back(_p1->backbRmsd(_p1Next)); 
		for (int j = i + 1; j < _ln; ++j){
// DB			cout << "[" << i <<"," << j << "]" << " ";
			_p2 = new Protein(recover(fort55All[j]));
			_res.push_back(_p1->backbRmsd(_p2));
			delete _p2;
		}
		*_p1 = *_p1Next;
		delete _p1Next;
	}
	delete _p1;
	return _res;
}


Protein SdaData::recover(vector<float>& fort55_){
// makes docked protein conformation based on
// p1 and p2 centers, and fort55 line
	// this center
	Vector3 thisCen(fort55_[0], fort55_[1], fort55_[2]);
	// basis vectors return x and y form fort55 z crosproduced x y:-)
	Vector3 bX(fort55_[3], fort55_[4], fort55_[5]);
	Vector3 bY(fort55_[6], fort55_[7], fort55_[8]);
	Vector3 bZ(crossProduct(bX, bY));
	// transforming vectors
	Vector3 trX = trVector(o100, bX, bY, bZ);
	Vector3 trY = trVector(o010, bX, bY, bZ);
	Vector3 trZ = trVector(o001, bX, bY, bZ);
	// get new coordinate
	assert(isGood2GoState());
	Protein _res = *p2;
	vector<Residue>::iterator iterVR;
	vector<Atom>::iterator iterVA;
	// foreach residue
	for (iterVR = _res.residues.begin();
	     iterVR !=_res.residues.end();
	     ++iterVR){
		// foreach atom
		for (iterVA = iterVR->atoms.begin();
		     iterVA !=iterVR->atoms.end();
		     ++iterVA){
		     // transform each atom coordinates acordingly
			iterVA->coor =
				(trVector((iterVA->coor -= p2Cen), trX, trY, trZ)+
				p1Cen + thisCen);
		}
	}
	return _res;
}

bool SdaData::isGood2GoState() const{
	if (state.centerP1 && state.centerP2 &&
            state.p1       && state.p2)
     		return true;
 	return false;
}

Vector3 SdaData::trVector(Vector3& orig_,
			  Vector3& bx_, Vector3& by_, Vector3& bz_){
	bx_.normalize(); by_.normalize(); bz_.normalize();
	Vector3 _res(orig_ * bx_, orig_ * by_, orig_ * bz_);
	return _res;
}

