//-------------------------------------------------------------------
/*! \file sdafort55.h
    \brief Manipulate fort.55 file from SDA output
    
// USE CASES:
// extract fort.55 file column, recover proteins, calculate rmsd
// half matrix of proteins in fort.55 file
// 
// this stores the data from fort55, also protein1 and protein2 as
// simple PdbFileS1 objects. this can process the fort55 file
// restore protien conformations, generate half matrix for 
// clustering.
//
//
// by D.M. EML Research 2005.11
// V0.2 
// V0.1
*/
//-------------------------------------------------------------------
#ifndef SDAFORT55_H
#define SDAFORT55_H

#include <vector>

#include "pdbfile.h"
#include "pdbline.h"

using namespace std;
//class PdbFileS1;
//class PdbFile;

typedef vector<string>::const_iterator VStrCI;
typedef unsigned int Uint;
typedef long unsigned int LUint;


/*! \brief Encapsulates one line from fort.55 file.
  
  A line from fort.55 file can be loaded and stored in this class. It is then
  used in SDAFort55 class.
  
  DMIssue now there it works with old fort.55 files as well with 14 colums
  but eventually we shoul not need this check and make it work with only 16
  columns fort.55 file?
*/
class F55Line {
  public:
    F55Line(): trNumb(0), stNumb(0), center(0.0f, 0.0f, 0.0f),
               basisX(0.0f, 0.0f, 0.0f), basisY(0.0f, 0.0f, 0.0f),
               //just test
               totEnergy(0.0f),elE(0.0f),desE(0.0f), hyDe(0.0f), ljE(0.0f),
               occur(0), avgElE(0.0f), elEDisp(0.0f) { cout << "construct line" << endl;}
               // no time
               //elE(0.0f), desE(0.0f), time(0), occur(0), avgElE(0.0f),
               //elEDisp(0.0f) {}
               //just test

//    F55Line(const F55Line& f55Line_);
//    F55Line(const vector<string>& f55Strings_);
    F55Line(const string& line_);
    F55Line& operator=(const F55Line& f55Line_);
    Uint trNumb;      //column 1: trajectory number
    Uint stNumb;      //column 2: step in the trajectory
    Vector3 center;   //column 3-5: Coordinates of protein 2
    Vector3 basisX;   //column 6-8: Orientation of Protein 2 along x
    Vector3 basisY;   //column 9-11: Orientation of Protein 2 along y
    float totEnergy; //add not before
    float elE;        //column 12: electrostatic interaction energy of the complex
    float desE;       //column 13: electrostatic desolvation energy of the complex
    Uint time;        //column 16: simulation time of the complex
    Uint occur;       //column 17: Number of contacts satisfied reaction condition.
    float avgElE;     //column 18: Averaged energy over all contacts satisfied
    float elEDisp;    //column 19: StdDev of averated energy over all contacts satisfied
    float hyDe;       //column 14: hydrophobic desolvation energy
    float ljE;        //column 15: Leonard-Jones energy of the comples
    // comment michael, terms for surface, daria
    float coulEC;     //column 20: Coulomb electrostatic energy of the complex
    float surDC;      //column 21: surface desolvation energy of the complex
    float elecC;      //column 22: total electrostatic energy of the complex
  private:
    
   // bool operator==(const F55Line& f55Line_);   // for later
    /*! number of columns in fort.55 file */
    static const Uint columns;
    /*! */
    static const Uint items;
};

/*! \brief Store and manipulate SDA ouptut, fort.55 file

  Load fort.55 file lines (all ore some), also protein 1 and 2 pdbs. 
  Once constructed  number of operations can be performed, 
  e.g. analyze fort.55 columns, recover proteins, calculate rmsd half
  matrix for clustering, etc.
*/
class SDAFort55 {
  public:
    typedef vector<F55Line>::const_iterator VF55CI;
    SDAFort55() {}
    SDAFort55(const SDAFort55& sdaF55_);
    SDAFort55(const vector<string>& lines_);
    SDAFort55(const vector<string>& lines_,
              const PdbFileS1& p1_,
              const PdbFileS1& p2_);
    SDAFort55& operator=(const SDAFort55& sdaF55_);
    void setFort55All(const vector<string>&  fort55Data_);
    void setProtein2(const PdbFileS1& protein2_);
    void setProtein1(const PdbFileS1& protein1_);
    void setP1Center(const Vector3& c_) { p1Center = c_;}
    void setP2Center(const Vector3& c_) { p2Center = c_;}
   // void setProtein1(const PdbFile& protein1_);
   // void setProtein2(const PdbFile& protein2_);

    const PdbFileS1*       getProtein1() const;
    const PdbFileS1*       getProtein2() const;
    const vector<F55Line>* getFort55All() const;

    vector<int>   getOccurancies() const;
    //add michael
    vector<float> getTotEnergies() const;
    vector<float> getElEnergies() const;
    vector<float> getAvgElEnergies() const;
    vector<float> getRmsds() const;
    vector<float> getElEDisp() const;
    vector<float> getDesE() const;
    vector<float> getHyDe() const;
    vector<float> getLjE() const;
    // for surface
    vector<float> getCoulEC() const;
    vector<float> getSurDC() const;
    vector<float> getElecC() const;
    Uint          getFort55LineNumber() const;
    

    PdbFileS1 recoverProtein(const F55Line& f55Line_) const;
    /*!
    // makes half matrix of rmsds between docked structures in fort55
    // Parameters:
    // number of complexes to take from fort55
    // Return:
    // half matrix odered into vector of floats
    */
    vector<float> makePairHalfMatrix(Uint complexNumber_ = 500) const;
   
  private:
    // makes the translation of p2
    //vector<float> getF55Column(unsigned int) const;
    Vector3 trVector(Vector3& origin_,
                     Vector3& basisx_,
                     Vector3& basisy_,
                     Vector3& basisz_) const;
    
    PdbFileS1 p2, p1;
    Vector3 p1Center, p2Center;
  public:
    vector<F55Line> fort55All;
};



/*! \brief Store and manipulate SDA ouptut, fort.55 file

  Load fort.55 file lines (all or some), also protein 1 and 2 pdbs. 
  Once constructed  number of operations can be performed, 
  e.g. analyze fort.55 columns, recover proteins, calculate rmsd half
  matrix for clustering, etc.
  NOTE the difference from SDAFort55 is that here proteins are stored
  just as vecotrs of their coordinates nothing else:-)
*/
class SDAFort552 {
  public:
    typedef vector<F55Line>::const_iterator VF55CI;
    SDAFort552(): p1Center(0.0f, 0.0f, 0.0f), 
                  p2Center(0.0f, 0.0f, 0.0f) {}
    SDAFort552(const SDAFort552& sdaF55_);

    SDAFort552& operator=(const SDAFort552& sdaF55_);
    void setFort55All(const char* fileName_, int lineNumb_ = 500);
    void setFort55All(const vector<string>&  fort55Data_);
    void setProtein2(const vector<Vector3>& p2_);
    void setProtein1(const vector<Vector3>& p1_);
    void setCenter1(const Vector3& c1_);
    void setCenter2(const Vector3& c2_);

    const vector<Vector3>* getProtein1() const;
    const vector<Vector3>* getProtein2() const;
    const vector<F55Line>* getFort55All() const;
    const Vector3*         getP1Center() const;
    const Vector3*         getP2Center() const;
    
    vector<Vector3>& accessProtein1();
    vector<Vector3>& accessProtein2();
    
    vector<int>   getOccurancies() const;
    vector<float> getElEnergies() const;
    vector<float> getAvgElEnergies() const;
    vector<float> getElEDisp() const;
  //  vector<float> getRmsds() const;
    float         getRmsd(const vector<Vector3>& pr_) const;
    Uint          getFort55LineNumber() const;

    void recoverProtein(const F55Line& f55Line_, 
                        vector<Vector3>& pr_) const; 
    void recoverProtein(const F55Line& f55Line_,
                        vector<Vector3*>& pr_) const;
    /*!
    // makes half matrix of rmsds between docked structures in fort55
    // Parameters:
    // number of complexes to take from fort55
    // Return:
    // half matrix odered into vector of floats
    */
    vector<float> makePairHalfMatrix(Uint complexNumber_ = 500) const;
   
  private:
    // makes the translation of p2
    //vector<float> getF55Column(unsigned int) const;
    Vector3 trVector(Vector3& origin_,
                     Vector3& basisx_,
                     Vector3& basisy_,
                     Vector3& basisz_) const;
    vector<Vector3> p1;
    vector<Vector3> p2;
    Vector3 p1Center, p2Center;
    
  public:
    vector<F55Line> fort55All;
    vector<Vector3> allProteins;
};

void getFort55Lines(const char* fileName_, 
                  vector<string>& lines_, 
                  int lineNumb_ = 500);
Vector3 getCenter1FromFort55(const char* fileName_);
Vector3 getCenter2FromFort55(const char* fileName_);



// Commets:
// - maybe I should store p1 and p2 center since it may be called quite often
//   sometimes, and it takes a while to calculate
#endif
