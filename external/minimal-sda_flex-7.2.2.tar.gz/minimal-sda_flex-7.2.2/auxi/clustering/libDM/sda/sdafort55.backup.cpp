//-------------------------------------------------------------------
/*! \file sdafort55.cpp

*/
//
//
//
//
// by D.M. EML Research 2005.11
// V0.2 - F55Line class added to store fort55 file lines
// V0.1
//-------------------------------------------------------------------
#include <vector>
#include <cassert>
#include <iostream>
#include <fstream>

#include "sdafort55.h"
#include "commonfoo.h"
#include "atom.h"
#include "vector3.h"
using namespace std;


//*******************************************************************
// FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO  
// inlines
inline Vector3
crossProduct(const Vector3& v1, const Vector3& v2){
  return Vector3(v1.y*v2.z - v1.z*v2.y,
                 v1.z*v2.x - v1.x*v2.z,
                 v1.x*v2.y - v1.y*v2.x);
}
inline void 
splitLine(const string& str_,
          vector<string>& pieces_,
          const string& separators_){
// startPost first found "good" char of the token
// endPost first found "bad" char at the end of token
  string::size_type startPos = str_.find_first_not_of(separators_, 0);
  string::size_type endPos   = str_.find_first_of(separators_, startPos);
  while(endPos != string::npos || startPos != string::npos){
  // token found
    pieces_.push_back(str_.substr(startPos, endPos - startPos));
    startPos = str_.find_first_not_of(separators_, endPos);
    endPos   = str_.find_first_of(separators_, startPos);
  }
}
inline bool
myIsNan(float x) {
  return x != x;
}

// non_inlines
void
getFort55Lines(const char* fileName_, vector<string>& lines_,
             int lineNumb_) {
             
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return;
  }
  
  string _str;
  vector<string> _splitLine;
  lines_.reserve(lineNumb_);
  
  // iterate through file
  int _num = 0;
  while(!fin.eof()) {
    getline(fin, _str);
    // skip if line is a commnet or empty
    if (_str.substr(0, 1) == "#" or _str.length() == 0) 
      continue;
      
    _splitLine.clear();
    splitLine(_str, _splitLine);
    // break if it contains 0.000 'os fort55 specific:-)
    if (_splitLine[2] == "0.000" &&
        _splitLine[5] == "0.000" &&
        _splitLine[8] == "0.000")
      break;

    lines_.push_back(_str);
    ++_num;  
    // if already collected lineNumb_ number of lines, then break
    if (_num >= lineNumb_)
      break;
  }
  fin.close();
}


Vector3
getCenter1FromFort55(const char* fileName_) {
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return Vector3(0.0f, 0.0f, 0.0f);
  }
  
  string _str;
  vector<string> _splitLine;
  getline(fin, _str);
  splitLine(_str, _splitLine);
  fin.close();
  return Vector3(atof(_splitLine[1].c_str()), 
                 atof(_splitLine[2].c_str()),
                 atof(_splitLine[3].c_str()));
}

Vector3
getCenter2FromFort55(const char* fileName_) {
  ifstream fin(fileName_);
  if (!fin.is_open()) {
    cout << "ERROR: can't open file for reading: " << fileName_ << endl;
    return Vector3(0.0f, 0.0f, 0.0f);
  }
  
  string _str;
  vector<string> _splitLine;
  getline(fin, _str);
  getline(fin, _str);
  splitLine(_str, _splitLine);
  fin.close();
  return Vector3(atof(_splitLine[1].c_str()),
                 atof(_splitLine[2].c_str()),
                 atof(_splitLine[3].c_str()));
}

// FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO FOO 
//*******************************************************************





// class F55Line
const ::Uint F55Line::columns = 22;//17; 
const ::Uint F55Line::items   = 10;
// constructor
/*F55Line::F55Line(const F55Line& f55Line) {
  trNumb = f55Line.trNumb;
  stNumb = f55Line.stNumb;
  center = f55Line.center;
  basisX = f55Line.basisX;
  basisY = f55Line.basisY;
  elE    = f55Line.elE;
  desE   = f55Line.desE;
  time   = f55Line.time;
  occur  = f55Line.occur;
  avgElE = f55Line.avgElE;
  elEDisp= f55Line.elEDisp;
}
F55Line::F55Line(const vector<string>& f55Strings_) {
  trNumb   = atoi(f55Strings_[0].c_str());
  stNumb   = atoi(f55Strings_[1].c_str());
  center.x = atof(f55Strings_[2].c_str()); 
  center.y = atof(f55Strings_[3].c_str());
  center.z = atof(f55Strings_[4].c_str());
  basisX.x = atof(f55Strings_[5].c_str());
  basisX.y = atof(f55Strings_[6].c_str());
  basisX.z = atof(f55Strings_[7].c_str());
  basisY.x = atof(f55Strings_[8].c_str());
  basisY.y = atof(f55Strings_[9].c_str());
  basisY.z = atof(f55Strings_[10].c_str());
  elE      = atof(f55Strings_[11].c_str());
  desE     = atof(f55Strings_[12].c_str());
  time     = static_cast<LUint>(atof(f55Strings_[13].c_str()));
  occur    = static_cast<Uint>(atof(f55Strings_[16].c_str()));
  avgElE   = atof(f55Strings_[15].c_str());
  elEDisp  = atof(f55Strings_[14].c_str());
  if (myIsNan(elEDisp))
     elEDisp = 0.0;
}*/
F55Line::F55Line(const string& line_) {
  //cout << "constructor F55Line const string& line_ " << endl;
  vector<string> _f55Strings; 
  _f55Strings.reserve(columns);
  splitLine(line_, _f55Strings);
  //assert(_f55Strings.size() == columns);
  trNumb   = atoi(_f55Strings[0].c_str());
  stNumb   = atoi(_f55Strings[1].c_str());
  center.x = atof(_f55Strings[2].c_str()); 
  center.y = atof(_f55Strings[3].c_str());
  center.z = atof(_f55Strings[4].c_str());
  basisX.x = atof(_f55Strings[5].c_str());
  basisX.y = atof(_f55Strings[6].c_str());
  basisX.z = atof(_f55Strings[7].c_str());
  basisY.x = atof(_f55Strings[8].c_str());
  basisY.y = atof(_f55Strings[9].c_str());
  basisY.z = atof(_f55Strings[10].c_str());
  elE      = atof(_f55Strings[11].c_str());
  desE     = atof(_f55Strings[12].c_str());
  hyDe     = atof(_f55Strings[13].c_str());
  ljE      = atof(_f55Strings[14].c_str());
  time     = static_cast<Uint>(atof(_f55Strings[15].c_str()));
  occur    = static_cast<Uint>(atof(_f55Strings[16].c_str()));
  avgElE   = atof(_f55Strings[17].c_str());
  elEDisp  = atof(_f55Strings[18].c_str());
  coulEC   = atof(_f55Strings[19].c_str());
  surDC    = atof(_f55Strings[20].c_str());
  elecC    = atof(_f55Strings[21].c_str());
  if (myIsNan(elEDisp))
     elEDisp = 0.0;
}
F55Line&
F55Line::operator=(const F55Line& f55Line_) {
  trNumb   = f55Line_.trNumb;
  stNumb   = f55Line_.stNumb;
  center   = f55Line_.center; 
  basisX   = f55Line_.basisX;
  basisY   = f55Line_.basisY;
  elE      = f55Line_.elE;
  desE     = f55Line_.desE;
  time     = f55Line_.time;
  occur    = f55Line_.occur;
  avgElE   = f55Line_.avgElE;
  elEDisp  = f55Line_.elEDisp;
  hyDe     = f55Line_.hyDe;
  ljE      = f55Line_.ljE;
  coulEC   = f55Line_.coulEC;
  surDC    = f55Line_.surDC;
  elecC    = f55Line_.elecC;
  return *this;
}

// class SDAFort55 ---------------------------------------------------
// constructor
SDAFort55::SDAFort55(const SDAFort55& sdaF55_) {
  p1 = *sdaF55_.getProtein1();
  p2 = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
}
SDAFort55::SDAFort55(const vector<string>& lines_) {
  setFort55All(lines_);
}
SDAFort55::SDAFort55(const vector<string>& lines_,
                     const PdbFileS1& p1_,
                     const PdbFileS1& p2_) {
  setFort55All(lines_);
  setProtein1(p1_);
  setProtein2(p2_);
}
// operator
SDAFort55&
SDAFort55::operator=(const SDAFort55& sdaF55_) {
  p1        = *sdaF55_.getProtein1();
  p2        = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
  return *this;
}
// set
void
SDAFort55::setFort55All(const vector<string>& fort55Data_) {
  fort55All.clear();
  fort55All.reserve(fort55Data_.size());
  for (VStrCI vstrCI = fort55Data_.begin();
       vstrCI != fort55Data_.end(); ++vstrCI) {
    fort55All.push_back(F55Line(*vstrCI));
  }
}
void
SDAFort55::setProtein2(const PdbFileS1& protein2_){
  p2 = protein2_;
}
void
SDAFort55::setProtein1(const PdbFileS1& protein1_){
  p1 = protein1_;
}
// get
const PdbFileS1*
SDAFort55::getProtein1() const {
  return &p1;
}
const PdbFileS1*
SDAFort55::getProtein2() const {
  return &p2;
}
const vector<F55Line>*
SDAFort55::getFort55All() const {
  return &fort55All;
}
//
vector<int>
SDAFort55::getOccurancies() const {
// returns vector of occurancies form fort55 file 
  
  vector<int> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->occur);
  }

  return _res;    
}
vector<float>
SDAFort55::getElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elE);
  }
  return _res;
}
vector<float>
SDAFort55::getAvgElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->avgElE);
  }
  return _res;
}
vector<float>
SDAFort55::getElEDisp() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elEDisp);
  }
  return _res;
}
vector<float>
SDAFort55::getRmsds() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(p2.backbRmsd(recoverProtein(*vf55CI)));
  }
  return _res;
}

vector<float>
SDAFort55::getDesE() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->desE);
  }
  return _res;
}
vector<float>
SDAFort55::getHyDe() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->hyDe);
  }
  return _res;
}
vector<float>
SDAFort55::getLjE() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->ljE);
  }
  return _res;
}
vector<float>
SDAFort55::getCoulEC() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->coulEC);
  }
  return _res;
}
vector<float>
SDAFort55::getSurDC() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->surDC);
  }
  return _res;
}
vector<float>
SDAFort55::getElecC() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elecC);
  }
  return _res;
}

Uint
SDAFort55::getFort55LineNumber() const {
  return fort55All.size();
}

vector<float>
SDAFort55::makePairHalfMatrix(Uint complexNumber_) const {
  //test if there is some date to work on:-)
  assert(fort55All.size() > 1);
  //
  PdbFileS1 *_pA, *_pB, *_pNext;
  int _lines = getFort55LineNumber();
  // consider only specified number of complexes
  if (_lines > complexNumber_)
    _lines = complexNumber_;
  vector<float> _res;
  vector<PdbFileS1*> prot;
  prot.reserve(_lines);
  for (int i = 0; i < _lines; ++i) {
	  PdbFileS1* tmp = new PdbFileS1(recoverProtein(fort55All[i]));
	  prot.push_back(tmp);
  }
  _res.reserve((_lines * _lines - _lines) / 2);
  _pA = prot[0];//new PdbFileS1(recoverProtein(fort55All[0]));
  // for each first protein in pair while building halfMatrix
  for (int i = 1; i < _lines; ++i){
    _pNext = prot[i];//new PdbFileS1(recoverProtein(fort55All[i]));
    _res.push_back(_pA->backbRmsd(*_pNext));
    // for each second protien in pair 
    for (int j = i + 1; j < _lines; ++j){
        _pB = prot[j];//new PdbFileS1(recoverProtein(fort55All[j]));
        _res.push_back(_pA->backbRmsd(*_pB));
    }
    *_pA = *_pNext; // now first protein becomes next
  }
  for (int i = 1; i < _lines; ++i) {
	 delete prot[i];
  }
  return _res;
}

PdbFileS1
SDAFort55::recoverProtein(const F55Line& f55Line_) const {
  // makes docked protein conformation based on p1 and p2 centers
  // and fort55 line
  Vector3 _thisCenter(f55Line_.center);
  // basis vectors: x and y from fort55, z crossproducted x y
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  // transforming vectors
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  // now get new coordinates
  PdbFileS1 _res = p2;
  // here we take out reference to PdbFileS1 data, and we'll
  // work on this reference this way changing the object itself 
  vector<PdbLineS1>& _resPdbLines = _res.accessPdbLines();
  // for each PdbLineS1 object in reference to vector of them
  for (vector<PdbLineS1>::iterator iterPL = _resPdbLines.begin();
       iterPL != _resPdbLines.end();
       ++iterPL) {
    // this groovy line makes the transformation in fact  
    iterPL->accessCoord() = 
            trVector(iterPL->accessCoord() -= p2Center,
                     _trx, _try, _trz) + p1Center +
                     _thisCenter;
  }
  return _res;
}

// private:
Vector3
SDAFort55::trVector(Vector3& origin_,
                    Vector3& basisx_,
                    Vector3& basisy_,
                    Vector3& basisz_) const {
  basisx_.normalize();
  basisy_.normalize();
  basisz_.normalize();
  return Vector3(origin_ * basisx_,
                 origin_ * basisy_,
                 origin_ * basisz_);
}



// class SDAFort552 ---------------------------------------------------
// constructor
SDAFort552::SDAFort552(const SDAFort552& sdaF55_) {
  p1        = *sdaF55_.getProtein1();
  p2        = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
  p1Center  = *sdaF55_.getP1Center();
  p2Center  = *sdaF55_.getP2Center();
}

// operator
SDAFort552&
SDAFort552::operator=(const SDAFort552& sdaF55_) {
  p1        = *sdaF55_.getProtein1();
  p2        = *sdaF55_.getProtein2();
  fort55All = *sdaF55_.getFort55All();
  p1Center  = *sdaF55_.getP1Center();
  p2Center  = *sdaF55_.getP2Center();
  return *this;
}
// set
void
SDAFort552::setFort55All(const char* fileName_, int lineNumb_) {
  fort55All.clear(); fort55All.reserve(lineNumb_);
  vector<string> _lines; _lines.reserve(lineNumb_);
  getFort55Lines(fileName_, _lines, lineNumb_);
  for (vector<string>::const_iterator cit = _lines.begin();
       cit != _lines.end(); ++cit) {
    fort55All.push_back(F55Line(*cit));     
  }
  p1Center = getCenter1FromFort55(fileName_);
  p2Center = getCenter2FromFort55(fileName_);
}

void
SDAFort552::setFort55All(const vector<string>& fort55Data_) {
  fort55All.clear();
  fort55All.reserve(fort55Data_.size());
  for (VStrCI vstrCI = fort55Data_.begin();
       vstrCI != fort55Data_.end(); ++vstrCI) {
    fort55All.push_back(F55Line(*vstrCI));
  }
}
void
SDAFort552::setProtein2(const vector<Vector3>& protein2_){
  p2 = protein2_;
}
void
SDAFort552::setProtein1(const vector<Vector3>& protein1_){
  p1 = protein1_;
}
void
SDAFort552::setCenter1(const Vector3& c_) {
  p1Center = c_;
}
void 
SDAFort552::setCenter2(const Vector3& c_) {
  p2Center = c_;
}
// access
vector<Vector3>& 
SDAFort552::accessProtein1() {
  return p1;
}

vector<Vector3>&
SDAFort552::accessProtein2() {
  return p2;
}
// get
const vector<Vector3>*
SDAFort552::getProtein1() const {
  return &p1;
}
const vector<Vector3>*
SDAFort552::getProtein2() const {
  return &p2;
}
const vector<F55Line>*
SDAFort552::getFort55All() const {
  return &fort55All;
}
const Vector3*
SDAFort552::getP1Center() const {
  return &p1Center;
}
const Vector3* 
SDAFort552::getP2Center() const {
  return &p2Center;
}
//
vector<int>
SDAFort552::getOccurancies() const {
// returns vector of occurancies form fort55 file  
  vector<int> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->occur);
  }
  return _res;    
}
vector<float>
SDAFort552::getElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elE);
  }
  return _res;
}
vector<float>
SDAFort552::getAvgElEnergies() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->avgElE);
  }
  return _res;
}
vector<float>
SDAFort552::getElEDisp() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(vf55CI->elEDisp);
  }
  return _res;
}
/*
vector<float>
SDAFort552::getRmsds() const {
  vector<float> _res;
  assert(fort55All.size() > 0);
  _res.reserve(fort55All.size());
  for (VF55CI vf55CI = fort55All.begin();
              vf55CI !=fort55All.end();
              ++vf55CI) {
    _res.push_back(p2.backbRmsd(recoverProtein(*vf55CI)));
  }
  return _res;
}
*/

float
SDAFort552::getRmsd(const vector<Vector3>& pr_) const {
  return vector3Rmsd(p2, pr_);
}

Uint
SDAFort552::getFort55LineNumber() const {
  return fort55All.size();
}

vector<float>
SDAFort552::makePairHalfMatrix(Uint complexNumber_) const {
  //test if there is some data to work on:-)
  assert(fort55All.size() > 1);
  //
  int _lines = getFort55LineNumber();
  // consider only specified number of complexes
  if (_lines > complexNumber_)
    _lines = complexNumber_;
  vector<float> _res;
  _res.reserve((_lines * _lines - _lines) / 2);
  vector<Vector3> _pA; _pA.reserve(p2.size());
  recoverProtein(fort55All[0], _pA);
  // for each first protein in pair while building halfMatrix
  for (int i = 1; i < _lines; ++i){
    vector<Vector3> _pNext; _pNext.reserve(p2.size());
    recoverProtein(fort55All[i], _pNext);
    _res.push_back(vector3Rmsd(_pA, _pNext));
    // for each second protein in pair 
    for (int j = i + 1; j < _lines; ++j){
        vector<Vector3> _pB; _pB.reserve(p2.size());
        recoverProtein(fort55All[j], _pB);
        _res.push_back(vector3Rmsd(_pA, _pB));
        _pB.clear();
    }
    _pA = _pNext; // now first protein becomes next
    _pNext.clear();
  }
  _pA.clear();
  return _res;
}

void
SDAFort552::recoverProtein(const F55Line& f55Line_,
                          vector<Vector3>& pr_) const {
  // makes docked protein conformation based on p1 and p2 centers
  // and fort55 line
  Vector3 _thisCenter(f55Line_.center);
  // basis vectors: x and y from fort55, z crossproducted x y
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  // transforming vectors
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  // now get new coordinates
  pr_ = p2;
  // here we take out reference to PdbFileS1 data, and we'll
  // work on this reference this way changing the object itself 
  // for each PdbLineS1 object in reference to vector of them
  for (vector<Vector3>::iterator itV = pr_.begin();
       itV != pr_.end(); ++itV) {
    // this groovy line makes the transformation in fact    
    *itV = trVector(*itV -= p2Center,
                    _trx, _try, _trz) + p1Center + _thisCenter;
  }
}

void
SDAFort552::recoverProtein(const F55Line& f55Line_,
                          vector<Vector3*>& pr_) const {
  // makes docked protein conformation based on p1 and p2 centers
  // and fort55 line
  Vector3 _thisCenter(f55Line_.center);
  // basis vectors: x and y from fort55, z crossproducted x y
  Vector3 _bx(f55Line_.basisX);
  Vector3 _by(f55Line_.basisY);
  Vector3 _bz(crossProduct(_bx, _by));
  // transforming vectors
  Vector3 _o100(1.0f, 0.0f, 0.0f);
  Vector3 _o010(0.0f, 1.0f, 0.0f);
  Vector3 _o001(0.0f, 0.0f, 1.0f);
  Vector3 _trx = trVector(_o100, _bx, _by, _bz); 
  Vector3 _try = trVector(_o010, _bx, _by, _bz);
  Vector3 _trz = trVector(_o001, _bx, _by, _bz);
  
  // here we take out reference to PdbFileS1 data, and we'll
  // work on this reference this way changing the object itself 
  // for each PdbLineS1 object in reference to vector of them
  assert(p2.size() == pr_.size());
  vector<Vector3>::const_iterator citV;
  vector<Vector3*>::iterator itV;
  for (citV = p2.begin(), itV = pr_.begin(); 
       citV != p2.end(), itV != pr_.end();
        ++citV, ++itV) {
    // get new coord
    *(*itV) = *citV;
    // this groovy line makes the transformation in fact    
    *(*itV) = trVector(*(*itV) -= p2Center,
                    _trx, _try, _trz) + p1Center + _thisCenter;
  }
}

// private:
Vector3
SDAFort552::trVector(Vector3& origin_,
                    Vector3& basisx_,
                    Vector3& basisy_,
                    Vector3& basisz_) const {
  basisx_.normalize();
  basisy_.normalize();
  basisz_.normalize();
  return Vector3(origin_ * basisx_,
                 origin_ * basisy_,
                 origin_ * basisz_);
}




