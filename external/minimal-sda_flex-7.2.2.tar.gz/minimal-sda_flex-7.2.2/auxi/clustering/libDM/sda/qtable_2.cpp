/*! \file qtable.cpp

*/

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cassert>

#include "qtable_2.h"
#include "pdbfile_2.h"
#include "commonfoo.h"

using namespace std;

inline void splitLine(const string& str_,
                      vector<string>& pieces_,
                      const string& separators_) {
  // startPost first found "good" char of the token
  // endPost first found "bad" char at the end of token
  string::size_type startPos = str_.find_first_not_of(separators_, 0);
  string::size_type endPos   = str_.find_first_of(separators_, startPos);
  while(endPos != string::npos || startPos != string::npos){
    // token found
     pieces_.push_back(str_.substr(startPos, endPos - startPos));
     startPos = str_.find_first_not_of(separators_, endPos);
     endPos   = str_.find_first_of(separators_, startPos);
  }
} 

inline void stripString(string& s_in) {
  const string from = " ";
  const string to = "";
  size_t search_here = 0;
  size_t found_here;
  while ((found_here = s_in.find(from, search_here)) != string::npos) {
    s_in.replace(found_here, 1, to);
    search_here = found_here;
  }
}

inline void replaceChars(string& str_, char from, char to) {
  for (int i = 0; i < str_.length(); ++i) {
    if (str_[i] == from)
      str_[i] = to;
  }

}

namespace libDM_SDA {
const string QTable::EQUIVALENCE = "EQUIVALENCE";
const string QTable::OPLS = "OPLS";


QTable::QTable(const char* fileName_) {
  ifstream fin;
  fin.open(fileName_);
  if (!fin.is_open()) {
    cerr << "ERROR: can't open file: " << fileName_ << endl;
    exit(0);
  }

  string _line;
  vector<string> _splitLine;
  fin.seekg(0);
  getline(fin, _line);
  splitLine(_line, _splitLine);
  
  // read equivalence part
  while(_line != "" and !fin.eof()) {
    _splitLine.clear(); 
    getline(fin, _line);
    replaceChars(_line, '\t', ' ');
    splitLine(_line, _splitLine);
    resEq1.push_back(_splitLine[0]);
    atomEq1.push_back(_splitLine[1]);
    resEq2.push_back(_splitLine[2]);
    atomEq2.push_back(_splitLine[3]); 
  }
  getline(fin, _line); // OPLS in this line
  getline(fin, _line); // resi
  
  // read charges and radii
  while(!fin.eof()) {
    _splitLine.clear();
    getline(fin, _line);
    if (_line == "")
      break;
    
    replaceChars(_line, '\t', ' ');
    splitLine(_line, _splitLine);
   
    residues.push_back(_splitLine[0]);
    atoms.push_back(_splitLine[1]);
    charges.push_back(atof(_splitLine[2].c_str()));
    radii.push_back(atof(_splitLine[5].c_str()));
  }
  
  fin.close();

}

float
QTable::getRadii(const string& res_, const string& atom_) const {
    
  string _res = res_;
  string _atom= atom_;
  assert(residues.size() == atoms.size() and
         residues.size() == charges.size() and
         residues.size() == radii.size());
  int n = residues.size();
  for (int i = 0; i < n; ++i) {
    if (residues[i] == _res and atoms[i] == _atom) {
        return radii[i];
    } 
  }
  
  // not found get equivalent name
  bool goon = false;
  assert(resEq1.size() == resEq2.size() and
         resEq1.size() == atomEq1.size() and
         resEq1.size() == atomEq2.size());
  n = resEq1.size();
  for (int i = 0; i < n; ++i) {
    if (resEq1[i] == _res and atomEq1[i] == _atom) {
      _res = resEq2[i];
      _atom= atomEq2[i];
      goon = true;
      break;
    }
  }
  
  if (goon) {
    int n = residues.size();
    for (int i = 0; i < n; ++i) {
      if (residues[i] == _res and atoms[i] == _atom) {
        return radii[i];
      }
    }
  } else {
    cerr << "WARNING: radii for residue: " << _res << " and atom: " << _atom
         << " was not found!\n";
    return 0.0f;
  } 
}


using libDM_molecule::PdbFile;
using libDM_molecule::PdbLine;
void extractRadii(const PdbFile& pdbFile_,
                  const QTable& qTable_, vector<float>& radii) {
  const vector<PdbLine>* pLines = pdbFile_.getPdbLines();
  for (vector<PdbLine>::const_iterator cit = pLines->begin();
       cit != pLines->end(); ++cit) {
    radii.push_back(qTable_.getRadii(*cit->getResName(), *cit->getAtom()));
  }
}


} // namespace libDM_SDA
