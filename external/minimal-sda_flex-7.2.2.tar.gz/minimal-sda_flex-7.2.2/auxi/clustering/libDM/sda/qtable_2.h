/*! \file qtable.h wraps qtable file

*/

#ifndef QTABLE_2_H
#define QTABLE_2_H

#include <vector>
#include <string>
#include "pdbfile_2.h"

namespace libDM_SDA {

using std::vector;
using std::string;

using libDM_molecule::PdbFile;

class QTable {
  public:
    /*! construct object from qtable file */
    QTable(const char* fileName_);
    
    /*! finds and returns radii for residue 'res', atom 'atom' 
        in qtable file
    */
    float getRadii(const string& res, const string& atom) const;
  
  private:
    vector<string> residues;
    vector<string> atoms;
    vector<float>  charges;
    vector<float>  radii;
    
    vector<string> resEq1;
    vector<string> resEq2;
    vector<string> atomEq1;
    vector<string> atomEq2;
    
    static const string EQUIVALENCE;
    static const string OPLS;

};




/*! Extracts radii from qtable
    pdbFile_ -> PdbFile object with ready protein
    qTable_  -> QTable object with wrapt qtable file
    radii_   -> vector to load radii to
*/                   
void extractRadii(const PdbFile& pdbFile_,
                  const QTable& qTable_, vector<float>& radii_);
                  
} // namespace libDM_SDA                 
                  
#endif

     

