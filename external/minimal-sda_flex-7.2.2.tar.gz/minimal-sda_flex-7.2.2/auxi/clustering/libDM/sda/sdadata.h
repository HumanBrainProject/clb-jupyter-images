//-------------//
// sdadata.h   //
//-------------//
#ifndef SDADATA_H
#define SDADATA_H


#include "../molecule/protein.h"
#include "../3d/vector3.h"
using namespace std;

class SdaData{
		struct State {
			bool centerP1;
			bool centerP2;
			bool p1;
			bool p2;
			bool fort55All;
			bool fort55One;
			bool fort55Avg;
		};
	public:

		SdaData();
		void init();
	//---methods--->
		//set
		void setCenterP1(Vector3);
		Vector3 getCenterP1();
		void setCenterP2(Vector3);
		Vector3 getCenterP2();
		void setP1(const Protein*);
		void setP2(const Protein*);
		//get
		void getFort55DataAll(vector<vector<float> >);
		void getFort55DataOne(vector<float>);
		int  getFort55LineNumber();
		// make average
		void makeFort55Avg();
		// main
		float   getEnergyNum(int);
		Protein getDockedNum(int);
		Protein getDockedAvg();
	//---members--->
		vector<float> makePairMatrix(int linNum_ = 500);


	private:
	//---methods--->
		Protein recover(vector<float>&);
		bool isGood2GoState() const;
		Vector3 trVector(Vector3& original,
				 Vector3& basisX,
				 Vector3& basisY,
				 Vector3& baissZ);

	//---members--->
		State state;
		const Protein* p1;
		const Protein* p2;
		Vector3 p1Cen;
		Vector3 p2Cen;
		// basis unit vectors
		Vector3 o100, o010, o001;


		vector<vector<float> > fort55All;
		// INFO: vector<float> fort55One has 10 members:
		// 1-3 - center of this protein
		// 4-6 - basis x of this protein
		// 7-9 - basis y of this protein
		// 10  - energy from SDA
		vector<float> fort55One;
		vector<float> fort55Avg;
};

#endif


