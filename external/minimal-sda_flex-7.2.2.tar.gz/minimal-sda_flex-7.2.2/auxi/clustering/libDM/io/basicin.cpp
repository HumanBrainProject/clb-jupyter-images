//-----------------------------------------------------------------//
// basicin.cpp                                                     //
//                                                                 //
// class BasicIn                                                   //
// and abstract class holding some commen stuf for file input      //
//                                                                 //
// libDM V 0.3	2005.05.21                                         //
// D.M.                                                            //
//-----------------------------------------------------------------//
#include <iostream>
#include <cstdlib>

#include "../constdata/constdata.h"
#include "basicin.h"

using namespace std;

//===class===>
//---methods--->
// manage
void BasicIn::who() const{
	cout << "INFO: class BasicIn" << endl;
}
// main
void BasicIn::openFile(const char* fileName_){

	if (fin.is_open())
		this->clear();
	fin.open(fileName_);
	if (!fin.is_open()){
		cout << "Failed to open the file: " << fileName_ << endl;
		exit(1);
	}
	fileName = fileName_;
}
void BasicIn::openFile(const  string& fileName_){
	char* _fileName = const_cast<char*>(fileName_.c_str());
	openFile(_fileName);
	//fileName = fileName_;
}
vector<string> BasicIn::getLinesX(){
// returns all lines from file as vector of string
	vector<string> _vs;
	if (!fin.is_open()){
		cout << "ERROR: there is no file opened!" << endl;
		return _vs;
	}
	streampos _sp = 0;
	fin.seekg(_sp);
	string _str;
	while(!fin.eof()){
		getline(fin, _str);
		_vs.push_back(_str);
	}
	return _vs;
}
//---protected methods--->
bool BasicIn::isComment(string& str_){
	if (str_.substr(0, 1) == SHOLD2)
		return true;
	return false;
}
bool BasicIn::isCommentEmpty(string& str_){
	if (str_.substr(0, 1) == SHOLD2 ||
	    str_.length() == 0)
	    	return true;
	return false;
}
inline void BasicIn::eatLine(){
	while (fin.eof() != '\n' && (!fin.eof()))
		continue;
}

inline void BasicIn::splitLine(const string& str_,
		      vector<string>& pieces_,
		      const string& separators_){
// startPost first found "good" char of the token
// endPost first found "bad" char at the end of token
	string::size_type startPos = str_.find_first_not_of(separators_, 0);
	string::size_type endPos   = str_.find_first_of(separators_, startPos);
	while(endPos != string::npos || startPos != string::npos){
		// token found
		pieces_.push_back(str_.substr(startPos, endPos - startPos));
		startPos = str_.find_first_not_of(separators_, endPos);
		endPos   = str_.find_first_of(separators_, startPos);
	}
}
//---private methods--->
void BasicIn::clear(){
	fin.clear();
	fin.close();

	fileName = "";
}
//===class===/


