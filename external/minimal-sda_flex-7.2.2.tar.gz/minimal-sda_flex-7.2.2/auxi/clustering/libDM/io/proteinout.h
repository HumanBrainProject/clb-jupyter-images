//---------------//
// proteinout.h  //
//---------------//
#ifndef PROTEINOUT_H
#define PROTEINOUT_H

#include <string>
#include <vector>
#include "basicout.h"

using namespace std;
class Chain;
class Protein;
class Residue;
class Atom;

class ProteinOut: public BasicOut{
  public:
  //---methods--->
    ProteinOut() {}
    void writeProtein(const string& fileName_,
                      const Protein& prot_);
    void writeResidues(const string& fileName_,
                       const vector<Residue>& res_);
    void writeResidues(const string& fileName_,
                       const vector<const Residue*>& res_);
    //void outFProtein(const string&, Protein&);
    //void outFResidues(string&, vector<const Residue*>&);
  private:
    //---methods--->
    void writeLine(unsigned int index_, 
                   const Residue& res_, 
                   const Atom& atom_);
    void writeLine(unsigned int index_,
                   const Chain& chain_,
                   const Residue& res_,
                   const Atom& atom_);
    //---members--->
};


/*

*/
#endif


