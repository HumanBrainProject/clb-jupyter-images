//-------------//
// basicin.h   //
//-------------//
#ifndef BASICIN_H
#define BASICIN_H

#include <fstream>
#include <vector>
#include <string>
using namespace std;
class BasicIn{
	public:
	//---methods--->
		// manage
		virtual ~BasicIn(){};
		virtual void who() const;
		// main
		void openFile(const char*);
		void openFile(const string&);
		virtual vector<string> getLinesX() = 0;
	//---members--->
		string fileName;
	protected:
	//---methods--->
		bool isComment(string&);
		bool isCommentEmpty(string&);
		inline void eatLine();
		inline void splitLine(const string& str_, 
				      vector<string>& pieces_, 
				      const string& separators_ = " ");
	//---members--->
		ifstream fin;
	private:
	//---methods--->
		// manage
		void clear();
	//---members--->
};

#endif

