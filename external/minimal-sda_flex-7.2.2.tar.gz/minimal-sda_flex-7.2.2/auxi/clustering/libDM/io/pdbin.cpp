//-----------------------------------------------------------------//
// pdbin.cpp                                                       //
//                                                                 //
// class PdbIn                                                     //
// derived class for reading pdb files                             //
//                                                                 //
// libDM V 0.3 2005.05.21                                          //
// D.M.                                                            //
//-----------------------------------------------------------------//
#include <iostream>
#include "pdbin.h"
using namespace std;
//===class===>
//---static--->
const string PdbIn::ATOM = "ATOM";
//---methods--->
void PdbIn::who() const{
  cout << "INFO: class PdbIn" << endl;
}
vector<string> PdbIn::getLinesX(){
// maybe I need a simple blind and faster version without checking for 
// ATOM in some situations may be usefull don't you think?:_)
// reads ATOM lines and returns a string vector of those	
  vector<string> _vs;
  if (!fin.is_open()){
    cout << "ERROR: there is no pdb file opened! " << endl;
    return _vs;
  }                
  streampos _sp = 0;
  fin.seekg(_sp);
  string _str;
  while(!fin.eof()){
    getline(fin, _str);
    if (_str.substr(0, 4) != ATOM)
      continue;
    _vs.push_back(_str);
  }
  return _vs;
}



//===class===/

