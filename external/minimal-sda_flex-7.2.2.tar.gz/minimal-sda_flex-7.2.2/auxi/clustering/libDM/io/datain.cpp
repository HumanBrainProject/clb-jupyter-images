 //-------------------------------------------------------
// datain.cpp
//
// This class reads and stores various data from files.
//-------------------------------------------------------
#include <cstdlib>
#include <iostream>

#include "../constdata/constdata.h"
#include "datain.h"
#include "vector3.h"
#include <string.h>

using namespace std;

//---inlines--->
inline char from321(const string& aa){
	for (int i = 0; i < AAARRAY; ++i){
		if (AAA[i] == aa)
			return A[i];
	}
}


//===class===>
//---methods--->
// manage
void DataIn::who() const{
	cout << "INFO: class DataIn" << endl;
}

vector<string> DataIn::getLinesX(){
//
  vector<string> _vs;
  if (!fin.is_open()){
    cout << "ERROR: there is no file opened!" << endl;
    return _vs; 
  }
  streampos _sp = 0;
  fin.seekg(_sp);
  string _str;
  while(!fin.eof()){
    getline(fin, _str);
    if (isCommentEmpty(_str))
      continue;
    _vs.push_back(_str);
  }
  return _vs;
}
// getting column data
void DataIn::getFloatColumn(const string& fileName_,
 			    vector<float>& data_,
			    const int column_){
	openFile(fileName_);
	vector<string> _splitLine;
	vector<string>::const_iterator citerVS;
	string _str;
	int _n = 0;
	while (!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		citerVS = _splitLine.begin();
		citerVS += (column_ - 1);
		data_.push_back( atof(citerVS->c_str()) );
		_splitLine.clear();
		++_n;
	}
}

void DataIn::getStrings(const string& fileName_,
			vector<string>& vs_,
			const int column_){
//
	openFile(fileName_);
	vector<string> _splitLine;
	string _str;
	while (!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		vs_.push_back(_splitLine[column_ - 1]);
		_splitLine.clear();   
	}
}

void DataIn::getAAChar(const string& fileName_, 
                       char res_[],
		       const int column_){
//
	openFile(fileName_);
	vector<string> _splitLine;
	vector<string>::const_iterator citerVS;
	string _str;
	int _n = 0;
	while (!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		citerVS = _splitLine.begin();
		citerVS += (column_ -1);
		res_[_n] = *citerVS->c_str();
		_splitLine.clear();
		++_n;
	}    
}

void DataIn::getAAFloat(const string& fileName_,
                        float res_[],
		        const int column_){
//
	openFile(fileName_);
	vector<string> _splitLine;
	vector<string>::const_iterator citerVS;
	string _str;
	int _n = 0;
	while (!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		citerVS = _splitLine.begin();
		citerVS += (column_ - 1);
		res_[_n] = atof(citerVS->c_str());
		_splitLine.clear();
		++_n;
	}
}

void DataIn::getAA2dMatrix(const string& fileName_, float res_[][AAARRAY]){
// reads 2d 20x20 matrix from file
// nice algo to use sstream
	openFile(fileName_);
	string _str;
	int _n = 0, _u;
	vector<string> _splitLine;
	while(!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		for (int i = 1; i <= AAARRAY; ++i){
			_u = i - 1;
			res_[_n][_u] = atof(_splitLine[i].c_str());
		}
	
		_splitLine.clear();
		++_n;
	}
}

//---
map<char, float> DataIn::getAAFloat(const string& fileName_){
//
	openFile(fileName_);
	vector<string> _splitLine;
	vector<string>::const_iterator citerVS;
	string _str;
	map<char, float> _res;
	while (!fin.eof()){

		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		citerVS = _splitLine.begin();
		_res[from321(*citerVS)] = atof((++citerVS)->c_str());
		_splitLine.clear();
	}
	return _res;
}


void DataIn::getAAFloat(const string& fileName_, map<char, float>* map_){
	openFile(fileName_);
	vector<string> _splitLine;
	vector<string>::const_iterator citerVS;
	string _str;

	while (!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		splitLine(_str, _splitLine);
		citerVS = _splitLine.begin();
		(*map_)[from321(*citerVS)] = atof((++citerVS)->c_str());
		_splitLine.clear();
	}
}

void
DataIn::getAAAFloat(const string& fileName_,
                    map<string, float>& data_) {
  openFile(fileName_);
  vector<string> _splitLine;
  vector<string>::const_iterator citS;
  string _str;
  while (!fin.eof()){
    getline(fin, _str);
    if (isCommentEmpty(_str))
      continue;
    splitLine(_str, _splitLine);
    citS = _splitLine.begin();
    data_[*citS] = atof((++citS)->c_str());
    _splitLine.clear();
  }                   
}

vector<string>
DataIn::getFort55All(int lineNumb_) {
  //openFile(fileName_);
  string _str;
  vector<string> _res;
  vector<string> _splitLine;
  _res.reserve(lineNumb_);
  
  // iterate through file
  int _num = 0;
  while(!fin.eof()) {
    getline(fin, _str);
    // skip if line is a commnet or empty
    if (isCommentEmpty(_str))
      continue;
    _splitLine.clear();
    splitLine(_str, _splitLine);
    // break if it contains 0.000 'os fort55 specific:-)
    if (_splitLine[2] == "0.000" &&
        _splitLine[5] == "0.000" &&
        _splitLine[8] == "0.000")
      break;

    _res.push_back(_str);
    ++_num;  
    // if already collected lineNumb_ number of lines, then break
    if (_num >= lineNumb_)
      break;
  }
  return _res;
}

// michael add reading of two new lines of comments
Vector3
DataIn::getFort55Center1(const string& file_) {
  ifstream fin(file_.c_str());
  string _str;

  getline(fin, _str); _str.clear(); getline(fin, _str); _str.clear();

  getline(fin, _str);
  fin.close();
  
  //cout << atof(_str.substr(1, 8).c_str()) << endl;
  //cout << atof(_str.substr(9, 8).c_str()) << endl;;
  //cout << atof(_str.substr(17,8).c_str()) << endl;;
  cout << "getCenter1" << atof(_str.substr(1, 8).c_str()) << " " << atof(_str.substr(9, 8).c_str()) << " " << atof(_str.substr(17,8).c_str()) << endl;
  
  return Vector3(atof(_str.substr(1, 8).c_str()),
                 atof(_str.substr(9, 8).c_str()),
                 atof(_str.substr(17,8).c_str()));
}

Vector3
DataIn::getFort55Center2(const string& file_) {
  ifstream fin(file_.c_str());
  string _str;

  getline(fin, _str); _str.clear(); getline(fin, _str); _str.clear();
  getline(fin, _str); _str.clear();
  getline(fin, _str);
  fin.close();
  
  //cout << atof(_str.substr(1, 8).c_str()) << endl;
  //cout << atof(_str.substr(9, 8).c_str()) << endl;
  //cout << atof(_str.substr(17,8).c_str()) << endl;
  
  cout << "getCenter2" << atof(_str.substr(1, 8).c_str()) << " " << atof(_str.substr(9, 8).c_str()) << " " << atof(_str.substr(17,8).c_str()) << endl;

  return Vector3(atof(_str.substr(1, 8).c_str()),
                 atof(_str.substr(9, 8).c_str()),
                 atof(_str.substr(17,8).c_str()));
}
  
void
DataIn::getFort55All(const string& fileName_,
                     vector<string>& data_,
                     int lineNumb_) {
  openFile(fileName_);
  string _str;
  vector<string> _splitLine;
  data_.reserve(lineNumb_);
  
  // iterate through file
  int _num = 0;
  while(!fin.eof()) {
    getline(fin, _str);
    // skip if line is a commnet or empty
    if (isCommentEmpty(_str))
      continue;
    _splitLine.clear();
    splitLine(_str, _splitLine);
    //in case the second column is not the trajectory length, there is an error in columns
    if ( _splitLine[1].find('.') != _splitLine[1].npos ) {

        string error_message = "\ncontains wrong number of columns! \n May be some numbers (in the first column) " +
                                _splitLine[0] + "are too big for their column width?\n" +
                                "Try to insert spaces manually or run read_record complexes -format_cluster -large_traj_nb ";
        //cout << "\nERROR: file "<<fileName_<<" contains wrong number of columns!\nMay be some numbers (in the first column "<<_splitLine[0]<<")\n are to big for their column width?\n\nPlease insert spaces manually or run sda with ???? enabled" << endl;
        cout << error_message << endl;
        exit(-1);
    }
    // break if it contains 0.000 'os fort55 specific:-)
    if (_splitLine[2] == "0.000" &&
        _splitLine[5] == "0.000" &&
        _splitLine[8] == "0.000")
      break;

    data_.push_back(_str);
    ++_num;  
    // if already collected lineNumb_ number of lines, then break
    if (_num >= lineNumb_)
      break;
  }
}

vector<float> DataIn::getFort55One(const string& fileName_,
                                   const int num_){
	openFile(fileName_);
	string _str;
	int _num = 1;
	vector<float> _res;
	vector<string> _splitLine;
	_res.reserve(10);
	_splitLine.reserve(10);
	while(!fin.eof()){
		getline(fin, _str);
		if (isCommentEmpty(_str))
			continue;
		if (_num != num_){
			++_num;
			continue;
		}
		splitLine(_str, _splitLine);
		// skip line if all zeros
		if (_splitLine[2] == "0.000" &&
		    _splitLine[5] == "0.000" &&
		    _splitLine[8] == "0.000"){
		    	continue;
		}
		for (int i = 0; i < 10; ++i){
			_res.push_back(atof(_splitLine[i+2].c_str()));
		}
		return _res;
	}
	cerr << "WARNING: line not found?" << endl;
	return _res;
}
	
inline void BasicIn::splitLine(const string& str_,
		      vector<string>& pieces_,
		      const string& separators_){
// startPost first found "good" char of the token
// endPost first found "bad" char at the end of token
	string::size_type startPos = str_.find_first_not_of(separators_, 0);
	string::size_type endPos   = str_.find_first_of(separators_, startPos);
	while(endPos != string::npos || startPos != string::npos){
		// token found
		pieces_.push_back(str_.substr(startPos, endPos - startPos));
		startPos = str_.find_first_not_of(separators_, endPos);
		endPos   = str_.find_first_of(separators_, startPos);
	}
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
