//--------------//
// fullpdbout.h //
//--------------//
#ifndef FULLPDBOUT_H
#define FULLPDBOUT_H

#include <string>
#include <vector>
#include <fstream>
#include "basicout.h"
using namespace std;
class FullPdb;
class PdbLine;

class FullPdbOut: public BasicOut{
	public:
		virtual void who() const;
		//---methods--->
		void outFFullPdb(const string&, FullPdb&);
	private:
		//---methods--->
		void writePdbLine(int, const PdbLine&);
		//---members--->
};


#endif


