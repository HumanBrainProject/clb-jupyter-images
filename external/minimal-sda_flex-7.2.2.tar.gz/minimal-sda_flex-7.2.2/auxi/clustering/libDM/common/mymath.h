/*! \file mymath.h
    \brief More common mathematical functions here

*/

#ifndef MYMATH_H
#define MYMATH_H

#include <iostream>
#include <vector>
#include <cmath> 
#include <cassert>

using namespace std;

namespace libDM_math{

//_____________Statistics_____________________________________________
/*! Gets average of data vector */
template<typename T>
float average(const vector<T>* data_){
// returns average of data vector
  assert(data_->size() != 0);
  typename vector<T>::const_iterator citerT;
  long double _res = 0.0f;
  for (citerT = data_->begin();
     citerT !=data_->end();
     ++citerT){
    _res += *citerT;
  }
  long double _1overN = ((long double)1.0f) / data_->size();
  return _res * _1overN;
}

/* Gets variability of data vector */
template<typename T>
long double variability(const vector<T>* data_){
  assert(data_->size() != 0);
  if (data_->size() == 1) 
    return (long double) 0.0;
  typename vector<T>::const_iterator citerT;
  long double _avg = average(data_);
  long double _res = 0.0f;
  for (citerT = data_->begin();
       citerT !=data_->end();
       ++citerT){
    _res += (*citerT - _avg) * (*citerT - _avg);
  }
  long double _1overN = ((long double) 1.0f) / ((long double)data_->size() - 1);
  return _res * _1overN;
}

/*! Gets standard deviation of data vector */
template<typename T>
long double stdDeviation(const vector<T>* data_){
  return sqrt(variability(data_));
}

//___________________MinMax__________________________________________
/*! Gets Max value from array */
template<typename T>
T getMax(T* data_, long long size_) {
  assert(size_ > 0);
  T maxT = data_[0];
  for (long long i = 0; i < size_; ++i) {
    if (data_[i] > maxT)
      maxT = data_[i];  
  }
  return maxT;
}

template<typename T>
T getMin(T* data_, long long size_) {
  assert(size_ > 0);
  T minT = data_[0];
  for (long long i = 0; i < size_; ++i) {
    if (data_[i] < minT)
      minT = data_[i];
  }
  return minT;
}



} // namespace libDM_math


#endif

