#!/usr/bin/python

import os, sys


class IOOut:
  def getOutput(self, command):
    self.child = os.popen(command)
    self.data = self.child.read()
    self.err = self.child.close()
    return self.data


up1  = "../"
up2  = "../../"
sep  = "/"

dirs = [
  "3d", 
  "common",  
  "sda", 
  "io", 
  "molecule", 
  "invest/acc",
  "invest/clusterh",
  "invest/rescontact"]
#  "md",
#  "other/datamatrix",
#  "other/gridmap",
#  "other/fortran"]


makeType = input("Input:\n  1  -> for compilation with debuging\n"+ \
                         "  2  -> for clean compilation\n"+ \
                         "  3  -> only remove *.o files\n")
if (makeType != 1 and makeType != 2 and makeType != 3):
  print "wrong selection"
  sys.exit(1)

print "Removing object files:\n"
for i in dirs:
  io = IOOut()
  io.getOutput("rm "+up2+i+sep+"*.o")
  print '  ->  '+up2+i+sep
  if makeType == 1:
    os.system("make --file=Makefile -C "+up2+i+sep)
  elif makeType == 2:
    os.system("make --file=Makefile_clean -C "+up2+i+sep)
  elif makeType == 3:
    print "Just deleted *.o files"
  
  
  
  
  
  
  
