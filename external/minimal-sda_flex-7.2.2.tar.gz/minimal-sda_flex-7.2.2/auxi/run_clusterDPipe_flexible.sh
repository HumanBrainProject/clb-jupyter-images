

#CLUST_DPIPE_EXE=../../../../bin/cluster
#CLUST_DPIPE_EXE=/exports/scratch/workgroup/sdac/trunk/auxi/clustering/programs/sda/clust/go

CLUST_DPIPE_EXE=/exports/scratch/workgroup/TestFortran90_v4_tparrallel/auxi/clustering/programs/clust/go

SDA_EXE=/exports/scratch/workgroup/TestFortran90_v4_tparrallel


P1_root=../../../../../Data/Mode1/pqrnoh_mode-7-
P2=../../../../../Data/RanGTPase-com-C/pqrnoh_RanGTPase-com-C.pdb

N=1000
N2=10

##test variable
N2modif=$N2

cp ../complexes .
${SDA_EXE}/bin/read_record complexes -split 15

for i in `seq 15`
do

 NBCOMPLEXE=`wc -l complex${i} | gawk '{print $1}'`
 ((NBCOMPLEXE=NBCOMPLEXE-4))
 echo "complex${i} $NBCOMPLEXE complexes"

 if [[ $NBCOMPLEXE -le 0 ]] ; then
     echo "complex${i} is empty"
     rm complex${i}

## limitation of cluster program, could print all the minimum, not working
# elif [[ $NBCOMPLEXE -le 10 ]]; then
#     echo "complex${i} is less than 10, print all data"
#     /scratch/mcm/martinml/SDA_flex/sda_flex/bin/trajectory2dcd complexe

 else

   ((NOSHIFT=$i-8))
   P1=${P1_root}${NOSHIFT}.pdb
   echo $P1

   mkdir Complexe$i
   mv complex$i Complexe$i

   cd Complexe$i

   ## make format cluster
   ${SDA_EXE}/bin/read_record complex$i -format_cluster
   COMPLEXES=complex${i}.comp_cluster
  
   N=$NBCOMPLEXE

## try to limit but not working
#  if [[ $N -lt $N2 ]] ; then 
#        echo "restrict N2 to $N"
#	N2modif=$N-1
#  else
#	N2modif=$N2-1
#  fi

##
  if [[ $NBCOMPLEXE -le 10 ]]; then
     echo "complex${i} is less than 10, print all data"
     ${SDA_FLEX}/bin/trajectory2dcd complex$i Min.pdb -pdb2 $P2 -min_complexe $NBCOMPLEXE

  ## else normal clustering
  else

   $CLUST_DPIPE_EXE  -cl -n $N -f55 $COMPLEXES -p1 $P1 -p2 $P2 >> out_complexe$i
   $CLUST_DPIPE_EXE  -sc -f55 $COMPLEXES -p1 $P1 -p2 $P2  >> out_complexe$i
   $CLUST_DPIPE_EXE  -an -p -clcl ${N2modif} -f55 $COMPLEXES -p1 $P1 -p2 $P2  >> out_complexe$i
   $CLUST_DPIPE_EXE  -re -clcl ${N2modif} -f55 $COMPLEXES -p1 $P1 -p2 $P2  >> out_complexe$i

  fi

   cd ..

 fi

done


