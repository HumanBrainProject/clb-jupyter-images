sed 's/ H / HN/g' p2.pdb > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HG / HG1/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HG / HG2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HD / HD2/g' p2-tmp.pdb > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb
sed 's/3HD / HD2/g' p2-tmp.pdb > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb
sed 's/3HG / HG2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HB / HB1/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HB / HB2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HB / HB2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HA / HA1/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HA / HA2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HA / HA2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HE / HE1/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HE / HE2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HE / HE2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HZ / HZ1/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HZ / HZ2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HZ / HZ2/g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb
sed 's/1HB1 /HB11 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HB1 /HB12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HB1 /HB13 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HG1 /HG11 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HG1 /HG12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HG1 /HG12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HD1 /HD11 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HD1 /HD12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HD1 /HD12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HG2 /HG21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HG2 /HG22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HG2 /HG22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 

sed 's/1HH /HH1 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HH /HH2 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HH /HH2 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HB2 /HB21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HB2 /HB22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HB2 /HB22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HG2 /HG21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HG2 /HG22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HG2 /HG22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/1HD2 /HD21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HD2 /HD22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HD2 /HD22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 

sed 's/1HH2 /HH21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HH2 /HH22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HH2 /HH22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 

sed 's/1HE2 /HE21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HE2 /HE22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HE2 /HE22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 

sed 's/1HH2 /HH21 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HH2 /HH22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HH2 /HH22 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 

sed 's/1HH1 /HH11 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/2HH1 /HH12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 
sed 's/3HH1 /HH12 /g' p2-tmp.pdb  > p2-new.pdb
cp p2-new.pdb p2-tmp.pdb 

